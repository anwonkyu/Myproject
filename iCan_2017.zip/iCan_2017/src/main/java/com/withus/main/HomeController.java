package com.withus.main;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.boardinfo.dao.BoardInfoVO;
import com.withus.boardinfo.service.BoardInfoService;
import com.withus.boardlist.dao.BoardListVO;
import com.withus.boardlist.service.BoardListService;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.service.CalnoteService;
import com.withus.category.dao.CategoryVO;
import com.withus.category.service.CategoryService;
import com.withus.commons.TextUtil;
import com.withus.commons.XmlResult;
import com.withus.commons.seed.SEEDUtil;
import com.withus.commons.seed.WithusSeed;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileVo;
import com.withus.logo.dao.LogoVO;
import com.withus.logo.service.LogoService;
import com.withus.member.dao.MemberVo;
import com.withus.member.service.MemberService;
import com.withus.popup.dao.PopupmanVO;
import com.withus.popup.service.PopupmanService;
 
import com.withus.processing.dao.ProcessingVO;
import com.withus.processing.service.ProcessingService;
import com.withus.vodLog.dao.VodLogVO;
import com.withus.vodLog.service.VodLogService;
 
/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
    private VodLogService vodLogService;
	
	@Autowired 
	private CalnoteService calnoteService;
	
	@Autowired 
	private ProcessingService processingService;
	
	@Resource
	private PopupmanService popupService;
	
 
	@Resource
	private BoardListService boardListService;
	
	@Resource
	private BoardInfoService boardInfoService; 
	

	@Resource
	private MemberService memberService;
	
	@Resource
	private CategoryService categoryService;
	
	@Resource(name = "logoService")
	private LogoService logoService;
	
 
	@Resource
    private UploadFileService uploadFileService;
	
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;
	
	// util:properties 로 생성된 빈은 java.util.Properties 의 인스턴스이기 때문에
    // 요렇게 Autowired 해서 쓸 수 있다.
    @Autowired Properties prop;
	
    @RequestMapping(value = "/main/main.do", method = RequestMethod.GET)
    public String home( Model model, @RequestParam(value="user", defaultValue="", required=true) String user, HttpServletRequest req) throws Exception  {
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
    	String userId = "";
		int userlevel = 0;
		if(principal != null && principal instanceof MemberVo){  
			userId = ((MemberVo)principal).getUsername() ; // 로그인 사용자 ID set			 
			userlevel = ((MemberVo)principal).getLevels() ; //내부 3/ 외부 회원 1  구분 		 
		} 

    	// P=팝업창, M= 메인팝업존
	   	 ArrayList<PopupmanVO> popupListP  = popupService.selectPopupmanList_today("P");
	   	// ArrayList<PopupmanVO> popupListM  = popupService.selectPopupmanList_today("M");  
	   	 
	   	 
    	 LogoVO logo = logoService.selectLogo();
    	 int board_limit = 6;
    	 if (logo.getBoardLimit() != null) {
    		 board_limit = logo.getBoardLimit();  
    	 }
    	 
    	 int video_limit = 6;  
    	 if (logo.getNewVideoLimit() != null) {
    		 video_limit = logo.getNewVideoLimit();  
    	 } 
    	 
    	 //공지사항 
    	 ArrayList<BoardListVO> noticeList  = boardListService.selectNotice_limit(prop.getProperty("BOARD_NOTCIE_ID"), board_limit);

    	 //자료실
    	 //ArrayList<BoardListVO> dataList  = boardListService.selectNotice_limit(prop.getProperty("BOARD_DATA_ID"), board_limit);
    	 
 
    	 //Pending Document
    	 ArrayList<CalnoteVO> pendList  = calnoteService.userPanding(video_limit, 0);
      
    	 //Processed Document
    	 ArrayList<CalnoteVO> procList  = calnoteService.userProcessed(video_limit, 0); 
    	 
    	 ArrayList<ProcessingVO> processingList  = processingService.userProcessing(video_limit, 0); 
 
  		 
  		model.addAttribute("pendList",pendList);  
  		model.addAttribute("procList",procList);  
  		model.addAttribute("popupListP",popupListP);  
    	model.addAttribute("processingList",processingList); 
     	// model.addAttribute("popupListM",popupListM); 
  		 model.addAttribute("noticeList",noticeList);  
  		// model.addAttribute("dataList",dataList);  
  		 
     	return "/main/main";
   } 
    
 

    
    @RequestMapping(value = "/myWorks.do", method = RequestMethod.GET)
    public String myWorks( Model model,  HttpServletRequest req) throws Exception  {
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
 
 
		 LogoVO logo = logoService.selectLogo();
	 
	   	 int video_limit = 6;  
	   	 if (logo.getNewVideoLimit() != null) {
	   		 video_limit = logo.getNewVideoLimit();  
	   	 } 
	   	 
    	 //Pending Document
    	 ArrayList<CalnoteVO> cal_pendList  = calnoteService.userCalnoteListPanding(video_limit, 0);
    	 
    	 ArrayList<CalnoteVO> tr_pendList  = calnoteService.userTrListPanding(video_limit, 0);
      
    	 //Processed Document
    	 //ArrayList<CalnoteVO> procList  = calnoteService.userCalnoteListProcessed(video_limit, 0); 
 
  		 
  		model.addAttribute("cal_pendList",cal_pendList);  
  		model.addAttribute("tr_pendList",tr_pendList);  
 
 		
    	return "/myWork/myWorks";
   } 
    
    
    
    
    @RequestMapping(value = "/topMenu.do", method = {RequestMethod.GET, RequestMethod.POST})
    public String topMenu( Model model ,  @RequestParam(value="menu_type", defaultValue="", required=true) String menu_type, 
    		@RequestParam(value="returnValue", defaultValue="", required=true) String returnValue
    		 
    		) throws Exception  {

       List<CategoryVO> cateList1 = null;
  	   if ( categoryService.selectCategoryList_Menu("A") != null) {
  		   cateList1 = categoryService.selectCategoryList_Menu("A");
  	   } 
  	   List<CategoryVO> cateList2 = null;
  	   if ( categoryService.selectCategoryList_Menu("B") != null) {
  		   cateList2 = categoryService.selectCategoryList_Menu( "B");
  	   }
  	   List<CategoryVO> cateList3 = null;
  	   if ( categoryService.selectCategoryList_Menu("C") != null) {
  		   cateList3 = categoryService.selectCategoryList_Menu( "C");
  	   }
  	   
 
  	  // System.out.println("menu_code:"+menu_code);
  	   
  	   HashMap<String, Object> hashMap = new HashMap<String, Object>();
  
  	   hashMap.put("cateList1", cateList1);
  	   hashMap.put("cateList2", cateList2);
  	   hashMap.put("cateList3", cateList3);
  	  
  	 
  	   
  	   if (menu_type != null && menu_type.equals("header")) {  // 헤드 에서만 사이트 정보 불러옴
  		   model.addAttribute("SITE_INFO", logoService.selectLogo());
 
  		vodLogService.webLogInsert(); //웹로그
 	
  		vodLogService.contactStatInsert(); // 페이징 접속 카운트 W- 웹, M - 모바일
 
  	   }
  	 Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
  	Object principal = auth.getPrincipal();
  	String id = ((MemberVo)principal).getUsername(); 
  	MemberVo thisMember = memberService.memberInfo(id);
  	   
  	   
  	   
  	   
  	model.addAttribute("thisMember", thisMember);  
       model.addAttribute("menuList", hashMap);  
       return returnValue;
    //	return "/include/topMenu";
   } 
    
 
    @RequestMapping(value = "/boardList.do",  method = {RequestMethod.GET, RequestMethod.POST})
    public String boardList( Model model, @RequestParam(value="returnValue", defaultValue="", required=true) String returnValue) throws Exception  {
  
    	 ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
         model.addAttribute("leftList", boardInfoList); 
 
  	 return returnValue;
       //return "/include/siteInfo";
   } 
    
    
    
    @RequestMapping(value = "/siteInfo.do",  method = {RequestMethod.GET, RequestMethod.POST})
    public String siteInfo( Model model, @RequestParam(value="returnValue", defaultValue="", required=true) String returnValue) throws Exception  {

 	 model.addAttribute("SITE_INFO", logoService.selectLogo());

		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		String userId = ""; //아이디
		String userName = "";
		if(principal != null && principal instanceof MemberVo){  
			userId = ((MemberVo)principal).getUsername() ; // 로그인 사용자 ID set
			userName = WithusSeed.returnSeedDeStr(((MemberVo)principal).getName());
			memberService.insert_visit(userId, userName);
		}
		int today = memberService.today_visit();
		int total = memberService.total_visit();
		
		model.addAttribute("today", today);
		model.addAttribute("total", total);
  	 return returnValue;
       //return "/include/siteInfo";
   } 
    
   
    
    @RequestMapping(value="/sitemap.do",  method ={RequestMethod.GET, RequestMethod.POST})
	public String siteMap(Model model) throws Exception{
    	
    	 List<CategoryVO> cateList1 = null;
    	   if ( categoryService.selectCategoryList_Menu("A") != null) {
    		   cateList1 = categoryService.selectCategoryList_Menu("A");
    	   } 
    	   List<CategoryVO> cateList2 = null;
    	   if ( categoryService.selectCategoryList_Menu("B") != null) {
    		   cateList2 = categoryService.selectCategoryList_Menu( "B");
    	   }
    	   List<CategoryVO> cateList3 = null;
    	   if ( categoryService.selectCategoryList_Menu("C") != null) {
    		   cateList3 = categoryService.selectCategoryList_Menu( "C");
    	   }
    	  
    	   
    	   HashMap<String, Object> hashMap = new HashMap<String, Object>(); 
   
    	   hashMap.put("cateList1", cateList1);
    	   hashMap.put("cateList2", cateList2);
    	   hashMap.put("cateList3", cateList3);
    	   model.addAttribute("menuList", hashMap);  
		return "/info/sitemap";		
	}
     
    
	@RequestMapping(value="/login.do",  method ={RequestMethod.GET, RequestMethod.POST})
	public String login(){
		return "/member/login";		
	}
	
	@RequestMapping(value="/error.do",  method ={RequestMethod.GET, RequestMethod.POST})
	public String error(){
		return "/error/error";		
	}
	
	@RequestMapping(value="/error2.do",  method ={RequestMethod.GET, RequestMethod.POST})
	public String error2(){
		return "/error/error2";		
	}
	
	@RequestMapping(value="/error3.do",  method ={RequestMethod.GET, RequestMethod.POST})
	public String error3(){
		return "/error/error3";		
	}
	@RequestMapping(value="/error4.do",  method ={RequestMethod.GET, RequestMethod.POST})
	public String error4(){
		return "/error/error4";		
	}
 
//    @Secured("ROLE_VODMAN")
//    @RequestMapping(value = "/admin", method = RequestMethod.GET)
//    public String admin() {
//         return "admin";
//    }
//
//    @Secured("ROLE_USER")
//    @RequestMapping(value = "/admin/test", method = RequestMethod.GET)
//    public String admin_test() {
//         return "admin";
//    }
//    
//    @Secured({"ROLE_USER","ROLE_VODMAN"})
//    @RequestMapping(value = "/user", method = RequestMethod.GET)
//    public String user(Principal principal) {
//
//         // 첫번째 방법
//         Authentication auth = SecurityContextHolder.getContext().getAuthentication();
//         logger.info(auth.toString());
//
//         // 두번째 방법
//         User user = (User)SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//         logger.info(user.toString());
//
//         // 세번째 방법
//         logger.info(principal.toString());
//
//         return "home";
//    }
	
 
    
    
    @RequestMapping(value="/downloadFile.do",method=RequestMethod.POST)
    public void downloadFile(Integer seq
            , HttpServletResponse response) throws Exception {
		UploadFileVo uplaodFileVo = new UploadFileVo();
		uplaodFileVo = uploadFileService.getUploadFile(seq);

		boolean fileCheck = false;
		// 0. 로그인 체크
		int userLevel = 0;
		// 1. 파일 공개구분, 삭제 구분
		// 2. 접근 가능 레벨 확인
		// 3. 비밀글 확인(게시판)
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			 userLevel =(((MemberVo)principal).getLevels());
		}
		
		String file_path = uplaodFileVo.getSaveDir().trim() ;
		
		//설계자료 D, 운전자료 O, 자료분석 A, 도우미발간대장 H,공지사항/자료실/개선의견 N, Support S, Support_re R
		if (uplaodFileVo.getFlag().equals("R")) { 
			fileCheck = true;
		} else if (uplaodFileVo.getFlag().equals("B")) {
			fileCheck = boardListService.fileCheck(uplaodFileVo.getOcode() ,userLevel );	 
		} else {
			fileCheck = true; 
		}
 
		
		if (fileCheck ) {  // 파일 다운로그 권한 확인
	        String orgname = uplaodFileVo.getOrgName();
	        String newname = uplaodFileVo.getFileName();
	 
	        // MIME Type 을 application/octet-stream 타입으로 변경
	        // 무조건 팝업(다운로드창)이 뜨게 된다.
	        response.setContentType("application/octet-stream");
	       
	        // 브라우저는 ISO-8859-1을 인식하기 때문에
	        // UTF-8 -> ISO-8859-1로 디코딩, 인코딩 한다.
	       // System.out.println("orgname:"+orgname);
	        orgname = URLEncoder.encode(orgname, "UTF-8");
	        //orgname = new String(orgname.getBytes("UTF-8"), "iso-8859-1");
	        // 파일명 지정
	        response.setHeader("Content-Disposition", "attachment; filename=\""+orgname+"\"");
	       
	        OutputStream os = response.getOutputStream();
	        // String path = servletContext.getRealPath("/resources");
	        // d:/upload 폴더를 생성한다.
	        // server에 clean을 하면 resources 경로의 것이 다 지워지기 때문에
	        // 다른 경로로 잡는다(실제 서버에서는 위의 방식으로)
	       
	        //FileInputStream fis = new FileInputStream(WebContants.BASE_PATH + File.separator + newname);
	        FileInputStream fis = null;
	        try {
		        fis = new FileInputStream(file_path + File.separator + newname);
		        int n = 0;
		        byte[] b = new byte[512];
		        while((n = fis.read(b)) != -1 ) {
		            os.write(b, 0, n);
		        }
//		        fis.close();
//		        os.close();
	        } catch (Exception e) {
	        	logger.info(e.toString()); 
	        	
	        } finally{
	        	close(fis);
	        	close(os); 
	        }
		}
    } 
	 

    
    @Secured({"ROLE_MANAGER","ROLE_VODMAN"})
    @RequestMapping(value="/VodmanDownloadFile.do",method=RequestMethod.POST)
    public void VodmanDownloadFile(Integer seq
            , HttpServletResponse response) throws Exception {
		UploadFileVo uplaodFileVo = new UploadFileVo();
		uplaodFileVo = uploadFileService.getUploadFile(seq);
		
		boolean fileCheck = false;
		// 0. 로그인 체크
		int userLevel = 0;
		// 1. 파일 공개구분, 삭제 구분
		// 2. 접근 가능 레벨 확인
		// 3. 비밀글 확인(게시판)
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			 userLevel =(((MemberVo)principal).getLevels());
		}
		     
		String file_path = uplaodFileVo.getSaveDir().trim() ;
		
		//설계자료 D, 운전자료 O, 자료분석 A, 도우미발간대장 H,공지사항/자료실/개선의견 N, Support S, Support_re R
 
		 
		//관리자 로그인
		fileCheck = true;
		
		if (fileCheck ) {  // 파일 다운로그 권한 확인
	        String orgname = uplaodFileVo.getOrgName();
	        String newname = uplaodFileVo.getFileName();
	 
	        // MIME Type 을 application/octet-stream 타입으로 변경
	        // 무조건 팝업(다운로드창)이 뜨게 된다.
	        response.setContentType("application/octet-stream");
	       
	        // 브라우저는 ISO-8859-1을 인식하기 때문에
	        // UTF-8 -> ISO-8859-1로 디코딩, 인코딩 한다.
	        //orgname = new String(orgname.getBytes("UTF-8"), "iso-8859-1");
	        orgname = URLEncoder.encode(orgname, "UTF-8");
	       
	        // 파일명 지정
	        response.setHeader("Content-Disposition", "attachment; filename=\""+orgname+"\"");
	       
	        OutputStream os = response.getOutputStream();
	        // String path = servletContext.getRealPath("/resources");
	        // d:/upload 폴더를 생성한다.
	        // server에 clean을 하면 resources 경로의 것이 다 지워지기 때문에
	        // 다른 경로로 잡는다(실제 서버에서는 위의 방식으로)
	       
	        //FileInputStream fis = new FileInputStream(WebContants.BASE_PATH + File.separator + newname);
	        FileInputStream fis = null;
	        try {
		        fis = new FileInputStream(file_path + File.separator + newname);
		        int n = 0;
		        byte[] b = new byte[512];
		        while((n = fis.read(b)) != -1 ) {
		            os.write(b, 0, n);
		        }
//		        fis.close();
//		        os.close();
	        } catch (Exception e) {
	        	logger.info(e.toString()); 
	        	
	        } finally{
	        	close(fis);
	        	close(os); 
	        }
		}
    } 
	 
    protected static void close(Closeable closable) { 
   		if (closable != null) { 
    			try { 
    				closable.close(); 
    			} catch (IOException ignore) { 
    				 //System.out.println("IGNORE: " + ignore); 
    				 logger.info(ignore.toString()); 
    		} 
    	} 
    } 

    
	@RequestMapping(value="/deleteFile.do", method=RequestMethod.POST)
    public View deleteFile(  @RequestParam(value="seq") Integer seq , Model model)
            throws Exception { 
        
        XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class); 
     
        XmlResult xml = new XmlResult(); 
		
        if (seq != null && seq > 0) {
			int value =uploadFileService.deleteFile(seq);
			if (value > 0) {
			    xml.setMessage("삭제되었습니다.");
		        xml.setError(false);
			} else {
				 xml.setMessage("파일삭제에 실패하였습니다.");
	             xml.setError(true);
			}
		} else {
			 xml.setMessage("정보가 올바르지 않습니다.");
             xml.setError(true);
		} 
        
        model.addAttribute("xmlData", xml);
        return xmlView; 
    }
	
		@RequestMapping(value="/uploadfileCheck.do", method={RequestMethod.POST,RequestMethod.GET})
		public View fileCheck(@RequestParam(value="filename" )String filename,
				@RequestParam(value="flag")String flag, Model model){
//	System.out.println(filename);		
		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class); 
    	XmlResult xml = new XmlResult();
			
  			int index = filename.lastIndexOf(".");
  			if(index > 0){
  				String fileName = filename.substring(0, index);
  				String fileExtension = filename.substring(index + 1); 

  				if (com.withus.commons.TextUtil.getEnableExtension(fileExtension, flag)){
  					   xml.setMessage("업로드 가능");
	  			       xml.setError(true);
  				} else {
  					xml.setMessage("선택하신 파일은 업로드 될 수 없습니다");
	  			    xml.setError(false);
  				}
  				
  			} else {
  				xml.setMessage("선택하신 파일은 업로드 될 수 없습니다");
  			    xml.setError(false);
  			} 
		        model.addAttribute("xmlData", xml);
		        return xmlView; 
		} 

	
	 
	
		// 멀티 파일 업로드
		@RequestMapping(value = "/upload/editor_upload.do", method = RequestMethod.POST)
		@ResponseBody
		public String multiplePhotoUpload(HttpServletRequest request) {
			// 파일정보
			StringBuffer sb = new StringBuffer();
			try {
			// 파일명을 받는다 - 일반 원본파일명
			String oldName = request.getHeader("file-name");
			// 파일 기본경로 _ 상세경로
			//String filePath = "D:/workspace/Spring/src/main/webapp/resources/photoUpload/";
			String filePath = prop.getProperty("EDITOR_PATH").trim();
			String saveName = sb.append(new SimpleDateFormat("yyyyMMddHHmmss")
			                    .format(System.currentTimeMillis()))
			                    .append(UUID.randomUUID().toString())
			                    .append(oldName.substring(oldName.lastIndexOf("."))).toString();
			InputStream is = request.getInputStream();
			OutputStream os = new FileOutputStream(filePath + saveName);
			int numRead;
			byte b[] = new byte[Integer.parseInt(request.getHeader("file-size"))];
			while ((numRead = is.read(b, 0, b.length)) != -1) {
			  os.write(b, 0, numRead);
			}
			os.flush();
			os.close();
			// 정보 출력
			sb = new StringBuffer();
			sb.append("&bNewLine=true")
			  .append("&sFileName=").append(oldName)
			  //.append("&sFileURL=").append("http://localhost:8090/Spring/resources/photoUpload/")
			  .append("&sFileURL=").append(prop.getProperty("EDITOR_SERVICE").trim())			  
			  .append(saveName);
			} catch (Exception e) {
			e.printStackTrace();
			}
			return sb.toString();
		}
		
		// 싱글 파일 업로드
		@RequestMapping(value = "/upload/editor_upload2.do", method = RequestMethod.POST)
		public String multiplePhotoUpload2(MultipartHttpServletRequest mpRequest) {
			// 파일정보
			StringBuffer sb = new StringBuffer();
			try {
			String oldName = "";
			String saveName = "";
				Iterator<String> it = mpRequest.getFileNames();
				 
    			while (it.hasNext()) {
       					MultipartFile multiFile = mpRequest.getFile((String) it.next()); 

       						if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename()) 
       							 ) { // 파일 체크 
       							//String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename());  // 확장자 없이 파일 등록
       							oldName = multiFile.getOriginalFilename();  // 확장자 포함
       							
       							String filePath = prop.getProperty("EDITOR_PATH").trim();
       							saveName = sb.append(new SimpleDateFormat("yyyyMMddHHmmss")
       							                    .format(System.currentTimeMillis()))
       							                    .append(UUID.randomUUID().toString())
       							                    .append(oldName.substring(oldName.lastIndexOf("."))).toString();
       							
       							
       							multiFile.transferTo(new File(filePath+File.separator  + saveName)); 
	       					  
       						} else if( multiFile.getSize() == 0)  {
       						} else {
       							break; 
       						} 
       					 
       			}
			 
			// 정보 출력
			sb = new StringBuffer();
			sb.append("?sFileName=").append(oldName)
			  //.append("&sFileURL=").append("http://localhost:8090/Spring/resources/photoUpload/")
			  .append("&sFileURL=").append(prop.getProperty("EDITOR_SERVICE").trim())			  
			  .append(saveName);
			} catch (Exception e) {
			e.printStackTrace();
			}
//			System.out.println("multiplePhotoUpload2:::"+sb.toString());
			//return sb.toString();
			//return "/editor/sample/photo_uploader/callback.html"+sb.toString();
			//return "redirect:/editor/sample/photo_uploader/callback.html"+sb.toString();
			return "forward:/editor/sample/photo_uploader/callback2.jsp"+sb.toString();
			
		}
	
 
		
		 /*
	     * ms-word 파일을 직접 생성 
	     */
	    @RequestMapping(value="/get_doc.do", method={RequestMethod.POST,RequestMethod.GET})
	    public void getImage(  HttpServletResponse response ) throws Exception{ 
	    
	    	  SimpleDateFormat fileFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
	          String file_name = new StringBuilder("Support").append("_").append(fileFormat.format(new Date())).append(".docx").toString();
	            	 
			     BufferedOutputStream out=null;
			     InputStream in=null;
			     try {
			      response.setContentType("application/msword");
			      response.setHeader("Content-Disposition", "inline;filename="+file_name);
			      //File file=new File(filePath);
			
			       // in=new FileInputStream(file);
			        out=new BufferedOutputStream(response.getOutputStream());
			        int len;
			        byte[] buf=new byte[1024];
			        while ( (len=in.read(buf)) > 0) {
			        out.write(buf,0,len);
			        }
			  
			     }catch(Exception e){
			      e.printStackTrace();
			      System.out.println("파일 전송 에러");
			     } finally {
			      if ( out != null ) try { out.close(); }catch(Exception e){}
			      if ( in != null ) try { in.close(); }catch(Exception e){}
			     }
		     
	    }
	    
}

 