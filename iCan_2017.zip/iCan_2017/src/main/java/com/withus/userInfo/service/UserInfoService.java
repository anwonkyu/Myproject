package com.withus.userInfo.service;

import com.withus.userInfo.dao.UserInfoVo;

public interface UserInfoService {
	void insertUserInfo(UserInfoVo userInfoVo)throws Exception;
	
	int updateUserInfo(UserInfoVo userInfoVo)throws Exception;
	
	public UserInfoVo getUserInfo(String id)throws Exception;

	public UserInfoVo deleteUserInfo(String id)throws Exception;
}
