package com.withus.department.service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.withus.department.dao.DepartmentMapper;
import com.withus.department.dao.DepartmentVO;
@Service("departmentService")
public class DepartmentServiceImpl implements DepartmentService{
	private static final Logger LOGGER = LoggerFactory.getLogger(DepartmentServiceImpl.class);
	
	@Resource(name="departmentMapper")
	private DepartmentMapper departmentMapper;
	
	@Override
	public void insertDepartment(DepartmentVO departmentVo) throws Exception {
		departmentMapper.insertDepartment(departmentVo);
	}

	@Override
	public ArrayList<DepartmentVO> selectDepartmentList(String searchWord, int start, int end) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		Integer startRownum = start;
		Integer endRownum = end;
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("searchWord", searchWord);
		return departmentMapper.selectDepartmentList(hashmap);
	}

	@Override
	public int selectDepartmentListTotCnt(String searchWord) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
	   	 
		hashmap.put("searchWord", searchWord);
		return departmentMapper.selectDepartmentListTotCnt(hashmap);
	}

	@Override
	public int deleteDepartment(String deptCd) throws Exception {
		return departmentMapper.deleteDepartment(deptCd);
	}

	@Override
	public int updateDepartment(DepartmentVO departmentVo) throws Exception {
		return departmentMapper.updateDepartment(departmentVo);
	}

	@Override
	public DepartmentVO getDepartment(String deptCd) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("deptCd", deptCd);
		return departmentMapper.getDepartment(hashmap);
	}

}
