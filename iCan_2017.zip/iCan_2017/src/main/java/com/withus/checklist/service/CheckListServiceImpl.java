package com.withus.checklist.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.withus.checklist.dao.CheckListMapper;
import com.withus.commons.TextUtil;

@Service("checkListService")
public class CheckListServiceImpl implements CheckListService{

	@Resource(name = "checkListMapper")
	private CheckListMapper checkListMapper;
	
	/*
	 * 수정
	 */
	@Transactional(propagation = Propagation.REQUIRED)
	public int check_list_update(Map parameter) throws Exception {
		int obj = 0;
		int item_size = 0;
		String size = TextUtil.getMapValue( (Map) parameter, "item_size", "0");
	 
		if (size != null && size.length() > 0) {
			item_size = Integer.parseInt(size.trim());
			
			//parameter  배열로 넘어옴
			for (int i = 1; i <= item_size; i++) {
				String seq = TextUtil.getMapValue((Map) parameter, "seq" + i, ""); 
				String no = TextUtil.getMapValue((Map) parameter, "no" + i, ""); 
 
				String description = TextUtil.getMapValue((Map) parameter, "description" + i, "");  
 
					// 정보 담기
					Map itemMap = new HashMap();
					itemMap.put("check_type", (String) ((Map) parameter).get("type"));  
					
					itemMap.put("seq", seq);  
					itemMap.put("no", no);
					itemMap.put("description", description);
	
				 
					obj = checkListMapper.check_list_update(itemMap);
		 
			} // end for i

		}
		return obj;
	}

 
	@Override
	public ArrayList<?> selectCheckList(String type,String user) throws Exception {
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		hashmap.put("check_type", type);
		hashmap.put("user", user);
		return checkListMapper.checklist_item(hashmap);
	}
}
