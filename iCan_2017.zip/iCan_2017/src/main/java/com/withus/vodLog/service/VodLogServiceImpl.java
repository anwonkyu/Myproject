package com.withus.vodLog.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 




import com.withus.vodLog.service.VodLogService;
 
import com.withus.vodLog.dao.CounterVO;
import com.withus.vodLog.dao.VodLogMapper;
import com.withus.vodLog.dao.VodLogVO;
 
/**
 * @Class Name : VodLogServiceImpl.java
 * @Description : VodLog Business Implement class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 20150303
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service 
public class VodLogServiceImpl implements
        VodLogService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(VodLogServiceImpl.class);
 
    @Resource(name="vodLogMapper")
    private VodLogMapper vodLogMapper;

	@Override
	public ArrayList<VodLogVO> selectVodLogList(VodLogVO vo, int start, int end)
			throws Exception { 
		vo.setStart(start);
		vo.setEnd(end);
		return vodLogMapper.selectVodLogList(vo);
	}

	@Override
	public int selectVodLogListTotCnt(VodLogVO vo) {
		 
		return vodLogMapper.selectVodLogListTotCnt(vo);
	}

	@Override
	public ArrayList<VodLogVO> selectVodLogListLive(VodLogVO vo, int start,
			int end) throws Exception {
		vo.setStart(start);
		vo.setEnd(end);
		return vodLogMapper.selectVodLogListLive(vo);
	}

	@Override
	public int selectVodLogListTotCntLive(VodLogVO vo) {
		return vodLogMapper.selectVodLogListTotCntLive(vo);
	}

	@Override
	public ArrayList<CounterVO> selectCounterList(Integer Year, Integer Month,
			Integer Day, String flag, String type) throws Exception {  
		if(flag == null) flag="WV";
    	if(type == null) type="V";
 
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("Year", Year.toString());
		hashmap.put("Month", Month.toString());
		hashmap.put("Day", Day.toString());
		hashmap.put("Flag", flag);
		hashmap.put("Type", type);
		
		return vodLogMapper.selectCounterList(hashmap);
	}
	
	@Override
	public ArrayList<CounterVO> selectCounterListMonth(Integer Year, Integer Month,
			 String flag, String type) throws Exception {  
		if(flag == null) flag="WV";
    	if(type == null) type="V";
 
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("Year", Year.toString());
		hashmap.put("Month", Month.toString());
 
		hashmap.put("Flag", flag);
		hashmap.put("Type", type);
		
		return vodLogMapper.selectCounterListMonth(hashmap);
	}
	@Override
	public ArrayList<CounterVO> selectCounterListYear(Integer Year, String flag, String type) throws Exception {  
		if(flag == null) flag="WV";
    	if(type == null) type="V";
 
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("Year", Year.toString());
		 
		hashmap.put("Flag", flag);
		hashmap.put("Type", type);
		
		return vodLogMapper.selectCounterListYear(hashmap);
	}

	@Override
	public ArrayList<CounterVO> selectCounterListLive(Integer Year,
			Integer Month, Integer Day, String flag )
			throws Exception {
		
		
    	if(flag == null) flag="WL";
 
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("Year", Year.toString());
		hashmap.put("Month", Month.toString());
		hashmap.put("Day", Day.toString());
		hashmap.put("Flag", flag);
 
		return vodLogMapper.selectCounterListLive(hashmap);
	}
	@Override
	public ArrayList<CounterVO> selectCounterListMonthLive(Integer Year, Integer Month,
			 String flag ) throws Exception {  
		if(flag == null) flag="WV";
 
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("Year", Year.toString());
		hashmap.put("Month", Month.toString());
 
		hashmap.put("Flag", flag);
 		
		return vodLogMapper.selectCounterListMonthLive(hashmap);
	}
	@Override
	public ArrayList<CounterVO> selectCounterListYearLive(Integer Year, String flag ) throws Exception {  
		if(flag == null) flag="WV";
 
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("Year", Year.toString());
		 
		hashmap.put("Flag", flag);
 
		return vodLogMapper.selectCounterListYearLive(hashmap);
	}
	
	
	@Override
	public ArrayList<CounterVO> selectCounterListMenu(String type)
			throws Exception {
		if(type == null) type="V";
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
	 
		hashmap.put("Type", type);
 
		return vodLogMapper.selectCounterListMenu(hashmap);
	}

	@Override
	public ArrayList<VodLogVO> connectCount(String Flag) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		 
		hashmap.put("Flag", Flag);
		return vodLogMapper.connectCount(hashmap);
	}
	
	
	public ArrayList<VodLogVO>  connectCountWeek(int iDate, String Flag) throws Exception {
		
		Calendar today = Calendar.getInstance();    
	 
		today.add(Calendar.DATE,iDate+1);
		
		int check_year = today.get(Calendar.YEAR);
		int check_month = (today.get(Calendar.MONTH));
		int check_day = today.get(Calendar.DATE);
		
		ArrayList<Object> mArrayList;
		 mArrayList = new ArrayList<Object>();
		 
		//System.out.println("aa:"+ today.get(Calendar.YEAR)+"-"+(today.get(Calendar.MONTH)+1)+"-"+(today.get(Calendar.DATE)) );
		for(int i=0; i<7; i++)
		{
			today.set(check_year, check_month, check_day);
			today.add(Calendar.DATE,i);
			//System.out.println(i+""+ today.get(Calendar.YEAR)+"-"+(today.get(Calendar.MONTH)+1)+"-"+(today.get(Calendar.DATE)) );
			
			String temp_month = ""+(today.get(Calendar.MONTH)+1);
			if ( (today.get(Calendar.MONTH)+1 ) < 10) {
				temp_month = "0"+ (today.get(Calendar.MONTH)+1);
			}
			String temp_day = ""+(today.get(Calendar.DATE));
			if ( today.get(Calendar.DATE) < 10) {
				temp_day = "0"+(today.get(Calendar.DATE));
			}
			
			mArrayList.add(today.get(Calendar.YEAR)+temp_month+temp_day); 
			
		}
		
		HashMap<String, Object> hashmap = new HashMap<String, Object>();
		 
		hashmap.put("list", mArrayList); 
		hashmap.put("Flag", Flag); 
		
		return vodLogMapper.connectCountWeek(hashmap);
	}

	@Override
	public ArrayList<VodLogVO> connectCountMonth(Integer idx, String flag)
			throws Exception { 
		
		Calendar calendar = Calendar.getInstance();
		calendar.add(calendar.MONTH,+(idx));
		//System.out.println("idx:"+idx);
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
		String beforeYear = dateFormat.format(calendar.getTime()).substring(0,4); 
		String beforeMonth = dateFormat.format(calendar.getTime()).substring(4,6); 
		//System.out.println(beforeYear+beforeMonth);
 
		int lastDay = calendar.getActualMaximum(Calendar.DATE); // 해당월 마지막일 
		//System.out.println(lastDay);
		
		ArrayList<Object> mArrayList;
		 mArrayList = new ArrayList<Object>();
		 
		//System.out.println("aa:"+ today.get(Calendar.YEAR)+"-"+(today.get(Calendar.MONTH)+1)+"-"+(today.get(Calendar.DATE)) );
		for(int i=1; i<=lastDay; i++)
		{
 
			String temp_day = ""+(i);
			if ( i < 10) {
				temp_day = "0"+(i);
			}
			
			mArrayList.add(beforeYear+beforeMonth+temp_day); 
			
		}
		
		HashMap<String, Object> hashmap = new HashMap<String, Object>();
		 
		hashmap.put("list", mArrayList); 
		hashmap.put("Flag", flag); 
		
		return vodLogMapper.connectCountMonth(hashmap);
	}

	@Override
	public ArrayList<VodLogVO> connectCountYear(String idx, String flag)
			throws Exception {
		
		ArrayList<Object> mArrayList;
		 mArrayList = new ArrayList<Object>();
		 
		//System.out.println("aa:"+ today.get(Calendar.YEAR)+"-"+(today.get(Calendar.MONTH)+1)+"-"+(today.get(Calendar.DATE)) );
		for(int i=1; i<=12; i++)
		{ 
			String temp_month = ""+(i);
			if ( i < 10) {
				temp_month = "0"+(i);
			}
			mArrayList.add(idx+temp_month); 
			
		}
		
		HashMap<String, Object> hashmap = new HashMap<String, Object>();
		 
		hashmap.put("list", mArrayList); 
		hashmap.put("Flag", flag); 
		
		return vodLogMapper.connectCountYear(hashmap);
	}

	@Override
	public ArrayList<VodLogVO> selectVodLogListAll(VodLogVO vo)
			throws Exception {
		return vodLogMapper.selectVodLogListAll(vo);
	}

	@Override
	public ArrayList<VodLogVO> selectVodLogListLiveAll(VodLogVO vo)
			throws Exception {
		return vodLogMapper.selectVodLogListLiveAll(vo);
	}
	
	
	@Override
	public void contactStatInsert() throws Exception {

		String flag = "W";
		if (com.withus.commons.HeadCheck.user_agent() != null && com.withus.commons.HeadCheck.user_agent().equals("etc")) {
			flag = "W";
		} else {
			if (com.withus.commons.HeadCheck.user_agent() != null && 
				(	    com.withus.commons.HeadCheck.user_agent().equals("iphone") ||
						com.withus.commons.HeadCheck.user_agent().equals("ipod") ||
						com.withus.commons.HeadCheck.user_agent().equals("ipad") ||
						com.withus.commons.HeadCheck.user_agent().equals("android") ||
						com.withus.commons.HeadCheck.user_agent().equals("windows phone")  
				 )) {
				flag = "M";
			} else {
				flag = "W";
			} 
		}
		
	    HashMap<String, String> hashmap = new HashMap<String, String>();

		hashmap.put("flag", flag);   
 
		vodLogMapper.contactStatInsert(hashmap);
		
	}
	
	
	public void webLogInsert() throws Exception {
		HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest(); 

				
		String a = req.getRemoteAddr();
		String b = req.getHeader("referer");
		String c = req.getRequestURI();
		String d = req.getQueryString();
		String e = req.getHeader("user-agent");
		String f = ((HttpSession)req.getSession(true)).getId();
		String g = req.getMethod();
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("logIp", a);
		hashmap.put("logReferer", b);
		hashmap.put("logUri", c);
		hashmap.put("logAuery", d);
		hashmap.put("logAgent", e);
		hashmap.put("logSessionID", f);
		hashmap.put("logMethod", g);
		
		//	 values(#{logIp} ,now(),#{logReferer},#{logUri},#{logAuery},#{logAgent},#{logSessionID},DAYOFWEEK(NOW()),#{logMethod}) 
 
		vodLogMapper.webLogInsert(hashmap);
	}
	
	@Override
	public void pageCnnCnt() {
		String flag = "W";
		if (com.withus.commons.HeadCheck.user_agent() != null && com.withus.commons.HeadCheck.user_agent().equals("etc")) {
			flag = "W";
		} else {
			if (com.withus.commons.HeadCheck.user_agent() != null && 
				(	    com.withus.commons.HeadCheck.user_agent().equals("iphone") ||
						com.withus.commons.HeadCheck.user_agent().equals("ipod") ||
						com.withus.commons.HeadCheck.user_agent().equals("ipad") ||
						com.withus.commons.HeadCheck.user_agent().equals("android") ||
						com.withus.commons.HeadCheck.user_agent().equals("windows phone")  
				 )) {
				flag = "M";
			} else {
				flag = "W";
			} 
		}
		
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("flag", flag);
 
		vodLogMapper.pageCnnCnt(hashmap);
	}
 
}
