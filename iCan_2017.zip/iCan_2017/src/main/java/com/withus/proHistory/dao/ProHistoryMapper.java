package com.withus.proHistory.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository("proHistoryMapper")
public interface ProHistoryMapper {
public int insertProHistory(ProHistoryVO vo)throws Exception;
	
	public ArrayList<ProHistoryVO> selectProHistoryList(HashMap<String, String> hashmap) throws Exception;
	
	public int selectProHistoryListTotCnt(HashMap<String, String> hashmap);
}
