package com.withus.aop.service;

public interface AopService {

	public void pageCnnCnt(String flag) ;
}
