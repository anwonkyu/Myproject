package com.withus.memo;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.View;

import com.ext.jfile.JProperties;
import com.itextpdf.text.log.SysoCounter;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.thoughtworks.xstream.XStream;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.service.CalnoteService;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
 
import com.withus.memo.service.ContentMemoService;
 
import com.withus.memo.dao.ContentMemoVO;

/**
 * @Class Name : ContentMemoController.java
 * @Description : ContentMemo Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/comment")
public class ContentMemoController {
	
    @Autowired Properties prop;

    @Resource(name = "contentMemoService")
    private ContentMemoService contentMemoService;
     
    @Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;
    @Resource
	private PagingHelperService page;
	  
	@Autowired 
	private CalnoteService calnoteService;  
	
    /**
	 * content_memo 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 ContentMemoDefaultVO
	 * @return "/contentMemo/ContentMemoList"
	 * @exception Exception
	 */
    
    @RequestMapping(value="/list.do")
    public String selectContentMemoList(String calnoteId,  Integer curPage,String searchFild,  String searchWord, Model model, String state, boolean completed_check)
            throws Exception {
    	if (calnoteId == null) calnoteId="";
     
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
 
//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		int totalRecord = contentMemoService.selectContentMemoListTotCnt(
				calnoteId,  searchFild,  searchWord, state );
		
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		
        ArrayList<ContentMemoVO> contentMemoList = contentMemoService.selectContentMemoList(
        		 calnoteId,  searchFild,  searchWord , state,  start,  end);
        model.addAttribute("resultList", contentMemoList);
        
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("state", state);
		model.addAttribute("completed_check", completed_check);
        
        return "/memo/list";
    } 
    
//    @RequestMapping(value="/feedback_list.do")
//    public String selectContentMemoListFeedback(String calnoteId,  Integer curPage,String searchFild,  String searchWord, Model model, String state, boolean completed_check)
//            throws Exception {
//    
//    	if (calnoteId == null) calnoteId="";
//     
//    	if (curPage == null) curPage = 1;
//		if (searchWord == null) searchWord = "";
//		if (searchFild == null) searchFild = "";
// 
////		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
////		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
//		
//		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_20").trim());
//		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
//		
//		int totalRecord = contentMemoService.selectContentMemoListTotCnt(
//				calnoteId,  searchFild,  searchWord, state );
//		
//		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
// 	
//		page.setPagingHelper(pagingHelper);
//		int start = pagingHelper.getStartRecord();
//		int end = pagingHelper.getEndRecord();
//		
//		Integer prevLink = page.getPrevLink();
//		Integer nextLink = page.getNextLink();
//		Integer firstPage = page.getFirstPage();
//		Integer lastPage = page.getLastPage();
//		int[] pageLinks = page.getPageLinks();  
//		
//        ArrayList<ContentMemoVO> contentMemoList = contentMemoService.selectContentMemoList(
//        		 calnoteId,  searchFild,  searchWord , state,  start,  end);
//        model.addAttribute("resultList", contentMemoList);
//        
//        model.addAttribute("totalRecord", totalRecord);
//        model.addAttribute("prevLink", prevLink);
//		model.addAttribute("nextLink", nextLink);
//		model.addAttribute("firstPage", firstPage);
//		model.addAttribute("lastPage", lastPage);
//		model.addAttribute("pageLinks", pageLinks);
//		model.addAttribute("curPage", curPage); 
//		 model.addAttribute("state", state);
//		 model.addAttribute("completed_check", completed_check);
//        
//        return "/memo/feedback_list";
//    } 
    
    
    @RequestMapping(value="/write.do", method=RequestMethod.GET)
    public String addContentMemoView( Model model)
            throws Exception { 
        return "/memo/writeForm";
    }
    
    @RequestMapping(value="/write.do", method=RequestMethod.POST)
     public View addContentMemo(
    		@ModelAttribute("contentMemoVO") ContentMemoVO contentMemoVO , Model model,boolean system)
            throws Exception { 
    	//System.out.println(contentMemoVO.toString());
	    	XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult();

		        if (contentMemoService.insertContentMemo(contentMemoVO) > 0) {
		        	Map<String, Object> map = new HashMap<String, Object>();
		        	ArrayList<ContentMemoVO> contentFeedbackList = contentMemoService.selectContentMemoList(
		        			contentMemoVO.getCalnoteId(), "", "", "feedback", 100, 0);
		        	CalnoteVO calnoteVo = calnoteService.getCalnote(contentMemoVO.getCalnoteId());
		        	map.put("calnoteVo", calnoteVo);
		        	map.put("calnoteId", contentMemoVO.getCalnoteId());
		        	map.put("contentFeedbackList", contentFeedbackList);
		        	
		          /*  calnoteService.updateCalnote(calnoteVo);*/
		        	com.withus.pdf.calNote.CalnoteFeedbackController.buildPdfDocument2(map);
		        	/*String savePath = JProperties.getString("system.calnoteFeedback");
		        	com.itextpdf.text.pdf.PdfReader realPageReader = new com.itextpdf.text.pdf.PdfReader(savePath+"/"+calnoteVo.getCalnoteId()+".pdf");
			        int realTotalPage = realPageReader.getNumberOfPages();
			        int realTotalPageNum = 0;
			        for(int i = 1; i<= realTotalPage; i++) {
			            realTotalPageNum = i;
			        }
			        calnoteVo.setRealTotalPage(realTotalPageNum);*/
		              
		        	xml.setMessage("등록 되었습니다.");
			        xml.setError(false);
		        } else {
		        	 xml.setMessage("등록에 실패하였습니다.");
		 	         xml.setError(true);
		        } 
    	    model.addAttribute("xmlData", xml);
	        return xmlView;
    }
    
    @RequestMapping(value="/reply.do", method=RequestMethod.POST)
    public View replyContentMemo(
    		@ModelAttribute("contentMemoVO") ContentMemoVO contentMemoVO , Model model)
            throws Exception { 
    	
    	//System.out.println(contentMemoVO.toString());
	    	XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult();
   
	            ContentMemoVO MemoVO = contentMemoService.selectContentMemo(contentMemoVO.getMuid());
	        
	        	contentMemoVO.setParentMuid(MemoVO.getMuid());
	        	contentMemoVO.setStep(MemoVO.getStep()+1);
      
		        if (contentMemoService.replyContentMemo(contentMemoVO) > 0) {
			        xml.setMessage("등록 되었습니다.");
			        xml.setError(false);
		        } else {
		        	 xml.setMessage("등록에 실패하였습니다.");
		 	         xml.setError(true);
		        } 
    	    model.addAttribute("xmlData", xml);
	        return xmlView;
    }
    
    
    @RequestMapping(value="/update.do", method=RequestMethod.GET)
    public String updateContentMemoView(
            @RequestParam(value="muid" ,required=true) int muid ,
            int curPage , String serchFild, String serchWrod , Model model)
            throws Exception {
        ContentMemoVO contentMemoVO = contentMemoService.selectContentMemo(muid);
        
        model.addAttribute("contentMemoVO", contentMemoVO);
        model.addAttribute("serchFild", serchFild);
        model.addAttribute("serchWrod", serchWrod);
        model.addAttribute("curPage", curPage);
        return "/memo/writeForm";
    }
 

    @RequestMapping(value="/update.do", method=RequestMethod.POST)
    public View updateContentMemo(
    		@ModelAttribute("contentMemoVO")  ContentMemoVO contentMemoVO, Model model )
            throws Exception { 
    
	    	XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult();

		        if (contentMemoService.updateContentMemo(contentMemoVO) > 0) {
			        xml.setMessage("수정 되었습니다.");
			        xml.setError(false);
		        } else {
		        	 xml.setMessage("수정에 실패하였습니다.");
		 	         xml.setError(true);
		        } 
		        model.addAttribute("xmlData", xml);
	        return xmlView;
    }
    
    @RequestMapping(value="/updateFlag.do", method=RequestMethod.POST)
    public View updateContentMemoFlag(
    		@ModelAttribute("contentMemoVO")  ContentMemoVO contentMemoVO, Model model )
            throws Exception { 
    
	    	XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult();
		        if (contentMemoService.updateContentMemoFlag(contentMemoVO) > 0) {
			        xml.setMessage("수정 되었습니다.");
			        xml.setError(false);
		        } else {
		        	 xml.setMessage("수정에 실패하였습니다.");
		 	         xml.setError(true);
		        } 
		        model.addAttribute("xmlData", xml);
	        return xmlView;
    }
    
    @RequestMapping(value="/update_list.do", method=RequestMethod.POST)
    public String updateContentMemo_list(
    		@ModelAttribute("contentMemoVO")  ContentMemoVO contentMemoVO,
    		int curPage , String serchFild, String serchWrod 
    		)
            throws Exception {
           contentMemoService.updateContentMemo(contentMemoVO);
        
        return "forward:/memo/list.do";
    }
    
    @RequestMapping("/delete.do")
    public View deleteContentMemo(
    		  @ModelAttribute("contentMemoVO") ContentMemoVO contentMemoVO , Model model
    		  )
            throws Exception {
 
    	XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult();

	        if (contentMemoService.deleteContentMemo(contentMemoVO) > 0) {
		        xml.setMessage("삭제 되었습니다.");
		        xml.setError(false);
	        } else {
	        	 xml.setMessage("삭제에 실패하였습니다.");
	 	        xml.setError(true);
	        } 
	    model.addAttribute("xmlData", xml);
        return xmlView;
    }
    
    @RequestMapping(value="/selectContentMemoFlag.do", method={RequestMethod.GET, RequestMethod.POST})
    public @ResponseBody Map<?,?> auto(String calnoteId, String state) throws Exception {
		Map< String, Object> map = new HashMap< String, Object>();
		if(contentMemoService.selectContentMemoFlag(calnoteId, state) == null){
			return null;
		}else{
			
			map.put("data",contentMemoService.selectContentMemoFlag(calnoteId, state));
		   return map;
		}
    }
    
    @RequestMapping(value="/comment_check.do" , method=RequestMethod.POST)
    public View comment_check(
    		  @ModelAttribute("contentMemoVO") ContentMemoVO contentMemoVO , Model model
    		  ) throws Exception {
 
    	XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult();
 
		int cnt = contentMemoService.comment_check(contentMemoVO);
 
		xml.setMessage(cnt+"");
	        if (cnt > 0) {
		       xml.setError(true);		       
	        } else {	
	 	        xml.setError(false);
	        } 
	    model.addAttribute("xmlData", xml);
        return xmlView;
    }
    
    
    @RequestMapping(value="/codceComment_select.do" )
    public View codceComment_select(
            String state ,
            String calnoteId , Model model)
            throws Exception {
    	
    	XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult();
        
        ContentMemoVO contentMemoVO = contentMemoService.codceComment_select(calnoteId, state);
 
        try{
	        if (contentMemoVO != null ) {
	        	 
	        	 String return_value = contentMemoVO.getWdate();
	             if (return_value != null) { 
	          	   return_value = return_value.replaceAll("-", "").replaceAll(" ","").replaceAll(":", "").replaceAll("\\.", "");	          	 
	             }
 
		        xml.setMessage(return_value );
		        xml.setError(true);
	        } else {
	         
	        	xml.setMessage("");
	 	        xml.setError(false);
	        } 
        }catch (Exception e) {
			e.printStackTrace();
			System.out.println(e);
		}
        
        model.addAttribute("xmlData", xml);
  
        return xmlView;
    }
 
    

}
 