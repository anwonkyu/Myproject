package com.withus.boardHistory.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;
import com.withus.boardHistory.dao.BoardHistoryVO;

@Repository("boardHistoryMapper")
public interface BoardHistoryMapper {
	
	public int insertBoardHistory(BoardHistoryVO vo)throws Exception;
	
	public ArrayList<BoardHistoryVO> selectBoardHistoryList(HashMap<String, String> hashmap) throws Exception;
	
	public int selectBoardHistoryListTotCnt(HashMap<String, String> hashmap);
	
	public int selectBoardDeleteCnt(HashMap<String, String> hashmap);

}
