package com.withus.boardlist;

import java.io.File;
 
import java.text.SimpleDateFormat;
import java.util.ArrayList;
 
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
 
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
 
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
 
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.View;

import com.ext.jfile.service.JFileDetails;
import com.ext.jfile.service.JFileService;
import com.thoughtworks.xstream.XStream;
import com.withus.boardinfo.dao.BoardInfoVO;
import com.withus.boardinfo.service.BoardInfoService;
import com.withus.boardlist.service.BoardListService;
 
import com.withus.boardlist.dao.BoardListVO;
 
 
import com.withus.category.service.CategoryService;
import com.withus.commons.TextUtil;
import com.withus.commons.XmlResult;
import com.withus.commons.mail.DefaultMailMessage;
import com.withus.commons.mail.MailNotifier;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.commons.seed.SEEDUtil;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileServiceImpl;
import com.withus.commons.uploadFile.service.UploadFileVo;
import com.withus.member.dao.MemberVo;
 
import com.withus.member.service.MemberService;
import com.withus.memo.service.ContentMemoService;
 
 
/**
 * @Class Name : BoardListController.java
 * @Description : BoardList Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/board")
public class BoardListController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardListController.class);
			
	@Autowired Properties prop;
	
	@Autowired Properties mailProp;
	
    @Autowired
    private JavaMailSender mailSender; 
    
	@Resource(name = "mailNotifier")
	private MailNotifier mailNotifier;
	
    @Autowired
   	private MemberService memberService;
       
    
    @Autowired
    private BoardListService boardListService;
    
    @Resource
    private UploadFileService uploadFileService;
    
    @Resource
	 private ContentMemoService memoService;
 
    @Resource
    private BoardInfoService boardInfoService;
    
    @Resource
    private JFileService jfileService;
    
    @Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;

   
	 @Resource
	 private PagingHelperService page;
	 
	 @Resource
	 private CategoryService cateService;
	 
    /**
	 * board_list 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 BoardListDefaultVO
	 * @return "/boardList/BoardListList"
	 * @exception Exception
	 */
    @RequestMapping(value="/boardListAll.do" ,method={RequestMethod.GET, RequestMethod.POST})
    public String selectBoardListListAll( Integer curPage,String searchFild,  String searchWord, Model model,  Integer pagelimit)
            throws Exception {
    	
    	 
    	
    	if (curPage == null) curPage = 1;
    	if (pagelimit == null) pagelimit = 10;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = ""; 
		
		int seq = 0; 
		  
		
		//int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		
//		if (pagelimit != null)  {
//			numPerPage = Integer.parseInt(pagelimit);
//		}
		//int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
	 
		if (searchFild != null && searchFild.equals("name")) {
			searchWord = com.withus.commons.seed.WithusSeed.returnSeedEnStr(searchWord);  // 암호화
		}
	 
		int totalRecord = boardListService.selectBoardListListTotCntAll( searchFild, searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		
		// 게시물 전체
		
        ArrayList<BoardListVO> boardListList = boardListService.selectBoardListListAll( searchFild,  searchWord, start, end );
 
        model.addAttribute("resultList", boardListList);          
 
        model.addAttribute("totalRecord", totalRecord);
		model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		

        return "/board/boardList";
    } 
    
    
    @RequestMapping(value="/boardList.do" ,method={RequestMethod.GET, RequestMethod.POST})
    public String selectBoardListList(Integer boardId , Integer curPage,String searchFild,  String searchWord, Model model, String pagelimit)
            throws Exception {
    	if (boardId == null) return null;
    	
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = ""; 
 
		
		//int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		if (pagelimit != null)  {
			numPerPage = Integer.parseInt(pagelimit);
		}
		//int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
	 
		if (searchFild != null && searchFild.equals("name")) {
			searchWord = com.withus.commons.seed.WithusSeed.returnSeedEnStr(searchWord);  // 암호화
		}
		int totalRecord = boardListService.selectBoardListListTotCnt(boardId, searchFild, searchWord  );
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks(); 
		
		BoardInfoVO boardInfo = boardInfoService.selectBoardInfo(boardId);
		ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
 	  	 
			
		model.addAttribute("boardInfo", boardInfo );   //게시판 정보
		// 게시물 전체
        ArrayList<BoardListVO> boardListList = boardListService.selectBoardListList(boardId, searchFild,  searchWord, start, end );
        
        model.addAttribute("resultList", boardListList);  
        
        //공지 게시물 (open_space=Y)
   
        ArrayList<BoardListVO> boardListList_notice = boardListService.selectBoardListList_notice(boardId);
         
        
        model.addAttribute("resultList_notice", boardListList_notice);  
        model.addAttribute("totalRecord", totalRecord);
		model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 

		model.addAttribute("boardInfoList", boardInfoList);
        return "/board/boardList";
    } 
    
    
    @RequestMapping(value="/listWrite.do" )
    public String addBoardListView(@RequestParam(value="listId", defaultValue = "0",required=true) Integer listId ,@RequestParam(value="boardId" ) Integer boardId, 
    		Model model, String mode)  throws Exception {
    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession(false);
       
        BoardInfoVO boardInfo = new BoardInfoVO();
        
        if (boardId != null && boardId > 0) {
        	boardInfo = boardInfoService.selectBoardInfo(boardId);
        } else {
        	return null;
        }
        
        //랜덤 값을 세션에 저장하고 사용자가 입력한 확인 문자열이 세션에 저장된 문자열과 같은지 체크한다.
  		int iRandomNum = 0;
  		java.util.Random r = new java.util.Random(); //난수 객체 선언 및 생성
  		iRandomNum = r.nextInt(999)+10000;
 // 		session.setAttribute("iRandomNum", String.valueOf(iRandomNum)); 
   
        model.addAttribute("boardInfo", boardInfo);
    	  
        return "/board/listWrite";
    }
    
    @RequestMapping(value="/listWriteProc.do", method=RequestMethod.POST)
    public String addBoardList(MultipartHttpServletRequest mpRequest, @ModelAttribute("BoardListVO") BoardListVO boardListVO,  
    		 Model model )
            throws Exception {
    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession();
	 
		BoardInfoVO boardInfo = new BoardInfoVO();
		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
		if (session != null) {
		  if (boardInfo != null && boardInfo.getBoardUserFlag().equals("f")) { // 관리자 전용게시판 확인
				Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
				Object principal = auth.getPrincipal(); 
				if(principal != null && principal instanceof MemberVo){ 
					boardListVO.setDupinfo(((MemberVo)principal).getUsername() ); // 로그인 사용자 ID set
				}
		        
		    
		    	 int result_value = 	 boardListService.insertBoardList(boardListVO);    
		    	
		 		if (result_value > 0) {
		       	 
		       			model.addAttribute("msg", "등록 되었습니다."); 
						model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId());
						
				 } else {
					 	model.addAttribute("msg", "등록에 실패하였습니다."); 
						model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId());
				 } 
		       
	        } else {
	        	model.addAttribute("msg", "등록에 실패하였습니다."); 
				model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId());
	        }
		} else {
			 
			model.addAttribute("msg", "확인문자열이 올바르지 않습니다."); 
			model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId());
		}
 
	       // return link; 
	        
	      
			return "/include/redirect"; 
    	
    }
  
    
    @RequestMapping(value="/listWriteXml.do", method=RequestMethod.POST)
    public View addBoardListXml(MultipartHttpServletRequest mpRequest, @ModelAttribute("boardListVO") BoardListVO boardListVO,   
    		 @RequestParam(value="chk_word" ,required=true) String chk_word, Model model )
            throws Exception {
 
    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession();
        
		//MemberVo memberVo = (MemberVo)session.getAttribute(prop.getProperty("USER_KEY").trim());
		
        
		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult();
        
		BoardInfoVO boardInfo = new BoardInfoVO();
		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
		if (session != null &&  session.getAttribute("iRandomNum").equals(chk_word)) {
		  if (boardInfo != null && boardInfo.getBoardUserFlag().equals("f")) { // 관리자 전용게시판 확인
				Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
				Object principal = auth.getPrincipal(); 
				if(principal != null && principal instanceof MemberVo){ 
					boardListVO.setDupinfo(((MemberVo)principal).getUsername() ); // 로그인 사용자 ID set
				}
		        
		    	 
		    	 int result_value = 	 boardListService.insertBoardList(boardListVO);    

		 		if (result_value > 0) {
			        
			       		  model.addAttribute("msg", "추가 되었습니다."); 
						  model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId() );
					 } else {
				        	 xml.setMessage("등록에 실패하였습니다.");
				 	        xml.setError(false);
				 }
	    			
	      
		       
	        } else {
	        	 xml.setMessage("등록에 실패하였습니다.");
		 	        xml.setError(false);
	        }
		} else {
			xml.setMessage("확인문자열을 확인하세요!");
	 	    xml.setError(false);
		}

	        model.addAttribute("xmlData", xml);
	        return xmlView;
	        
	         
    	
    }
    
    @RequestMapping(value="/listView.do")
    public String updateBoardListView(
            @RequestParam(value="listId",required=true) Integer listId, Integer curPage , String searchFild, String searchWord, Model model)
            throws Exception {  
    	
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";

        BoardListVO boardListVO= boardListService.selectBoardList(listId);
     
        //조회수 증가
        if (boardListVO != null) {
        	boardListService.updateReadCount(listId); 
        }
        
       
        model.addAttribute("boardListVO", boardListVO);
    	BoardInfoVO boardInfo = new BoardInfoVO();
		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
 
//		String menu_code  = cateService.getMenuCode2(selectCode, menuCode, boardListVO.getBoardId());	  
//		if (menu_code != null && menu_code.length() > 0) {
//			 
//			model.addAttribute("menuName", cateService.getMenuNm(menu_code));  // 현재 메뉴 명
//			model.addAttribute("menuNameAll", cateService.getMenuNmAll(menu_code)); // 전체 메뉴
//			} else {
//				String menuName_temp = "";
//				String menuNameAll_temp = "";
//				if (boardListVO.getBoardId() == 1 ) {
//					menuName_temp= "공지사항";
//					menuNameAll_temp = "통합게시판 > 공지사항";
//				} else if (boardListVO.getBoardId() == 2) {
//					menuName_temp= "시스템 개선 및 의견";
//					menuNameAll_temp = "통합게시판 > 시스템 개선 및 의견";
//				}else if (boardListVO.getBoardId() == 7) {
//					menuName_temp= "운전지원자료";
//					menuNameAll_temp = "통합게시판 > 운전지원자료";
//				}else if (boardListVO.getBoardId() == 8) {
//					menuName_temp= "HIPER16 RTSR";
//					menuNameAll_temp = "통합게시판 > HIPER16 RTSR";
//				}
//				model.addAttribute("menuName", menuName_temp);  // 현재 메뉴 명
//				model.addAttribute("menuNameAll", menuNameAll_temp); // 전체 메뉴
//			}
			
		
		BoardListVO nextBoard = boardListService.getNextBoard(listId, searchFild, searchWord);
		BoardListVO prevBoard = boardListService.getPrevBoard(listId, searchFild, searchWord);
		
		 /*
		 * 첨부파일 정보 읽어 오기
		 */ 
        
		List<UploadFileVo> uploadFileList = uploadFileService.getUploadFileList(boardListVO.getListId().toString(),"B" ); 
		model.addAttribute("uploadFileList", uploadFileList);  // 첨부파일
 
		model.addAttribute("boardInfo", boardInfo); 
		model.addAttribute("curPage", curPage); 
		model.addAttribute("nextBoard", nextBoard); 
		model.addAttribute("prevBoard", prevBoard); 
		if(boardListVO.getJfile() != null){
			List<JFileDetails> jfileVo = jfileService.getAttachFiles(boardListVO.getJfile());
			model.addAttribute("jfileList", jfileVo);  // 파일목록
			}
		if(boardListVO.getListReLevel() ==0){
			return "/board/listView";
		}else{
			return "/board/listViewReply";
		
		}
    }
    
    
    @RequestMapping(value="/listUpdate.do",  method ={RequestMethod.GET, RequestMethod.POST})
    public String updateBoardListUpdate(
            @RequestParam(value="listId",required=true)Integer listId, Integer curPage , String searchFild, String searchWord , Model model,  String listPasswd, String mode)
            throws Exception {  
    	
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		
		HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession(false);
		
        BoardListVO boardListVO= boardListService.selectBoardList(listId);
    	BoardInfoVO boardInfo = new BoardInfoVO();
		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
 	  	 
//		String menu_code  = cateService.getMenuCode2(selectCode, menuCode, boardListVO.getBoardId());
//		
//		if (menu_code != null && menu_code.length() > 0) {
//	
//		model.addAttribute("menuName", cateService.getMenuNm(menu_code));  // 현재 메뉴 명
//		model.addAttribute("menuNameAll", cateService.getMenuNmAll(menu_code)); // 전체 메뉴
//		} else {
//			String menuName_temp = "";
//			String menuNameAll_temp = "";
//			if (boardListVO.getBoardId() == 1 ) {
//				menuName_temp= "공지사항";
//				menuNameAll_temp = "통합게시판 > 공지사항";
//			} else if (boardListVO.getBoardId() == 2) {
//				menuName_temp= "시스템 개선 및 의견";
//				menuNameAll_temp = "통합게시판 > 시스템 개선 및 의견";
//			}else if (boardListVO.getBoardId() == 7) {
//				menuName_temp= "운전지원자료";
//				menuNameAll_temp = "통합게시판 > 운전지원자료";
//			}else if (boardListVO.getBoardId() == 8) {
//				menuName_temp= "HIPER16 RTSR";
//				menuNameAll_temp = "통합게시판 > HIPER16 RTSR";
//			}
//			model.addAttribute("menuName", menuName_temp);  // 현재 메뉴 명
//			model.addAttribute("menuNameAll", menuNameAll_temp); // 전체 메뉴
//		}
		
		int iRandomNum = 0;
  		java.util.Random r = new java.util.Random(); //난수 객체 선언 및 생성
  		iRandomNum = r.nextInt(999)+10000;
  		session.setAttribute("iRandomNum", String.valueOf(iRandomNum)); 
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		String userId = "";
		 
		boolean return_value=false;
		if(principal != null && principal instanceof MemberVo){  
			userId = ((MemberVo)principal).getUsername() ; // 로그인 사용자 ID set
			 
		}
	 
		 if (boardInfo != null && boardInfo.getBoardUserFlag().equals("f")) { // 관리자 전용게시판 확인
			 if (userId != null && userId.equals(boardListVO.getMem_id())) {
			      return_value = true;
			  }  else if (listPasswd != null && boardListService.pwdCheck(listPasswd, listId) > 0) {
				  return_value = true;
			  } else {
				  return_value = false;
			  }
		  } 
		
		if (return_value) {
			/*
      		 * 첨부파일 정보 읽어 오기
      		 */ 
              
      		List<UploadFileVo> uploadFileList = uploadFileService.getUploadFileList(boardListVO.getListId().toString(),"B" ); 
      		model.addAttribute("uploadFileList", uploadFileList);  // 첨부파일
      	
      		model.addAttribute("mode", mode); 
	      	model.addAttribute("boardInfo", boardInfo);
	        model.addAttribute("boardListVO", boardListVO);
	        model.addAttribute("searchWord", searchWord);
	        model.addAttribute("searchFild", searchFild);
	        model.addAttribute("curPage", curPage);
	        if(boardListVO.getListReLevel() == 0){
	        	return "/board/listWrite";
	        }else{
	        	return "board/listReply";
	        }
	        
		} else {
			
			model.addAttribute("msg", "정보가 올바르지 않습니다."); 
			model.addAttribute("url", "/board/listView.do?listId="+boardListVO.getListId()	);
			return "/include/redirect";  
		}
       
    }
   
    @RequestMapping(value="/listUpdateProc.do", method=RequestMethod.POST)
    public String updateBoardList(MultipartHttpServletRequest mpRequest,
    		@ModelAttribute("boardListVO") BoardListVO boardListVO, Integer curPage , String searchFild, String searchWord ,
    		 
    		Model model
            ) throws Exception {
    	
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
	 
    	
		if (boardListService.updateBoardList(boardListVO) > 0) {

        	//파일 삭제
    		List<String> attachDel = boardListVO.getAttachDel();
    		if (attachDel != null) {
    			uploadFileService.deleteSelect(attachDel);
    		//	System.out.println("파일삭제::"+attachDel.size());
    		}
    		 
 
    		model.addAttribute("msg", "수정 되었습니다."); 
			model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId() );
		} else {
			  
			model.addAttribute("msg", "수정에 실패하였습니다."); 
			model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId() );
		} 
 
		return "/include/redirect"; 		
    }
    
    @RequestMapping(value="/listUpdateProcXml.do", method=RequestMethod.POST)
    public View updateBoardListXml(MultipartHttpServletRequest mpRequest,
    		@ModelAttribute("boardListVO") BoardListVO boardListVO, Integer curPage , String searchFild, String searchWord ,
    		Model model
            ) throws Exception {
    	
    	
    	
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class); 
    	XmlResult xml = new XmlResult();
    	
		if (boardListService.updateBoardList(boardListVO) > 0) {

        	//파일 삭제
    		List<String> attachDel = boardListVO.getAttachDel();
    		if (attachDel != null) {
    			uploadFileService.deleteSelect(attachDel);
    		//	System.out.println("파일삭제::"+attachDel.size());
    		}
    		 
    		 model.addAttribute("msg", "수정 되었습니다."); 
		     xml.setError(true);
        
		} else {
			  
			    xml.setMessage("수정에 실패하였습니다.");
		        xml.setError(false);
		} 

        model.addAttribute("xmlData", xml);
        return xmlView;
         
    			
    }

 
    @RequestMapping("/listDelete.do")
    public String deleteBoardList(
    		@RequestParam(value="listId",required=true)Integer listId,
    		@RequestParam(value="boardId",required=true)Integer boardId,
    	 
    		Model model) 
            throws Exception {
    	
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		String userId = "";
		 
		if(principal != null && principal instanceof MemberVo){  
			userId = ((MemberVo)principal).getUsername() ; // 로그인 사용자 ID set
		}
 	 
		BoardListVO boardListVO = new BoardListVO();
		
    	boardListVO = boardListService.selectBoardList(listId);
    	
    	int del_value = -1;
    	BoardInfoVO boardInfo = new BoardInfoVO();
    	boardInfo = boardInfoService.selectBoardInfo(boardId);
    	int listReLevel = boardListVO.getListReLevel();
    	int listStep = boardListVO.getListStep();
		BoardListVO selectCheckLow = boardListService.selectCheckRow(boardListVO.getListRef(), listReLevel+1, listStep+1);
		int checkLow = selectCheckLow.getListId();
		if(checkLow == 0){

		if (boardInfo != null && boardInfo.getBoardUserFlag().equals("f")) { // 관리자 전용게시판 확인

			  if (userId != null && userId.equals(boardListVO.getMem_id())) {
				  del_value=  boardListService.deleteBoardList(boardListVO);  
			  }  
		  }
		}

		  
		 if (del_value > 0) {
			//파일 삭제
			  uploadFileService.deleteFileAll(boardListVO.getListId()+"", "B");
			  
		  }
        
		if (del_value > 0) {
			model.addAttribute("msg", "삭제되었습니다."); 
			model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId() );
			
	    } else {
			  
			model.addAttribute("msg", "삭제에 실패하였습니다."); 
			model.addAttribute("url", "/board/boardList.do?boardId="+boardListVO.getBoardId() );
		} 

		return "/include/redirect"; 	
	
	 

    }
    
    @RequestMapping("/listDeleteXml.do")
    public View deleteBoardListXml( @ModelAttribute("boardListVO")
            BoardListVO boardListVO , Model model)
            throws Exception {
    	
    	//HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		//HttpSession session = req.getSession();
        //MemberVo memberVo = (MemberVo)session.getAttribute(WebContants.USER_KEY);
		//MemberVo memberVo = (MemberVo)session.getAttribute(prop.getProperty("USER_KEY").trim());
        
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		String userId = null;
 
		if(principal != null && principal instanceof MemberVo){  
			userId = ((MemberVo)principal).getUsername() ; // 로그인 사용자 ID set 
		} 
		
        XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class); 
     
        XmlResult xml = new XmlResult(); 
        //boardListVO = boardListService.selectBoardList(boardListVO.getListId());
    	BoardInfoVO boardInfo = new BoardInfoVO();
		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
		int del_value = -1;
		  if (boardInfo != null && boardInfo.getBoardUserFlag().equals("f")) { // 관리자 전용게시판 확인
			  if (userId != null &&  boardListService.dupCheck(userId, boardListVO.getListId()) > 0 ) {
				  	del_value = boardListService.deleteBoardList(boardListVO);  
		        } else if (userId == null && boardListVO.getListPasswd() != null && boardListService.pwdCheck(boardListVO.getListPasswd(), boardListVO.getListId())> 0) {
					del_value = boardListService.deleteBoardList(boardListVO);  
		        }
		  }
			  
		 if (del_value > 0){
			  xml.setMessage("삭제되었습니다.");
		      xml.setError(true);
		 } else { 
              xml.setMessage("정보가 올바르지 않습니다.");
              xml.setError(false);
         } 
        
        model.addAttribute("xmlData", xml);
        return xmlView; 
    }
  

    @RequestMapping(value="/pwdCheck.do",  method ={RequestMethod.GET, RequestMethod.POST})
	public String pwdCheck(  Model model,  Integer boardId) throws Exception{
//    	String menu_code  = cateService.getMenuCode2(selectCode, menuCode,boardId);	  
//		
//		model.addAttribute("menuName", cateService.getMenuNm(menu_code));  // 현재 메뉴 명
//		model.addAttribute("menuNameAll", cateService.getMenuNmAll(menu_code)); // 전체 메뉴 
		 
		return "/board/pwdCheck";		
	}
    
    
    @RequestMapping(value="/category/docnum.do", method={RequestMethod.GET, RequestMethod.POST})
    public View selectIndept(String doc_type, String nowyear, String h_name, String mode ,String doc_num,  Model model ) throws Exception {
    	
    
    	String create_num = h_name+nowyear;
    	
		int selectIndept = boardListService.selectInDept(doc_type, nowyear, h_name, mode, create_num);
		String nextString = "";
		
		String return_num = h_name+nowyear+nextString;
		
		if (selectIndept < 10) {			
			return_num = return_num + "00"+selectIndept;
		} else if (selectIndept < 100) {
			return_num = return_num + "0"+selectIndept;
		} else {
			return_num = return_num + selectIndept;
		}
	  
		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
        
 
        if (return_num != null) {
	    	xml.setMessage(return_num);
	 	    xml.setError(true);
        } else {
        	xml.setMessage("0");
	 	    xml.setError(false);
        }
	   
	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
		
    		
    	}
    	
    
    @RequestMapping(value="/listReply.do" )
    public String addBoardListReplyForm(
            @RequestParam(value="listId",required=true)Integer listId, @RequestParam(value="boardId",required=true)Integer boardId, Integer curPage , String searchFild, String searchWord , Model model
        	 )
            throws Exception {  
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
				
		
        BoardListVO boardListVO= boardListService.selectBoardListVodman(listId);
        
//        String menu_code  = cateService.getMenuCode2(selectCode, menuCode, boardListVO.getBoardId());
//		
//		if (menu_code != null && menu_code.length() > 0) {
//		 
//		model.addAttribute("menuName", cateService.getMenuNm(menu_code));  // 현재 메뉴 명
//		model.addAttribute("menuNameAll", cateService.getMenuNmAll(menu_code)); // 전체 메뉴
//		} else {
//			String menuName_temp = "";
//			String menuNameAll_temp = "";
//			if (boardListVO.getBoardId() == 1 ) {
//				menuName_temp= "공지사항";
//				menuNameAll_temp = "통합게시판 > 공지사항";
//			} else if (boardListVO.getBoardId() == 2) {
//				menuName_temp= "시스템 개선 및 의견";
//				menuNameAll_temp = "통합게시판 > 시스템 개선 및 의견";
//			}else if (boardListVO.getBoardId() == 7) {
//				menuName_temp= "운전지원자료";
//				menuNameAll_temp = "통합게시판 > 운전지원자료";
//			}else if (boardListVO.getBoardId() == 8) {
//				menuName_temp= "HIPER16 RTSR";
//				menuNameAll_temp = "통합게시판 > HIPER16 RTSR";
//			}
//			model.addAttribute("menuName", menuName_temp);  // 현재 메뉴 명
//			model.addAttribute("menuNameAll", menuNameAll_temp); // 전체 메뉴
//		}
		
    	//답글 등록 일경우
		boardListVO.setListTitle("");
		boardListVO.setListContents("");
		 //leftMenu 게시판 목록
		BoardInfoVO boardInfo = new BoardInfoVO();
        ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
        if (boardId != null && boardId > 0) {
        	boardInfo = boardInfoService.selectBoardInfo(boardId);
        } else {
        	return null;
        }
       
        model.addAttribute("boardInfoList", boardInfoList);
        model.addAttribute("boardInfo", boardInfo);
        model.addAttribute("boardListVO", boardListVO);
        model.addAttribute("searchWord", searchWord);
        model.addAttribute("searchFild", searchFild);
        model.addAttribute("curPage", curPage);
        return "/board/listReply";
    }
    
    @RequestMapping(value="/listReplyPorc.do", method=RequestMethod.POST)
    public String addBoardListReply(MultipartHttpServletRequest mpRequest, @ModelAttribute("boardListVO") BoardListVO boardListVO
 
    		)
            throws Exception {
    	
//    	BoardInfoVO boardInfo = new BoardInfoVO();
//		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
    	
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		String userId = "";
		 
		if(principal != null && principal instanceof MemberVo){  
			userId = ((MemberVo)principal).getUsername() ; // 로그인 사용자 ID set
			boardListVO.setMem_id(userId);
		} 
		
		int result_value = 	 boardListService.insertBoardListReply(boardListVO);    

		if (result_value > 0) {
		 
		}  
          //return "forward:/board/boardList.do?boardId="+boardListVO.getBoardId()+"&menuCode="+menuCode+"&selectCode="+selectCode;
		return "redirect:/board/boardList.do?boardId="+boardListVO.getBoardId() ;
     }
    
    
}


