package com.withus.secured.dao;

/**
 * @Class Name : SecuredResourcesVO.java
 * @Description : SecuredResources VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class SecuredResourcesVO {
    private static final long serialVersionUID = 1L;
    
    /** resource_id */
    private String resourceId;
    
    /** resource_name */
    private String resourceName;
    
    /** resource_pattern */
    private String resourcePattern;
    
    /** resource_type */
    private String resourceType;
    
    /** sort_order */
    private Integer sortOrder;
    
    private String authority;
    
    private Integer seq;
    
    
    
    
    public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

	public String getResourceId() {
        return this.resourceId;
    }
    
    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }
    
    public String getResourceName() {
        return this.resourceName;
    }
    
    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }
    
    public String getResourcePattern() {
        return this.resourcePattern;
    }
    
    public void setResourcePattern(String resourcePattern) {
        this.resourcePattern = resourcePattern;
    }
    
    public String getResourceType() {
        return this.resourceType;
    }
    
    public void setResourceType(String resourceType) {
        this.resourceType = resourceType;
    }
    
    public Integer getSortOrder() {
        return this.sortOrder;
    }
    
    public void setSortOrder(Integer sortOrder) {
        this.sortOrder = sortOrder;
    }
    
}
