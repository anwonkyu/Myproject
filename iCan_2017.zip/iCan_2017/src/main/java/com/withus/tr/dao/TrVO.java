package com.withus.tr.dao;

public class TrVO {
	private String trId;
	private String docId;
	private String docName;
	private String state;
	private Integer bodyPageNum;
	private Integer totalPageNum;
	private String regDate;
	private String modDate;
	private String appDate;
	private String userId;
	private String deptCd;
	private String deleteFlag;
	private String jfile;
	private String cowriter;
	private String reviewer;
	private String approver;
	private String contents;
	private Integer year;
	private String userDept;
	private String edmsDocId;
	private String dept_cd_;	
	private String stat;
	private String name;
	private String sortField;
	private String sortOrder;
	private String owner;
	private String hAppDate; 
	
	 
	public String gethAppDate() {
		return hAppDate;
	}
	public void sethAppDate(String hAppDate) {
		this.hAppDate = hAppDate;
	}
	
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getSortField() {
		return sortField;
	}
	public void setSortField(String sortField) {
		this.sortField = sortField;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept_cd_() {
		return dept_cd_;
	}
	public void setDept_cd_(String dept_cd_) {
		this.dept_cd_ = dept_cd_;
	}
	public String getStat() {
		return stat;
	}
	public void setStat(String stat) {
		this.stat = stat;
	}
	public String getUserDept() {
		return userDept;
	}
	public void setUserDept(String userDept) {
		this.userDept = userDept;
	}
	public String getEdmsDocId() {
		return edmsDocId;
	}
	public void setEdmsDocId(String edmsDocId) {
		this.edmsDocId = edmsDocId;
	}
	public Integer getYear() {
		return year;
	}
	public void setYear(Integer year) {
		this.year = year;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getTrId() {
		return trId;
	}
	public void setTrId(String trId) {
		this.trId = trId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public Integer getBodyPageNum() {
		return bodyPageNum;
	}
	public void setBodyPageNum(Integer bodyPageNum) {
		this.bodyPageNum = bodyPageNum;
	}
	public Integer getTotalPageNum() {
		return totalPageNum;
	}
	public void setTotalPageNum(Integer totalPageNum) {
		this.totalPageNum = totalPageNum;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getModDate() {
		return modDate;
	}
	public void setModDate(String modDate) {
		this.modDate = modDate;
	}
	public String getAppDate() {
		return appDate;
	}
	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getDeptCd() {
		return deptCd;
	}
	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getJfile() {
		return jfile;
	}
	public void setJfile(String jfile) {
		this.jfile = jfile;
	}
	public String getCowriter() {
		return cowriter;
	}
	public void setCowriter(String cowriter) {
		this.cowriter = cowriter;
	}
	public String getReviewer() {
		return reviewer;
	}
	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}
	public String getApprover() {
		return approver;
	}
	public void setApprover(String approver) {
		this.approver = approver;
	}
	
}
