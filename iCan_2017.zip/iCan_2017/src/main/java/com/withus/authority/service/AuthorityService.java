package com.withus.authority.service;

import java.util.ArrayList;
 

import com.withus.authority.dao.AuthorityVO;

/**
 * @Class Name : AuthorityService.java
 * @Description : Authority Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface AuthorityService {
	
	/**
	 * authority을 등록한다.
	 * @param vo - 등록할 정보가 담긴 AuthorityVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    int insertAuthority(AuthorityVO vo) throws Exception;
    
    /**
	 * authority을 수정한다.
	 * @param vo - 수정할 정보가 담긴 AuthorityVO
	 * @return void형
	 * @exception Exception
	 */
    int updateAuthority(AuthorityVO vo) throws Exception;
    
    /**
	 * authority을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 AuthorityVO
	 * @return void형 
	 * @exception Exception
	 */
    int deleteAuthority(String authority) throws Exception;
    
    /**
	 * authority을 조회한다.
	 * @param vo - 조회할 정보가 담긴 AuthorityVO
	 * @return 조회한 authority
	 * @exception Exception
	 */
    AuthorityVO selectAuthority(String authority) throws Exception;
    
    /**
	 * authority 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return authority 목록
	 * @exception Exception
	 */
    ArrayList<AuthorityVO> selectAuthorityList() throws Exception;
    
    /**
	 * authority 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return authority 총 갯수
	 * @exception
	 */
    int selectAuthorityListTotCnt();
    
}
