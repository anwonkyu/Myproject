package com.withus.serverFile.connection.sftp2;

import java.io.File;

import com.jcraft.jsch.SftpException;

public class SampleSFTP {
 
 
 public SampleSFTP(){
  
 }
 
 public void test() {
  System.out.println("test()");
  SFTP sftp = new SFTP();
  sftp.setServer("106.255.241.77");
  sftp.setUser("withus_nrf", "withustech00");
  sftp.login();
  /*
  
  //file download sample
  if(sftp.downloadFile("service.xml", "d:\\test.xml")){
   System.out.println("OK");
  }else{
   System.out.println("NOK");
  }
  
  //file upload sample
  File file = new File("d://test.txt");
  if(sftp.uploadFile("/home/phing", file)){
   System.out.println("OK||FILE_NAME:"+file.getName());
  }else{
   System.out.println("NOK||FILE_NAME:"+file.getName());
  }
  
  
  //directory file name list
 
   */
  
  //파일 리스트
  String data = sftp.getList("/reserve/ftpTest");
  System.out.println(data);
  
  String data2 = sftp.getList("/reserve/ftpTest/test2");
  System.out.println(data2);
  
  //파일 체크
  if(sftp.fileCheck("/", "reserve")){
   System.out.println("OK");
  }else{
   System.out.println("NOK");
  }
  sftp.logout();

 }
 
 
 public static void main(String[] args) throws Exception {
  SampleSFTP sample = new SampleSFTP();
  System.out.println("시작");
  sample.test();
  System.out.println("종료");
 }
} 
