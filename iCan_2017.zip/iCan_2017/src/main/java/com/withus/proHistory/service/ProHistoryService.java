package com.withus.proHistory.service;

import java.util.ArrayList;

import com.withus.proHistory.dao.ProHistoryVO;

public interface ProHistoryService {
	int insertProHistory(ProHistoryVO vo) throws Exception;
	
	ArrayList<ProHistoryVO> selectProHistoryList(Integer proId, String state, String searchFild, String searchWord,int start, int end) throws Exception;
	
	int selectProHistoryListTotCnt(Integer proId, String state, String searchFild, String searchWord)throws Exception;
}
