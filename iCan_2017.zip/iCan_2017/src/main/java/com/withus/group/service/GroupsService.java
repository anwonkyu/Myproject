package com.withus.group.service;

import java.util.ArrayList;
import java.util.List;
 








import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;

import com.withus.group.dao.GroupsVO;

/**
 * @Class Name : GroupsService.java
 * @Description : Groups Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface GroupsService {
	
	/**
	 * groups을 등록한다.
	 * @param vo - 등록할 정보가 담긴 GroupsVO
	 * @return int
	 * @exception Exception
	 */
    int insertGroups(GroupsVO vo) throws Exception;
    
    /**
	 * groups을 수정한다.
	 * @param vo - 수정할 정보가 담긴 GroupsVO
	 * @return int형
	 * @exception Exception
	 */
    int updateGroups(GroupsVO vo) throws Exception;
    
    /**
	 * groups을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 GroupsVO
	 * @return int형 
	 * @exception Exception
	 */
    int deleteGroups(int groupId) throws Exception;
    
    /**
	 * groups을 조회한다.
	 * @param vo - 조회할 정보가 담긴 GroupsVO
	 * @return 조회한 groups
	 * @exception Exception
	 */
    GroupsVO selectGroups(int groupId) throws Exception;
    
    /**
	 * groups 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return groups 목록
	 * @exception Exception
	 */
    ArrayList<GroupsVO> selectGroupsList() throws Exception;
    
    /**
	 * groups 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return groups 총 갯수
	 * @exception
	 */
    int selectGroupsListTotCnt();

	ArrayList<GroupsVO> selectGroupsMemberList(int groupId);

	ArrayList<GroupsVO> selectGroupsAuthority(int groupId);

	int deleteGroupsMember(int seq);

	int deleteGroupsAuthority(int seq);
	@Transactional
	int insertGroupsMember(MultiValueMap<String, String> params) throws Exception;
	@Transactional
	int insertGroupsAuthority(MultiValueMap<String, String> params) throws Exception;
    
}
