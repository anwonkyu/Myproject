package com.withus.logo.dao;

/**
 * @Class Name : LogoVO.java
 * @Description : Logo VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-12-31
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class LogoVO {
    private static final long serialVersionUID = 1L;
    
    /** seq */
    private int seq;
    
    /** top_logo */
    private String topLogo;
    private String topLogoExt;
    
    /** footer_logo */
    private String footerLogo;
    private String footerLogoExt;
    
    /** wdate */
    private String wdate;
    
    /** media_logo */
    private String mediaLogo;
    private String mediaLogoExt;
    
    /** play_logo */
    private String playLogo;
    
    /** play_pos */
    private String playPos;
    
    /** opacity */
    private int opacity;
    
    /** top_logo_url */
    private String topLogoUrl;
    
    /** top_logo_text */
    private String topLogoText;
    
    /** top_logo_use */
    private String topLogoUse;
    
    private String footAddress;
    
    private String copyright;
    
    private String skinPath;
    
    private String skinColor;
    
    private Integer newVideoLimit;
    
    private Integer boardLimit;
    
    
    
    public Integer getBoardLimit() {
		return boardLimit;
	}

	public void setBoardLimit(Integer boardLimit) {
		this.boardLimit = boardLimit;
	}

	public Integer getNewVideoLimit() {
		return newVideoLimit;
	}

	public void setNewVideoLimit(Integer newVideoLimit) {
		this.newVideoLimit = newVideoLimit;
	}

	public String getSkinPath() {
		return skinPath;
	}

	public void setSkinPath(String skinPath) {
		this.skinPath = skinPath;
	}

	public String getSkinColor() {
		return skinColor;
	}

	public void setSkinColor(String skinColor) {
		this.skinColor = skinColor;
	}

	public String getCopyright() {
		return copyright;
	}

	public void setCopyright(String copyright) {
		this.copyright = copyright;
	}

	public String getFootAddress() {
		return footAddress;
	}

	public void setFootAddress(String footAddress) {
		this.footAddress = footAddress;
	}

	public int getSeq() {
        return this.seq;
    }
    
    public void setSeq(int seq) {
        this.seq = seq;
    }
    
    public String getTopLogo() {
        return this.topLogo;
    }
    
    public void setTopLogo(String topLogo) {
        this.topLogo = topLogo;
    }
    
    public String getFooterLogo() {
        return this.footerLogo;
    }
    
    public void setFooterLogo(String footerLogo) {
        this.footerLogo = footerLogo;
    }
    
    public String getWdate() {
        return this.wdate;
    }
    
    public void setWdate(String wdate) {
        this.wdate = wdate;
    }
    
    public String getMediaLogo() {
        return this.mediaLogo;
    }
    
    public void setMediaLogo(String mediaLogo) {
        this.mediaLogo = mediaLogo;
    }
    
    public String getPlayLogo() {
        return this.playLogo;
    }
    
    public void setPlayLogo(String playLogo) {
        this.playLogo = playLogo;
    }
    
    public String getPlayPos() {
        return this.playPos;
    }
    
    public void setPlayPos(String playPos) {
        this.playPos = playPos;
    }
    
    public int getOpacity() {
        return this.opacity;
    }
    
    public void setOpacity(int opacity) {
        this.opacity = opacity;
    }
    
    public String getTopLogoUrl() {
        return this.topLogoUrl;
    }
    
    public void setTopLogoUrl(String topLogoUrl) {
        this.topLogoUrl = topLogoUrl;
    }
    
    public String getTopLogoText() {
        return this.topLogoText;
    }
    
    public void setTopLogoText(String topLogoText) {
        this.topLogoText = topLogoText;
    }
    
    public String getTopLogoUse() {
        return this.topLogoUse;
    }
    
    public void setTopLogoUse(String topLogoUse) {
        this.topLogoUse = topLogoUse;
    }

	public String getTopLogoExt() {
		return topLogoExt;
	}

	public void setTopLogoExt(String topLogoExt) {
		this.topLogoExt = topLogoExt;
	}

	public String getFooterLogoExt() {
		return footerLogoExt;
	}

	public void setFooterLogoExt(String footerLogoExt) {
		this.footerLogoExt = footerLogoExt;
	}

	public String getMediaLogoExt() {
		return mediaLogoExt;
	}

	public void setMediaLogoExt(String mediaLogoExt) {
		this.mediaLogoExt = mediaLogoExt;
	}
    
    
    
}
