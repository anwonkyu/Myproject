package com.withus.tr.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.withus.calHistory.dao.CalHistoryVO;
import com.withus.calHistory.service.CalHistoryService;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.service.CalnoteServiceImpl;
import com.withus.commons.seed.WithusSeed;
import com.withus.member.dao.MemberVo;
import com.withus.member.service.MemberService;
import com.withus.tr.dao.TrMapper;
import com.withus.tr.dao.TrVO;
@Service("trService")
public class TrServiceImpl implements TrService{
	private static final Logger LOGGER = LoggerFactory.getLogger(CalnoteServiceImpl.class);
	
	@Resource(name="trMapper")
	private TrMapper trMapper;
	
	
	@Autowired MemberService memberService;
	@Resource(name = "calHistoryService")
	private CalHistoryService calHistoryService;
	
	@Override
	@Transactional
	public void insertTr(TrVO trVo) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		Authentication auth = (Authentication)request.getUserPrincipal();
		if(auth == null){
	          
	     }else{
	    	 Object principal = auth.getPrincipal();
	    	 String userId = ((MemberVo)principal).getId();
	    	 trVo.setUserId(userId);  //아이디
	    	 String userDept = memberService.selectDept(userId);
	    	 trVo.setUserDept(userDept);
	    	 trVo.setName(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	    	 trMapper.insertTr(trVo); 
	  //  	 System.out.println("insertTr:::::::::::::"+trVo.toString());
	    	CalHistoryVO vo = new CalHistoryVO();
         	vo.setCalnoteId(trVo.getTrId());
         	vo.setState(trVo.getState());
         	calHistoryService.insertCalHistory(vo);
         	
	     }
		
	}

	@Override
	public ArrayList<TrVO> selectTr(int start, int end,String docName, String docId, String datepicker, String datepicker2,String deptCd,String userDept, String sortField, String sortOrder,String state) throws Exception {
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		Integer startRownum = start;
		Integer endRownum = end;
		

		String[] sortFieldList = sortField.split(",");
		String[] sortOrderList = sortOrder.split(",");
		
		List<TrVO> list = new ArrayList<TrVO>();
		
		for (int i = 0; i < sortFieldList.length; i++) { 
			TrVO sortListVo = new TrVO();
			sortListVo.setSortField(sortFieldList[i]);
			sortListVo.setSortOrder(sortOrderList[i]);
			list.add(sortListVo);
		}
		
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("docName", docName);
		hashmap.put("docId", docId);
		hashmap.put("docName", docName);
		hashmap.put("datepicker", datepicker);
		hashmap.put("datepicker2", datepicker2);
		hashmap.put("deptCd", deptCd);
		hashmap.put("userDept", userDept);
		hashmap.put("sortField", sortField);
		hashmap.put("sortOrder", sortOrder);
		hashmap.put("sortList", list);
		hashmap.put("state", state);
		
		
		return trMapper.selectTr(hashmap);
	}

	@Override	
	public int selectTrTotCnt(String docName, String docId, String datepicker, String datepicker2,String deptCd,String userDept,String state) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("docId", docId);
		hashmap.put("docName", docName);
		hashmap.put("datepicker", datepicker);
		hashmap.put("datepicker2", datepicker2);
		hashmap.put("deptCd", deptCd);
		hashmap.put("userDept", userDept);
		hashmap.put("state", state);
		return trMapper.selectTrTotCnt(hashmap);
	}

	@Override
	public TrVO getTr(String trId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("trId", trId);
		return trMapper.getTr(hashmap);
	}
	
	@Override
	public TrVO getTrDocId(String docId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("docId", docId);
		return trMapper.getTrDocId(hashmap);
	}

	@Override
	@Transactional
	public int updateTr(TrVO trVo) throws Exception {
		
		int return_value = -1;
		return_value = trMapper.updateTr(trVo);
		if (return_value > 0) {
		CalHistoryVO vo = new CalHistoryVO();
     	vo.setCalnoteId(trVo.getTrId());
     	vo.setState(trVo.getState());
     	calHistoryService.insertCalHistory(vo);
     	 
		}  
     	
		return return_value;
	}

	@Override
	public int deleteTr(String trId) throws Exception {
		return trMapper.deleteTr(trId);
	}


	
	@Override
	public ArrayList<TrVO> pandingTr(int start, int end,String searchFild, String searchWord, String sortField, String sortOrder) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	     		hashmap.put("sortField", sortField);
	     		hashmap.put("sortOrder", sortOrder);
	     		hashmap.put("searchFild", searchFild);
	     		hashmap.put("searchWord", searchWord);
	     	 
	     		return trMapper.pandingTr(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

	@Override	
	public int pandingTrTotCnt(String searchFild, String searchWord) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return 0;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디
	        	//hashmap.put("userId", ((MemberVo)principal).getId());
	        	hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
				hashmap.put("searchFild", searchFild);
				hashmap.put("searchWord", searchWord);
				return trMapper.pandingTrTotCnt(hashmap);
	         } else {
	        	 return 0;
	         }
	     }
	     
	}
	
	@Override
	public ArrayList<TrVO> processedTr(int start, int end,String searchFild, String searchWord, String sortField, String sortOrder) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	     		hashmap.put("sortField", sortField);
	     		hashmap.put("sortOrder", sortOrder);
	     		hashmap.put("searchFild", searchFild);
	     		hashmap.put("searchWord", searchWord);
	     	 
	     		return trMapper.processedTr(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

	@Override	
	public int processedTrTotCnt(String searchFild, String searchWord) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return 0;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디
	        	//hashmap.put("userId", ((MemberVo)principal).getId());
	        	hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	        	hashmap.put("searchFild", searchFild);
				hashmap.put("searchWord", searchWord);
				return trMapper.processedTrTotCnt(hashmap);
	         } else {
	        	 return 0;
	         }
	     }
	     
	}

	@Override
	public String lastNumberCheck(String docId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("docId", docId);
		return trMapper.lastNumberCheck(hashmap);
	}
	
	
}
