package com.withus.boardinfo;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

 






import com.withus.boardinfo.service.BoardInfoService;
 
import com.withus.boardinfo.service.BoardInfoServiceImpl;
import com.withus.boardinfo.dao.BoardInfoVO;
import com.withus.boardlist.service.BoardListService;

/**
 * @Class Name : BoardInfoController.java
 * @Description : BoardInfo Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class VodmanBoardInfoController {

    @Autowired
    private BoardInfoService boardInfoService;
	
    @Autowired
    private BoardListService boardListService;
    
    private static final Logger LOGGER = LoggerFactory.getLogger(VodmanBoardInfoController.class);
 
    /**
	 * board_info 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 BoardInfoDefaultVO
	 * @return "/boardInfo/BoardInfoList"
	 * @exception Exception
	 */
    @RequestMapping(value="/board/infoList.do",method={RequestMethod.GET, RequestMethod.POST})
    public String selectBoardInfoList( ModelMap model) throws Exception { 
	 
        ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
     
        model.addAttribute("baordInfoList", boardInfoList); 
        
        return "/vodman/board/infoList";
    } 
    
    @RequestMapping(value="/board/addInfo.do", method=RequestMethod.GET)
    public String addBoardInfoView(ModelMap model) throws Exception {
    	
    	 ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
    	 model.addAttribute("baordInfoList", boardInfoList); 
        return "/vodman/board/infoForm";
    }
    
    @RequestMapping(value="/board/addInfo.do", method=RequestMethod.POST)
    public String addBoardInfo(
            BoardInfoVO boardInfoVO)
            throws Exception {
        boardInfoService.insertBoardInfo(boardInfoVO);
          
        return "forward:/vodman/board/infoList.do";
    }
    
    @RequestMapping("/board/infoView.do")
    public String updateBoardInfoView( int boardId, Model model)
            throws Exception {
    	
    	BoardInfoVO boardInfoVO=boardInfoService.selectBoardInfo(boardId);
    	ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
    	
   	 	model.addAttribute("baordInfoList", boardInfoList); 
        model.addAttribute("boardInfoVO",boardInfoVO);
        return "/vodman/board/infoView";
    }
 

    @RequestMapping(value="/board/updateInfo.do", method=RequestMethod.GET)
    public String updateBoardform(int boardId, Model model) throws Exception{
    	
    	BoardInfoVO boardInfoVO=boardInfoService.selectBoardInfo(boardId);
    	ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
    	
   	 	model.addAttribute("baordInfoList", boardInfoList); 
        model.addAttribute("boardInfoVO",boardInfoVO);
    	return "/vodman/board/infoForm";
    }
    
    @RequestMapping(value="/board/updateInfo.do", method=RequestMethod.POST)
    public String updateBoardInfo(
            BoardInfoVO boardInfoVO )
            throws Exception {
        boardInfoService.updateBoardInfo(boardInfoVO);
 
        return "forward:/vodman/board/infoList.do";
    }
    
    @RequestMapping("/board/deleteInfo.do")
    public String deleteBoardInfo(
    		int boardId)
            throws Exception {
        if (boardInfoService.deleteBoardInfo(boardId) > 0 ){  // 게시판 삭제
        	boardListService.deleteBoardListId(boardId);  // 게시물 삭제
        }
        return "forward:/vodman/board/infoList.do";
    }

}
