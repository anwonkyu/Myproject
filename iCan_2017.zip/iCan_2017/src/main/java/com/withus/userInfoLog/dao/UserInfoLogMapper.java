package com.withus.userInfoLog.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 



import com.withus.userInfoLog.dao.UserInfoLogVO;
 

/**
 * @Class Name : UserInfoLogDAO.java
 * @Description : UserInfoLog DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2015-01-19
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("userInfoLogMapper")
public interface UserInfoLogMapper  {

	/**
	 * user_info_log을 등록한다.
	 * @param vo - 등록할 정보가 담긴 UserInfoLogVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertUserInfoLog(UserInfoLogVO vo) throws Exception ;

 
    /**
	 * user_info_log을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 UserInfoLogVO
	 * @return void형 
	 * @exception Exception
	 */
    public void deleteUserInfoLog(String userid) throws Exception ;

    /**
	 * user_info_log을 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserInfoLogVO
	 * @return 조회한 user_info_log
	 * @exception Exception
	 */
    public UserInfoLogVO selectUserInfoLog(String userid) throws Exception ;

    /**
	 * user_info_log 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return user_info_log 목록
	 * @exception Exception
	 */
    public ArrayList<UserInfoLogVO> selectUserInfoLogList(HashMap<String, String> hashmap) throws Exception ;

    /**
	 * user_info_log 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return user_info_log 총 갯수
	 * @exception
	 */
    public int selectUserInfoLogListTotCnt(HashMap<String, String> hashmap) ;

}
