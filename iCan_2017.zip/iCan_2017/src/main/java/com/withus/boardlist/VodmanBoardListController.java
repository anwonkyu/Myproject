package com.withus.boardlist;

import java.io.File;
 
import java.text.SimpleDateFormat;
import java.util.ArrayList;
 
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
 











import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
 
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.View;











import com.ext.jfile.service.JFileDetails;
import com.ext.jfile.service.JFileService;
import com.ext.jfile.service.impl.JFileVO;
import com.withus.boardHistory.dao.BoardHistoryVO;
import com.withus.boardHistory.service.BoardHistoryService;
import com.withus.boardinfo.dao.BoardInfoVO;
import com.withus.boardinfo.service.BoardInfoService;
import com.withus.boardlist.service.BoardListService;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.boardlist.dao.BoardListVO;
 
 
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
 
import com.withus.commons.uploadFile.service.UploadFileVo;
 
import com.withus.member.dao.MemberVo;
import com.withus.memo.service.ContentMemoService;
 
 
/**
 * @Class Name : BoardListController.java
 * @Description : BoardList Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class VodmanBoardListController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardListController.class);
			
	@Autowired Properties prop;
	
    @Autowired
    private BoardListService boardListService;
    
    @Autowired
    private BoardHistoryService boardHistoryService;
    
    @Resource
    private UploadFileService uploadFileService;
    
    @Resource
	 private ContentMemoService memoService;
 
    @Resource
    private BoardInfoService boardInfoService;
    
    @Resource
    private JFileService jfileService;
    
    @Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;

 
	 @Resource
	 private PagingHelperService page;
	 
	 
    /**
	 * board_list 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 BoardListDefaultVO
	 * @return "/boardList/BoardListList"
	 * @exception Exception
	 */
    @RequestMapping(value="/board/boardList.do" ,method={RequestMethod.GET, RequestMethod.POST})
    public String selectBoardListList(Integer boardId , Integer curPage,String searchFild,  String searchWord, Model model, String hcode)
            throws Exception {
    	
    	if (boardId == null) return null;
    	
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = ""; 
		
		int seq = 0; 
		if (boardId != null ) {
			seq = Integer.parseInt(boardId.toString().substring(0, 1)); 
		} 
 
 
		
		//int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		//int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
	 
		int totalRecord = boardListService.selectBoardListListTotCntVodman(boardId, searchFild, searchWord, hcode);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks(); 
		
		BoardInfoVO boardInfo = boardInfoService.selectBoardInfo(boardId);
	 
		model.addAttribute("boardInfo", boardInfo );   //게시판 정보

		// 게시물 전체
        ArrayList<BoardListVO> boardListList = boardListService.selectBoardListListVodman(boardId, searchFild,  searchWord, start, end, hcode);
        model.addAttribute("resultList", boardListList);  
        
        //공지 게시물 (open_space=Y)
        ArrayList<BoardListVO> boardListList_notice = boardListService.selectBoardListList_notice(boardId);

       //leftMenu 게시판 목록
        ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
        
        model.addAttribute("resultList_notice", boardListList_notice);  
        
		model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("hcodes", hcode);
		model.addAttribute("boardInfoList", boardInfoList);
		
		
		
        return "/vodman/board/boardList";
    } 
    
    @RequestMapping(value="/board/listWrite.do", method=RequestMethod.GET)
    public String addBoardListView(@RequestParam(value="boardId" ,required=true) Integer boardId, Model model, String mode)  throws Exception {
  
        BoardInfoVO boardInfo = new BoardInfoVO();

        //leftMenu 게시판 목록
        ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
        
        if (boardId != null && boardId > 0) {
        	boardInfo = boardInfoService.selectBoardInfo(boardId);
        } else {
        	return null;
        }
        model.addAttribute("mode", mode);
        model.addAttribute("boardInfo", boardInfo);
    	model.addAttribute("boardInfoList", boardInfoList);
    	
        return "/vodman/board/listWrite";
    } 
    
    @RequestMapping(value="/board/listWrite.do", method=RequestMethod.POST)
    public String addBoardListMult(MultipartHttpServletRequest mpRequest, @ModelAttribute("boardListVO") BoardListVO boardListVO)
            throws Exception {
//    	BoardInfoVO boardInfo = new BoardInfoVO();
//		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());

		int result_value = 	 boardListService.insertBoardList(boardListVO);    
 
         
         /* return "forward:/vodman/board/boardList.do?boardId="+boardListVO.getBoardId();*/
          return "redirect:boardList.do?boardId="+boardListVO.getBoardId();
     }
    
    @RequestMapping(value="/board/listView.do", method=RequestMethod.GET)
    public String updateBoardListView(
            @RequestParam(value="listId",required=true) Integer listId, Integer curPage , String searchFild, String searchWord,Integer memoCurPage, Model model)
            throws Exception {  
    	
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";

        BoardListVO boardListVO= boardListService.selectBoardListVodman(listId);
 
        model.addAttribute("boardListVO", boardListVO);
    	BoardInfoVO boardInfo = new BoardInfoVO();
		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
		model.addAttribute("boardInfo", boardInfo);
		
 
		model.addAttribute("curPage", curPage); 
 
		  /*

				* 첨부파일 정보 읽어 오기
				 */  

				/*List<UploadFileVo> uploadFileList = uploadFileService.getUploadFileList(boardListVO.getListId().toString(),"B" ); 
				model.addAttribute("uploadFileList", uploadFileList);  // 파일목록   */
		
				if(boardListVO.getJfile() != null){
				List<JFileDetails> jfileVo = jfileService.getAttachFiles(boardListVO.getJfile());
				model.addAttribute("jfileList", jfileVo);  // 파일목록
				}
				//leftMenu 게시판 목록 
		        ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
		    	model.addAttribute("boardInfoList", boardInfoList); 
		  if(boardListVO.getListReLevel() == 0){
			  return "/vodman/board/listView";
		  }else{
			  return "/vodman/board/listViewReply";
		  }
    }
    
    
    @RequestMapping(value="/board/listUpdate.do", method=RequestMethod.GET)
    public String updateBoardListUpdate(
            @RequestParam(value="listId" ,required=true)Integer listId, @RequestParam(value="boardId" ,required=true)Integer boardId, Integer curPage , String searchFild, String searchWord , Model model, String mode)
            throws Exception {  
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		
        BoardListVO boardListVO= boardListService.selectBoardListVodman(listId);
        
        /*

		 * 첨부파일 정보 읽어 오기
		 */ 
 
		/*List<UploadFileVo> uploadFileList = uploadFileService.getUploadFileList(boardListVO.getListId().toString(),"B" ); 
		model.addAttribute("uploadFileList", uploadFileList);  // 파일목록   */

		if(boardListVO.getJfile() != null){
		List<JFileDetails> jfileVo = jfileService.getAttachFiles(boardListVO.getJfile());
		model.addAttribute("jfileList", jfileVo);  // 파일목록
		}

		 //leftMenu 게시판 목록
		BoardInfoVO boardInfo = new BoardInfoVO();
        ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
        if (boardId != null && boardId > 0) {
        	boardInfo = boardInfoService.selectBoardInfo(boardId);
        } else {
        	return null;
        }
        model.addAttribute("boardInfoList", boardInfoList);
        model.addAttribute("boardInfo", boardInfo);
        model.addAttribute("boardListVO", boardListVO);
        model.addAttribute("searchWord", searchWord);
        model.addAttribute("searchFild", searchFild);
        model.addAttribute("curPage", curPage);
        model.addAttribute("mode", mode);
        if(boardListVO.getListReLevel() == 0){
        	return "/vodman/board/listWrite";
        }else{
        	return "/vodman/board/listWriteReply";
        }
    }
    
    @RequestMapping(value="/board/listUpdate.do", method=RequestMethod.POST)
    public String updateBoardList(MultipartHttpServletRequest mpRequest,
    		@ModelAttribute("boardListVO") BoardListVO boardListVO, Integer curPage , String searchFild, String searchWord ,
    		Model model
            ) throws Exception {
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = ""; 

		int result_value = boardListService.updateBoardList(boardListVO);
      
        return "forward:/vodman/board/boardList.do?boardId="+boardListVO.getBoardId();
    			
    }

//    @RequestMapping(value="/listUpdate.do", method=RequestMethod.POST)
//    public String updateBoardList(MultipartHttpServletRequest mpRequest,
//    		@ModelAttribute("boardListVO") BoardListVO boardListVO, int curPage , String searchFild, String searchWrod 
//            ) throws Exception {
//    	
//    	
//        boardListService.updateBoardList(boardListVO);
//        

//      //파일업로드
//		Iterator<String> it = mpRequest.getFileNames();
// 
//		while (it.hasNext()) {
//				MultipartFile multiFile = mpRequest.getFile((String) it.next());
//	 
//				String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename());
//				multiFile.transferTo(new File(WebContants.BASE_PATH + filename));
// 
//				
//				UploadFileVo attachFile = new UploadFileVo();
//				attachFile.setFile_name(filename);
//				attachFile.setOrg_name(multiFile.getOriginalFilename());
//				attachFile.setFile_size(multiFile.getSize());
//				attachFile.setOcode(boardListVO.getSeq()+"");
//				attachFile.setFlag("B");
//				
//				if ( multiFile.getSize() > 0 && multiFile.getOriginalFilename() != null ) {
//					 
//					if (multiFile.getName() != null && multiFile.getName().equals("thumbnail") ) {
//						attachFile.setType("I"); // 이미지 파일 
//					} else {
//						attachFile.setType("N"); //  일반 파일 
//					}
//					
//					uploadFileService.insertAttachFile(attachFile);
//				} 
//		} 
//		
// 
//        return "forward:/board/boardList.do?curPage="+curPage
//        		+ "&searchFild=" + searchFild 
//    			+ "&serchWrod=" + searchWrod ;
//    			
//    }
    
    @RequestMapping("/board/listDelete.do")
    public String deleteBoardList( @ModelAttribute("boardListVO")
            BoardListVO boardListVO )
            throws Exception { 
     
 
    	boardListVO = boardListService.selectBoardListVodman(boardListVO.getListId());
    	int listReLevel = boardListVO.getListReLevel();
    	int listStep = boardListVO.getListStep();
    	BoardListVO selectCheckLow = boardListService.selectCheckRow(boardListVO.getListRef(), listReLevel+1, listStep+1);
    	int checkLow = selectCheckLow.getListId();

//    	BoardInfoVO boardInfo = new BoardInfoVO();
//		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
    	if(checkLow == 0){

		 if (boardListService.deleteBoardList(boardListVO) > 0 ){ 
			//파일 삭제
			//  uploadFileService.deleteFileAll(boardListVO.getListId()+"", "B");
		 }
    	}

		 return "forward:/vodman/board/boardList.do?boardId="+boardListVO.getBoardId();
    }
    
    @RequestMapping(value="/board/listReply.do", method=RequestMethod.GET)
    public String addBoardListReplyForm(
            @RequestParam(value="listId",required=true)Integer listId, @RequestParam(value="boardId",required=true)Integer boardId, Integer curPage , String searchFild, String searchWord , Model model)
            throws Exception {  
    	
    	if (curPage == null) curPage = 1;
    	if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		
        BoardListVO boardListVO= boardListService.selectBoardListVodman(listId);
        
        /*

		 * 첨부파일 정보 읽어 오기
		 */ 
        
//		List<UploadFileVo> uploadFileList = uploadFileService.getUploadFileList(boardListVO.getListId().toString(),"B" ); 
//		model.addAttribute("uploadFileList", uploadFileList);  // 첨부파일		

		if(boardListVO.getJfile() != null){
		List<JFileDetails> jfileVo = jfileService.getAttachFiles(boardListVO.getJfile());
		model.addAttribute("jfileList", jfileVo);  // 파일목록
		}
		 //leftMenu 게시판 목록
		BoardInfoVO boardInfo = new BoardInfoVO();
        ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
        if (boardId != null && boardId > 0) {
        	boardInfo = boardInfoService.selectBoardInfo(boardId);
        } else {
        	return null;
        }

      //답글 등록 일경우
      	boardListVO.setListTitle("");
      	boardListVO.setListContents("");
        model.addAttribute("boardInfoList", boardInfoList);
        model.addAttribute("boardInfo", boardInfo);
        model.addAttribute("boardListVO", boardListVO);
        model.addAttribute("searchWord", searchWord);
        model.addAttribute("searchFild", searchFild);
        model.addAttribute("curPage", curPage);
        return "/vodman/board/listWriteReply";
    }
    
    @RequestMapping(value="/board/listReply.do", method=RequestMethod.POST)
    public String addBoardListReply(MultipartHttpServletRequest mpRequest, @ModelAttribute("boardListVO") BoardListVO boardListVO)
            throws Exception {
    	
//    	BoardInfoVO boardInfo = new BoardInfoVO();
//		boardInfo = boardInfoService.selectBoardInfo(boardListVO.getBoardId());
		
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		String userId = "";
		 
		if(principal != null && principal instanceof MemberVo){  
			userId = ((MemberVo)principal).getUsername() ; // 로그인 사용자 ID set
			boardListVO.setMem_id(userId);
		}
		int result_value = 	 boardListService.insertBoardListReply(boardListVO);    
 
        // return "forward:/vodman/board/boardList.do?boardId="+boardListVO.getBoardId();
		return "redirect:/vodman/board/boardList.do?boardId="+boardListVO.getBoardId();
     }
    
    @RequestMapping(value="/boardHistory/list.do")
    public String boardHistoryList( String state , Integer curPage,String searchFild,  String searchWord, Model model)
            throws Exception {
    	/*if (String.valueOf(listId)== "" || listId==null){
    		return "redirect:/vodman//board/boardList.do";
    	}*/
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		int totalRecord = boardHistoryService.selectBoardHistoryListTotCnt(state, searchFild, searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		ArrayList<BoardInfoVO> boardInfoList = boardInfoService.selectBoardInfoList();
        ArrayList<?> boardHistoryList = boardHistoryService.selectBoardHistoryList(state, searchFild, searchWord, start, end);
        model.addAttribute("resultList", boardHistoryList);
        model.addAttribute("boardInfoList", boardInfoList);
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
        return "vodman/board/boardHistoryList";
    }
    
    

}


