package com.withus.memo.dao;

/**
 * @Class Name : ContentMemoVO.java
 * @Description : ContentMemo VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class ContentMemoVO {
    
    
    /** muid */
    private Integer muid;
    
    /** ocode */
    private String calnoteId;
    
    /** id */
    private String id;
    
    /** wdate */
    private String wdate;
    
    /** comment */
    private String contents;
    
    /** wname */
    private String wname;
    
    /** ip */
    private String ip;
    
    private String state;
    
    private String delFlag;
    
    private Integer parentMuid;
    
    private Integer step;
    
    private String flag;
    
    private boolean system;
    
    
    

	public boolean getSystem() {
		return system;
	}

	public void setSystem(boolean system) {
		this.system = system;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Integer getStep() {
		return step;
	}

	public void setStep(Integer step) {
		this.step = step;
	}

	public Integer getParentMuid() {
		return parentMuid;
	}

	public void setParentMuid(Integer parentMuid) {
		this.parentMuid = parentMuid;
	}

 
	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Integer getMuid() {
        return this.muid;
    }
    
    public void setMuid(Integer muid) {
        this.muid = muid;
    }
    
    public String getId() {
        return this.id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
     
    

	public String getCalnoteId() {
		return calnoteId;
	}

	public void setCalnoteId(String calnoteId) {
		this.calnoteId = calnoteId;
	}

	public String getWdate() {
        return this.wdate;
    }
    
    public void setWdate(String wdate) {
        this.wdate = wdate;
    }
    
   
    public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getWname() {
        return this.wname;
    }
    
    public void setWname(String wname) {
        this.wname = wname;
    }
    
    public String getIp() {
        return this.ip;
    }
    
    public void setIp(String ip) {
        this.ip = ip;
    }

	@Override
	public String toString() {
		return "ContentMemoVO [muid=" + muid + ", calnoteId=" + calnoteId
				+ ", id=" + id + ", wdate=" + wdate + ", contents=" + contents
				+ ", wname=" + wname + ", ip=" + ip + ", state=" + state
				+ ", delFlag=" + delFlag + ", parentMuid=" + parentMuid
				+ ", step=" + step + "]";
	}
 
    
}
