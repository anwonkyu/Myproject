package com.withus.category.dao;

/**
 * @Class Name : CategoryVO.java
 * @Description : Category VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2011-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class CategoryVO {
   
    /** cuid */
    private Integer cuid;
    
    /** ctype */
    private String ctype;
    
    /** ccode */
    private String ccode;
    
    /** cparent_code */
    private String cparentCode;
    
    /** ctitle */
    private String ctitle;
    
    /** clevel */
    private Integer clevel;
    
    /** cinfo */
    private String cinfo;
    
    /** del_flag */
    private String delFlag;
    
    /** openflag */
    private String openflag;
    
    /** memo */
    private String memo;
    
    private String flag2;
    
    
    
    public String getFlag2() {
		return flag2;
	}

	public void setFlag2(String flag2) {
		this.flag2 = flag2;
	}

	public Integer getCuid() {
        return this.cuid;
    }
    
    public void setCuid(Integer cuid) {
        this.cuid = cuid;
    }
    
    public String getCtype() {
        return this.ctype;
    }
    
    public void setCtype(String ctype) {
        this.ctype = ctype;
    }
    
    public String getCcode() {
        return this.ccode;
    }
    
    public void setCcode(String ccode) {
        this.ccode = ccode;
    }
    
    public String getCparentCode() {
        return this.cparentCode;
    }
    
    public void setCparentCode(String cparentCode) {
        this.cparentCode = cparentCode;
    }
    
    public String getCtitle() {
        return this.ctitle;
    }
    
    public void setCtitle(String ctitle) {
        this.ctitle = ctitle;
    }
    
    public Integer getClevel() {
        return this.clevel;
    }
    
    public void setClevel(Integer clevel) {
        this.clevel = clevel;
    }
    
    public String getCinfo() {
        return this.cinfo;
    }
    
    public void setCinfo(String cinfo) {
        this.cinfo = cinfo;
    }
    
    public String getDelFlag() {
        return this.delFlag;
    }
    
    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag;
    }
    
    public String getOpenflag() {
        return this.openflag;
    }
    
    public void setOpenflag(String openflag) {
        this.openflag = openflag;
    }
    
    public String getMemo() {
        return this.memo;
    }
    
    public void setMemo(String memo) {
        this.memo = memo;
    }

	@Override
	public String toString() {
		return "CategoryVO [cuid=" + cuid + ", ctype=" + ctype + ", ccode="
				+ ccode + ", cparentCode=" + cparentCode + ", ctitle=" + ctitle
				+ ", clevel=" + clevel + ", cinfo=" + cinfo + ", delFlag="
				+ delFlag + ", openflag=" + openflag + ", memo=" + memo
				+ ", flag2=" + flag2 + "]";
	}

 
    
}
