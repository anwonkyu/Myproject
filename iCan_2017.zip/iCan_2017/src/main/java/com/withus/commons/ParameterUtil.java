package com.withus.commons;

import java.util.Map;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;

/**
 * Parameter Utility Class.
 */
public class ParameterUtil {

	/**
	 * Parameter정보를 조회한다.
	 * @param request HttpServletRequest 객체
	 * @return Parameter정보 Map
	 */
	public static Map getParameterMap(HttpServletRequest request) {
		Map map = new HashMap();
		try {
			//1) 파라미터정보를 Map에 담는다.
			Map paramerterMap = request.getParameterMap();
			Iterator iter = paramerterMap.keySet().iterator();
			String key = null;
			String[] value = null;
			while (iter.hasNext()) {
				key = (String) iter.next();
				value = (String[]) paramerterMap.get(key);

				if (value.length > 1) {
					map.put(key, value);
				} else {
					map.put(key, value[0]);
				}
			}
			//2) 세션정보를 파라미터에 담는다.(사용자정보를 쿼리에서 사용하는 경우가 많으므로)
			HttpSession session = request.getSession();
			//AuthController확인(SESS_USER라는 명칭으로 세션에 사용자정보 저장되어 있다고 가정)
			if (session != null && session.getAttribute("SESS_USER") != null) {
				Map user = (Map) session.getAttribute("SESS_USER");
				map.putAll(user);
			}
		} catch (Exception e) {
			System.out.println("            <<< ParameterUtil - getParameterMap(HttpServletRequest request) >>>");
			System.out.println("            " + e.getMessage());
		}
		return map;
	}

	/**
	 * 빈(Empty) Map을 가져온다.
	 *
	 * @param resultColumns Map Columns 명
	 * @return 빈(Empty) Map
	 */
	public static Map getEmptyResult(String resultColumns) {
		Map map = null;
		if (resultColumns != null && !resultColumns.equals("")) {
			map = new HashMap();
			String[] columns = StringUtils.split(resultColumns, ",");
			for (int i = 0; i < columns.length; i++) {
				map.put(columns[i], "");
			}
		}
		return map;
	}
}
