package com.withus.buseo.dao;

/**
 * @Class Name : BuseoVO.java
 * @Description : Buseo VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class BuseoVO {
     
    /** binx */
    private Integer binx;
    
    /** buseo_code */
    private String buseoCode;
    
    /** buseo_name */
    private String buseoName;
    
    /** buseo_comment */
    private String buseoComment;
    
    /** buseo_sosok */
    private String buseoSosok;
    
    public Integer getBinx() {
        return this.binx;
    }
    
    public void setBinx(Integer binx) {
        this.binx = binx;
    }
    
    public String getBuseoCode() {
        return this.buseoCode;
    }
    
    public void setBuseoCode(String buseoCode) {
        this.buseoCode = buseoCode;
    }
    
    public String getBuseoName() {
        return this.buseoName;
    }
    
    public void setBuseoName(String buseoName) {
        this.buseoName = buseoName;
    }
    
    public String getBuseoComment() {
        return this.buseoComment;
    }
    
    public void setBuseoComment(String buseoComment) {
        this.buseoComment = buseoComment;
    }
    
    public String getBuseoSosok() {
        return this.buseoSosok;
    }
    
    public void setBuseoSosok(String buseoSosok) {
        this.buseoSosok = buseoSosok;
    }
    
}
