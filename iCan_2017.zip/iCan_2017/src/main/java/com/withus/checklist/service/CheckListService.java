package com.withus.checklist.service;

import java.util.ArrayList;
import java.util.Map;
 
public interface CheckListService {

	int check_list_update(Map parameter) throws Exception;

	ArrayList<?> selectCheckList(String type,String user)throws Exception;

}
