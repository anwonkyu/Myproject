package com.withus.category.service;

import java.util.ArrayList;
import java.util.List;
 








import com.withus.category.dao.CategoryVO;
 

/**
 * @Class Name : CategoryService.java
 * @Description : Category Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2011-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface CategoryService {
	
	/**
	 * category을 등록한다.
	 * @param vo - 등록할 정보가 담긴 CategoryVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    int insertCategory(CategoryVO vo) throws Exception;
    
    /**
	 * category을 수정한다.
	 * @param vo - 수정할 정보가 담긴 CategoryVO
	 * @return void형
	 * @exception Exception
	 */
    int updateCategory(CategoryVO vo) throws Exception;
    
    /**
	 * category을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 CategoryVO
	 * @return void형 
	 * @exception Exception
	 */
    int deleteCategory(int cuid) throws Exception;
    
    /**
	 * category을 조회한다.
	 * @param vo - 조회할 정보가 담긴 CategoryVO
	 * @return 조회한 category
	 * @exception Exception
	 */
    CategoryVO selectCategory(int cuid) throws Exception;
    
    /**
	 * category 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return category 목록
	 * @exception Exception
	 */
    ArrayList<CategoryVO> selectCategoryList(String ccode, String ctype) throws Exception;
    
    /**
	 * category 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return category 총 갯수
	 * @exception
	 */
    int selectCategoryListTotCnt(String ccode, String ctype);
    
    public ArrayList<CategoryVO> selectCategoryList_child(String ccode, String ctype) throws Exception;
    
	public String getCateNm(String ccode, String ctype)throws Exception;
	
	public String getDeptCode(String cinfo, String ctype, String ctitle)throws Exception;
	
	public String getCateNmAll(String ccode, String ctype)throws Exception;
	
	public ArrayList<CategoryVO> selectCategoryList_cinfo(String ccode, String ctype, String cinfo) throws Exception;
	public ArrayList<CategoryVO> selectCategoryList_open(String ccode, String ctype, String cinfo) throws Exception;
	public ArrayList<CategoryVO> selectCategoryList_Count(String ccode, String ctype, String cinfo) throws Exception;
	
	
	public ArrayList<CategoryVO> selectCategoryList_Menu(String cinfo) throws Exception;
	
	public String getMenuNm(String ccode )throws Exception;
	public String getMenuNmAll(String ccode )throws Exception;

	public String getMenuCode(String ccode, String type)throws Exception;
	public String getMenuCode2(String selectCode, String menuCode, int boardId)throws Exception;

	ArrayList<CategoryVO> selectCode_flag2(String flag2)throws Exception;
	
	public String getCate_listNameAll(String ccode, String ctype)throws Exception;
    
}
