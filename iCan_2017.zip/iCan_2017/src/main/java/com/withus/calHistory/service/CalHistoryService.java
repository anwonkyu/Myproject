package com.withus.calHistory.service;

import java.util.ArrayList;

import org.springframework.transaction.annotation.Transactional;

import com.withus.calHistory.dao.CalHistoryVO;

public interface CalHistoryService {

	int insertCalHistory(CalHistoryVO vo) throws Exception;
	
	ArrayList<CalHistoryVO> selectCalHistoryList(String calnoteId, String ctype, String searchFild, String searchWord,int start, int end) throws Exception;
	
	int selectCalHistoryListTotCnt(String calnoteId, String state, String searchFild, String searchWord)throws Exception;

	ArrayList<?> selectCalHistoryListAll(String calnoteId,String ctype)throws Exception;


}
