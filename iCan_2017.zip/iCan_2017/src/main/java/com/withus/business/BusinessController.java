package com.withus.business;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.business.dao.BusinessVO;
import com.withus.business.service.BusinessService;
import com.withus.commons.XmlResult;
@Controller
@RequestMapping("/business")
public class BusinessController {
	
	private static final Logger logger = LoggerFactory.getLogger(VodmanBusinessController.class);
	
	@Autowired
    private BusinessService businessService;
	
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;
	
    @RequestMapping(value="/selectbox.do", method={RequestMethod.GET, RequestMethod.POST})
    public @ResponseBody Map<?,?> auto3() throws Exception {
    	Map< String, Object> map = new HashMap< String, Object>();
    	String flag="";
    	map.put("data", businessService.AllBusinessList(flag));
    	return map;
    }
    
 
    
    @RequestMapping(value="/etcCheck.do", method={RequestMethod.GET, RequestMethod.POST})
    public View checkDocId(Model model, String bizCd ) throws Exception {
     
    	BusinessVO businessVo = businessService.getBusiness(bizCd); 
    	
    	String returnValue = "";
    	
    	returnValue =  businessVo.getBizEtc()+"/"
    	+businessVo.getPlantCd()+"/"
    	+businessVo.getUnitNum()+"/"
    	+businessVo.getChngCoreCycleNum();
		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
    	xml.setMessage(returnValue);
 	    xml.setError(true);
	    model.addAttribute("xmlData", xml);
	    return xmlView;
    	}
    
}
