package com.old.test.service;

import java.util.ArrayList;
 


 
import com.old.test.dao.TestVo;
import com.withus.commons.paging.PagingHelperService;
 
 
public interface TestService  {
	 
	public TestVo test()throws Exception;
	 
	
}


