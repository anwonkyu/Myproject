package com.withus.commons;
 
import java.util.ArrayList;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.withus.buseo.dao.BuseoVO;
import com.withus.buseo.service.BuseoService;
import com.withus.member.dao.MemberVo;

public class SessionInterceptor extends HandlerInterceptorAdapter {

	private static final Logger logger = LoggerFactory.getLogger(SessionInterceptor.class);

	@Autowired
	private BuseoService buseoService;
	
	@Autowired Properties prop;
	 
	 public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
  
		 
		 String requestURI = request.getRequestURI();

				if (requestURI.indexOf("/member/sessionCreate.do") > -1 
						|| requestURI.indexOf("/member/sessionCreate2.do") > -1) { 
					//세션체크 예외페이지
	        		return true;
		  			 
		  		 } else {
		  			 HttpSession session = request.getSession();
			  	      MemberVo memberVo = (MemberVo)session.getAttribute(prop.getProperty("USER_KEY").trim());
			  	        
			  		 ArrayList<BuseoVO> buseoVoList = buseoService.selectBuseoListAll();
			  		 // 세션에서 로그인 정보가 없을 경우 웹페이지 접근 자체를 막아 버림 
			   		 
			  		 if (memberVo != null && memberVo.getName().length() > 0 ) {
			  			 
			  			 if (buseoVoList != null) {
			  			 
			  				 for (int i = 0; i < buseoVoList.size(); i++) {
			  					 
			  					 if (memberVo.getBuseo().equals(buseoVoList.get(i).getBuseoCode() )) { 
			  						 // 시청 권한이 없음
			  						 request.getRequestDispatcher(request.getContextPath() + "/out.jsp").forward(request, response);
			  						 return false;
			  					 } 
			  				 }
			  			 } 
			  			 return true;
		  		 } else {
		  			 request.getRequestDispatcher(request.getContextPath() + "/out.jsp").forward(request, response);
					 return false;
		  		 }
		   
	        }  
		 
		 
		 //uri 별로 로그인 처리
/*
	        String requestURI = request.getRequestURI();

	        if (requestURI.indexOf("/main/main.do") > -1) { //세션체크 예외페이지
	        	return true;
	        } else if (requestURI.indexOf("/video/view.do") > -1) {
	        	return true;
	        } else if (requestURI.indexOf("/radio/radioOnAir.do") > -1) {
	        	return true;
	        } else if (requestURI.indexOf("/member/login.do") > -1) {
	        	return true;
	        } else if (requestURI.indexOf("/member/login_ok.do") > -1) {
	        	return true;
	        } else {//위의 예외페이지 외에는 세션값을 체크해서 있으면 그냥 페이지표시
	        	// session검사
		        if (memberVo != null && !memberVo.getId().isEmpty()) {
		        	return true;
		        } else {
		        	//정상적인 세션정보가 없으면 로그인페이지로 이동
		        	request.getRequestDispatcher(request.getContextPath() + "/member/login.do").forward(request, response);
		        	//response.sendRedirect("/member/login.do");
		        	return false;
		        }
	        }
*/
	        
	       }
}
