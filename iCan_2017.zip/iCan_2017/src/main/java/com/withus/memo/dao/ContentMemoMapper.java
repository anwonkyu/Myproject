package com.withus.memo.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 



import com.withus.memo.dao.ContentMemoVO;
 
/**
 * @Class Name : ContentMemoDAO.java
 * @Description : ContentMemo DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("contentMemoMapper")
public interface ContentMemoMapper
{

	/**
	 * content_memo을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ContentMemoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertContentMemo(ContentMemoVO vo) throws Exception;
    
    public int replyContentMemo(ContentMemoVO vo) throws Exception;

    /**
	 * content_memo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 ContentMemoVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateContentMemo(ContentMemoVO vo) throws Exception ;
    public int updateContentMemoFlag(ContentMemoVO vo) throws Exception ;
    /**
	 * content_memo을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ContentMemoVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteContentMemo(ContentMemoVO vo) throws Exception ;
    
    public int deleteContentMemoUser(ContentMemoVO vo) throws Exception ;

    public ContentMemoVO selectContentMemoFlag(HashMap<String, String> hashmap)throws Exception ;
    
    public int comment_check(ContentMemoVO vo) throws Exception ;
    
    
    /**
	 * content_memo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ContentMemoVO
	 * @return 조회한 content_memo
	 * @exception Exception
	 */
    public ContentMemoVO selectContentMemo(int muid) throws Exception;

    /**
	 * content_memo 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return content_memo 목록
	 * @exception Exception
	 */
    public ArrayList<ContentMemoVO> selectContentMemoList(HashMap<String, String> hashmap) throws Exception;
    /**
	 * content_memo 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return content_memo 총 갯수
	 * @exception
	 */
    public int selectContentMemoListTotCnt(HashMap<String, String> hashmap);

	public ContentMemoVO codceComment_select(HashMap<String, String> hashmap);

}
