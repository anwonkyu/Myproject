package com.withus.member;
 
import java.io.File;
import java.util.Iterator;
import java.util.List;
 
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.category.service.CategoryService;
import com.withus.commons.WebContants;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileVo;
import com.withus.member.service.MemberService;
import com.withus.member.dao.MemberVo;

import org.springframework.oxm.xstream.XStreamMarshaller;

 
@Controller
@RequestMapping("/member")
public class MemberColtroller {

private static final Logger logger = LoggerFactory.getLogger(MemberColtroller.class);
	
	@Autowired
	private MemberService memberService;
	
	@Resource(name = "categoryService")
    private CategoryService categoryService;
	
	@Autowired Properties prop;
	
	@Resource
	private PagingHelperService page;
 
	@Resource(name = "xstreamMarshaller")
	private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView;

	
//	@RequestMapping(value="/login.do", method=RequestMethod.GET)
//	public String login(){
//		return "/member/login";		
//	}
	
	@RequestMapping(value="/logout.do", method=RequestMethod.GET)
	public String logout(HttpSession session){
		session.invalidate();
		return "/member/login";		
	}
	
	// 일반 로그인 사용 (스프링 시큐리티사용시 적용하면 오류)
	 
	@RequestMapping(value="/login2.do", method=RequestMethod.POST)
	public String login(@RequestParam(value="id" )String id, @RequestParam(value="pwd")String pwd ){
		
		HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession(false);
		
		MemberVo memberVo = memberService.login(id, pwd);
		
		if (memberVo != null) {
		 
 			session.setAttribute(prop.getProperty("USER_KEY"), memberVo);
			
			//return "member.changePasswd";
			return "redirect:/main/main.do";
		} else {
			System.out.println("login-실패");
			return "/member/login2";
		}
	}
	 
 
	@RequestMapping(value="/view.do", method=RequestMethod.GET)
	public String memberView(String id, 
			 
			Model model) throws Exception {
 
		//상세보기 
		MemberVo memberVo = memberService.memberInfo(id);
 
		model.addAttribute("thisMember", memberVo);   
	 

		return "/member/view";
	}
	
	
	@RequestMapping(value="/write.do", method=RequestMethod.GET)
	public String write( Model model) throws Exception {
 
		return "/member/writeform";
	}
	
/*
	@RequestMapping(value="/write.do", method=RequestMethod.POST)
	public String write(@ModelAttribute("memberVo") MemberVo memberVo) {
//public String write(@ModelAttribute("memberVo") MemberVo memberVo, Principal principal) {		
		//Principal principal 인증 정보 저장 객체
		
		memberService.insert(memberVo);
		//return "redirect:/member/list.do";
		return "redirect:/main/main.do";
	}
*/	
	
	@RequestMapping(value="/write.do", method=RequestMethod.POST)
	public View write(@ModelAttribute("memberVo") MemberVo memberVo, Model model ) throws Exception {
	//public String write(@ModelAttribute("memberVo") MemberVo memberVo, Principal principal) {		
		//Principal principal 인증 정보 저장 객체
	 
		   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     if ( memberService.insert(memberVo) > 0) {
			        xml.setMessage("등록 되었습니다.");
			        xml.setError(true);
		       
		    } else {
		    	 xml.setMessage("등록에 실패하였습니다.");
		 	     xml.setError(false);
		    }

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
	 
	
	@RequestMapping(value="/update.do", method=RequestMethod.GET)
	public String modify(String id, 
			Model model) throws Exception {
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 

			String vod_id = ((MemberVo)principal).getUsername();
			
			MemberVo thisMember = memberService.memberInfo(vod_id);
			//수정페이지에서의 보일 게시글 정보
			model.addAttribute("thisMember", thisMember);
		 
			return "/member/writeform";
		} else {
			return "redirect:/login.do";
		}
		
		
	}
	
/*	
	@RequestMapping(value="/update.do", method=RequestMethod.POST)
	public String modify( @ModelAttribute("memberVo") MemberVo memberVo, Integer curPage,String searchFild, String searchWord) throws Exception {
 
		if (curPage == null) curPage = 1;
		if (searchFild == null) searchFild = "";  
		if (searchWord == null) searchWord = "";  
	
		memberService.update(memberVo); 
		
//		searchWord = URLEncoder.encode(searchWord,"UTF-8");
		return "redirect:/member/view.do?id=" + memberVo.getId() 
			+ "&curPage=" + curPage 
			+ "&searchFild=" + searchFild
			+ "&searchWord=" + searchWord;
		//return "list";
 	}

	 */
	
	@RequestMapping(value="/pwd_change.do", method=RequestMethod.GET)
	public String pwdChange( 
			Model model) throws Exception { 
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 

			String vod_id = ((MemberVo)principal).getUsername();
			
			MemberVo thisMember = memberService.memberInfo(vod_id);
			 
			//수정페이지에서의 보일 게시글 정보
			model.addAttribute("thisMember", thisMember);
	 		
			return "/member/pwdChange";
		} else {
			return "redirect:/login.do";
		} 
	 
	}
	
	 @RequestMapping(value="/pwdUpdate.do", method=RequestMethod.POST)
		public View pwdUpdate(@RequestParam(value="userpassword",required=true) String pwd, @RequestParam(value="old_pwd",required=true) String old_pwd,
				Model model ) throws Exception { 
		 
		 	XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
 
			     if ( memberService.pwdUpdate_user(pwd, old_pwd) > 0) {
				        xml.setMessage("수정 되었습니다.");
				        xml.setError(true); 
			    } else {
			    	xml.setMessage("수정에 실패하였습니다.");
			 	    xml.setError(false);
			    }  
			  model.addAttribute("xmlData", xml);
			  return xmlView;
		}
	 
	
	

	@RequestMapping(value="/update.do", method=RequestMethod.POST)
	public View update(MultipartHttpServletRequest mpRequest, @ModelAttribute("memberVo") MemberVo memberVo, Model model, String attachDel ) throws Exception {
	//public String write(@ModelAttribute("memberVo") MemberVo memberVo, Principal principal) {		
		//Principal principal 인증 정보 저장 객체
 
			Iterator<String> it = mpRequest.getFileNames();
			
			if (attachDel != null && attachDel.equals("Y")) {
				memberVo.setSsn("");
			}

			while (it.hasNext()) {
					MultipartFile multiFile = mpRequest.getFile((String) it.next()); 

						if (multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename())  
							//	&& com.withus.commons.TextUtil.isFileCheck(multiFile.getContentType())
							) { // 파일 체크 
							File file = new File(prop.getProperty("SIGN_PATH").trim()+File.separator + memberVo.getId()+File.separator );
							if (!file.exists())
								file.mkdirs();
							
							String filename = UploadUtil.getUniqueFileName_ext(multiFile.getOriginalFilename());
 
							multiFile.transferTo(new File(prop.getProperty("SIGN_PATH").trim()+File.separator + memberVo.getId()+File.separator + filename));
							memberVo.setSsn(filename);
						}
			}
		   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     if ( memberService.update(memberVo) > 0) {
			        xml.setMessage(memberVo.getId());
			        xml.setError(true);
		       
		    } else {
		    	 xml.setMessage(memberVo.getId());
		 	     xml.setError(false);
		    }

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
	//id:"admin", name:"관리자", buseo:"1234", gray:"5678"
	//세션 생성 로그인 테스트
		@RequestMapping(value="/sessionCreate.do", method={RequestMethod.POST})
		public String sessionCreate(@RequestParam(value="id" ,required=true)String id, @RequestParam(value="name")String name , 
				@RequestParam(value="buseo")String buseo, @RequestParam(value="gray")String gray ){
			//System.out.println("sessionCreate-------------");
			
			HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			HttpSession session = req.getSession(false);
			
			MemberVo memberVo = new MemberVo();
			
			memberVo.setId(id);
			memberVo.setName(name);
			memberVo.setBuseo(buseo);
			memberVo.setGray(gray); 
 
				//session.setAttribute(WebContants.USER_KEY, memberVo);
				session.setAttribute(prop.getProperty("USER_KEY").trim(), memberVo); 
				return "redirect:/"; 
		}
		
		@RequestMapping(value="/sessionCreate2.do", method=RequestMethod.POST)
		public String sessionCreate2(HttpServletRequest req  ){
			
		 	HttpSession session = req.getSession(false); 
			if(  session.getAttribute("sid") == null || ((String) session.getAttribute("sid")).length() <=0){
				return "/main/out";
			}
			
			MemberVo memberVo = new MemberVo();
			
			memberVo.setId(session.getAttribute("sid").toString());
			memberVo.setName(session.getAttribute("sid").toString());
			memberVo.setBuseo(session.getAttribute("deptno").toString());
			memberVo.setGray(session.getAttribute("departmentNumber").toString()); 
			 
				//session.setAttribute(WebContants.USER_KEY, memberVo);
				session.setAttribute(prop.getProperty("USER_KEY").trim(), memberVo); 
				
				return "/"; 
		}
		
		 @RequestMapping(value="/procIdCheck.do", method={RequestMethod.POST})
		    public View idCheck(String id, ModelMap model) throws Exception {
		       
		      	if (id == null) id = ""; 
		      	
		    	XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult();
		        
		        	if ( memberService.checkId(id) > 0) { // 관리자 전용게시판 확인

					     xml.setMessage(id);  // 해당아이디 사용중
					     xml.setError(false);
				 
			        } else {
			        	 xml.setMessage(id);
				 	     xml.setError(true);
			        }

			        model.addAttribute("xmlData", xml);
			        return xmlView; 
		    }
		 
			@RequestMapping(value="/iframe_approvalMemberList.do",method={RequestMethod.GET, RequestMethod.POST})
			public String approvalMemberList(String kinds, Integer curPage, String searchFild,String searchWord, Model model,String searchLevel) throws Exception{
				if (curPage == null) curPage = 1;
				if (searchFild == null) searchFild = "";
				if (searchWord == null) searchWord = "";
				int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
				int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
				int totalRecord = 0;
				String deptMemo = categoryService.getDeptCode("A", "B", searchWord);
				if(searchFild.equals("dept_cd_")){
				 totalRecord = memberService.getTotalRecord(searchFild, searchWord, searchLevel,deptMemo);
				}else{
				 totalRecord = memberService.getTotalRecord(searchFild, searchWord, searchLevel,"");	
				}
				PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
				page.setPagingHelper(pagingHelper);
				int start = pagingHelper.getStartRecord();
				int end = pagingHelper.getEndRecord();
				List<MemberVo> list = memberService.getMemberList(searchFild,  searchWord, start, end, searchLevel,deptMemo);
				Integer no = page.getListNo();
				Integer prevLink = page.getPrevLink();
				Integer nextLink = page.getNextLink();
				Integer firstPage = page.getFirstPage();
				Integer lastPage = page.getLastPage();
				int[] pageLinks = page.getPageLinks();
				model.addAttribute("list",list); 
				 model.addAttribute("no", no);
				model.addAttribute("prevLink", prevLink);
				model.addAttribute("nextLink", nextLink);
				model.addAttribute("firstPage", firstPage);
				model.addAttribute("lastPage", lastPage);
				model.addAttribute("pageLinks", pageLinks);
				model.addAttribute("curPage", curPage); 
				model.addAttribute("totalRecord", totalRecord);
				model.addAttribute("kinds", kinds);
				
				return "/calNote/iframe_approvalList";
			}
	
}
