package com.withus.buseo;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.withus.buseo.service.BuseoService;
import com.withus.buseo.dao.BuseoVO;
 
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.member.dao.MemberVo;

/**
 * @Class Name : BuseoController.java
 * @Description : Buseo Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/buseo")
public class BuseoController {

	@Autowired Properties prop;
	
    @Autowired
    private BuseoService buseoService;
    
    @Resource
    private PagingHelperService page;
   
	
    /**
	 * buseo 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 BuseoDefaultVO
	 * @return "/buseo/BuseoList"
	 * @exception Exception
	 */
    @RequestMapping(value="/list.do")
    public String selectBuseoList(String searchWord, Integer curPage, 
    		ModelMap model)
            throws Exception {
    	
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = ""; 

//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		int totalRecord = buseoService.selectBuseoListTotCnt( searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks(); 
		
		
        ArrayList<?> buseoList = buseoService.selectBuseoList(searchWord, start, end);
        
        model.addAttribute("resultList", buseoList);
  
        return "/buseo/list";
    } 
    
    
	@RequestMapping(value="/view.do", method=RequestMethod.GET)
	public String memberView(Integer binx, 
			 
			Model model) throws Exception {
 
		//상세보기 
		BuseoVO buseoVO = buseoService.selectBuseo(binx);
	 
		model.addAttribute("buseoVO", buseoVO);   
	 

		return "/buseo/view";
	}
	
	
    @RequestMapping(value="/write.do", method=RequestMethod.GET)
    public String addBuseoView()
            throws Exception { 
        return "/buseo/writeForm";
    }
    
    @RequestMapping(value="/write.do", method=RequestMethod.POST)
    public String addBuseo(
            BuseoVO buseoVO )
            throws Exception {
        buseoService.insertBuseo(buseoVO);
       
        return "forward:/buseo/list.do";
    }
    
    @RequestMapping(value="/update.do", method=RequestMethod.GET)
    public String updateBuseoView(
            @RequestParam(value="binx",required=true) int binx  , Model model)
            throws Exception {
        BuseoVO buseoVO = new BuseoVO();
        buseoVO.setBinx(binx);        

        BuseoVO thisBuseo = buseoService.selectBuseo(binx); 

		model.addAttribute("thisBuseo", thisBuseo);
 		
		
        return "/buseo/writeForm";
    }
 

    @RequestMapping(value="/update.do", method=RequestMethod.POST)
    public String updateBuseo(
    		  @ModelAttribute("buseoVO") BuseoVO buseoVO
              , Integer curPage, String searchWord
            )
            throws Exception {
    	

		if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";  
		
        buseoService.updateBuseo(buseoVO);
      
        return "redirect:/buseo/view.do?id=" + buseoVO.getBinx()
    			+ "&curPage=" + curPage 
    			+ "&searchWord=" + searchWord;
    }
    
    @RequestMapping("/delete.do")
    public String deleteBuseo(
            BuseoVO buseoVO )
            throws Exception {
        buseoService.deleteBuseo(buseoVO);
     
        return "forward:/buseo/list.do";
    }

}
