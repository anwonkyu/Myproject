package com.withus.department.dao;

public class DepartmentVO {
	private String deptCd;
	private String deptName;
	private String portalDeptCd;
	private String etc;
	private String deptDesc;
	
	public String getDeptDesc() {
		return deptDesc;
	}
	public void setDeptDesc(String deptDesc) {
		this.deptDesc = deptDesc;
	}
	public String getDeptCd() {
		return deptCd;
	}
	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getPortalDeptCd() {
		return portalDeptCd;
	}
	public void setPortalDeptCd(String portalDeptCd) {
		this.portalDeptCd = portalDeptCd;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	
}
