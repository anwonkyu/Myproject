package com.withus.business.dao;

public class BusinessVO {
	private String bizCd;
	private String bizName;
	private String etc;
	private String bizEtc;
	private String plantCd;
	private String unitNum;
	private String chngCoreCycleNum;
	
	private String plant_cd_;
	
	
	public String getPlant_cd_() {
		return plant_cd_;
	}
	public void setPlant_cd_(String plant_cd_) {
		this.plant_cd_ = plant_cd_;
	}
	public String getBizCd() {
		return bizCd;
	}
	public void setBizCd(String bizCd) {
		this.bizCd = bizCd;
	}
	public String getBizName() {
		return bizName;
	}
	public void setBizName(String bizName) {
		this.bizName = bizName;
	}
	public String getEtc() {
		return etc;
	}
	public void setEtc(String etc) {
		this.etc = etc;
	}
	public String getBizEtc() {
		return bizEtc;
	}
	public void setBizEtc(String bizEtc) {
		this.bizEtc = bizEtc;
	}
	public String getPlantCd() {
		return plantCd;
	}
	public void setPlantCd(String plantCd) {
		this.plantCd = plantCd;
	}
	public String getUnitNum() {
		return unitNum;
	}
	public void setUnitNum(String unitNum) {
		this.unitNum = unitNum;
	}
	public String getChngCoreCycleNum() {
		return chngCoreCycleNum;
	}
	public void setChngCoreCycleNum(String chngCoreCycleNum) {
		this.chngCoreCycleNum = chngCoreCycleNum;
	}
	
}
