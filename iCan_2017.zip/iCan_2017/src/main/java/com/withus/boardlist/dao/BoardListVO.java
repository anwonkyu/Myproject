package com.withus.boardlist.dao;

import java.util.List;

/**
 * @Class Name : BoardListVO.java
 * @Description : BoardList VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 * 
 * 		Copyright (C) All right reserved.
 */
public class BoardListVO {

	/** list_id */
	private Integer listId;

	/** board_id */
	private Integer boardId;

	/** seq */
	private Integer seq;

	/** list_name */
	private String listName;

	/** list_title */
	private String listTitle;

	/** list_contents */
	private String listContents;

	/** list_email */
	private String listEmail;

	/** list_link */
	private String listLink;

	/** list_passwd */
	private String listPasswd;

	/** list_re_level */
	private Integer listReLevel = 0;

	/** list_read_count */
	private Integer listReadCount = 0;

	/** list_ref */
	private Integer listRef = 0;

	/** list_step */
	private Integer listStep = 0;

	/** list_html_use */
	private String listHtmlUse = "f";

	/** list_date */
	private java.util.Date listDate;

	/** list_open 怨듦컻 鍮꾧났媛� */
	private String listOpen = "Y";

	/** open_space 怨듭� �뿬遺� */
	private String openSpace = "N";

	/** del_flag �궘�젣�뿬遺� */
	private String delFlag = "N";

	/** ip */
	private String ip;

	/** list_security 鍮꾨�湲��뿬遺� */
	private String listSecurity = "N";

	/** rsdate */
	private String rsdate;

	/** redate */
	private String redate;

	/** dupinfo */
	private String dupinfo;

	private String hogi;

	private String cycle;

	private String plant_type;

	private String y_m;

	private String doc_num;

	private String data_type;

	private String cycle_code;

	private String doc_type;

	private String bu_name;

	private String re_indate_0;

	private String re_indate_1;

	private String re_indate_2;

	private String re_indate_3;

	private String re_indate_4;

	private String print;

	private String distribution;
	
	private String in_dept;
	
	private String hcode;
	
	private String mem_id ;
	
	
	private Integer attcnt = 0;
	
	public List<String> mailCheck;
	
	public String jfile;
	
	
	

	public String getJfile() {
		return jfile;
	}

	public void setJfile(String jfile) {
		this.jfile = jfile;
	}

	public List<String> getMailCheck() {
		return mailCheck;
	}

	public void setMailCheck(List<String> mailCheck) {
		this.mailCheck = mailCheck;
	}

	public Integer getAttcnt() {
		return attcnt;
	}

	public void setAttcnt(Integer attcnt) {
		this.attcnt = attcnt;
	}

	public String getMem_id() {
		return mem_id;
	}

	public void setMem_id(String mem_id) {
		this.mem_id = mem_id;
	}

	public String getHcode() {
		return hcode;
	}

	public void setHcode(String hcode) {
		this.hcode = hcode;
	}

	public List<String> attachDel;

	public String getIn_dept() {
		return in_dept;
	}

	public void setIn_dept(String in_dept) {
		this.in_dept = in_dept;
	}

	public String getPlant_type() {
		return plant_type;
	}

	public void setPlant_type(String plant_type) {
		this.plant_type = plant_type;
	}

	public String getDoc_type() {
		return doc_type;
	}

	public void setDoc_type(String doc_type) {
		this.doc_type = doc_type;
	}

	public String getBu_name() {
		return bu_name;
	}

	public void setBu_name(String bu_name) {
		this.bu_name = bu_name;
	}

	public String getRe_indate_0() {
		return re_indate_0;
	}

	public void setRe_indate_0(String re_indate_0) {
		this.re_indate_0 = re_indate_0;
	}

	public String getRe_indate_1() {
		return re_indate_1;
	}

	public void setRe_indate_1(String re_indate_1) {
		this.re_indate_1 = re_indate_1;
	}

	public String getRe_indate_2() {
		return re_indate_2;
	}

	public void setRe_indate_2(String re_indate_2) {
		this.re_indate_2 = re_indate_2;
	}

	public String getRe_indate_3() {
		return re_indate_3;
	}

	public void setRe_indate_3(String re_indate_3) {
		this.re_indate_3 = re_indate_3;
	}

	public String getRe_indate_4() {
		return re_indate_4;
	}

	public void setRe_indate_4(String re_indate_4) {
		this.re_indate_4 = re_indate_4;
	}

	public String getPrint() {
		return print;
	}

	public void setPrint(String print) {
		this.print = print;
	}

	public String getDistribution() {
		return distribution;
	}

	public void setDistribution(String distribution) {
		this.distribution = distribution;
	}

	public String getData_type() {
		return data_type;
	}

	public void setData_type(String data_type) {
		this.data_type = data_type;
	}

	public String getDoc_num() {
		return doc_num;
	}

	public void setDoc_num(String doc_num) {
		this.doc_num = doc_num;
	}

	public String getCycle_code() {
		return cycle_code;
	}

	public void setCycle_code(String cycle_code) {
		this.cycle_code = cycle_code;
	}

	public String getHogi() {
		return hogi;
	}

	public void setHogi(String hogi) {
		this.hogi = hogi;
	}

	public String getCycle() {
		return cycle;
	}

	public void setCycle(String cycle) {
		this.cycle = cycle;
	}


	public String getY_m() {
		return y_m;
	}

	public void setY_m(String y_m) {
		this.y_m = y_m;
	}

	private String searchFild;
	private String searchWord;

	private String name;
	private String buseo;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBuseo() {
		return buseo;
	}

	public void setBuseo(String buseo) {
		this.buseo = buseo;
	}

	public List<String> getAttachDel() {
		return attachDel;
	}

	public void setAttachDel(List<String> attachDel) {
		this.attachDel = attachDel;
	}

	public String getSearchFild() {
		return searchFild;
	}

	public void setSearchFild(String searchFild) {
		this.searchFild = searchFild;
	}

	public String getSearchWord() {
		return searchWord;
	}

	public void setSearchWord(String searchWord) {
		this.searchWord = searchWord;
	}

	public Integer getListId() {
		return this.listId;
	}

	public void setListId(Integer listId) {
		this.listId = listId;
	}

	public Integer getBoardId() {
		return this.boardId;
	}

	public void setBoardId(Integer boardId) {
		this.boardId = boardId;
	}

	public Integer getSeq() {
		return this.seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public String getListName() {
		return this.listName;
	}

	public void setListName(String listName) {
		this.listName = listName;
	}

	public String getListTitle() {
		return this.listTitle;
	}

	public void setListTitle(String listTitle) {
		this.listTitle = listTitle;
	}

	public String getListContents() {
		return this.listContents;
	}

	public void setListContents(String listContents) {
		this.listContents = listContents;
	}

	public String getListEmail() {
		return this.listEmail;
	}

	public void setListEmail(String listEmail) {
		this.listEmail = listEmail;
	}

	public String getListLink() {
		return this.listLink;
	}

	public void setListLink(String listLink) {
		this.listLink = listLink;
	}

	public String getListPasswd() {
		return this.listPasswd;
	}

	public void setListPasswd(String listPasswd) {
		this.listPasswd = listPasswd;
	}

	public Integer getListReLevel() {
		return this.listReLevel;
	}

	public void setListReLevel(Integer listReLevel) {
		this.listReLevel = listReLevel;
	}

	public Integer getListReadCount() {
		return this.listReadCount;
	}

	public void setListReadCount(Integer listReadCount) {
		this.listReadCount = listReadCount;
	}

	public Integer getListRef() {
		return this.listRef;
	}

	public void setListRef(Integer listRef) {
		this.listRef = listRef;
	}

	public Integer getListStep() {
		return this.listStep;
	}

	public void setListStep(Integer listStep) {
		this.listStep = listStep;
	}

	public String getListHtmlUse() {
		return this.listHtmlUse;
	}

	public void setListHtmlUse(String listHtmlUse) {
		this.listHtmlUse = listHtmlUse;
	}

	public java.util.Date getListDate() {
		return this.listDate;
	}

	public void setListDate(java.util.Date listDate) {
		this.listDate = listDate;
	}

	public String getListOpen() {
		return this.listOpen;
	}

	public void setListOpen(String listOpen) {
		this.listOpen = listOpen;
	}

	public String getOpenSpace() {
		return this.openSpace;
	}

	public void setOpenSpace(String openSpace) {
		this.openSpace = openSpace;
	}

	public String getDelFlag() {
		return this.delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getIp() {
		return this.ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public String getListSecurity() {
		return this.listSecurity;
	}

	public void setListSecurity(String listSecurity) {
		this.listSecurity = listSecurity;
	}

	public String getRsdate() {
		return this.rsdate;
	}

	public void setRsdate(String rsdate) {
		this.rsdate = rsdate;
	}

	public String getRedate() {
		return this.redate;
	}

	public void setRedate(String redate) {
		this.redate = redate;
	}

	public String getDupinfo() {
		return this.dupinfo;
	}

	public void setDupinfo(String dupinfo) {
		this.dupinfo = dupinfo;
	}

	@Override
	public String toString() {
		return "BoardListVO [listId=" + listId + ", boardId=" + boardId + ", seq=" + seq + ", listName=" + listName
				+ ", listTitle=" + listTitle + ", listContents=" + listContents + ", listEmail=" + listEmail
				+ ", listLink=" + listLink + ", listPasswd=" + listPasswd + ", listReLevel=" + listReLevel
				+ ", listReadCount=" + listReadCount + ", listRef=" + listRef + ", listStep=" + listStep
				+ ", listHtmlUse=" + listHtmlUse + ", listDate=" + listDate + ", listOpen=" + listOpen + ", openSpace="
				+ openSpace + ", delFlag=" + delFlag + ", ip=" + ip + ", listSecurity=" + listSecurity + ", rsdate="
				+ rsdate + ", redate=" + redate + ", dupinfo=" + dupinfo + ", hogi=" + hogi + ", cycle=" + cycle
				+ ", plant_type=" + plant_type + ", y_m=" + y_m + ", doc_num=" + doc_num + ", data_type=" + data_type
				+ ", cycle_code=" + cycle_code + ", doc_type=" + doc_type + ", bu_name=" + bu_name + ", re_indate_0="
				+ re_indate_0 + ", re_indate_1=" + re_indate_1 + ", re_indate_2=" + re_indate_2 + ", re_indate_3="
				+ re_indate_3 + ", re_indate_4=" + re_indate_4 + ", print=" + print + ", distribution=" + distribution
				+ ", in_dept=" + in_dept + ", hcode=" + hcode + ", mem_id=" + mem_id + ", attcnt=" + attcnt
				+ ", mailCheck=" + mailCheck + ", jfile=" + jfile + ", attachDel=" + attachDel + ", searchFild="
				+ searchFild + ", searchWord=" + searchWord + ", name=" + name + ", buseo=" + buseo + "]";
	}

	
}
