package com.withus.business.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;



@Repository("businessMapper")
public interface BusinessMapper {
	
	public void insertBusiness(BusinessVO businessVo) throws Exception ;
	
	public ArrayList<BusinessVO> selectBusinessList(HashMap<String, String> hashmap) throws Exception;
	
	public int selectBusinessListTotCnt(HashMap<String, String> hashmap)throws Exception ;
	
	public int deleteBusiness(String bizCd)throws Exception;
	
	public int updateBusiness(BusinessVO businessVo)throws Exception;
	
	public BusinessVO getBusiness(HashMap<String, String> hashmap) throws Exception;
	
	public ArrayList<BusinessVO> AllBusinessList(HashMap<String, String> hashmap);
	
	
}
