package com.withus.ftpServer;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;

import com.ext.jfile.JProperties;
import com.thoughtworks.xstream.XStream;
import com.withus.calnote.CalculationNoteController;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.commons.XmlResult;
import com.withus.ftpServer.service.FtpServerService;

@Controller
@RequestMapping("/vodman")
public class FtpServerController {
	
	private static final Logger logger = LoggerFactory.getLogger(CalculationNoteController.class);
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;
    
    @Autowired
    private FtpServerService ftpServerService;
	
	  @RequestMapping(value="/ftpServer/ftpServer.do", method=RequestMethod.GET)
			public String ftpServer(Integer seq, Model model) throws Exception {
		  	int selectFTP = ftpServerService.selectFtpServer();
		  	model.addAttribute("selectFTP", selectFTP);
				return "/vodman/ftpServer/ftpServer";
			}
	  
	    @RequestMapping(value="/ftpServer/ftpServerUpdate.do", method=RequestMethod.POST)
		public View calUpdate(@RequestParam(value="serverNo",required=true) int serverNo, Model model ) throws Exception {
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
			     if (ftpServerService.updateFtpServer(serverNo)  > 0) {
				        xml.setError(true);
			       
			    } else {
			 	     xml.setError(false);
			    }

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	  
	  
}
