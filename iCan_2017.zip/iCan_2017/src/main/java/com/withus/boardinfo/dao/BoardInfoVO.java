package com.withus.boardinfo.dao;

/**
 * @Class Name : BoardInfoVO.java
 * @Description : BoardInfo VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class BoardInfoVO {
     
    /** board_id */
    private Integer boardId;
    
    /** seq */
    private Integer seq;
    
    /** board_title */
    private String boardTitle;
    
    /** board_page_line */
    private Integer boardPageLine;
    
    /** board_image_flag */
    private String boardImageFlag ="f";
    
    /** board_file_flag */
    private String boardFileFlag="f";
    
    /** board_link_flag */
    private String boardLinkFlag="f";
    
    /** board_top_comments */
    private String boardTopComments;
    
    /** board_footer_comments */
    private String boardFooterComments;
    
    /** board_user_flag */
    private String boardUserFlag="f";
    
    /** board_priority */
    private Integer boardPriority;
    
    /** board_date */
    private String boardDate;
    
    /** flag */
    private String flag;
    
    /** board_auth_list */
    private Integer boardAuthList;
    
    /** board_auth_read */
    private Integer boardAuthRead;
    
    /** board_auth_write */
    private Integer boardAuthWrite;
    
    /** del_flag */
    private String delFlag;
    
    /** view_comment */
    private String viewComment="f";
    
    /** board_ccode */
    private String boardCcode;
    
    /** board_security_flag */
    private String boardSecurityFlag="f";
    
    private Integer boardCnt;

    private String mail;
    
    
	public String getmail() {
		return mail;
	}

	public void setmail(String mail) {
		this.mail = mail;
	}

	public Integer getBoardId() {
		return boardId;
	}

	public void setBoardId(Integer boardId) {
		this.boardId = boardId;
	}

	public Integer getSeq() {
		return seq;
	}

	public void setSeq(Integer seq) {
		this.seq = seq;
	}

	public String getBoardTitle() {
		return boardTitle;
	}

	public void setBoardTitle(String boardTitle) {
		this.boardTitle = boardTitle;
	}

	public Integer getBoardPageLine() {
		return boardPageLine;
	}

	public void setBoardPageLine(Integer boardPageLine) {
		this.boardPageLine = boardPageLine;
	}

	public String getBoardImageFlag() {
		return boardImageFlag;
	}

	public void setBoardImageFlag(String boardImageFlag) {
		this.boardImageFlag = boardImageFlag;
	}

	public String getBoardFileFlag() {
		return boardFileFlag;
	}

	public void setBoardFileFlag(String boardFileFlag) {
		this.boardFileFlag = boardFileFlag;
	}

	public String getBoardLinkFlag() {
		return boardLinkFlag;
	}

	public void setBoardLinkFlag(String boardLinkFlag) {
		this.boardLinkFlag = boardLinkFlag;
	}

	public String getBoardTopComments() {
		return boardTopComments;
	}

	public void setBoardTopComments(String boardTopComments) {
		this.boardTopComments = boardTopComments;
	}

	public String getBoardFooterComments() {
		return boardFooterComments;
	}

	public void setBoardFooterComments(String boardFooterComments) {
		this.boardFooterComments = boardFooterComments;
	}

	public String getBoardUserFlag() {
		return boardUserFlag;
	}

	public void setBoardUserFlag(String boardUserFlag) {
		this.boardUserFlag = boardUserFlag;
	}

	public Integer getBoardPriority() {
		return boardPriority;
	}

	public void setBoardPriority(Integer boardPriority) {
		this.boardPriority = boardPriority;
	}

	public String getBoardDate() {
		return boardDate;
	}

	public void setBoardDate(String boardDate) {
		this.boardDate = boardDate;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public Integer getBoardAuthList() {
		return boardAuthList;
	}

	public void setBoardAuthList(Integer boardAuthList) {
		this.boardAuthList = boardAuthList;
	}

	public Integer getBoardAuthRead() {
		return boardAuthRead;
	}

	public void setBoardAuthRead(Integer boardAuthRead) {
		this.boardAuthRead = boardAuthRead;
	}

	public Integer getBoardAuthWrite() {
		return boardAuthWrite;
	}

	public void setBoardAuthWrite(Integer boardAuthWrite) {
		this.boardAuthWrite = boardAuthWrite;
	}

	public String getDelFlag() {
		return delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getViewComment() {
		return viewComment;
	}

	public void setViewComment(String viewComment) {
		this.viewComment = viewComment;
	}

	public String getBoardCcode() {
		return boardCcode;
	}

	public void setBoardCcode(String boardCcode) {
		this.boardCcode = boardCcode;
	}

	public String getBoardSecurityFlag() {
		return boardSecurityFlag;
	}

	public void setBoardSecurityFlag(String boardSecurityFlag) {
		this.boardSecurityFlag = boardSecurityFlag;
	}

	public Integer getBoardCnt() {
		return boardCnt;
	}

	public void setBoardCnt(Integer boardCnt) {
		this.boardCnt = boardCnt;
	}
    
    
    
}
