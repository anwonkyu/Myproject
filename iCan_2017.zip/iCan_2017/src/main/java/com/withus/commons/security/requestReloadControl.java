package com.withus.commons.security;
 
import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.commons.XmlResult;
import com.withus.commons.security.ReloadableFilterInvocationSecurityMetadataSource;


@Controller
public class requestReloadControl { 
	private static final Logger LOGGER = LoggerFactory.getLogger(requestReloadControl.class);
	
	@Resource(name = "xstreamMarshaller")
	private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView;
    
    @RequestMapping(value="/vodman/site/requestReload.do" , method=RequestMethod.POST)
    public View requestReload( Model model) throws Exception {  
    	
    	XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
        
        int rtn_value = -1;
    	try{
	    	ApplicationContext appContext = ContextLoaderListener.getCurrentWebApplicationContext();
	 		ReloadableFilterInvocationSecurityMetadataSource reload = (com.withus.commons.security.ReloadableFilterInvocationSecurityMetadataSource)appContext.getBean("reloadableFilterInvocationSecurityMetadataSource");
	 		reload.reload();
	 		rtn_value = 1;
    	} catch (Exception e) {
 
    		rtn_value = 1;
    		LOGGER.info("requestReloadControl:"+e);
    	}
    	
    	 if ( rtn_value > 0) { 
		     
		        xml.setMessage("적용 되었습니다.");
		        xml.setError(true);
		       
		    } else {
		    	xml.setMessage("적용에 실패하였습니다.");
		 	     xml.setError(false);
		    }
    	 
    	 model.addAttribute("xmlData", xml);
 	    
 	    return xmlView;
    }
}
