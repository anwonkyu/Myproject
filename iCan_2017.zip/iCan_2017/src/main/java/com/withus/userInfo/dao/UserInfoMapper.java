package com.withus.userInfo.dao;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository("userInfoMapper")
public interface UserInfoMapper {
	public void insertUserInfo(UserInfoVo userInfoVo)throws Exception;
	
	public UserInfoVo getUserInfo(HashMap<String, String> hashmap) throws Exception;
	
	public UserInfoVo deleteUserInfo(HashMap<String, String> hashmap) throws Exception;
	
	public int updateUserInfo(UserInfoVo userInfoVo)throws Exception;
}
