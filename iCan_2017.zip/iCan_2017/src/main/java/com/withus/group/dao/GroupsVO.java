package com.withus.group.dao;

/**
 * @Class Name : GroupsVO.java
 * @Description : Groups VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class GroupsVO {
    private static final long serialVersionUID = 1L;
    
    /** id */
    private Integer id;
    
    /** group_name */
    private String groupName;
    
    Integer groupId;
    String authority;
    String memberId;
    
    Integer seq;
    
    
    
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Integer getGroupId() {
		return groupId;
	}
	public void setGroupId(Integer groupId) {
		this.groupId = groupId;
	}
	public String getAuthority() {
		return authority;
	}
	public void setAuthority(String authority) {
		this.authority = authority;
	}
	public String getMemberId() {
		return memberId;
	}
	public void setMemberId(String memberId) {
		this.memberId = memberId;
	}
    
    
    
}
