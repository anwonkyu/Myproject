package com.withus.member.service;

import java.util.ArrayList;
 








import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.annotation.Transactional;

import com.withus.commons.paging.PagingHelperService;
import com.withus.member.dao.MemberVo;
import com.withus.question.dao.QuestionVO;
 
public interface MemberService  {
	@Transactional
	public int insert(MemberVo memberVo)throws Exception;
	
	@Transactional
	public int insert2(MemberVo memberVo)throws Exception;
	
	public MemberVo login(String id, String pwd);
	@Transactional
	public int update(MemberVo memberVo) throws Exception;
	@Transactional
	public void changePwd(MemberVo memberVo);
	
	public void bye(MemberVo memberVo);
 
	public MemberVo memberInfo(String id);

	ArrayList<MemberVo> getMemberList(String searchFild ,String searchWord, int start, int end, String searchLevel, String deptMemo);

	int getTotalRecord(String searchFild, String searchWord, String searchLevel, String deptMemo) throws Exception;
	
	public void insertAuthority(String id, String authority);
	
	public int deleteMember(String id);
 

	public void deleteAuthority(String id);

	public int checkId(String id); 
	
	public int loginHistory(String id, String flag) ;
	
	public int pwdUpdate(String id, String pwd) throws Exception;

	public int updateApproval(String approval, String id);

	public int pwdUpdate_user( String pwd, String old_pwd) throws Exception;

	public MemberVo findMember(String userName, String userEmail);
	
	public MemberVo findMemberId(String userId, String userName, String userEmail)throws Exception;

	public MemberVo findMemberId_Hp(String userName, String hp)throws Exception;
	
	ArrayList<MemberVo> getMemberListAll(String searchFild ,String searchWord,  String searchLevel);
	
	ArrayList<MemberVo> questionList_Dcode(String Dcode) throws Exception;



	public int insert_visit(String userId, String userName);
	
	public int total_visit();
	
	public int today_visit();

	public String selectDept(String id);

	public ArrayList<MemberVo> readUserInfoList(String[] userIds)throws Exception;
	
}


