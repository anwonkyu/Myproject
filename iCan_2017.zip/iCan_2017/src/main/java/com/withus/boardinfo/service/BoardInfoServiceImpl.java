package com.withus.boardinfo.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 


import com.withus.boardinfo.service.BoardInfoService;
 
import com.withus.boardinfo.dao.BoardInfoMapper;
import com.withus.boardinfo.dao.BoardInfoVO;
 
/**
 * @Class Name : BoardInfoServiceImpl.java
 * @Description : BoardInfo Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service 
public class BoardInfoServiceImpl  implements BoardInfoService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(BoardInfoServiceImpl.class);

    @Resource(name="boardInfoMapper")
    private BoardInfoMapper boardInfoDAO;
    
    /** ID Generation */
    //@Resource(name="{egovBoardInfoIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * board_info을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BoardInfoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertBoardInfo(BoardInfoVO vo) throws Exception {
      
        return boardInfoDAO.insertBoardInfo(vo);
    }

    /**
	 * board_info을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BoardInfoVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateBoardInfo(BoardInfoVO vo) throws Exception {
    	return boardInfoDAO.updateBoardInfo(vo);
    }

    /**
	 * board_info을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BoardInfoVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteBoardInfo(int boardId) throws Exception {
        return  boardInfoDAO.deleteBoardInfo(boardId);
      }
    /**
	 * board_info을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BoardInfoVO
	 * @return 조회한 board_info
	 * @exception Exception
	 */
    public BoardInfoVO selectBoardInfo(int boardId) throws Exception {
        BoardInfoVO resultVO = boardInfoDAO.selectBoardInfo(boardId);
 
        return resultVO;
    }

    /**
	 * board_info 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return board_info 목록
	 * @exception Exception
	 */
    public ArrayList<BoardInfoVO> selectBoardInfoList() throws Exception {
        return boardInfoDAO.selectBoardInfoList();
    }

    /**
	 * board_info 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return board_info 총 갯수
	 * @exception
	 */
    public int selectBoardInfoListTotCnt() {
		return boardInfoDAO.selectBoardInfoListTotCnt();
	}
    
}
