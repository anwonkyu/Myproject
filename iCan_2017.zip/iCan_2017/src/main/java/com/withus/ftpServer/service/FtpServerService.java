package com.withus.ftpServer.service;


public interface FtpServerService {
	
	public int updateFtpServer(int serverNo)throws Exception; 
	
	public int selectFtpServer()throws Exception;

}
