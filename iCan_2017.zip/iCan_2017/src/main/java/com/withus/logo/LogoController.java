package com.withus.logo;
 
 
import java.io.File;
import java.util.Iterator;
import java.util.Properties; 

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest; 

import com.withus.commons.uploadFile.UploadUtil;
import com.withus.logo.service.LogoService;
import com.withus.logo.dao.LogoVO;
 

/**
 * @Class Name : LogoController.java
 * @Description : Logo Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-12-31
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping(value="/vodman") 
public class LogoController {

	
	 private static final Logger logger = LoggerFactory.getLogger(LogoController.class);
	            		
    @Resource(name = "logoService")
    private LogoService logoService;
    
    @Autowired Properties prop;
 
    
    @RequestMapping(value="/site/updateLogo.do", method={RequestMethod.GET,RequestMethod.POST })
    public String updateLogoView(
            Model model)
            throws Exception {
 
        model.addAttribute("logo",logoService.selectLogo());
        return "/vodman/site/updateLogo";
    }

   


//  @RequestMapping(value="/site/updateLogoproc.do", method=RequestMethod.POST)
//	public String updateLogo(
//			 @ModelAttribute("uploadForm") FileUpload uploadForm,
//	            Model map) throws IllegalStateException, IOException {
//	      
//	File dir = new File(prop.getProperty("LOGO_PATH")); 
//  	if (!dir.isDirectory()) { 
//  		dir.mkdirs(); 
//  	}
//  	
//  	 List<MultipartFile> addFiles = uploadForm.getFiles();
//  	 
//     List<String> fileNames = new ArrayList<String>();
//
//     if (null != addFiles && addFiles.size() > 0) {
//         for (MultipartFile multipartFile : addFiles) {
//
//             String fileName = multipartFile.getOriginalFilename();
//             if (!"".equalsIgnoreCase(fileName)) {
//                 // Handle file content - multipartFile.getInputStream()
//                 multipartFile.transferTo(new File(dir + fileName));
//                 fileNames.add(fileName);
//             }
//         }
//     }else {
//    	 System.out.println("none file");
//     }
//
//     map.addAttribute("files", fileNames);
//     
//      
//    	
////	  logoService.updateLogo(logoVO);
//    
//     return "redirect:/vodman/site/updateLogo.do";
//}

 
    
    /*
     * XSS 필터 를 multipartFilter 보더 먼저 해야 파일이 업로드 되는데 xss 필터를 타지 않음
     *  
     */
    @RequestMapping(value="/site/updateLogoproc.do", method=RequestMethod.POST)
	public String updateLogo(MultipartHttpServletRequest mpRequest, @ModelAttribute("logoVO") LogoVO logoVO) throws Exception {
 
 
    	//파일업로드
		    	File dir = new File(prop.getProperty("LOGO_PATH").trim());
		    	if (!dir.isDirectory()) { 
		    		dir.mkdirs(); 
		    	}
		    	
    			Iterator<String> it = mpRequest.getFileNames();

    			while (it.hasNext()) { 
					MultipartFile multiFile = mpRequest.getFile((String) it.next());
					
				if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename()) 
						&& com.withus.commons.TextUtil.isFileImage(multiFile.getContentType())) {
						
					String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename());
 					multiFile.transferTo(new File(prop.getProperty("LOGO_PATH").trim()+File.separator+  filename));
 					//multiFile.transferTo(new File(prop.getProperty("LOGO_PATH") + filename));

					/* 등록 파일 복사
					File destination = File.createTempFile("file", filename, dir);
					FileCopyUtils.copy(multiFile.getInputStream(), new FileOutputStream(destination));
					*/
 					/*
 					 * 파일확장자 가져오기
 					 */
 					 	int fileIndex = StringUtils.lastIndexOf(multiFile.getOriginalFilename(), '.');
				        String extension = null;
				        if (fileIndex != -1) {
				            extension = StringUtils.substring(multiFile.getOriginalFilename(), fileIndex + 1); 
				        } 
				        
						if (multiFile.getName() != null && multiFile.getName().equals("topLogofile") ) {
							logoVO.setTopLogo(filename);
							logoVO.setTopLogoExt(extension);
							
						} else if (multiFile.getName() != null && multiFile.getName().equals("footerLogofile") ) {
							logoVO.setFooterLogo(filename);
							logoVO.setFooterLogoExt(extension);
						} else if (multiFile.getName() != null && multiFile.getName().equals("mediaLogofile") ) {
							/*
							 * 썸네일 생성 (썸네일 위치 지정된곳 웹서비스 되는곳)
							 */
							com.withus.commons.uploadFile.UploadUtil.createThumb(prop.getProperty("LOGO_PATH").trim()+File.separator + filename, prop.getProperty("WEB_ROOT_UPLOAD").trim()+File.separator+ "logo" + File.separator+ filename+"."+extension, 800, 800); // 썸네일 생성
							logoVO.setMediaLogo(filename);
							logoVO.setMediaLogoExt(extension);
						} else if (multiFile.getName() != null && multiFile.getName().equals("playLogofile") ) {
 
							logoVO.setPlayLogo(filename+"."+extension);
							/*
							 * 썸네일 생성 (썸네일 위치 지정된곳 웹서비스 되는곳)
							 */
							com.withus.commons.uploadFile.UploadUtil.createThumb(prop.getProperty("LOGO_PATH").trim()+File.separator + filename, prop.getProperty("WEB_ROOT_UPLOAD").trim()+File.separator+ "logo" + File.separator+ filename+"."+extension, 300, 300); // 썸네일 생성
     						 
							
						} 
					} 
    			} 
    		
        logoService.updateLogo(logoVO);
       
        return "redirect:/vodman/site/updateLogo.do";
    }
    
  
    
}
