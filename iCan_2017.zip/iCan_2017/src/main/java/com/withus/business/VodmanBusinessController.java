package com.withus.business;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.business.dao.BusinessVO;
import com.withus.business.service.BusinessService;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;

@Controller
@RequestMapping("/vodman")
public class VodmanBusinessController {
	
	private static final Logger logger = LoggerFactory.getLogger(VodmanBusinessController.class);

	@Autowired Properties prop;
	
    @Autowired
    private BusinessService businessService;
    
    @Resource
    private PagingHelperService page;
    
    @Resource(name = "xstreamMarshaller")
	private XStreamMarshaller xstreamMarshaller;
    
    @Resource(name = "xmlView")
    private View xmlView;
    
	@RequestMapping(value="/business/bizWrite.do", method=RequestMethod.GET)
	public String write( Model model) throws Exception {
 
		return "/vodman/business/addForm";
	}
	
    @RequestMapping(value="/business/bizWrite.do", method=RequestMethod.POST)
    public String addBusiness(
           BusinessVO businessVo )throws Exception {
    	businessService.insertBusiness(businessVo);
   
       
        return "redirect:/vodman/business/bizList.do";
    }
    
    @RequestMapping(value="/business/bizList.do")
    public String selectBuseoList(String searchWord, Integer curPage, 
    		ModelMap model)
            throws Exception {
    	
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = ""; 
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		int totalRecord = businessService.selectBusinessListTotCnt(searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		ArrayList<?> businessList = businessService.selectBusinessList(searchWord, start, end);
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks(); 
		
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		
        model.addAttribute("resultList", businessList);
  
        return "/vodman/business/bizList";
    } 
    
    @RequestMapping(value="/business/selectbox.do", method={RequestMethod.GET, RequestMethod.POST})
    public @ResponseBody Map<?,?> auto2() throws Exception {
    	Map< String, Object> map = new HashMap< String, Object>();
    	map.put("data", businessService.AllBusinessList(""));
    	return map;
    }
    
    @RequestMapping(value="/business/bizDelete.do", method=RequestMethod.POST)
	public View bizDelete(@RequestParam(value="bizCd" ,required=true)String bizCd, Model model ) {
			   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     try {
				if ( businessService.deleteBusiness(bizCd) > 0) {
				        xml.setMessage("삭제되었습니다.");
				        xml.setError(true);
				   
				} else {
					xml.setMessage("삭제에 실패하였습니다.");
				     xml.setError(false);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
    
    @RequestMapping(value="/business/bizUpdate.do", method=RequestMethod.GET)
	public String bizUpdate(String bizCd, 
			Model model) throws Exception {
		BusinessVO businessVo = businessService.getBusiness(bizCd);
 
		//수정페이지에서의 보일 게시글 정보
		model.addAttribute("thisVo", businessVo);
 		
		return "/vodman/business/addForm";
	}
    
	@RequestMapping(value="/business/bizUpdate.do", method=RequestMethod.POST)
	public View bizUpdate(@ModelAttribute("businessVo") BusinessVO businessVo, Model model ) throws Exception {
	 
		   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     if ( businessService.updateBusiness(businessVo) > 0) {
			        xml.setMessage(businessVo.getBizCd());
			        xml.setError(true);
		       
		    } else {
		    	 xml.setMessage(businessVo.getBizCd());
		 	     xml.setError(false);
		    }

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
    
    
}
