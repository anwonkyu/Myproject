package com.withus.proHistory.service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.withus.member.dao.MemberVo;
import com.withus.memo.service.ContentMemoServiceImpl;
import com.withus.proHistory.dao.ProHistoryMapper;
import com.withus.proHistory.dao.ProHistoryVO;
@Service("proHistoryService")
public class ProHistoryServiceImpl implements ProHistoryService{
	private static final Logger LOGGER = LoggerFactory.getLogger(ContentMemoServiceImpl.class);
	
	@Resource(name="proHistoryMapper")
	private ProHistoryMapper proHistoryDAO;
	
	@Override
	public int insertProHistory(ProHistoryVO vo) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		if(principal != null && principal instanceof MemberVo){ 
			vo.setUserId(((MemberVo)principal).getUsername() );
		} else{
        	 return -1;
        }
		return proHistoryDAO.insertProHistory(vo);
	}

	@Override
	public ArrayList<ProHistoryVO> selectProHistoryList(Integer proId, String state, String searchFild,
			String searchWord, int start, int end) throws Exception {
		Integer startRownum = start;
		Integer endRownum = end;
		Integer pro_id = proId;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("proId", pro_id.toString());
		hashmap.put("state", state);
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		return proHistoryDAO.selectProHistoryList(hashmap);
	}

	@Override
	public int selectProHistoryListTotCnt(Integer proId, String state, String searchFild, String searchWord)
			throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		Integer pro_id = proId;
		hashmap.put("proId", pro_id.toString());
		hashmap.put("state", state);
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
	 
		return proHistoryDAO.selectProHistoryListTotCnt(hashmap);
	}

}
