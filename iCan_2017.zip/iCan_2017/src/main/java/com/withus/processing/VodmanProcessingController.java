package com.withus.processing;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.processing.dao.ProcessingVO;
import com.withus.processing.service.ProcessingService;

@Controller
@RequestMapping("/vodman")
public class VodmanProcessingController {
	@Autowired Properties prop;
	
	@Autowired ProcessingService processingService;
	
    @Resource
	private PagingHelperService page;
	 
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;
	  
	@Resource(name = "xmlView")
	private View xmlView;
	
	
	@RequestMapping(value="/processing/list.do")
    public String selectContentMemoList(ProcessingVO processingVo,  Integer curPage,String searchFild,  String searchWord,  Model model,String searchComplete)
            throws Exception {
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		if (searchComplete == null) searchComplete = "";
//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		int totalRecord = processingService.selectProcessingTotCnt(searchWord, searchFild,"","","","","",searchComplete);
		
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		
        ArrayList<ProcessingVO> contentMemoList = processingService.selectProcessingList( searchFild, searchWord, start, end,"","","","","","","",searchComplete);
        model.addAttribute("resultList", contentMemoList);
        
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
        
        return "/vodman/processing/proList";
    } 
	
	  @RequestMapping(value = "/processing/processingAdd.do", method=RequestMethod.GET )
	    public String processingAdd( Model model) throws Exception  {
			return "/processing/processingAdd";
	  }
	  
	  @RequestMapping(value="/processing/processingAdd.do", method=RequestMethod.POST)
	    public String calWrite(ProcessingVO ProcessingVo )throws Exception {
	 
	    	processingService.insertProcessing(ProcessingVo);
	        return "redirect:/calNote/calNoteList.do";
	    }
	  
	  @RequestMapping(value="/processing/processingUpdate.do", method=RequestMethod.GET)
		public String processingUpdate( Integer seq, Model model) throws Exception {
	    	
			ProcessingVO processingVo = processingService.getProcessing(seq);
			model.addAttribute("thisVo", processingVo);
			return "/vodman/processing/approveForm";
		}
	  
	    @RequestMapping(value="/processing/processingUpdate.do", method=RequestMethod.POST)
		public View calUpdate(@ModelAttribute("processingVo") ProcessingVO processingVo, Model model ) throws Exception {
	 
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
			     if ( processingService.AppProcessing(processingVo) > 0) {
				        xml.setMessage(String.valueOf(processingVo.getSeq()));
				        xml.setError(true);
			       
			    } else {
			    	 xml.setMessage(String.valueOf(processingVo.getSeq()));
			 	     xml.setError(false);
			    }

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	    
	    @RequestMapping(value="/processing/processingDelete.do", method=RequestMethod.POST)
		public View deptDelete(@RequestParam(value="seq" ,required=true)Integer seq, Model model ) {
				   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     try {
					if ( processingService.deleteProcessing(seq) > 0) {
					        xml.setMessage("삭제되었습니다.");
					        xml.setError(true);
					   
					} else {
						xml.setMessage("삭제에 실패하였습니다.");
					     xml.setError(false);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	    
	    @RequestMapping(value="/processing/mailSend.do")
	    public String approvalList()throws Exception{  
	    	return "/vodman/processing/approveUpdateList";
	    }
	  
	  
}
