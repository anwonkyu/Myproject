package com.withus.buseo.service;

import java.util.ArrayList;
 

import com.withus.buseo.dao.BuseoVO;
 
import com.withus.commons.paging.PagingHelperService;

/**
 * @Class Name : BuseoService.java
 * @Description : Buseo Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface BuseoService  {
	
	/**
	 * buseo을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BuseoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    String insertBuseo(BuseoVO vo) throws Exception;
    
    /**
	 * buseo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BuseoVO
	 * @return void형
	 * @exception Exception
	 */
    void updateBuseo(BuseoVO vo) throws Exception;
    
    /**
	 * buseo을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BuseoVO
	 * @return void형 
	 * @exception Exception
	 */
    void deleteBuseo(BuseoVO vo) throws Exception;
    
    /**
	 * buseo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BuseoVO
	 * @return 조회한 buseo
	 * @exception Exception
	 */
    BuseoVO selectBuseo(int binx) throws Exception;
    
    /**
	 * buseo 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return buseo 목록
	 * @exception Exception
	 */
    ArrayList<BuseoVO> selectBuseoList(String searchWord, int start, int end) throws Exception;
    
    ArrayList<BuseoVO> selectBuseoListAll() throws Exception;
    
    /**
	 * buseo 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return buseo 총 갯수
	 * @exception
	 */
    int selectBuseoListTotCnt(String serachWorld);
    
 
}
