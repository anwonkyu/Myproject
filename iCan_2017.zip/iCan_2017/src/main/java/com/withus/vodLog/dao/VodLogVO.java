package com.withus.vodLog.dao;

/**
 * @Class Name : VodLogVO.java
 * @Description : VodLog VO class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 20150303
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class VodLogVO {
    private static final long serialVersionUID = 1L;
    
    /** no */
    private Integer no;
    
    /** ip */
    private String ip;
    
    /** vod_id */
    private String vodId;
    
    /** vod_name */
    private String vodName;
    
    /** vod_code */
    private String vodCode;
    
    /** regDate */
    private java.util.Date regdate;
    
    /** vod_buseo */
    private String vodBuseo;
    
    /** vod_gray */
    private String vodGray;
    
    /** oflag */
    private String oflag;
    
    private Integer start;
    
    private Integer end;
    
    private String title;
    
    private String sdate;
    private String edate;
    
    private Integer sum ;
    
    
    
    public Integer getSum() {
		return sum;
	}

	public void setSum(Integer sum) {
		this.sum = sum;
	}

	public String getSdate() {
		return sdate;
	}

	public void setSdate(String sdate) {
		this.sdate = sdate;
	}

	public String getEdate() {
		return edate;
	}

	public void setEdate(String edate) {
		this.edate = edate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getStart() {
		return start;
	}

	public void setStart(Integer start) {
		this.start = start;
	}

	public Integer getEnd() {
		return end;
	}

	public void setEnd(Integer end) {
		this.end = end;
	}

	public Integer getNo() {
        return this.no;
    }
    
    public void setNo(Integer no) {
        this.no = no;
    }
    
    public String getIp() {
        return this.ip;
    }
    
    public void setIp(String ip) {
        this.ip = ip;
    }
    
    public String getVodId() {
        return this.vodId;
    }
    
    public void setVodId(String vodId) {
        this.vodId = vodId;
    }
    
    public String getVodName() {
        return this.vodName;
    }
    
    public void setVodName(String vodName) {
        this.vodName = vodName;
    }
    
    public String getVodCode() {
        return this.vodCode;
    }
    
    public void setVodCode(String vodCode) {
        this.vodCode = vodCode;
    }
    
    public java.util.Date getRegdate() {
        return this.regdate;
    }
    
    public void setRegdate(java.util.Date regdate) {
        this.regdate = regdate;
    }
    
    public String getVodBuseo() {
        return this.vodBuseo;
    }
    
    public void setVodBuseo(String vodBuseo) {
        this.vodBuseo = vodBuseo;
    }
    
    public String getVodGray() {
        return this.vodGray;
    }
    
    public void setVodGray(String vodGray) {
        this.vodGray = vodGray;
    }
    
    public String getOflag() {
        return this.oflag;
    }
    
    public void setOflag(String oflag) {
        this.oflag = oflag;
    }
    
}
