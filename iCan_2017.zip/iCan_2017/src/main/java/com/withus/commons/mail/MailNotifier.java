package com.withus.commons.mail;

import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeUtility;

import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;

public class MailNotifier {

	/** JavaMailSender 객체. */
	private JavaMailSender mailSender;

	/**
	 * 주어진 mailSender에 해당하는 JavaMailSender 객체를 설정한다.
	 * 
	 * @param mailSender
	 *            JavaMailSender 객체
	 */
	public void setMailSender(JavaMailSender mailSender) {
		this.mailSender = mailSender;
	}

	/**
	 * 주어진 mailMsg에 해당하는 메일 전송 정보를 송신한다.
	 * 
	 * @param mailMsg
	 *            DefaultMailMessage VO
	 */
	public void sendEmailTo(DefaultMailMessage mailMsg) {
		MimeMessage message = mailSender.createMimeMessage();
		Boolean isAttach = false;
		if (mailMsg.getFiles() != null && (mailMsg.getFiles()).length > 0)
			isAttach = true;
		// 메일 메세지 생성

		try {
			// TODO 메일 연동이 완료될 경우 아래 부분 제거해야 함
			 //mailMsg.setTo("dev@withustch.com");

			MimeMessageHelper messageHelper = new MimeMessageHelper(message, isAttach, mailMsg.getCharset());
			messageHelper.setSubject(mailMsg.getSubject());
			messageHelper.setText(mailMsg.getHtmlContent(), true);
			messageHelper.setFrom(new InternetAddress(mailMsg.getFrom(),mailMsg.getFromName()));
			messageHelper.setTo(new InternetAddress(mailMsg.getTo(), mailMsg.getToName(), mailMsg.getCharset()));
			// 파일첨부
			if (isAttach) {
				String[] files = mailMsg.getFiles();
				for (int i = 0; i < files.length; i++) {
					// files[i] ... C:\\a.txt
					DataSource dataSource = new FileDataSource(files[i]);
					messageHelper.addAttachment( MimeUtility.encodeText(files[i], mailMsg.getCharset(), "B"), dataSource);
				}
			}
		} catch (Throwable e) {
			System.out.println("[Exception]mailSender.createMimeMessage & setting : "
							+ e);
			return;
		}
		// 메일 전송
		try {
			// 메일 연동이 완료될 경우 아래 부분  mailSender.send(message);을 실행
	 System.out.println("sendEmail::"+message);
			mailSender.send(message);
		} catch (MailException e) {
			System.out.println("[Exception]mailSender.send : " + e);
		}
	}
}
