package com.withus.commons.paging;
 
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
 
@Service 
public  class PagingHelperServiceImpl implements PagingHelperService {

	protected Logger LOGGER = LoggerFactory.getLogger(PagingHelperServiceImpl.class);
	
	private PagingHelper pagingHelper; //페이징 처리 유틸리티 클래스
	
	public int getListNo() {
		return pagingHelper.getListNo(); 
	}
	
	public int getPrevLink() {
		return pagingHelper.getPrevLink();
	}
	
	public int getFirstPage() {
		return pagingHelper.getFirstPage();
	}
	
	public int getLastPage() {
		return pagingHelper.getLastPage();
	}
	
	public int getLastPage2() {
		return pagingHelper.getLastPage2();
	}
	
	public int getNextLink() {
		return pagingHelper.getNextLink();
	}

	public int[] getPageLinks() {
		return pagingHelper.getPageLinks();
	}

	public PagingHelper getPagingHelper() {
		return pagingHelper;
	}

	public void setPagingHelper(PagingHelper pagingHelper) {
		this.pagingHelper = pagingHelper;
	}

}
