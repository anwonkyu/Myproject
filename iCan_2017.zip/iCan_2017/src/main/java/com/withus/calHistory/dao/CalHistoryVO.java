package com.withus.calHistory.dao;

public class CalHistoryVO {
	private Integer seq;
	private String calnoteId;
	private String userId;
	private String state;
	private String regDate;
	private String comments;
	private String stateName;
	
	
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getCalnoteId() {
		return calnoteId;
	}
	public void setCalnoteId(String calnoteId) {
		this.calnoteId = calnoteId;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	@Override
	public String toString() {
		return "CalHistoryVO [seq=" + seq + ", calnoteId=" + calnoteId
				+ ", userId=" + userId + ", state=" + state + ", regDate="
				+ regDate + ", comments=" + comments + ", stateName="
				+ stateName + "]";
	}
	
	
}
