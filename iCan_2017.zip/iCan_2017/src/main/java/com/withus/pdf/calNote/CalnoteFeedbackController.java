package com.withus.pdf.calNote;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.ext.jfile.JProperties;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPCell;
import com.lowagie.text.Cell;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.LineSeparator;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.memo.dao.ContentMemoVO;

public class CalnoteFeedbackController {
	public static void  buildPdfDocument2(Map<String, Object> map ) throws Exception {
		List<ContentMemoVO> contentFeedbackList = (List<ContentMemoVO>) map.get("contentFeedbackList");
		if(! contentFeedbackList.isEmpty()){
		Document document = new Document();
		PdfWriter writer = null;
	 	/*List<ContentMemoVO> contentIndList = (List<ContentMemoVO>) map.get("contentIndList");
	 	List<ContentMemoVO> contentRevList = (List<ContentMemoVO>) map.get("contentRevList");
	 	List<ContentMemoVO> contentAppList = (List<ContentMemoVO>) map.get("contentAppList");*/
	 	String caloteId = (String) map.get("calnoteId");
	 	CalnoteVO calnoteVo = (CalnoteVO) map.get("calnoteVo");
	 	SimpleDateFormat formatter = new SimpleDateFormat ( "yy-MM-dd", Locale.KOREA );
	 	Date currentTime = new Date ( );
	 	String dTime = formatter.format ( currentTime );
	 	String savePath = JProperties.getString("system.calnoteFeedback");
	 	File file = new File(savePath);
	    if (!file.exists())
	      file.mkdirs();
	 	FileOutputStream fos = new FileOutputStream(new File(savePath, caloteId+".pdf"));
	 	writer = PdfWriter.getInstance(document, fos);
	 	/*HeaderFooter footer = new HeaderFooter(new Phrase("this is page "), new Phrase("."));
	 	document.setFooter(footer);*/
	 	document.open();
	 	
	 	String malgunFont = JProperties.getString("malgun.font");
		 BaseFont bfKorean = BaseFont.createFont(malgunFont, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
	 	Font font10 = new Font(bfKorean, 10);
	 	 Font font12 = new Font(bfKorean, 12);
	 	 Font font22 = new Font(bfKorean, 22);
	 	 Chunk linebreak = new Chunk(new LineSeparator());
	      
	      formatter = new SimpleDateFormat ( "yyyy", Locale.KOREA );
	      dTime = formatter.format ( currentTime );
	      
	      Paragraph header = new Paragraph(calnoteVo.getDocId()+" Rev."+calnoteVo.getRevision(),font10);
	      document.add(header);
	      document.add(linebreak);
	      
	     /* Paragraph title = new Paragraph("설계노트 결제의견 처리 이력서", FontFactory.getFont(FontFactory.HELVETICA, 22, Font.UNDERLINE));*/
	      Paragraph title = new Paragraph("설계노트 결재의견 처리 이력서", font22);
	      title.setAlignment(Element.ALIGN_CENTER);
	      document.add(title);
	      
	     
	    	  Table table1 = new Table(4,contentFeedbackList.size()*4+1);
	    	  table1.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
	    	  SimpleDateFormat transFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	    	  
	    	  
	    	  /*Cell approval = new Cell(new Paragraph("Feedback",new Font(bfKorean, 10, Font.BOLD)));	
	    	  approval.setHorizontalAlignment(Element.ALIGN_CENTER);
	    	  approval.setColspan(4);
	    	  table1.addCell(approval);*/
	    	  int i = 0;
	    	  for(ContentMemoVO contentVo : contentFeedbackList){
	    		 i++;
	    	 
	    		  Cell reviewDate = new Cell(new Paragraph(contentVo.getWdate(),new Font(bfKorean, 10 /*, Font.BOLD*/)));
	    		  Cell reviewers = new Cell(new Paragraph(contentVo.getWname(),new Font(bfKorean, 10 /*, Font.BOLD*/)));
	    		  Cell comments = new Cell(new Paragraph(contentVo.getContents(),new Font(bfKorean, 10 /*, Font.BOLD*/)));
	    		  Cell floating = new Cell(new Paragraph(" ",new Font(bfKorean, 6 /*, Font.BOLD*/)));
	    		  reviewDate.setColspan(3);
	    		  reviewers.setColspan(3);
	    		  comments.setColspan(3);
	    		  floating.setColspan(4);
	    		  table1.addCell(new Paragraph(i+".검토일자", font10));
	    		  table1.addCell(reviewDate);
	    		  table1.addCell(new Paragraph("  검토자", font10));
	    		  table1.addCell(reviewers);
	    		  table1.addCell(new Paragraph("  검토의견", font10));
	    		  table1.addCell(comments);
	    		  table1.addCell(floating);
	    		  table1.setPadding(2);
	    	  }
	    	  document.add(table1);
	      
	      
	 	document.close();
		}
	 	
	 }
}
