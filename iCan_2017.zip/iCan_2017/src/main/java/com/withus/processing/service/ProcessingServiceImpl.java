package com.withus.processing.service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.withus.boardlist.service.BoardListServiceImpl;
import com.withus.calHistory.dao.CalHistoryVO;
import com.withus.commons.seed.WithusSeed;
import com.withus.member.dao.MemberVo;
import com.withus.processing.dao.ProcessingMapper;
import com.withus.processing.dao.ProcessingVO;

@Service("processingService")
public class ProcessingServiceImpl implements ProcessingService{
	
	 private static final Logger LOGGER = LoggerFactory.getLogger(BoardListServiceImpl.class);

	 @Resource(name="processingMapper")
	 private ProcessingMapper processingDAO;
	 
	@Override
	public int insertProcessing(ProcessingVO vo) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		Authentication auth = (Authentication)request.getUserPrincipal();
		if(auth == null){
	     }else{
	    	 Object principal = auth.getPrincipal();
	    	 if(principal != null && principal instanceof MemberVo){
	        	 vo.setUserId(((MemberVo)principal).getId());  //아이디
	        	 vo.setName(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     }
		
	}
		return processingDAO.insertProcessing(vo);
	}

	@Override
	public int updateProcessing(ProcessingVO vo) throws Exception {
		return processingDAO.updateProcessing(vo);
	}
	
	@Override
	public int AppProcessing(ProcessingVO vo) throws Exception {
		return processingDAO.AppProcessing(vo);
	}

	@Override
	public int deleteProcessing(int seq) throws Exception {
		return processingDAO.deleteProcessing(seq);
	}

	@Override
	public ProcessingVO getProcessing(int seq) throws Exception {
		return processingDAO.getProcessing(seq);
	}

	@Override
	public ArrayList<ProcessingVO> selectProcessingList( String searchFild, String searchWord, int start, int end,String type,String docId,String title,String datepicker,String datepicker2,String sortField,String sortOrder,String searchComplete) throws Exception {
		Integer startRownum = start;
		Integer endRownum = end;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("sortField", sortField);
		hashmap.put("sortOrder", sortOrder);
		hashmap.put("type", type);
		hashmap.put("docId", docId);
		hashmap.put("title", title);
		hashmap.put("datepicker", datepicker);
		hashmap.put("datepicker2", datepicker2);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("searchComplete", searchComplete);
		return processingDAO.selectProcessingList(hashmap);
	}

	@Override
	public int selectProcessingTotCnt(String searchWord, String searchFild,String type,String docId,String title,String datepicker,String datepicker2,String searchComplete) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("searchWord", searchWord);
		hashmap.put("searchField", searchFild);
		hashmap.put("type", type);
		hashmap.put("docId", docId);
		hashmap.put("title", title);
		hashmap.put("datepicker", datepicker);
		hashmap.put("datepicker2", datepicker2);
		hashmap.put("searchComplete", searchComplete);
		return processingDAO.selectProcessingTotCnt(hashmap);
	}

	@Override
	public ArrayList<ProcessingVO> userProcessing(int start, int end)
			throws Exception {
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	      
	     		return processingDAO.userProcessing(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

}
