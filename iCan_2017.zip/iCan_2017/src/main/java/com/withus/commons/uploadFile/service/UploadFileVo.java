package com.withus.commons.uploadFile.service;

public class UploadFileVo {

	Integer seq;  	  // 순차번호
	String orgName;  //원본파일명
	String fileName; //등록파일명
	Long fileSize;   //파일사이즈
	String ocode;	  //연계코드
	String flag;  	  //파일구분 V,B,L (vod,board,live)
	String type;      //파일 타입 (N - 일반파일, I-이미지파일(썸네일생성))
	String saveDir;      //파일 저장 경로
	Integer attachNo = 0;
	
	
	public String getSaveDir() {
		return saveDir;
	}
	public void setSaveDir(String saveDir) {
		this.saveDir = saveDir;
	}
	public Integer getAttachNo() {
		return attachNo;
	}
	public void setAttachNo(Integer attachNo) {
		this.attachNo = attachNo;
	}
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getOrgName() {
		return orgName;
	}
	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Long getFileSize() {
		return fileSize;
	}
	public void setFileSize(Long fileSize) {
		this.fileSize = fileSize;
	}
	public String getOcode() {
		return ocode;
	}
	public void setOcode(String ocode) {
		this.ocode = ocode;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
 
	
}
