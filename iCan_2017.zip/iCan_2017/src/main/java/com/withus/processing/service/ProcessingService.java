package com.withus.processing.service;

import java.util.ArrayList;

import com.withus.processing.dao.ProcessingVO;

public interface ProcessingService {

public int insertProcessing(ProcessingVO vo)throws Exception;
	
	public int updateProcessing(ProcessingVO vo)throws Exception;
	
	public int AppProcessing(ProcessingVO vo)throws Exception;
	
	public int deleteProcessing(int seq)throws Exception;
	
	public ProcessingVO getProcessing(int seq)throws Exception;
	
	public ArrayList<ProcessingVO> selectProcessingList( String searchFild, String searchWord, int start, int end,String type,String docId,String title,String datepicker,String datepicker2,String sortField,String sortOrder,String searchComplete) throws Exception;

	public int selectProcessingTotCnt(String searchWord, String searchFild,String type,String docId,String title,String datepicker,String datepicker2,String searchComplete)throws Exception;

	public ArrayList<ProcessingVO> userProcessing(int video_limit, int i)throws Exception;
}
