package com.withus.checklist;

import java.util.ArrayList;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
 

import org.springframework.web.servlet.ModelAndView;
 

import com.withus.checklist.service.CheckListService;
import com.withus.commons.ParameterUtil;
 
@Controller("checkListController")
public class VodmanCheckListController {
	@Resource(name = "checkListService")
    private CheckListService checkListService;
	
	@RequestMapping("/vodman/checkList/checkList")
	 public String doCheck_list() throws Exception {
 
		return "/vodman/checkList/listAll";
	}
	
	@RequestMapping("/vodman/checkList/checkListDetail")
	 public String getChecklistDetail(String type , ModelMap model) throws Exception {
		ArrayList<?> checkList = checkListService.selectCheckList(type,"");
		model.addAttribute("checkList", checkList); 
		model.addAttribute("type", type); 
		return "/vodman/checkList/checkListDetail";
	}
	
	
	
	@RequestMapping("/vodman/checkList/check_list_update.do")
	public String  check_list_update(HttpServletRequest request, HttpServletResponse response, Model model) throws Exception {
	 	Map parameter = ParameterUtil.getParameterMap(request);
	 	System.out.println("parameter======="+parameter);
		int a =  checkListService.check_list_update(parameter); 
 
		return "redirect:/vodman/checkList/checkListDetail.do?type="+request.getParameter("type");
		 
	}
	
	
	
	
}
