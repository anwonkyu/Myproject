package com.withus.siteSkin.dao;

/**
 * @Class Name : SiteSkinVO.java
 * @Description : SiteSkin VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150323
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class SiteSkinVO {
    private static final long serialVersionUID = 1L;
    
    /** seq */
    private Integer seq;
    
    /** title */
    private String title;
    
    /** content */
    private String description;
    
    /** path */
    private String path;
    
 
    /** memo */
    private String memo;
    
    private String img ;
 
    private Integer newVideoLimit ;
    
    private Integer boardLimit ;
    
    

	public Integer getBoardLimit() {
		return boardLimit;
	}

	public void setBoardLimit(Integer boardLimit) {
		this.boardLimit = boardLimit;
	}

	public Integer getNewVideoLimit() {
		return newVideoLimit;
	}

	public void setNewVideoLimit(Integer newVideoLimit) {
		this.newVideoLimit = newVideoLimit;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Integer getSeq() {
        return this.seq;
    }
    
    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    
    
    public String getPath() {
        return this.path;
    }
    
    public void setPath(String path) {
        this.path = path;
    }
    
    public String getMemo() {
        return this.memo;
    }
    
    public void setMemo(String memo) {
        this.memo = memo;
    }
    
}
