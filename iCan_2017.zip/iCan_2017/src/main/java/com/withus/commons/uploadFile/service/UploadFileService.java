package com.withus.commons.uploadFile.service;
import java.util.List;

public interface UploadFileService {

	public int insertAttachFile(UploadFileVo attachFile)throws Exception;
	
	public int insertAttachFile2(UploadFileVo attachFile)throws Exception;

	public List<UploadFileVo> getUploadFileList(String ocode, String flag)throws Exception;

	public UploadFileVo getUploadFile(int seq)throws Exception;
	
	public int deleteFile(int seq)throws Exception;
	
	public int deleteFileAll(String ocode , String flag)throws Exception;
 
	public List<UploadFileVo> getUploadFileListType(String ocode, String flag, String type)throws Exception;
	
	public void deleteSelect(List<String> attachDel) throws Exception;
	
	
	public List<UploadFileVo> getUploadFileListReAll(String ocode, String flag)throws Exception;
	
}
