package com.withus.vodLog.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;
  
/**
 * @Class Name : VodLogDAO.java
 * @Description : VodLog DAO Class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 20150303
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("vodLogMapper")
public interface VodLogMapper  {
 
 
    /**
	 * vod_log 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return vod_log 목록
	 * @exception Exception
	 */
    public ArrayList<VodLogVO> selectVodLogList(VodLogVO searchVO) throws Exception ;

    /**
	 * vod_log 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return vod_log 총 갯수
	 * @exception
	 */
    public int selectVodLogListTotCnt(VodLogVO searchVO) ;

	public ArrayList<VodLogVO> selectVodLogListLive(VodLogVO vo);

	public int selectVodLogListTotCntLive(VodLogVO vo);
	
	
	public ArrayList<CounterVO> selectCounterList(HashMap<String, String> hashmap);
	
	public ArrayList<CounterVO> selectCounterListLive(HashMap<String, String> hashmap);

	public ArrayList<CounterVO> selectCounterListMonth(
			HashMap<String, String> hashmap);
	public ArrayList<CounterVO> selectCounterListMonthLive(
			HashMap<String, String> hashmap);
	public ArrayList<CounterVO> selectCounterListYear(
			HashMap<String, String> hashmap);
	public ArrayList<CounterVO> selectCounterListYearLive(
			HashMap<String, String> hashmap);
	
	public ArrayList<CounterVO> selectCounterListMenu(
			HashMap<String, String> hashmap);

	public ArrayList<VodLogVO> connectCount(HashMap<String, String> hashmap);

	public ArrayList<VodLogVO> connectCountWeek(HashMap<String, Object> hashmap);

	public ArrayList<VodLogVO> connectCountMonth(HashMap<String, Object> hashmap);

	public ArrayList<VodLogVO> connectCountYear(HashMap<String, Object> hashmap);

	public ArrayList<VodLogVO> selectVodLogListAll(VodLogVO vo);

	public ArrayList<VodLogVO> selectVodLogListLiveAll(VodLogVO vo);

	public void contactStatInsert(HashMap<String, String> hashmap);

	public void webLogInsert(HashMap<String, String> hashmap);
 
	public void pageCnnCnt(HashMap<String, String> hashmap); 
	
	

}
