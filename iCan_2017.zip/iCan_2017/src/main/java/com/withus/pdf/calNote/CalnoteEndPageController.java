package com.withus.pdf.calNote;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import com.ext.jfile.JProperties;
import com.itextpdf.text.Element;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;
import com.withus.calnote.dao.CalnoteVO;

public class CalnoteEndPageController {
	public static void  buildPdfDocument2(Map<String, Object> map ) throws Exception {
		Document document = new Document();
		PdfWriter writer = null;
		
	 	CalnoteVO calnoteVo = (CalnoteVO) map.get("calnoteVo");
	 	SimpleDateFormat formatter = new SimpleDateFormat ( "yy-MM-dd", Locale.KOREA );
	 	Date currentTime = new Date ( );
	 	String dTime = formatter.format ( currentTime );
	 	String savePath = JProperties.getString("system.calnoteEnd");
	 	File file = new File(savePath);
	    if (!file.exists())
	    file.mkdirs();
	 	FileOutputStream fos = new FileOutputStream(new File(savePath, calnoteVo.getCalnoteId()+".pdf"));
	 	writer = PdfWriter.getInstance(document, fos);
	 	
	 	 document.open(); 
	 	 String malgunFont = JProperties.getString("malgun.font");
	 	 BaseFont bfKorean = BaseFont.createFont(malgunFont, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
	 	 Font font16 = new Font(bfKorean, 16);
	 	 Font font18 = new Font(bfKorean, 18);
	 	 Font font22 = new Font(bfKorean, 22);
	 	 Paragraph enter = new Paragraph(" ",font22);
	      formatter = new SimpleDateFormat ( "yyyy", Locale.KOREA );
	      dTime = formatter.format ( currentTime );
	      document.add(enter);
	      document.add(enter);
	      document.add(enter);
	      document.add(enter);
	      document.add(enter);
	      document.add(enter);
	      document.add(enter);
	      document.add(enter);
	      document.add(enter);
	      Paragraph title = new Paragraph("The End of Calulcation Note,"+calnoteVo.getDocId()+" Rev."+calnoteVo.getRevision(), font18);
	      Paragraph title2 = new Paragraph("(This page is not included in calculation page count)", font16);
	      title.setAlignment(Element.ALIGN_CENTER);
	      title2.setAlignment(Element.ALIGN_CENTER);
	      
	      document.add(title);
	      document.add(title2);
	      
	      
	 	document.close();
	 	
	 }
}
