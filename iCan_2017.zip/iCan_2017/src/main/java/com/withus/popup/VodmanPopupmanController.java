package com.withus.popup;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
 



import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileVo;
import com.withus.popup.service.PopupmanService;
 
import com.withus.popup.dao.PopupmanVO;

/**
 * @Class Name : PopupmanController.java
 * @Description : Popupman Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-12
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class VodmanPopupmanController {

    @Autowired Properties prop;
    
    @Autowired
    private PopupmanService popupmanService;
    
    @Resource
    private PagingHelperService page;
    
    @Resource
	 private UploadFileService uploadFileService;
    /**
	 * popupman 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 PopupmanDefaultVO
	 * @return "/popupman/PopupmanList"
	 * @exception Exception
	 */
    @RequestMapping(value="/popup/list.do")
    public String selectContentMemoList(Integer curPage,String searchFild,  String searchWord, Model model) 
            throws Exception {
     
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";

//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		int totalRecord = popupmanService.selectPopupmanListTotCnt(searchFild, searchWord);
		
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks(); 
		
		
        ArrayList<PopupmanVO> popupList = popupmanService.selectPopupmanList( searchFild, searchWord, start, end);
        model.addAttribute("resultList", popupList);
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("no", no);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
      
        return "/vodman/popup/list";
    } 
    
    @RequestMapping(value="/popup/write.do", method=RequestMethod.GET)
    public String addPopupmanView(  Model model)
            throws Exception {
     
        return "/vodman/popup/addForm";
    }
    
    @RequestMapping(value="/popup/write.do", method=RequestMethod.POST)
    public String addPopupman(MultipartHttpServletRequest mpRequest, @ModelAttribute("popupmanVO")PopupmanVO popupmanVO )
            throws Exception { 
     
    			Iterator<String> it = mpRequest.getFileNames();

    			while (it.hasNext()) {
    					MultipartFile multiFile = mpRequest.getFile((String) it.next()); 
    					String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename()); 
    					if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename())
    							&& com.withus.commons.TextUtil.isFileImage(multiFile.getContentType())) {
    						
    						multiFile.transferTo(new File(prop.getProperty("POPUP_PATH").trim() + filename));
    						// 대표이미지 업데이트
    						// 파일명과 확장자를 분리 - 썸네일 생성시 해더 정보값에 따라 확장자가 자동으로 붙어므로 원본 확장자를 넘겨줌
    						    int fileIndex = StringUtils.lastIndexOf(multiFile.getOriginalFilename(), '.');
    					        String extension = null;
    					        if (fileIndex != -1) {
    					            extension = StringUtils.substring(multiFile.getOriginalFilename(), fileIndex + 1); 
    					        } 
    					        int thumbsizeW = 600;
    					        if (popupmanVO.getWidth() != null && !popupmanVO.getWidth().equals("")) {
    					        	thumbsizeW = Integer.parseInt(popupmanVO.getWidth());
    					        }
    					        int thumbsizeH = 600;
    					        if (popupmanVO.getHeight() != null && !popupmanVO.getHeight().equals("")) {
    					        	thumbsizeH = Integer.parseInt(popupmanVO.getHeight());
    					        }
    					       
    					        com.withus.commons.uploadFile.UploadUtil.createThumb(prop.getProperty("POPUP_PATH").trim()+File.separator + filename, prop.getProperty("WEB_ROOT_UPLOAD").trim()+File.separator+ "popup" + File.separator+ filename+"."+extension, thumbsizeW, thumbsizeH);			// 썸네일 생성
     						 	
     						
    						popupmanVO.setImgName( filename+"."+extension); 
    					}
    			} 
    			int seq = popupmanService.insertPopupman(popupmanVO) ;
     
        return "forward:/vodman/popup/list.do";
    }
    
    @RequestMapping(value="/popup/update.do", method=RequestMethod.GET)
    public String updatePopupmanView(
            @RequestParam(value="seq",required=true) int seq ,  Model model)
            throws Exception {
        PopupmanVO popupmanVO = popupmanService.selectPopupman(seq);
         
        model.addAttribute("popupmanVO",popupmanVO);
        return "/vodman/popup/addForm";
    }
 

    @RequestMapping(value="/popup/update.do", method=RequestMethod.POST)   
    public String updatePopupman(MultipartHttpServletRequest mpRequest, @ModelAttribute("popupmanVO")PopupmanVO popupmanVO )
            throws Exception { 
        	// 파일 삭제
        	if (popupmanVO.getImg_del() != null && popupmanVO.getImg_del().equals("Y")) {
        		popupmanVO.setImgName("");
        	}
			 
    		//파일업로드
			Iterator<String> it = mpRequest.getFileNames(); 
			while (it.hasNext()) {
					MultipartFile multiFile = mpRequest.getFile((String) it.next());
 
					if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename())
							&& com.withus.commons.TextUtil.isFileImage(multiFile.getContentType())) {  
						String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename()); 
						multiFile.transferTo(new File(prop.getProperty("POPUP_PATH").trim() + filename));  
						
						// 대표이미지 업데이트
						// 파일명과 확장자를 분리 - 썸네일 생성시 해더 정보값에 따라 확장자가 자동으로 붙어므로 원본 확장자를 넘겨줌
						    int fileIndex = StringUtils.lastIndexOf(multiFile.getOriginalFilename(), '.');
					        String extension = null;
					        if (fileIndex != -1) {
					            extension = StringUtils.substring(multiFile.getOriginalFilename(), fileIndex + 1); 
					        } 
					        
					        int thumbsizeW = 600;
					        if (popupmanVO.getWidth() != null && !popupmanVO.getWidth().equals("")) {
					        	thumbsizeW = Integer.parseInt(popupmanVO.getWidth());
					        }
					        int thumbsizeH = 600;
					        if (popupmanVO.getHeight() != null && !popupmanVO.getHeight().equals("")) {
					        	thumbsizeH = Integer.parseInt(popupmanVO.getHeight());
					        }
					       
					        com.withus.commons.uploadFile.UploadUtil.createThumb(prop.getProperty("POPUP_PATH").trim()+File.separator + filename, prop.getProperty("WEB_ROOT_UPLOAD").trim()+File.separator+ "popup" + File.separator+ filename+"."+extension, thumbsizeW, thumbsizeH);			// 썸네일 생성
 						 	
					        
					        popupmanVO.setImgName( filename+"."+extension); 
					} 
			}  
			popupmanService.updatePopupman(popupmanVO);
			
        return "forward:/vodman/popup/list.do";
    }
    
    @RequestMapping("/popup/delete.do")
    public String deletePopupman(
    		 @RequestParam(value="seq" ,required=true) int seq)
            throws Exception {
        popupmanService.deletePopupman(seq);
       
        return "forward:/vodman/popup/list.do";
    }
    
    @RequestMapping(value="/popup/popup.do", method={RequestMethod.POST, RequestMethod.GET})   
    public String viewPopupman( @RequestParam(value="seq",required=true) int seq ,  Model model)
            throws Exception {
        PopupmanVO popupmanVO = popupmanService.selectPopupman(seq);
         
        model.addAttribute("popupmanVO",popupmanVO);
        return "/main/mian_popup";
    }
    

}
