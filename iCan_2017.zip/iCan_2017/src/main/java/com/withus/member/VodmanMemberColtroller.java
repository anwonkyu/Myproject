package com.withus.member;
 
 
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
 
 
import java.util.Properties;

import javax.annotation.Resource;
 





import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
 

import org.springframework.web.bind.annotation.RequestParam;
 

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.View;
 




import com.thoughtworks.xstream.XStream;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.member.service.MemberService;
import com.withus.member.dao.MemberVo;
  




import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
 
 




import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;


@Controller
@RequestMapping("/vodman")
public class VodmanMemberColtroller {

private static final Logger logger = LoggerFactory.getLogger(VodmanMemberColtroller.class);
	
	@Resource(name = "xstreamMarshaller")
	private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView;

	@Autowired
	private MemberService memberService;
	
	@Autowired Properties prop;
	
	@Resource
	private PagingHelperService page;
	
//	@RequestMapping(value="/login.do", method=RequestMethod.GET)
//	public String login(){
//		return "/vodman/member/login";		
//	}
	
	// 일반 로그인 사용 (스프링 시큐리티사용시 적용하면 오류)
	/*
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public String login(@RequestParam(value="id" )String id, @RequestParam(value="pwd")String pwd ){
		
		HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession(false);
		
		MemberVo memberVo = memberService.login(id, pwd);
		
		if (memberVo != null) {
		 
 			session.setAttribute(prop.getProperty("USER_KEY"), memberVo);
			
			//return "member.changePasswd";
			return "redirect:/main/main.do";
		} else {
			System.out.println("login-실패");
			return "/member/login";
		}
	}
	*/
 
	@RequestMapping(value="/member/view.do", method=RequestMethod.GET)
	public String memberView(String id, 
			 
			Model model) throws Exception {
 
		//상세보기 
		MemberVo memberVo = memberService.memberInfo(id);
 
		model.addAttribute("thisMember", memberVo);   
	 

		return "/vodman/member/view";
	}
	
	
	@RequestMapping(value="/member/write.do", method=RequestMethod.GET)
	public String write( Model model) throws Exception {
 
		return "/vodman/member/addForm";
	}
	
	@RequestMapping(value="/member/write.do", method=RequestMethod.POST)
	public View write(@ModelAttribute("memberVo") MemberVo memberVo, Model model ) throws Exception {
	//public String write(@ModelAttribute("memberVo") MemberVo memberVo, Principal principal) {		
		//Principal principal 인증 정보 저장 객체
	 
		   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     if ( memberService.insert(memberVo) > 0) {
			        xml.setMessage("등록 되었습니다.");
			        xml.setError(true);
		       
		    } else {
		    	 xml.setMessage("등록에 실패하였습니다.");
		 	     xml.setError(false);
		    }

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
	
	@RequestMapping(value="/member/writeExcel.do", method=RequestMethod.GET)
	public String writeExcel( Model model) throws Exception {
 
		return "/vodman/member/addFormExcel";
	}
	
	
	@RequestMapping(value="/member/writeExcel.do", method=RequestMethod.POST)
	public String memberWriteExcel(MultipartHttpServletRequest mpRequest, Model model) throws IllegalStateException, IOException {
		
		int true_cnt=0;
		int false_cnt = 0;
		String false_no = "";
		XSSFRow row;
		XSSFCell cell;

	try {
		
		Iterator<String> it = mpRequest.getFileNames(); 
		while (it.hasNext()) {
				MultipartFile multiFile = mpRequest.getFile((String) it.next()); 
				 
				if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename())
					) {
							String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename()); 
							multiFile.transferTo(new File(prop.getProperty("BASE_PATH").trim()+File.separator+  filename)); 
				
							FileInputStream inputStream = new FileInputStream(prop.getProperty("BASE_PATH").trim()+File.separator+  filename);
							XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					
							//sheet수 취득
							int sheetCn = workbook.getNumberOfSheets();
//							System.out.println("sheet수 : " + sheetCn);
							
							for(int cn = 0; cn < sheetCn; cn++){
//								System.out.println("취득하는 sheet 이름 : " + workbook.getSheetName(cn));
//								System.out.println(workbook.getSheetName(cn) + " sheet 데이터 취득 시작");
								
								//0번째 sheet 정보 취득
								XSSFSheet sheet = workbook.getSheetAt(cn);
								
								//취득된 sheet에서 rows수 취득
								int rows = sheet.getPhysicalNumberOfRows();
//								System.out.println(workbook.getSheetName(cn) + " sheet의 row수 : " + rows);
								
								//취득된 row에서 취득대상 cell수 취득
								if (rows> 0) {
								int cells = sheet.getRow(cn).getPhysicalNumberOfCells(); //
//								System.out.println(workbook.getSheetName(cn) + " sheet의 row에 취득대상 cell수 : " + cells);
								
								for (int r = 0; r < rows; r++) {
									MemberVo memberVo = new MemberVo();
									row = sheet.getRow(r); // row 가져오기
									if (row != null) {
			 
										for (int c = 0; c < cells; c++) {
											cell = row.getCell(c);
											if (cell != null) {
												String value = null;
												switch (cell.getCellType()) {
												case XSSFCell.CELL_TYPE_FORMULA:
													value = cell.getCellFormula();
													break;
												case XSSFCell.CELL_TYPE_NUMERIC:
													//value = "" + cell.getNumericCellValue();
//													value = String.valueOf((int)cell.getNumericCellValue());
//													break;													
 
													if(DateUtil.isCellDateFormatted(cell)){ //날짜데이터 포멧설정
														Date date = cell.getDateCellValue();
														value = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(date);
													}else{
														value = String.valueOf((int)cell.getNumericCellValue());
													}
													break;
													
												case XSSFCell.CELL_TYPE_STRING:
													value = "" + cell.getStringCellValue();
													break;
												case XSSFCell.CELL_TYPE_BLANK:
													value = "[null 아닌 공백]";
													break;
												case XSSFCell.CELL_TYPE_ERROR:
													value = "" + cell.getErrorCellValue();
													break;
												default:
												}
//												System.out.print(value + "\t");
												
												if (c == 0) {
													memberVo.setId(value);  // 아이디
													//System.out.println("아이디"+value);
												} else if (c == 1) {
													memberVo.setUserpassword(value);  // 패스워드
													//System.out.println("패스워드"+value);
												} else if (c == 2) { 
													memberVo.setName(value);  // 이름
													//System.out.println("이름"+value);
												}else if (c == 3) {
													memberVo.setEmail(value);  //이메일
													//System.out.println("이메일"+value);
												 
												}else if (c == 4) {
													int level = 1;  // level
													if (value != null && value.length() > 0) {
														level = Integer.parseInt(value.toString());
													}
													//System.out.println("레벨"+value);
													memberVo.setLevels(level);
												}else if (c == 5) {
													memberVo.setMemberGroup(value);  //소속 발전소
													//System.out.println("발전소"+value);
												}else if (c == 6) {
													memberVo.setHp(value); // 연락처
													//System.out.println("연락처"+value);
												} else if (c == 7) {
													memberVo.setAuthKey(value);  // 회원구분
													//System.out.println("회원구분"+value);
												} else if (c == 8) {
													memberVo.setJoinDate(value);  // joindate
													//System.out.println("등록일"+value);
												} else if (c == 9) {
													memberVo.setApproval(value);  // approval 승인여부
													//System.out.println("승인여부"+value);
												} else if (c == 10) {
													memberVo.setLastloginDate(value);  // lastlogin_date
													//System.out.println("최종로그인 일자"+value);
												} else if (c == 11) {
													memberVo.setIpost(value);  // ipost
													//System.out.println("아이포스트"+value);
												} else if (c == 12) {
													memberVo.setUseMailling(value);  // use_mailling
													//System.out.println("메일수신여부"+value);
												}
											} else {
//												System.out.print("[null]\t");
											}
											
											
										} // for(c) 문
//										System.out.print("\n");
										if (memberVo != null) {
											
											memberVo.setPwdAskNum(1);
											memberVo.setSsn("0");
											//memberVo.setAuthKey("USER");
									
											int rtn = 0;
											try{
												rtn = memberService.insert(memberVo);
											} catch (Exception ExceptionFactory ) {
												System.out.println(ExceptionFactory.toString());
											}
											if( rtn> 0) {
												true_cnt ++;
											} else {
												false_cnt ++;
												false_no = false_no+memberVo.getSsn()+",";
											}
										}
										
									}
								} // for(r) 문
//								System.out.println("등록:"+true_cnt);
//								System.out.println("실패:"+false_cnt);
//								System.out.println("실패 No:"+false_no);
								}
							}
							
							
							// 엑셀 파일 삭제
							if (new File(prop.getProperty("BASE_PATH").trim()+File.separator+  filename).exists()) {
								new File(prop.getProperty("BASE_PATH").trim()+File.separator+  filename).delete();
							}
							
						}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	

		model.addAttribute("true_cnt",true_cnt); 
		model.addAttribute("false_cnt", false_cnt);
		model.addAttribute("false_no", false_no);
	
		
	   return "/vodman/member/memberExcelOk";
	}
	
 
	
	@RequestMapping(value="/member/writeExcel2.do", method=RequestMethod.POST)
	public String memberWriteExcel2(MultipartHttpServletRequest mpRequest, Model model) throws IllegalStateException, IOException {
		
		int true_cnt=0;
		int false_cnt = 0;
		String false_no = "";
		XSSFRow row;
		XSSFCell cell;

	try {
		
		Iterator<String> it = mpRequest.getFileNames(); 
		while (it.hasNext()) {
				MultipartFile multiFile = mpRequest.getFile((String) it.next()); 
				 
				if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename())
					) {
							String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename()); 
							multiFile.transferTo(new File(prop.getProperty("BASE_PATH").trim()+File.separator+  filename)); 
				
							FileInputStream inputStream = new FileInputStream(prop.getProperty("BASE_PATH").trim()+File.separator+  filename);
							XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
					
							//sheet수 취득
							int sheetCn = workbook.getNumberOfSheets();
//							System.out.println("sheet수 : " + sheetCn);
							
							for(int cn = 0; cn < sheetCn; cn++){
//								System.out.println("취득하는 sheet 이름 : " + workbook.getSheetName(cn));
//								System.out.println(workbook.getSheetName(cn) + " sheet 데이터 취득 시작");
								
								//0번째 sheet 정보 취득
								XSSFSheet sheet = workbook.getSheetAt(cn);
								
								//취득된 sheet에서 rows수 취득
								int rows = sheet.getPhysicalNumberOfRows();
//								System.out.println(workbook.getSheetName(cn) + " sheet의 row수 : " + rows);
								
								//취득된 row에서 취득대상 cell수 취득
								if (rows> 0) {
								int cells = sheet.getRow(cn).getPhysicalNumberOfCells(); //
//								System.out.println(workbook.getSheetName(cn) + " sheet의 row에 취득대상 cell수 : " + cells);
								
								for (int r = 0; r < rows; r++) {
									MemberVo memberVo = new MemberVo();
									row = sheet.getRow(r); // row 가져오기
									if (row != null) {
										String temp_gray = "";
										String temp_buseo = "";
										for (int c = 0; c < cells; c++) {
											cell = row.getCell(c);
											if (cell != null) {
												String value = null;
												switch (cell.getCellType()) {
												case XSSFCell.CELL_TYPE_FORMULA:
													value = cell.getCellFormula();
													break;
												case XSSFCell.CELL_TYPE_NUMERIC:
													//value = "" + cell.getNumericCellValue();
													value = String.valueOf((int)cell.getNumericCellValue());
												 
													break;
												case XSSFCell.CELL_TYPE_STRING:
													value = "" + cell.getStringCellValue();
													break;
												case XSSFCell.CELL_TYPE_BLANK:
													value = "[null 아닌 공백]";
													break;
												case XSSFCell.CELL_TYPE_ERROR:
													value = "" + cell.getErrorCellValue();
													break;
												default:
												}
//												System.out.print(value + "\t");
												
												if (c == 0) {
													memberVo.setSsn(value);
//													System.out.println("번호");
												} else if (c == 1) {
													memberVo.setName(value);
//													System.out.println("이름");
												} else if (c == 2) {
													//memberVo.setBuseo(value);
													temp_gray = value;
//													System.out.println("직급");
												}else if (c == 3) {
													//memberVo.setBuseo(value+"/"+temp_gray);
													temp_buseo = value;
//													System.out.println("부서");
												}else if (c == 4) {
													memberVo.setId(value);
//													System.out.println("아이디");
												}else if (c == 5) {
													int level = 1;
													if (value != null && value.length() > 0) {
														level = Integer.parseInt(value.toString());
													}
													memberVo.setLevels(level);
//													System.out.println("레벨");
												}else if (c == 6) {
													memberVo.setUserpassword(value);
//													System.out.println("비밀번호");
												} 
											} else {
//												System.out.print("[null]\t");
											}
											
											
										} // for(c) 문
//										System.out.print("\n");
										if (memberVo != null) {
											memberVo.setBuseo(temp_buseo+"/"+temp_gray);
											memberVo.setPwdAskNum(1);
											memberVo.setAuthKey("USER");
											memberVo.setApproval("Y");
											
											int rtn = 0;
											try{
												rtn = memberService.insert2(memberVo);
											} catch (Exception ExceptionFactory ) {
												System.out.println(ExceptionFactory.toString());
											}
											if( rtn> 0) {
												true_cnt ++;
											} else {
												false_cnt ++;
												false_no = false_no+memberVo.getSsn()+",";
											}
										}
										
									}
								} // for(r) 문
//								System.out.println("등록:"+true_cnt);
//								System.out.println("실패:"+false_cnt);
//								System.out.println("실패 No:"+false_no);
								}
							}
							
							
							// 엑셀 파일 삭제
							if (new File(prop.getProperty("BASE_PATH").trim()+File.separator+  filename).exists()) {
								new File(prop.getProperty("BASE_PATH").trim()+File.separator+  filename).delete();
							}
							
						}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	

		model.addAttribute("true_cnt",true_cnt); 
		model.addAttribute("false_cnt", false_cnt);
		model.addAttribute("false_no", false_no);
	
		
	   return "/vodman/member/memberExcelOk";
	}
	
 
	
	@RequestMapping(value="/member/list.do",method={RequestMethod.GET, RequestMethod.POST})
	public String dispMemberList( Integer curPage, String searchFild,String searchWord, Model model,String searchLevel) throws Exception{
 
		if (curPage == null) curPage = 1;
		if (searchFild == null) searchFild = "";
		if (searchWord == null) searchWord = "";
 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		
		int totalRecord = memberService.getTotalRecord(searchFild, searchWord, searchLevel,"");
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
		
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
 
		List<MemberVo> list = memberService.getMemberList(searchFild,  searchWord, start, end, searchLevel,"");
		Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		
		model.addAttribute("list",list); 
		model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		
		return "/vodman/member/list";
	}
	
	 @RequestMapping(value="/member/mailSend.do",method={RequestMethod.GET, RequestMethod.POST})
		public String questionMemberList(Integer curPage, String searchFild,String searchWord, Model model,String searchLevel,String seq) throws Exception{
		 if (curPage == null) curPage = 1;
			if (searchFild == null) searchFild = "";
			if (searchWord == null) searchWord = "";
	 
			int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
			int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
			
			
			int totalRecord = memberService.getTotalRecord(searchFild, searchWord, searchLevel,"");
			PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
			
			page.setPagingHelper(pagingHelper);
			int start = pagingHelper.getStartRecord();
			int end = pagingHelper.getEndRecord();
	 
			List<MemberVo> list = memberService.getMemberList(searchFild,  searchWord, start, end, searchLevel,"");
			Integer no = page.getListNo();
			Integer prevLink = page.getPrevLink();
			Integer nextLink = page.getNextLink();
			Integer firstPage = page.getFirstPage();
			Integer lastPage = page.getLastPage();
			int[] pageLinks = page.getPageLinks();
			model.addAttribute("list",list); 
			 model.addAttribute("no", no);
			model.addAttribute("prevLink", prevLink);
			model.addAttribute("nextLink", nextLink);
			model.addAttribute("firstPage", firstPage);
			model.addAttribute("lastPage", lastPage);
			model.addAttribute("pageLinks", pageLinks);
			model.addAttribute("curPage", curPage); 
			model.addAttribute("totalRecord", totalRecord); 
			model.addAttribute("seq", seq); 
		 return "/vodman/member/mailSendList";
		}
	
	
	
	@RequestMapping(value="/site/pop_memberList.do",method={RequestMethod.GET, RequestMethod.POST})
	public String siteMemberList( Integer curPage, String searchFild,String searchWord, Model model,String searchLevel) throws Exception{
		
		if (curPage == null) curPage = 1;
		if (searchFild == null) searchFild = "";
		if (searchWord == null) searchWord = "";
 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		
		int totalRecord = memberService.getTotalRecord(searchFild, searchWord, searchLevel,"");
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
		
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
 
		List<MemberVo> list = memberService.getMemberList(searchFild,  searchWord, start, end, searchLevel,"");
		Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("list",list); 
		 model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		
		return "/vodman/site/pop_memberList";
	}
	
	
	@RequestMapping(value="/member/update.do", method=RequestMethod.GET)
	public String modify(String id, 
			Model model) throws Exception {
		
		MemberVo thisMember = memberService.memberInfo(id);

		//수정페이지에서의 보일 게시글 정보
		model.addAttribute("thisMember", thisMember);
 		
		return "/vodman/member/addForm";
	}
	
	
	@RequestMapping(value="/member/update.do", method=RequestMethod.POST)
	public View update(@ModelAttribute("memberVo") MemberVo memberVo, Model model ) throws Exception {
	//public String write(@ModelAttribute("memberVo") MemberVo memberVo, Principal principal) {		
		//Principal principal 인증 정보 저장 객체
	 
		   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     if ( memberService.update(memberVo) > 0) {
			        xml.setMessage(memberVo.getId());
			        xml.setError(true);
		       
		    } else {
		    	 xml.setMessage(memberVo.getId());
		 	     xml.setError(false);
		    }

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
	
 
		
		 @RequestMapping(value="/member/procIdCheck.do", method={RequestMethod.POST})
		    public View idCheck(String id, ModelMap model) throws Exception {
		       
		      	if (id == null) id = ""; 
		      	
		    	XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult();
		        
		        	if ( memberService.checkId(id) > 0) { // 관리자 전용게시판 확인
 
					     xml.setMessage(id);  // 해당아이디 사용중
					     xml.setError(false);
				 
			        } else {
			        	 xml.setMessage(id);
				 	     xml.setError(true);
			        }

			        model.addAttribute("xmlData", xml);
			        return xmlView; 
		    }
		 
		 
		 @RequestMapping(value="/member/delete.do", method=RequestMethod.POST)
			public View delete(@RequestParam(value="id" ,required=true)String id, Model model ) {
 				   
					XStream xst = xstreamMarshaller.getXStream();
			    	xst.alias("result", XmlResult.class);  
			        XmlResult xml = new XmlResult(); 
			        
				     if ( memberService.deleteMember(id) > 0) {
					        xml.setMessage("삭제되었습니다.");
					        xml.setError(true);
				       
				    } else {
				    	xml.setMessage("삭제에 실패하였습니다.");
				 	     xml.setError(false);
				    }

			    model.addAttribute("xmlData", xml);
			    
			    return xmlView;
			    
			}
		 
 
			@RequestMapping(value="/member/pwd_change.do", method=RequestMethod.GET)
			public String pwdChange(String id, 
					Model model) throws Exception {
				
				MemberVo thisMember = memberService.memberInfo(id);
		 
				//수정페이지에서의 보일 게시글 정보
				model.addAttribute("thisMember", thisMember);
		 		
				return "/vodman/member/pop_pwdChange";
			}
			
		 
		 
		 @RequestMapping(value="/member/pwdUpdate.do", method=RequestMethod.POST)
			public View pwdUpdate(@RequestParam(value="id",required=true)String id, @RequestParam(value="userpassword",required=true) String pwd,
					Model model ) throws Exception {
		   
					XStream xst = xstreamMarshaller.getXStream();
			    	xst.alias("result", XmlResult.class);  
			        XmlResult xml = new XmlResult(); 
			        
				     if ( memberService.pwdUpdate(id, pwd) > 0) {
					        xml.setMessage("수정 되었습니다.");
					        xml.setError(true);
				       
				    } else {
				    	xml.setMessage("수정에 실패하였습니다.");
				 	     xml.setError(false);
				    }

			    model.addAttribute("xmlData", xml);
			    
			    return xmlView;
			    
			}
		 
			
			@RequestMapping(value="/member/updateApproval.do", method=RequestMethod.POST)
			public View updateApproval (String approval, String id , Model model ) throws Exception {
			//public String write(@ModelAttribute("memberVo") MemberVo memberVo, Principal principal) {		
				//Principal principal 인증 정보 저장 객체 
				 
					XStream xst = xstreamMarshaller.getXStream();
			    	xst.alias("result", XmlResult.class);  
			        XmlResult xml = new XmlResult();  
				     if ( memberService.updateApproval(approval, id) > 0) {
				    	    xml.setMessage("수정 되었습니다!");
					        xml.setError(true); 
				    } else {
				    	 xml.setMessage("수정에 실패하였습니다!");
				 	     xml.setError(false);
				    }

			    model.addAttribute("xmlData", xml);
			    
			    return xmlView;
			    
			}
			
			@RequestMapping(value="/member/approveMemberList.do",method={RequestMethod.GET, RequestMethod.POST})
			public String approvalMemberList(String kinds, Integer curPage, String searchFild,String searchWord, Model model,String searchLevel) throws Exception{
				if (curPage == null) curPage = 1;
				if (searchFild == null) searchFild = "";
				if (searchWord == null) searchWord = "";
				int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
				int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
				
				int totalRecord = memberService.getTotalRecord(searchFild, searchWord, searchLevel,"");
				PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
				page.setPagingHelper(pagingHelper);
				int start = pagingHelper.getStartRecord();
				int end = pagingHelper.getEndRecord();
				List<MemberVo> list = memberService.getMemberList(searchFild,  searchWord, start, end, searchLevel,"");
				Integer no = page.getListNo();
				Integer prevLink = page.getPrevLink();
				Integer nextLink = page.getNextLink();
				Integer firstPage = page.getFirstPage();
				Integer lastPage = page.getLastPage();
				int[] pageLinks = page.getPageLinks();
				model.addAttribute("list",list); 
				 model.addAttribute("no", no);
				model.addAttribute("prevLink", prevLink);
				model.addAttribute("nextLink", nextLink);
				model.addAttribute("firstPage", firstPage);
				model.addAttribute("lastPage", lastPage);
				model.addAttribute("pageLinks", pageLinks);
				model.addAttribute("curPage", curPage); 
				model.addAttribute("totalRecord", totalRecord);
				model.addAttribute("kinds", kinds);
				
				return "/vodman/processing/approveList";
			}
			
	
}
