package com.withus.group.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 



import com.withus.group.service.GroupsService;
 
import com.withus.group.dao.GroupsVO;
import com.withus.group.dao.GroupsMapper;

/**
 * @Class Name : GroupsServiceImpl.java
 * @Description : Groups Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("groupsService")
public class GroupsServiceImpl implements
        GroupsService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(GroupsServiceImpl.class);

    @Resource(name="groupsMapper")
    private GroupsMapper groupsDAO;
    
    /** ID Generation */
    //@Resource(name="{egovGroupsIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * groups을 등록한다.
	 * @param vo - 등록할 정보가 담긴 GroupsVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertGroups(GroupsVO vo) throws Exception {
     
    	return groupsDAO.insertGroups(vo);
 
    }

    /**
	 * groups을 수정한다.
	 * @param vo - 수정할 정보가 담긴 GroupsVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateGroups(GroupsVO vo) throws Exception {
        return groupsDAO.updateGroups(vo);
    }

    /**
	 * groups을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 GroupsVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteGroups(int groupId) throws Exception {
    	return groupsDAO.deleteGroups(groupId);
    }

    /**
	 * groups을 조회한다.
	 * @param vo - 조회할 정보가 담긴 GroupsVO
	 * @return 조회한 groups
	 * @exception Exception
	 */
    public GroupsVO selectGroups(int groupId) throws Exception {
        GroupsVO resultVO = groupsDAO.selectGroups(groupId);
       
        return resultVO;
    }

    /**
	 * groups 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return groups 목록
	 * @exception Exception
	 */
    public ArrayList<GroupsVO> selectGroupsList() throws Exception {
        return groupsDAO.selectGroupsList();
    }

    /**
	 * groups 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return groups 총 갯수
	 * @exception
	 */
    public int selectGroupsListTotCnt() {
		return groupsDAO.selectGroupsListTotCnt();
	}

	@Override
	public ArrayList<GroupsVO> selectGroupsMemberList(int groupId) {
		  return groupsDAO.selectGroupsMemberList(groupId);
	}

	@Override
	public ArrayList<GroupsVO> selectGroupsAuthority(int groupId) {
		 return groupsDAO.selectGroupsAuthorityList(groupId);
	}

	@Override
	public int deleteGroupsMember(int seq) {
		return groupsDAO.deleteGroupsMember(seq);
	}

	@Override
	public int deleteGroupsAuthority(int seq) {
		return groupsDAO.deleteGroupsAuthority(seq);
	}
    
	
	@Override
	
	public int insertGroupsMember(MultiValueMap<String, String> params)
			throws Exception { 
	
		
		HashMap<String, String> param = null;
		ArrayList<Object> mArrayList;
		mArrayList = new ArrayList<Object>();

		String groupId = params.get("groupId").get(0).toString();
		for (int i = 0; i < params.get("chkValue").size(); i++) {
			param = new HashMap<String, String>();
			param.put("memberId", params.get("chkValue").get(i).toString()); 
			
			param.put("groupId", groupId);
			mArrayList.add(param);  
 		}  
			
			HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
			hashmap.put("list", mArrayList);  
 
			return groupsDAO.insertGroupsMember(hashmap);
	        
	}
	@Override
	
	public int insertGroupsAuthority(MultiValueMap<String, String> params)
			throws Exception { 
	
		
		HashMap<String, String> param = null;
		ArrayList<Object> mArrayList;
		mArrayList = new ArrayList<Object>();
	
		String groupId = params.get("groupId").get(0).toString();
		for (int i = 0; i < params.get("chkValue").size(); i++) {
			param = new HashMap<String, String>();
			param.put("authority", params.get("chkValue").get(i).toString()); 
			
			param.put("groupId", groupId);
			mArrayList.add(param);  
 		}  
			
			HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
			hashmap.put("list", mArrayList);  
 
			return groupsDAO.insertGroupsAuthority(hashmap);
	        
	}
}
