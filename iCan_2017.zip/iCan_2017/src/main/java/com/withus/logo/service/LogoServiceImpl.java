package com.withus.logo.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 







import com.withus.logo.service.LogoService;
 
import com.withus.logo.dao.LogoMapper;
import com.withus.logo.dao.LogoVO;
 

/**
 * @Class Name : LogoServiceImpl.java
 * @Description : Logo Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-12-31
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("logoService")
public class LogoServiceImpl implements LogoService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(LogoServiceImpl.class);

    @Resource(name="logoMapper")
    private LogoMapper logoDAO;
    
    /** ID Generation */
    //@Resource(name="{egovLogoIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

 

    /**
	 * logo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 LogoVO
	 * @return void형
	 * @exception Exception
	 */
    @CacheEvict(value = "SITEINFO", allEntries=true)
    public int updateLogo(LogoVO vo) throws Exception {

    	return logoDAO.updateLogo(vo) ;
    }
 
    @CacheEvict(value = "SITEINFO", allEntries=true)
    public int updateSkin(String path, String color, String newLimit, String boardLimit) throws Exception {
    	HashMap<String, String> hashmap = new HashMap<String, String>();
        hashmap.put("skinPath", path);
		hashmap.put("skinColor", color); 
		hashmap.put("newVideoLimit", newLimit); 
		hashmap.put("boardLimit", boardLimit); 
		return logoDAO.updateSkin(hashmap);
		
    }
    
    /**
	 * logo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 LogoVO
	 * @return 조회한 logo
	 * @exception Exception
	 */
    @Cacheable(value="SITEINFO")
    public LogoVO selectLogo() throws Exception {
        LogoVO resultVO = logoDAO.selectLogo();
        
        return resultVO;
    }
 
 
    
}
