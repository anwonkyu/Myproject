package com.withus.business.service;

import java.util.ArrayList;

import com.withus.business.dao.BusinessVO;

public interface BusinessService {
	
	 void insertBusiness(BusinessVO businessVo) throws Exception;
	 
	 ArrayList<BusinessVO> selectBusinessList(String searchWord, int start, int end) throws Exception;
	 
	 int selectBusinessListTotCnt(String searchWord)throws Exception;
	 
	 int deleteBusiness(String bizCd)throws Exception;
	 
	 int updateBusiness(BusinessVO businessVo)throws Exception;
	 
	 public BusinessVO getBusiness(String bizCd)throws Exception;
	 
	 ArrayList<BusinessVO> AllBusinessList(String flag)throws Exception;
}
