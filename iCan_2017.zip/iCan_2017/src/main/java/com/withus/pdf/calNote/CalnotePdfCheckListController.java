package com.withus.pdf.calNote;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.ext.jfile.JProperties;
import com.itextpdf.text.Element;
import com.itextpdf.text.pdf.PdfPCell;
import com.lowagie.text.Cell;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Image;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.LineSeparator;
import com.withus.calnote.dao.CalnoteUpdateVO;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.checklist.dao.CheckListVO;
import com.withus.member.dao.MemberVo;

public class CalnotePdfCheckListController {
	public static void  buildPdfDocument2(Map<String, Object> map ) throws Exception {
		Document document = new Document();
		PdfWriter writer = null;
		List<CheckListVO> checkList = (List<CheckListVO>) map.get("checkList");
	 	String caloteId = (String) map.get("calnoteId");
	 	CalnoteVO calnoteVo = (CalnoteVO) map.get("calnoteVo");
	 	CalnoteUpdateVO calnoteUpdateVo = (CalnoteUpdateVO) map.get("checklistVo");
 
	 	SimpleDateFormat formatter = new SimpleDateFormat ( "yy-MM-dd", Locale.KOREA );
	 	Date currentTime = new Date ( );
	 	String dTime = formatter.format ( currentTime );
	 	String savePath = JProperties.getString("system.calnoteCheckList");
	 	File file = new File(savePath);
	    if (!file.exists())
	      file.mkdirs();
	 	FileOutputStream fos = new FileOutputStream(new File(savePath, caloteId+".pdf"));
	 	writer = PdfWriter.getInstance(document, fos);
	 	
	 	document.open();
	 	String malgunFont = JProperties.getString("malgun.font");
	 	
		 BaseFont bfKorean = BaseFont.createFont(malgunFont, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
	 	Font font10 = new Font(bfKorean, 10);
	 	 Font font12 = new Font(bfKorean, 12);
	 	 Font font22 = new Font(bfKorean, 22);
	 	 Font font18 = new Font(bfKorean, 18);
	 	 Chunk linebreak = new Chunk(new LineSeparator());
	      
	      formatter = new SimpleDateFormat ( "yyyy", Locale.KOREA );
	      dTime = formatter.format ( currentTime );
	      
	      Paragraph header = new Paragraph(calnoteVo.getDocId()+" Rev."+calnoteVo.getRevision(),font10);
	      document.add(header);
	      document.add(linebreak);
	      
	     /* Paragraph title = new Paragraph("설계노트 결제의견 처리 이력서", FontFactory.getFont(FontFactory.HELVETICA, 22, Font.UNDERLINE));*/
	      Paragraph title = new Paragraph("표준 설계계산노트 독립검토 점검표", font18);
	      title.setAlignment(Element.ALIGN_CENTER);
	      document.add(title);
	      
	      
	      	
	      Table table1 = new Table(5, 6);
	      table1.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
	      Paragraph revDocTitle = new Paragraph("검토 대상서류:", font10);
	      Paragraph docNumberTitle = new Paragraph("      서류번호:", font10);
	      Paragraph revisionTitle = new Paragraph("개정번호:", font10);
	      Paragraph revision = new Paragraph(calnoteVo.getRevision(), font10);
	      Paragraph docNameTitle = new Paragraph("           제목:", font10);
	      Paragraph reviewerTitle = new Paragraph("   독립검토자:", font10);
	      
	      /*Paragraph independent = new Paragraph(independentVo.getName(), font10);
	      Paragraph reviewer = new Paragraph(reviewerVo.getName(), font10);
	      Paragraph approver = new Paragraph(approverVo.getName(), font10);*/
	      Cell independent = new Cell(new Paragraph("  "+calnoteVo.getIndependent() +"  " ,new Font(bfKorean, 10 , Font.UNDERLINE)));
	      independent.setHorizontalAlignment(Element.ALIGN_CENTER);
	      Cell reviewer = new Cell(new Paragraph("  "+calnoteVo.getReviewer() +"  " ,new Font(bfKorean, 10 , Font.UNDERLINE)));
	      reviewer.setHorizontalAlignment(Element.ALIGN_CENTER);
	      Cell approver = new Cell(new Paragraph("  "+calnoteVo.getApprover() +"  ",new Font(bfKorean, 10 , Font.UNDERLINE)));
	      approver.setHorizontalAlignment(Element.ALIGN_CENTER);
	      Cell signature = new Cell(new Paragraph("성  명",new Font(bfKorean, 10 , Font.NORMAL)));
	      signature.setHorizontalAlignment(Element.ALIGN_CENTER);
	      Cell revDocument = new Cell(new Paragraph("   ",new Font(bfKorean, 10, Font.NORMAL)));
	      Cell spacing = new Cell(new Paragraph("   ",new Font(bfKorean, 10, Font.NORMAL)));
	      revDocument.setColspan(4);
	      Cell docId = new Cell(new Paragraph(calnoteVo.getDocId(),new Font(bfKorean, 10, Font.NORMAL)));
	      docId.setColspan(2);
	      Cell docName = new Cell(new Paragraph(calnoteVo.getDocName(),new Font(bfKorean, 10, Font.NORMAL)));
	      docName.setColspan(4);
	      
	      
	      table1.addCell(revDocTitle);
	      table1.addCell(revDocument);
	      table1.addCell(docNumberTitle);
	      table1.addCell(docId);
	      table1.addCell(revisionTitle);
	      table1.addCell(revision);
	      table1.addCell(docNameTitle);
	      table1.addCell(docName);
	      table1.addCell(reviewerTitle);
	      table1.addCell(independent);
	      table1.addCell(reviewer);
	      table1.addCell(approver);
	      table1.addCell(spacing);
	      table1.addCell(spacing);
	      table1.addCell(signature);
	      table1.addCell(signature);
	      table1.addCell(signature);
	      
	      table1.setPadding(3);
	      document.add(table1);
	      
	      
	      Table table2 = new Table(8, checkList.size()+2);
	      table2.getDefaultCell().setBorder(PdfPCell.NO_BORDER);
	      HashMap<String, String> checkMap = new HashMap<String, String>();
	      checkMap.put("check01", calnoteUpdateVo.getCheck01());
	      checkMap.put("check02", calnoteUpdateVo.getCheck02());
	      checkMap.put("check03", calnoteUpdateVo.getCheck03());
	      checkMap.put("check04", calnoteUpdateVo.getCheck04());
	      checkMap.put("check05", calnoteUpdateVo.getCheck05());
	      checkMap.put("check06", calnoteUpdateVo.getCheck06());
	      checkMap.put("check07", calnoteUpdateVo.getCheck07());
	      checkMap.put("check08", calnoteUpdateVo.getCheck08());
	      checkMap.put("check09", calnoteUpdateVo.getCheck09());
	      checkMap.put("check10", calnoteUpdateVo.getCheck10());
	      checkMap.put("check11", calnoteUpdateVo.getCheck11());
	      checkMap.put("check12", calnoteUpdateVo.getCheck12());
	      checkMap.put("check13", calnoteUpdateVo.getCheck13());
	      checkMap.put("check14", calnoteUpdateVo.getCheck14());
	      checkMap.put("check15", calnoteUpdateVo.getCheck15());
	      checkMap.put("check16", calnoteUpdateVo.getCheck16());
	      checkMap.put("check17", calnoteUpdateVo.getCheck17());
	      checkMap.put("check18", calnoteUpdateVo.getCheck18());
	      checkMap.put("check19", calnoteUpdateVo.getCheck19());
	      checkMap.put("check20", calnoteUpdateVo.getCheck20());
	      
	      
	      
	      
	      
	      
	    /*  Paragraph yesTitle = new Paragraph("YES", font10);
			Paragraph noTitle = new Paragraph("NO", font10);
	      Paragraph n_aTtitle = new Paragraph("N/A", font10);
	      Paragraph remarkTitle = new Paragraph("Remark", font10);
	      Paragraph empty  = new Paragraph("  ", font10);*/
	      Paragraph yesTitle = new Paragraph("YES", FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE));
	      Paragraph noTitle = new Paragraph("NO", FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE));
	      Paragraph n_aTtitle = new Paragraph("N/A", FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE));
	      Paragraph remarkTitle = new Paragraph("Remark", FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE));
	      Paragraph empty  = new Paragraph("__", font10);

	      Cell reviewItemTitle = new Cell(new Paragraph("검토 항목",new Font(bfKorean, 10, Font.NORMAL)));
	      reviewItemTitle.setColspan(4);
	      table2.addCell(reviewItemTitle);
	      table2.addCell(yesTitle);
	      table2.addCell(noTitle);
	      table2.addCell(n_aTtitle);
	      table2.addCell(remarkTitle);
	     /* HttpServletRequest request = ((ServletRequestAttributes)RequestContextHolder.currentRequestAttributes()).getRequest();
	     Image checkImage = Image.getInstance(request.getSession().getServletContext().getRealPath("/") + JProperties.getString("image.check")); 
	     Cell cell = new Cell(checkImage);
	     cell.setBorderWidth(0);
	     cell.setBorderColor(new Color(255, 255, 255));
	     cell.setVerticalAlignment(Element.ALIGN_BOTTOM);*/
	     
	      int i = 0;
	      for(CheckListVO checkListVo : checkList){
	            Cell description = new Cell(new Paragraph(checkListVo.getDESCRIPTION(),new Font(bfKorean, 10)));
	            description.setColspan(4);
	            table2.addCell(description);
	            i++;
	            String firstDigit = checkMap.get("check0"+(i));
	            String secondtDigit = checkMap.get("check"+(i));
	            if(i <10 ){
	            if(firstDigit.equals("Y")){
	            	table2.addCell(new Paragraph(checkMap.get("check0"+(i)), FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE)));
	            	table2.addCell(empty);
	            }else{
	            	table2.addCell(empty);
	            	table2.addCell(new Paragraph(checkMap.get("check0"+(i)), FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE)));
	            }
	            }else{
	            	 if(secondtDigit.equals("Y")){
	 	            	
	 	            	table2.addCell(new Paragraph(checkMap.get("check"+(i)), FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE)));
	 	            	table2.addCell(empty);
	 	            }else{
	 	            	table2.addCell(empty);
	 	            	table2.addCell(new Paragraph(checkMap.get("check"+(i)), FontFactory.getFont(FontFactory.HELVETICA, 10, Font.UNDERLINE)));
	 	            }
	            }
	  	       
	  	        table2.addCell(empty);
	  	        table2.addCell(empty);
	  	        
	      }
	      table2.setPadding(3);
	      document.add(table2);

	  	document.close();
	 }
	
	
	
}
