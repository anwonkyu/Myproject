package com.withus.besttopsub.service;

import java.util.ArrayList;
import java.util.List;
 




import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;

import com.withus.besttopsub.dao.BestTopSubVO;

/**
 * @Class Name : BestTopSubService.java
 * @Description : BestTopSub Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-06
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface BestTopSubService {
	
	/**
	 * best_top_sub을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BestTopSubVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    String insertBestTopSub(BestTopSubVO vo) throws Exception;
    @Transactional
    int insertBestTopSub2(MultiValueMap<String,String> params) throws Exception;
    
    /**
	 * best_top_sub을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BestTopSubVO
	 * @return void형
	 * @exception Exception
	 */
    void updateBestTopSub(BestTopSubVO vo) throws Exception;
    
    /**
	 * best_top_sub을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BestTopSubVO
	 * @return void형 
	 * @exception Exception
	 */
    void deleteBestTopSub(String btiId) throws Exception;
    
    /**
	 * best_top_sub을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BestTopSubVO
	 * @return 조회한 best_top_sub
	 * @exception Exception
	 */
    BestTopSubVO selectBestTopSub(BestTopSubVO vo) throws Exception;
    
    /**
	 * best_top_sub 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return best_top_sub 목록
	 * @exception Exception
	 */
    public ArrayList<BestTopSubVO> selectBestTopSubList(int btiId) throws Exception;
    
    /**
	 * best_top_sub 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return best_top_sub 총 갯수
	 * @exception
	 */
    int selectBestTopSubListTotCnt();
    
}
