package com.withus.calnote.dao;

public class CalnoteUpdateVO {
	Integer seq;
	String userId;
	String calnoteId;
	String regDate;
	String tempSave;
	
	String check01;
	String check02;
	String check03;
	String check04;
	String check05;
	String check06;
	String check07;
	String check08;
	String check09;
	String check10;
	String check11;
	String check12;
	String check13;
	String check14;
	String check15;
	String check16;
	String check17;
	String check18;
	String check19;
	String check20;
	
	String comment01;
	String comment02;
	String comment03;
	String comment04;
	String comment05;
	String comment06;
	String comment07;
	String comment08;
	String comment09;
	String comment10;
	String comment11;
	String comment12;
	String comment13;
	String comment14;
	String comment15;
	String comment16;
	String comment17;
	String comment18;
	String comment19;
	String comment20;
	
	String type;
	
	
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCalnoteId() {
		return calnoteId;
	}
	public void setCalnoteId(String calnoteId) {
		this.calnoteId = calnoteId;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getTempSave() {
		return tempSave;
	}
	public void setTempSave(String tempSave) {
		this.tempSave = tempSave;
	}
	public String getCheck01() {
		return check01;
	}
	public void setCheck01(String check01) {
		this.check01 = check01;
	}
	public String getCheck02() {
		return check02;
	}
	public void setCheck02(String check02) {
		this.check02 = check02;
	}
	public String getCheck03() {
		return check03;
	}
	public void setCheck03(String check03) {
		this.check03 = check03;
	}
	public String getCheck04() {
		return check04;
	}
	public void setCheck04(String check04) {
		this.check04 = check04;
	}
	public String getCheck05() {
		return check05;
	}
	public void setCheck05(String check05) {
		this.check05 = check05;
	}
	public String getCheck06() {
		return check06;
	}
	public void setCheck06(String check06) {
		this.check06 = check06;
	}
	public String getCheck07() {
		return check07;
	}
	public void setCheck07(String check07) {
		this.check07 = check07;
	}
	public String getCheck08() {
		return check08;
	}
	public void setCheck08(String check08) {
		this.check08 = check08;
	}
	public String getCheck09() {
		return check09;
	}
	public void setCheck09(String check09) {
		this.check09 = check09;
	}
	public String getCheck10() {
		return check10;
	}
	public void setCheck10(String check10) {
		this.check10 = check10;
	}
	public String getCheck11() {
		return check11;
	}
	public void setCheck11(String check11) {
		this.check11 = check11;
	}
	public String getCheck12() {
		return check12;
	}
	public void setCheck12(String check12) {
		this.check12 = check12;
	}
	public String getCheck13() {
		return check13;
	}
	public void setCheck13(String check13) {
		this.check13 = check13;
	}
	public String getCheck14() {
		return check14;
	}
	public void setCheck14(String check14) {
		this.check14 = check14;
	}
	public String getCheck15() {
		return check15;
	}
	public void setCheck15(String check15) {
		this.check15 = check15;
	}
	public String getCheck16() {
		return check16;
	}
	public void setCheck16(String check16) {
		this.check16 = check16;
	}
	public String getCheck17() {
		return check17;
	}
	public void setCheck17(String check17) {
		this.check17 = check17;
	}
	public String getCheck18() {
		return check18;
	}
	public void setCheck18(String check18) {
		this.check18 = check18;
	}
	public String getCheck19() {
		return check19;
	}
	public void setCheck19(String check19) {
		this.check19 = check19;
	}
	public String getCheck20() {
		return check20;
	}
	public void setCheck20(String check20) {
		this.check20 = check20;
	}
	public String getComment01() {
		return comment01;
	}
	public void setComment01(String comment01) {
		this.comment01 = comment01;
	}
	public String getComment02() {
		return comment02;
	}
	public void setComment02(String comment02) {
		this.comment02 = comment02;
	}
	public String getComment03() {
		return comment03;
	}
	public void setComment03(String comment03) {
		this.comment03 = comment03;
	}
	public String getComment04() {
		return comment04;
	}
	public void setComment04(String comment04) {
		this.comment04 = comment04;
	}
	public String getComment05() {
		return comment05;
	}
	public void setComment05(String comment05) {
		this.comment05 = comment05;
	}
	public String getComment06() {
		return comment06;
	}
	public void setComment06(String comment06) {
		this.comment06 = comment06;
	}
	public String getComment07() {
		return comment07;
	}
	public void setComment07(String comment07) {
		this.comment07 = comment07;
	}
	public String getComment08() {
		return comment08;
	}
	public void setComment08(String comment08) {
		this.comment08 = comment08;
	}
	public String getComment09() {
		return comment09;
	}
	public void setComment09(String comment09) {
		this.comment09 = comment09;
	}
	public String getComment10() {
		return comment10;
	}
	public void setComment10(String comment10) {
		this.comment10 = comment10;
	}
	public String getComment11() {
		return comment11;
	}
	public void setComment11(String comment11) {
		this.comment11 = comment11;
	}
	public String getComment12() {
		return comment12;
	}
	public void setComment12(String comment12) {
		this.comment12 = comment12;
	}
	public String getComment13() {
		return comment13;
	}
	public void setComment13(String comment13) {
		this.comment13 = comment13;
	}
	public String getComment14() {
		return comment14;
	}
	public void setComment14(String comment14) {
		this.comment14 = comment14;
	}
	public String getComment15() {
		return comment15;
	}
	public void setComment15(String comment15) {
		this.comment15 = comment15;
	}
	public String getComment16() {
		return comment16;
	}
	public void setComment16(String comment16) {
		this.comment16 = comment16;
	}
	public String getComment17() {
		return comment17;
	}
	public void setComment17(String comment17) {
		this.comment17 = comment17;
	}
	public String getComment18() {
		return comment18;
	}
	public void setComment18(String comment18) {
		this.comment18 = comment18;
	}
	public String getComment19() {
		return comment19;
	}
	public void setComment19(String comment19) {
		this.comment19 = comment19;
	}
	public String getComment20() {
		return comment20;
	}
	public void setComment20(String comment20) {
		this.comment20 = comment20;
	}
	@Override
	public String toString() {
		return "CalnoteUpdateVO [seq=" + seq + ", userId=" + userId
				+ ", calnoteId=" + calnoteId + ", regDate=" + regDate
				+ ", tempSave=" + tempSave + ", check01=" + check01
				+ ", check02=" + check02 + ", check03=" + check03
				+ ", check04=" + check04 + ", check05=" + check05
				+ ", check06=" + check06 + ", check07=" + check07
				+ ", check08=" + check08 + ", check09=" + check09
				+ ", check10=" + check10 + ", check11=" + check11
				+ ", check12=" + check12 + ", check13=" + check13
				+ ", check14=" + check14 + ", check15=" + check15
				+ ", check16=" + check16 + ", check17=" + check17
				+ ", check18=" + check18 + ", check19=" + check19
				+ ", check20=" + check20 + ", comment01=" + comment01
				+ ", comment02=" + comment02 + ", comment03=" + comment03
				+ ", comment04=" + comment04 + ", comment05=" + comment05
				+ ", comment06=" + comment06 + ", comment07=" + comment07
				+ ", comment08=" + comment08 + ", comment09=" + comment09
				+ ", comment10=" + comment10 + ", comment11=" + comment11
				+ ", comment12=" + comment12 + ", comment13=" + comment13
				+ ", comment14=" + comment14 + ", comment15=" + comment15
				+ ", comment16=" + comment16 + ", comment17=" + comment17
				+ ", comment18=" + comment18 + ", comment19=" + comment19
				+ ", comment20=" + comment20 + ", type=" + type + "]";
	}

	
	
	
}
