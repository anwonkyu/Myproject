package com.withus.business.service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.withus.business.dao.BusinessMapper;
import com.withus.business.dao.BusinessVO;
@Service("businessService")
public class BusinessServiceImpl implements  BusinessService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessServiceImpl.class);

    @Resource(name="businessMapper")
    private BusinessMapper businessMapper;
    

	public void insertBusiness(BusinessVO businessVo) throws Exception {
		businessMapper.insertBusiness(businessVo);
	}
	
	public ArrayList<BusinessVO> selectBusinessList(String searchWord, int start, int end) throws Exception{
		
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		Integer startRownum = start;
		Integer endRownum = end;
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("searchWord", searchWord);
		return businessMapper.selectBusinessList(hashmap);
	}
	
	public int selectBusinessListTotCnt(String searchWord) throws Exception{
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
	   	 
		hashmap.put("searchWord", searchWord);
		return businessMapper.selectBusinessListTotCnt(hashmap);
	}
	
	public int deleteBusiness(String bizCd) throws Exception{
		return businessMapper.deleteBusiness(bizCd);
	}
	
	public int updateBusiness(BusinessVO businessVo) throws Exception{
		return businessMapper.updateBusiness(businessVo);
	}
	
	public BusinessVO getBusiness(String bizCd) throws Exception{
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("bizCd", bizCd);
		return businessMapper.getBusiness(hashmap);
		
	}
	
	 public ArrayList<BusinessVO> AllBusinessList(String flag) throws Exception {
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap.put("flag", flag);
		 return businessMapper.AllBusinessList(hashmap);
	 }
}
