package com.withus.commons.uploadFile;

import org.springframework.web.multipart.MultipartFile;

public class FileUploadForm {
	private MultipartFile file;
	private MultipartFile files; 
	

	/**
	 * @return the files
	 */
	public MultipartFile getFiles() {
		return files;
	}

	/**
	 * @param files the files to set
	 */
	public void setFiles(MultipartFile files) {
		this.files = files;
	}

	public MultipartFile getFile() {
		return file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}

}