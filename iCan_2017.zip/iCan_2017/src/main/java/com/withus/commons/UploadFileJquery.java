package com.withus.commons;

import java.io.File;
 
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
 
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
 
import org.springframework.web.bind.annotation.ModelAttribute;
 
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
 
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MaxUploadSizeExceededException;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;
 

import com.withus.commons.uploadFile.FileUploadForm;
import com.withus.commons.uploadFile.UploadFileMeta;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileVo;
 
@Controller
public class UploadFileJquery 
//implements HandlerExceptionResolver
{
 
	@Autowired Properties prop;
	@Resource
	 private UploadFileService uploadFileService;
 
    @RequestMapping(value="/upload/vodUpload.do",  method=RequestMethod.GET) 
    public String vodUpload(){
    	return "/fileUpload/vodUpload";
    }
    
    @RequestMapping(value="/upload/attachUpload.do",  method=RequestMethod.GET) 
    public String fileUpload(){
    	return "/fileUpload/attachUpload";
    }
    
    @RequestMapping(value="/upload/upload2.do",  method=RequestMethod.GET) 
    public String upload2(){
    	return "/fileUpload/upload2";
    }
    
   
  
    @RequestMapping(value="/upload/attachUpload.do",  method=RequestMethod.POST) 
    public synchronized  @ResponseBody Map<String, Object> fileUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception{ 
    		//throws IllegalStateException, IOException {
    
    	String ocode = request.getParameter("ocode"); 
    	if (ocode == null || ocode.length() <= 0) {
    		ocode="0";
    	}
       
       List<UploadFileMeta> files = new ArrayList<UploadFileMeta>(); 
       UploadFileMeta fileMeta = null; 
       //1. build an iterator 
       Iterator<String> itr =  request.getFileNames(); 
       MultipartFile mpf = null; 
       Map<String, Object> jsonObject = new HashMap<String, Object>(); 
       Map<String, Object> jsonSubObject = null; 
       ArrayList<Map<String, Object>> jsonList = new ArrayList<Map<String, Object>>();
       int attachNo = 0 ;
    
       //2. get each file 
       while(itr.hasNext()){ 
          //2.1 get next MultipartFile 
          mpf = request.getFile(itr.next()); 
          if ( mpf.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(mpf.getOriginalFilename()) && com.withus.commons.TextUtil.isFileCheck(mpf.getContentType())) { // 파일 체크
       //   System.out.println(mpf.getOriginalFilename() +" uploaded! "+files.size());
          
          String filename = UploadUtil.getUniqueFileName(mpf.getOriginalFilename());
 
		  //String fileExtension = filename.substring(filename.lastIndexOf(".") + 1); 
		    int fileIndex = StringUtils.lastIndexOf(mpf.getOriginalFilename(), '.');
	        String extension = null;
	        if (fileIndex != -1) {
	            extension = StringUtils.substring(mpf.getOriginalFilename(), fileIndex + 1); 
	        }  
          try { 
             // copy file to local disk (make sure the path "e.g. D:/temp/files" exists) 
        	 // FileCopyUtils.copy(mpf.getBytes(), new FileOutputStream(prop.getProperty("VIDEO_PATH")+mpf.getOriginalFilename())); 
        	  
        	  mpf.transferTo(new File(prop.getProperty("BASE_PATH").trim() + filename)); // 파일 생성
        	  UploadFileVo attachFile = new UploadFileVo();
        	  // 이미지 파일 일경우 썸네일 생성 
        	  if (com.withus.commons.TextUtil.getEnableExtension(extension, "thumbnail")
        			  && com.withus.commons.TextUtil.isFileImage(mpf.getContentType())) {
        		 
    			com.withus.commons.uploadFile.UploadUtil.createThumb(prop.getProperty("BASE_PATH").trim()+File.separator + filename, prop.getProperty("BASE_PATH").trim()+File.separator+ "thumb1" + File.separator+ filename+"."+extension, 250, 250);			// 썸네일 생성
				com.withus.commons.uploadFile.UploadUtil.createThumb(prop.getProperty("BASE_PATH").trim()+File.separator + filename, prop.getProperty("BASE_PATH").trim()+File.separator+ "thumb2" + File.separator+ filename+"."+extension, 760, 760);			// 썸네일 생성
				attachFile.setFlag("I");
        	  }else {
        		attachFile.setFlag("N");
        	  }
        	  //파일 정보DB 저장
      		attachFile.setFileName(filename);
      		attachFile.setOrgName(mpf.getOriginalFilename());
      		attachFile.setFileSize(mpf.getSize());
      		attachFile.setOcode(ocode);  // 영상 코드 제외 하기 위해서는 게시판, 영상관리, 생방송 파일 업로드쪽 변경해야함 , jquery upload 에서는 attachNo 를 이용해서 릴레이션 사용
      		if (uploadFileService.insertAttachFile2(attachFile) > 0 ){  //DB 에 파일 정보 저장
      			attachNo = attachFile.getAttachNo();
      			 
      		}
        	 
             } catch (IOException e) { 
             // TODO Auto-generated catch block 
            	 System.out.println(e);
            	 e.printStackTrace(); 
          } 
          
          //2.3 create new fileMeta 
          fileMeta = new UploadFileMeta(); 

          fileMeta.setName(mpf.getOriginalFilename()); 
          fileMeta.setSize(mpf.getSize()/1024+" Kb"); 
          //fileMeta.setSize(mpf.getSize()); 
          fileMeta.setType(mpf.getContentType()); 
          fileMeta.setUrl(prop.getProperty("BASE_SERVICE")+filename); 
          fileMeta.setThumbnailUrl(prop.getProperty("BASE_SERVICE")+"thumb1/"+filename); 
          fileMeta.setDeleteType("DELETE"); 
          fileMeta.setDeleteUrl(prop.getProperty("BASE_PATH")+filename); 
          jsonSubObject = new HashMap<String, Object>(); 
          jsonSubObject.put("error", 0 ); 
          jsonSubObject.put("url", fileMeta.getUrl()); 
          jsonSubObject.put("thumbnailUrl", fileMeta.getThumbnailUrl()); 
          jsonSubObject.put("name", fileMeta.getName()); 
          jsonSubObject.put("type", fileMeta.getType()); 
          jsonSubObject.put("size", fileMeta.getSize()); 
          jsonSubObject.put("deleteUrl", fileMeta.getDeleteUrl()); 
          jsonSubObject.put("deleteType", fileMeta.getDeleteType()); 
          jsonSubObject.put("attachNo", attachNo); 
          
          jsonList.add(jsonSubObject); 
          jsonObject.put("files", jsonList); 
          
          
          //2.4 add to files 
          files.add(fileMeta); 
          }  //if
       }//while 
       // [{"fileName":"app_engine-85x77.png","fileSize":"8 Kb","fileType":"image/png"},...] 
//       System.out.println("제이슨 객체 출력 ="+jsonObject.toString()); 
//       System.out.println("메서드 종료==========================="); 
       // result will be like this
       
       return jsonObject; 
    }
    
    
    
    @RequestMapping(value="/upload/vodUpload.do",  method=RequestMethod.POST) 
    public synchronized  @ResponseBody Map<String, Object> vodUpload(MultipartHttpServletRequest request, HttpServletResponse response, ModelMap model) 
    		throws IllegalStateException, IOException {

    	Map<String, MultipartFile> files = request.getFileMap();
      
       UploadFileMeta fileMeta = null; 
       //1. build an iterator 
  
       Map<String, Object> jsonObject = new HashMap<String, Object>(); 
       Map<String, Object> jsonSubObject = null; 
       ArrayList<Map<String, Object>> jsonList = new ArrayList<Map<String, Object>>(); 
      // System.out.println("메서드 시작 =================="); 
       Date date = new Date(); 
 	   SimpleDateFormat sdf;
 	   
 	   
 	   for (int i = 0 ;  i < files.size() ; i ++ ) {
 		  CommonsMultipartFile cmf = (CommonsMultipartFile) files.get("fileupload");
	 		  
 		 if ( cmf.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(cmf.getOriginalFilename()) && com.withus.commons.TextUtil.isFileCheck(cmf.getContentType())) { // 파일 체크
 	 
	 	// ocode 생성후 파일네임에 적용
	       sdf = new SimpleDateFormat("yyyyMMddhhmmssSSS"); 
	 		String temp_ocode   = sdf.format( date );   //    동영상코드    
	       String subfolder = "";
	       if (temp_ocode != null) {
	       	subfolder = temp_ocode.substring(0, 4)+"/"+Integer.parseInt(temp_ocode.substring(4,6))+"/"+temp_ocode;
	       }
	       String filename = UploadUtil.getUniqueFileName(cmf.getOriginalFilename());
	       filename = temp_ocode+cmf.getOriginalFilename().substring(cmf.getOriginalFilename().lastIndexOf(".")); //영상파일네임 적용

	       fileMeta = new UploadFileMeta(); 

	          //fileMeta.setName(cmf.getOriginalFilename()); 
	       	  fileMeta.setName(filename);
	          fileMeta.setSize(cmf.getSize()/1024+" Kb"); 
	          //fileMeta.setSize(mpf.getSize()); 
	          fileMeta.setType(cmf.getContentType()); 
	          fileMeta.setUrl(cmf.getOriginalFilename()); 
	          fileMeta.setThumbnailUrl(cmf.getOriginalFilename()); 
	          fileMeta.setDeleteType("DELETE"); 
	          fileMeta.setDeleteUrl(cmf.getOriginalFilename()); 
	          jsonSubObject = new HashMap<String, Object>(); 
	          jsonSubObject.put("error", 0 ); 
	          jsonSubObject.put("url", fileMeta.getUrl()); 
	          jsonSubObject.put("thumbnailUrl", fileMeta.getThumbnailUrl()); 
	          jsonSubObject.put("name", fileMeta.getName()); 
	          jsonSubObject.put("type", fileMeta.getType()); 
	          jsonSubObject.put("size", fileMeta.getSize()); 
	          jsonSubObject.put("deleteUrl", fileMeta.getDeleteUrl()); 
	          jsonSubObject.put("deleteType", fileMeta.getDeleteType());
	          jsonSubObject.put("ocode", temp_ocode);
	          jsonSubObject.put("subfolder", subfolder);
	          
	          jsonList.add(jsonSubObject); 
	          jsonObject.put("files", jsonList); 
 
	 	
	         File dir = new File(prop.getProperty("VIDEO_PATH").trim()+subfolder);
			 if (!dir.isDirectory()) { 
			    	dir.mkdirs(); 
			 } 
		    	
			 cmf.transferTo(new File(prop.getProperty("VIDEO_PATH").trim()+subfolder + File.separator+filename)); // 파일 생성
 	   }
 	   }
 
//       System.out.println("제이슨 객체 출력 ="+jsonObject.toString()); 
//       System.out.println("메서드 종료==========================="); 
       // result will be like this
       
       return jsonObject; 
    }
    
    
    @RequestMapping(value = "/upload/upload2.do", method = RequestMethod.POST)
	public @ResponseBody Map<String, Object> saveFile(
			@ModelAttribute("uploadForm") FileUploadForm uploadForm, Model map) 
			throws IllegalStateException, IOException {
    	// LinkedList<UploadFileMeta> files = new LinkedList<UploadFileMeta>();
    	 Map<String, Object> jsonObject = new HashMap<String, Object>(); 
         Map<String, Object> jsonSubObject = null; 
         ArrayList<Map<String, Object>> jsonList = new ArrayList<Map<String, Object>>(); 
    	System.out.println("aa");
		try {
			 
			MultipartFile multipartFile = uploadForm.getFile();
			// List<MultipartFile> files = uploadForm.getFiles();
			String fileName = "";
			
			if (multipartFile != null) {
				fileName = multipartFile.getOriginalFilename();
				map.addAttribute("files", fileName);
				// return "file_upload_success";
				// 2. get each file
				UploadFileMeta fileMeta = null;
				
				 fileMeta = new UploadFileMeta(); 
				 
				 fileMeta.setName(multipartFile.getOriginalFilename()); 
		          fileMeta.setSize(multipartFile.getSize()/1024+" Kb"); 
		          //fileMeta.setSize(mpf.getSize()); 
		          fileMeta.setType(multipartFile.getContentType()); 
		          fileMeta.setUrl(prop.getProperty("VIDEO_SERVICE")+multipartFile.getOriginalFilename()); 
		          fileMeta.setThumbnailUrl(prop.getProperty("VIDEO_SERVICE")+multipartFile.getOriginalFilename()); 
		          fileMeta.setDeleteType("DELETE"); 
		          fileMeta.setDeleteUrl(prop.getProperty("VIDEO_PATH")+multipartFile.getOriginalFilename());
		          
		          jsonSubObject = new HashMap<String, Object>(); 
		          jsonSubObject.put("error", 0 ); 
		          jsonSubObject.put("url", fileMeta.getUrl()); 
		          jsonSubObject.put("thumbnailUrl", fileMeta.getThumbnailUrl()); 
		          jsonSubObject.put("name", fileMeta.getName()); 
		          jsonSubObject.put("type", fileMeta.getType()); 
		          jsonSubObject.put("size", fileMeta.getSize()); 
		          jsonSubObject.put("deleteUrl", fileMeta.getDeleteUrl()); 
		          jsonSubObject.put("deleteType", fileMeta.getDeleteType());
//		          jsonSubObject.put("ocode", temp_ocode);
//		          jsonSubObject.put("subfolder", subfolder);
		          
		          jsonList.add(jsonSubObject); 
		          jsonObject.put("files", jsonList); 
		          
			 
				// copy file to local disk (make sure the path
				// "e.g. D:/temp/files" exists)
				// FileCopyUtils.copy(multipartFile.getBytes(), new
				// FileOutputStream("d:/test/upload/video/"+fileName));
				System.out.println(fileName);
				String path = "d:/test/upload/video/" + fileName;
				
				File f = new File(path);
				multipartFile.transferTo(f);

				// 2.4 add to files
				//files.add(fileMeta);
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		// result will be like this
		// [{"fileName":"app_engine-85x77.png","fileSize":"8 Kb","fileType":"image/png"},...]
		return jsonObject;
	}
    
    
    
//	@Override
//	public ModelAndView resolveException(HttpServletRequest request,
//            HttpServletResponse response, Object handler, Exception exception) {
//		 Map<String, Object> model = new HashMap<String, Object>();
//	        if (exception instanceof MaxUploadSizeExceededException)
//	        {
//	            model.put("errors", exception.getMessage());
//	        } else
//	        {
//	            model.put("errors", "Unexpected error: " + exception.getMessage());
//	        }
//	        model.put("FileMeta", new UploadFileMeta());
//	        model.put("url", "/error/uploadError.do");
//	        
//	        return new ModelAndView("/error/uploadError", model);
//	} 
 
}
