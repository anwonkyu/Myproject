package com.withus.tr.service;

import java.util.ArrayList;
import java.util.List;

import com.withus.tr.dao.TrVO;

public interface TrService {
	void insertTr(TrVO trVo)throws Exception;
	
	ArrayList<TrVO> selectTr(int start, int end,String docName, String docId, String datepicker, String datepicker2,String deptCd,String userDept, String sortField, String sortOrder,String state)throws Exception;
	
	int selectTrTotCnt(String docName, String docId, String datepicker, String datepicker2,String deptCd,String userDept,String state)throws Exception;
	
	public TrVO getTr(String trId)throws Exception;
	
	public TrVO getTrDocId(String docId)throws Exception;
	
	int updateTr(TrVO trVo)throws Exception;
	
	int deleteTr(String trId)throws Exception;

	ArrayList<TrVO> pandingTr(int start, int end, String searchFild,
			String searchWord, String sortField, String sortOrder)
			throws Exception;

	int pandingTrTotCnt(String searchFild, String searchWord) throws Exception;

	ArrayList<TrVO> processedTr(int start, int end, String searchFild,
			String searchWord, String sortField, String sortOrder)
			throws Exception;

	int processedTrTotCnt(String searchFild, String searchWord)
			throws Exception;
	
	 String lastNumberCheck(String docId) throws Exception;
	
	
	
}
