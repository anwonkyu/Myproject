package com.withus.boardHistory;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.boardHistory.service.BoardHistoryService;
import com.withus.boardlist.BoardListController;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.commons.XmlResult;

@Controller
@RequestMapping("/vodman")
public class boardHistoryController {
	
	private static final Logger logger = LoggerFactory.getLogger(BoardListController.class);
	 @Resource(name = "xstreamMarshaller")
	  private XStreamMarshaller xstreamMarshaller;

	  @Resource(name = "xmlView")
	  private View xmlView;
	  
	  @Autowired
	  private BoardHistoryService boardHistoryService;
	  
    @RequestMapping(value="/boardHistory/selectBoardDeleteCnt.do", method=RequestMethod.POST)
	public View calUpdate(int listId, int boardId, Model model ) throws Exception {
 
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
		     if ( boardHistoryService.selectBoardDeleteCnt(listId) > 0) {
			        xml.setError(false);
		       
		    } else {
		 	     xml.setError(true);
		    }

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
}
