package com.withus.popup.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
import com.withus.commons.paging.PagingHelperServiceImpl;
import com.withus.popup.service.PopupmanService;
 
import com.withus.popup.dao.PopupmanMapper;
import com.withus.popup.dao.PopupmanVO;
 
 

/**
 * @Class Name : PopupmanServiceImpl.java
 * @Description : Popupman Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-12
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("popupmanService")
public class PopupmanServiceImpl  implements  PopupmanService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(PopupmanServiceImpl.class);

    @Resource(name="popupmanMapper")
    private PopupmanMapper popupmanDAO;
 
    /** ID Generation */
    //@Resource(name="{egovPopupmanIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * popupman을 등록한다.
	 * @param vo - 등록할 정보가 담긴 PopupmanVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertPopupman(PopupmanVO vo) throws Exception { 
        return popupmanDAO.insertPopupman(vo) ;
    }

    /**
	 * popupman을 수정한다.
	 * @param vo - 수정할 정보가 담긴 PopupmanVO
	 * @return void형
	 * @exception Exception
	 */
    public int updatePopupman(PopupmanVO vo) throws Exception {
        return popupmanDAO.updatePopupman(vo);
    }

    /**
	 * popupman을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 PopupmanVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deletePopupman(int seq) throws Exception {
       return popupmanDAO.deletePopupman(seq);
    }

    /**
	 * popupman을 조회한다.
	 * @param vo - 조회할 정보가 담긴 PopupmanVO
	 * @return 조회한 popupman
	 * @exception Exception
	 */
    public PopupmanVO selectPopupman(int seq) throws Exception {
        PopupmanVO resultVO = popupmanDAO.selectPopupman(seq);
       
        return resultVO;
    }

    /**
	 * popupman 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return popupman 목록
	 * @exception Exception
	 */
    public ArrayList<PopupmanVO> selectPopupmanList(String searchFild, String searchWord, int start, int end) throws Exception {
    	
    	Integer startRownum = start;
		Integer endRownum = end;
 
    	HashMap<String, String> hashmap = new HashMap<String, String>();
   	 
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		
        return popupmanDAO.selectPopupmanList(hashmap);
    }
     

    /**
	 * popupman 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return popupman 총 갯수
	 * @exception
	 */
    public int selectPopupmanListTotCnt(String searchFild, String searchWord ) {
    	HashMap<String, String> hashmap = new HashMap<String, String>();
	 
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		
		return popupmanDAO.selectPopupmanListTotCnt(hashmap);
	}
    
 
	@Override
	public ArrayList<PopupmanVO> selectPopupmanList_today(String popFlag) {
		return popupmanDAO.selectPopupmanList_today(popFlag);
	}

 
    
}
