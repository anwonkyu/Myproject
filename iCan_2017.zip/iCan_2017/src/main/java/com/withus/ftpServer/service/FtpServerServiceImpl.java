package com.withus.ftpServer.service;

import java.util.HashMap;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.withus.business.service.BusinessServiceImpl;
import com.withus.ftpServer.dao.FtpServerMapper;
import com.withus.ftpServer.dao.FtpServerVO;
@Service("ftpServerService")
public class FtpServerServiceImpl implements FtpServerService{

	private static final Logger LOGGER = LoggerFactory.getLogger(BusinessServiceImpl.class);
	
	@Resource(name="ftpServerMapper")
	private FtpServerMapper ftpServerMapper;
	
	@Override
	public int updateFtpServer(int serverNo) throws Exception {
		Integer serverNo_ = serverNo;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("serverNo", serverNo_.toString());
		return ftpServerMapper.updateFtpServer(hashmap);
	}

	@Override
	public int selectFtpServer() throws Exception {
		System.out.println("==last==");
		System.out.println("@===="+ftpServerMapper.selectFtpServer());
		return ftpServerMapper.selectFtpServer();
	}

}
