package com.withus.commons.uploadFile;

import java.io.IOException;
import java.util.UUID;

import net.coobird.thumbnailator.Thumbnails;

import org.apache.commons.lang.StringUtils;

public class UploadUtil {

    public static String getUniqueFileName(String fileName) {

        String uniqueFilename = "";
        String uuid = StringUtils.remove(UUID.randomUUID().toString(), '-').toUpperCase();

//        int fileIndex = StringUtils.lastIndexOf(fileName, '.');
//
//        // 파일명과 확장자를 분리
//        if (fileIndex != -1) {
//            String extension = StringUtils.substring(fileName, fileIndex + 1);
//            uniqueFilename = uuid + "." + extension;
//        } else {
//            uniqueFilename = uuid;
//        }
//
//        return uniqueFilename;
        
        return uuid;
    }
    
    public static String getUniqueFileName_ext(String fileName) {

        String uniqueFilename = "";
        String uuid = StringUtils.remove(UUID.randomUUID().toString(), '-').toUpperCase();

        int fileIndex = StringUtils.lastIndexOf(fileName, '.');

        // 파일명과 확장자를 분리
        if (fileIndex != -1) {
            String extension = StringUtils.substring(fileName, fileIndex + 1);
            uniqueFilename = uuid + "." + extension;
        } else {
            uniqueFilename = uuid;
        }

        return uniqueFilename;
 
    }
    
    
	/**
	 * 썸네일 생성
	 * @param orgName 원본 파일
	 * @param destName 썸네일 이미지 파일
	 * @param width 썸네일 이미지 크기
	 * @param height 썸네일 이미지 크기
	 * @return 파일명
	 * @throws IOException
	 */
	public static void createThumb(String orgName, String destName, int width, int height) throws IOException {

		Thumbnails.of(orgName).size(width,height).toFile(destName);
	  
	}
 
}
