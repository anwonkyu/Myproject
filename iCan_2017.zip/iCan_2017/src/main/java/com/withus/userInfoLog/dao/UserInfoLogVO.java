package com.withus.userInfoLog.dao;

/**
 * @Class Name : UserInfoLogVO.java
 * @Description : UserInfoLog VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2015-01-19
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class UserInfoLogVO {
    private static final long serialVersionUID = 1L;
    
    /** seq */
    private int seq;
    
    /** userid */
    private String userid;
    
    /** username */
    private String username;
    
    /** update_date */
    private java.util.Date updateDate;
    
    /** ip */
    private String ip;
    
    /** birthday */
    private String birthday;
    
    /** sex */
    private String sex;
    
    /** tel */
    private String tel;
    
    /** mobile */
    private String mobile;
    
    /** zipcode */
    private String zipcode;
    
    /** addr1 */
    private String addr1;
    
    /** addr2 */
    private String addr2;
    
    /** email */
    private String email;
    
    /** deptcode */
    private String deptcode;
    
    /** etc */
    private String etc;
    
    /** userpwd */
    private String userpwd;
    
    /** user_out */
    private String userOut;
    
    public int getSeq() {
        return this.seq;
    }
    
    public void setSeq(int seq) {
        this.seq = seq;
    }
    
    public String getUserid() {
        return this.userid;
    }
    
    public void setUserid(String userid) {
        this.userid = userid;
    }
    
    public String getUsername() {
        return this.username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public java.util.Date getUpdateDate() {
        return this.updateDate;
    }
    
    public void setUpdateDate(java.util.Date updateDate) {
        this.updateDate = updateDate;
    }
    
    public String getIp() {
        return this.ip;
    }
    
    public void setIp(String ip) {
        this.ip = ip;
    }
    
    public String getBirthday() {
        return this.birthday;
    }
    
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    
    public String getSex() {
        return this.sex;
    }
    
    public void setSex(String sex) {
        this.sex = sex;
    }
    
    public String getTel() {
        return this.tel;
    }
    
    public void setTel(String tel) {
        this.tel = tel;
    }
    
    public String getMobile() {
        return this.mobile;
    }
    
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    public String getZipcode() {
        return this.zipcode;
    }
    
    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }
    
    public String getAddr1() {
        return this.addr1;
    }
    
    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }
    
    public String getAddr2() {
        return this.addr2;
    }
    
    public void setAddr2(String addr2) {
        this.addr2 = addr2;
    }
    
    public String getEmail() {
        return this.email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getDeptcode() {
        return this.deptcode;
    }
    
    public void setDeptcode(String deptcode) {
        this.deptcode = deptcode;
    }
    
    public String getEtc() {
        return this.etc;
    }
    
    public void setEtc(String etc) {
        this.etc = etc;
    }
    
    public String getUserpwd() {
        return this.userpwd;
    }
    
    public void setUserpwd(String userpwd) {
        this.userpwd = userpwd;
    }
    
    public String getUserOut() {
        return this.userOut;
    }
    
    public void setUserOut(String userOut) {
        this.userOut = userOut;
    }
    
}
