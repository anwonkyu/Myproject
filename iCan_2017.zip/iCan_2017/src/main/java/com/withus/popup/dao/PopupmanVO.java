package com.withus.popup.dao;

/**
 * @Class Name : PopupmanVO.java
 * @Description : Popupman VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-12
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class PopupmanVO {
 
    /** seq */
    private Integer seq;
    
    /** title */
    private String title;
    
    /** use_html */
    private String useHtml;
    
    /** content */
    private String content;
    
    /** width */
    private String width;
    
    /** height */
    private String height;
    
    /** is_visible */
    private String isVisible;
    
    /** pop_level */
    private String popLevel;
    
    /** pop_link */
    private String popLink;
    
    private String linkType;
    
    /** img_name */
    private String imgName;
    
    /** pos_x */
    private String posX;
    
    /** pos_y */
    private String posY;
    
    /** pop_flag */
    private String popFlag;
    
    /** rstime */
    private String rstime;
    
    /** retime */
    private String retime;
    
    /** img_name_mobile */
    private String imgNameMobile;
    
    /** retime */
    private String img_del; 
    
    
    
    public String getLinkType() {
		return linkType;
	}

	public void setLinkType(String linkType) {
		this.linkType = linkType;
	}

	public String getImg_del() {
		return img_del;
	}

	public void setImg_del(String img_del) {
		this.img_del = img_del;
	}

	public Integer getSeq() {
        return this.seq;
    }
    
    public void setSeq(Integer seq) {
        this.seq = seq;
    }
    
    public String getTitle() {
        return this.title;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    public String getUseHtml() {
        return this.useHtml;
    }
    
    public void setUseHtml(String useHtml) {
        this.useHtml = useHtml;
    }
    
    public String getContent() {
        return this.content;
    }
    
    public void setContent(String content) {
        this.content = content;
    }
    
    public String getWidth() {
        return this.width;
    }
    
    public void setWidth(String width) {
        this.width = width;
    }
    
    public String getHeight() {
        return this.height;
    }
    
    public void setHeight(String height) {
        this.height = height;
    }
    
    public String getIsVisible() {
        return this.isVisible;
    }
    
    public void setIsVisible(String isVisible) {
        this.isVisible = isVisible;
    }
    
    public String getPopLevel() {
        return this.popLevel;
    }
    
    public void setPopLevel(String popLevel) {
        this.popLevel = popLevel;
    }
    
    public String getPopLink() {
        return this.popLink;
    }
    
    public void setPopLink(String popLink) {
        this.popLink = popLink;
    }
    
    public String getImgName() {
        return this.imgName;
    }
    
    public void setImgName(String imgName) {
        this.imgName = imgName;
    }
    
    public String getPosX() {
        return this.posX;
    }
    
    public void setPosX(String posX) {
        this.posX = posX;
    }
    
    public String getPosY() {
        return this.posY;
    }
    
    public void setPosY(String posY) {
        this.posY = posY;
    }
    
    public String getPopFlag() {
        return this.popFlag;
    }
    
    public void setPopFlag(String popFlag) {
        this.popFlag = popFlag;
    }
    
    public String getRstime() {
        return this.rstime;
    }
    
    public void setRstime(String rstime) {
        this.rstime = rstime;
    }
    
    public String getRetime() {
        return this.retime;
    }
    
    public void setRetime(String retime) {
        this.retime = retime;
    }
    
    public String getImgNameMobile() {
        return this.imgNameMobile;
    }
    
    public void setImgNameMobile(String imgNameMobile) {
        this.imgNameMobile = imgNameMobile;
    }
    
}
