package com.withus.department;

import java.util.ArrayList;
import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.business.dao.BusinessVO;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.department.dao.DepartmentVO;
import com.withus.department.service.DepartmentService;

@Controller
@RequestMapping("/vodman")
public class VodmanDepartmentController {
	
	private static final Logger logger = LoggerFactory.getLogger(VodmanDepartmentController.class);

	  @Autowired Properties prop;
	  @Autowired DepartmentService departmentService;
	  @Resource
	  private PagingHelperService page;
	  @Resource(name = "xstreamMarshaller")
	  private XStreamMarshaller xstreamMarshaller;
	  @Resource(name = "xmlView")
	  private View xmlView;
	  
	  @RequestMapping(value="/department/deptList.do")
	    public String selectDeptList(String searchWord, Integer curPage, 
	    		ModelMap model)
	            throws Exception {
	    	
	    	if (curPage == null) curPage = 1;
			if (searchWord == null) searchWord = ""; 
			
			int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
			int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
			
			int totalRecord = departmentService.selectDepartmentListTotCnt(searchWord);
			PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
	 	
			page.setPagingHelper(pagingHelper);
			int start = pagingHelper.getStartRecord();
			int end = pagingHelper.getEndRecord();
			
			ArrayList<?> departmentList = departmentService.selectDepartmentList(searchWord, start, end);
			
			Integer prevLink = page.getPrevLink();
			Integer nextLink = page.getNextLink();
			Integer firstPage = page.getFirstPage();
			Integer lastPage = page.getLastPage();
			int[] pageLinks = page.getPageLinks(); 
			
			model.addAttribute("prevLink", prevLink);
			model.addAttribute("nextLink", nextLink);
			model.addAttribute("firstPage", firstPage);
			model.addAttribute("lastPage", lastPage);
			model.addAttribute("pageLinks", pageLinks);
			model.addAttribute("curPage", curPage); 
			model.addAttribute("totalRecord", totalRecord); 
			
	        model.addAttribute("resultList", departmentList);
	  
	        return "/vodman/department/deptList";
	    } 
	  
	  @RequestMapping(value="/department/deptWrite.do", method=RequestMethod.GET)
		public String write( Model model) throws Exception {
	 
			return "/vodman/department/addForm";
		}
	  
	  @RequestMapping(value="/department/deptWrite.do", method=RequestMethod.POST)
	    public String deptWrite(DepartmentVO departmentVo )throws Exception {
	    	departmentService.insertDepartment(departmentVo);
	        return "redirect:/vodman/department/deptList.do";
	    }
	  
	  @RequestMapping(value="/department/deptUpdate.do", method=RequestMethod.GET)
		public String deptUpdate(String deptCd, Model model) throws Exception {
			DepartmentVO departMemtVo = departmentService.getDepartment(deptCd);
			//수정페이지에서의 보일 게시글 정보
			model.addAttribute("thisVo", departMemtVo);
	 		
			return "/vodman/department/addForm";
		}
	  
	  @RequestMapping(value="/department/deptUpdate.do", method=RequestMethod.POST)
		public View deptUpdate(@ModelAttribute("departmentVo") DepartmentVO departmentVo, Model model ) throws Exception {
		 
			   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     if ( departmentService.updateDepartment(departmentVo) > 0) {
				        xml.setMessage(departmentVo.getDeptCd());
				        xml.setError(true);
			       
			    } else {
			    	 xml.setMessage(departmentVo.getDeptCd());
			 	     xml.setError(false);
			    }

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	  
	  @RequestMapping(value="/department/deptDelete.do", method=RequestMethod.POST)
		public View deptDelete(@RequestParam(value="deptCd" ,required=true)String deptCd, Model model ) {
				   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     try {
					if ( departmentService.deleteDepartment(deptCd) > 0) {
					        xml.setMessage("삭제되었습니다.");
					        xml.setError(true);
					   
					} else {
						xml.setMessage("삭제에 실패하였습니다.");
					     xml.setError(false);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	  
	  
}
