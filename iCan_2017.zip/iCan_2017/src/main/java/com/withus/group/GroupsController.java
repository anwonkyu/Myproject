package com.withus.group;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.authority.dao.AuthorityVO;
import com.withus.commons.XmlResult;
import com.withus.group.service.GroupsService;
import com.withus.group.dao.GroupsVO;

/**
 * @Class Name : GroupsController.java
 * @Description : Groups Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class GroupsController {

    @Autowired
    private GroupsService groupsService;
    
    
    @Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView; 
    
    @RequestMapping(value="/site/groups.do")
    public String selectGroups(
    		ModelMap model)
            throws Exception { 
		
    	ArrayList<GroupsVO> GroupsList = groupsService.selectGroupsList(); 
        model.addAttribute("result", GroupsList);
        
        return "/vodman/site/groups";
    } 
    
    
    @RequestMapping(value="/site/groupsMember.do")
    public String selectGroupsMember( @RequestParam(value="groupId",required=true) Integer groupId,
    		ModelMap model)
            throws Exception { 
		
    	ArrayList<GroupsVO> GroupsList = groupsService.selectGroupsMemberList(groupId); 
        model.addAttribute("result", GroupsList);
        
        return "/vodman/site/groupsMember";
    } 
    
    @RequestMapping(value="/site/groupsAuthority.do")
    public String selectGroupsAuthority( @RequestParam(value="groupId",required=true) Integer groupId,
    		ModelMap model)
            throws Exception { 
		
    	ArrayList<GroupsVO> GroupsList = groupsService.selectGroupsAuthority(groupId); 
        model.addAttribute("result", GroupsList);
        
        return "/vodman/site/groupsAuthority";
    } 
    
    
    @RequestMapping(value="/site/groupsWrite.do", method=RequestMethod.GET)
  	public String write() throws Exception {
      	
      	return "/vodman/site/groupsWrite";
    }
      
      @RequestMapping(value="/site/groupsWrite.do" , method=RequestMethod.POST)
      public String addGroups( @ModelAttribute("GroupsVO") GroupsVO groupsVo )
              throws Exception {
    	  groupsService.insertGroups(groupsVo);
      	 return "redirect:/vodman/site/groups.do";
      }
      
      @RequestMapping(value="/site/groupsUpdate.do" , method=RequestMethod.GET)
      public String updateGroups(
              @RequestParam(value="groupId",required=true)  Integer groupId , Model model)
              throws Exception {
    	  
    	  GroupsVO groupsVo  = groupsService.selectGroups(groupId);
      	
          model.addAttribute("groupsVo", groupsVo);
         
          return "/vodman/site/groupsWrite";
      }
      
      @RequestMapping(value="/site/groupsDelete.do" ,method={RequestMethod.GET, RequestMethod.POST})
      public String deleteGroups(
    		  @RequestParam(value="groupId",required=true)  Integer groupId  )
              throws Exception {
    	  	groupsService.deleteGroups(groupId);
      		return "redirect:/vodman/site/groups.do";
      } 
      
      @RequestMapping(value="/site/groupsMemberDelete.do" ,method={RequestMethod.GET, RequestMethod.POST})
      public String deleteGroupsMember(
    		  @RequestParam(value="seq",required=true)  Integer seq, @RequestParam(value="groupId",required=true)  Integer groupId  )
              throws Exception {
    	  	groupsService.deleteGroupsMember(seq);
      		return "redirect:/vodman/site/groupsMember.do?groupId="+groupId;
      }
      
      @RequestMapping(value="/site/groupsAuthorityDelete.do" ,method={RequestMethod.GET, RequestMethod.POST})
      public String deleteGroupsAuthority(
    		  @RequestParam(value="seq",required=true)  Integer seq , @RequestParam(value="groupId",required=true)  Integer groupId )
              throws Exception {
    	  	groupsService.deleteGroupsAuthority(seq);
      		return "redirect:/vodman/site/groupsAuthority.do?groupId="+groupId;
      }
      
      
      @RequestMapping(value="/site/groupsWriteMember.do" , method=RequestMethod.POST)
      public View addGroupsMember(   @RequestParam MultiValueMap<String, String> params, Model model )
              throws Exception {
    	  
    	  
    	  XStream xst = xstreamMarshaller.getXStream();
      	  xst.alias("result", XmlResult.class); 
       
          XmlResult xml = new XmlResult(); 
          
          if (groupsService.insertGroupsMember(params) > 0) { 
         	xml.setMessage("등록 되었습니다!");
   	 	    xml.setError(true);
     	 
          }else {
  			xml.setMessage("등록에 실패하였습니다!");
  	 	    xml.setError(false);
  		}

  	        model.addAttribute("xmlData", xml);
  	        return xmlView;
    	  
      	 //return "redirect:/vodman/site/groupsMember.do?groupId="+params.get("groupId").get(0);
      }
      
      @RequestMapping(value="/site/groupsWriteAuthority.do" , method=RequestMethod.POST)
      public View addGroupsAutority(   @RequestParam MultiValueMap<String, String> params, Model model )
              throws Exception {
    	 
    	
    	 XStream xst = xstreamMarshaller.getXStream();
      	 xst.alias("result", XmlResult.class); 
       
          XmlResult xml = new XmlResult(); 
          
          if (  groupsService.insertGroupsAuthority(params) > 0) { 
         	xml.setMessage("등록 되었습니다!");
   	 	    xml.setError(true);
     	 
          }else {
  			xml.setMessage("등록에 실패하였습니다!");
  	 	    xml.setError(false);
  		}

  	        model.addAttribute("xmlData", xml);
  	        return xmlView;
      	 //return "redirect:/vodman/site/groupsAuthority.do?groupId="+params.get("groupId").get(0);
      }
      
      
    
}
