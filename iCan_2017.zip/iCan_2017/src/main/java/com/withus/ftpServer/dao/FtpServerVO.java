package com.withus.ftpServer.dao;

public class FtpServerVO {
	private Integer serverNo;

	public Integer getServerNo() {
		return serverNo;
	}

	public void setServerNo(Integer serverNo) {
		this.serverNo = serverNo;
	}
	
}
