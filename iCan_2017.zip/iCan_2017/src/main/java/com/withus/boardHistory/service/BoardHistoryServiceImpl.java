package com.withus.boardHistory.service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.withus.boardHistory.dao.BoardHistoryMapper;
import com.withus.boardHistory.dao.BoardHistoryVO;
import com.withus.member.dao.MemberVo;
import com.withus.memo.service.ContentMemoServiceImpl;
@Service("boardHistoryService")
public class BoardHistoryServiceImpl implements BoardHistoryService{
	
	 private static final Logger LOGGER = LoggerFactory.getLogger(ContentMemoServiceImpl.class);

	 @Resource(name="boardHistoryMapper")
	 private BoardHistoryMapper boardHistoryDAO;
	 
	@Override
	public int insertBoardHistory(BoardHistoryVO vo) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		if(principal != null && principal instanceof MemberVo){ 
			vo.setUserId(((MemberVo)principal).getUsername() );
			vo.setName(com.withus.commons.seed.SEEDUtil.getDecrypt(((MemberVo)principal).getName()) );
		} else{
        	 return -1;
        }
		return boardHistoryDAO.insertBoardHistory(vo);
	}

	@Override
	public ArrayList<BoardHistoryVO> selectBoardHistoryList(String state, String searchFild,
			String searchWord, int start, int end) throws Exception {
		Integer startRownum = start;
		Integer endRownum = end;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("state", state);
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		return boardHistoryDAO.selectBoardHistoryList(hashmap);
		
		
	}

	@Override
	public int selectBoardHistoryListTotCnt(String state, String searchFild, String searchWord)
			throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("state", state);
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		return boardHistoryDAO.selectBoardHistoryListTotCnt(hashmap);
	}

	@Override
	public int selectBoardDeleteCnt(int listId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		Integer listId_ = listId;
		hashmap.put("listId", listId_.toString());
		return boardHistoryDAO.selectBoardDeleteCnt(hashmap);
	}

	 
	 
}
