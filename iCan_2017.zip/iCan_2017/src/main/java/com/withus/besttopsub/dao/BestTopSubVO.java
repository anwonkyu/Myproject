package com.withus.besttopsub.dao;

import java.util.List;

/**
 * @Class Name : BestTopSubVO.java
 * @Description : BestTopSub VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-06
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class BestTopSubVO {
       
    /** bts_id */
    private Integer btsId;
    
    /** bti_id */
    private Integer btiId;
    
    /** bts_order */
    private Integer btsOrder;
    
    /** bts_title */
    private String btsTitle;
    
    /** bts_ocode */
    private String btsOcode;
    
    /** bts_uip */
    private String btsUip;
    
    /** bts_uid */
    private String btsUid;
    
    /** bts_udate */
    private String btsUdate;
    
    /** bts_rdate */
    private String btsRdate;
    
    /** bts_type */
    private String btsType;
    
    private String subfolder;
    
    private String modelimage;
    
    private String thumbnailFile ;
    
    private List bestListVo;
  
	public List getBestListVo() {
		return bestListVo;
	}

	public void setBestListVo(List bestListVo) {
		this.bestListVo = bestListVo;
	}

	public String getThumbnailFile() {
		return thumbnailFile;
	}

	public void setThumbnailFile(String thumbnailFile) {
		this.thumbnailFile = thumbnailFile;
	}

	public String getSubfolder() {
		return subfolder;
	}

	public void setSubfolder(String subfolder) {
		this.subfolder = subfolder;
	}

	public String getModelimage() {
		return modelimage;
	}

	public void setModelimage(String modelimage) {
		this.modelimage = modelimage;
	}

	public Integer getBtsId() {
		return btsId;
	}

	public void setBtsId(Integer btsId) {
		this.btsId = btsId;
	}

	public Integer getBtiId() {
		return btiId;
	}

	public void setBtiId(Integer btiId) {
		this.btiId = btiId;
	}

	public Integer getBtsOrder() {
		return btsOrder;
	}

	public void setBtsOrder(Integer btsOrder) {
		this.btsOrder = btsOrder;
	}

	public String getBtsTitle() {
		return btsTitle;
	}

	public void setBtsTitle(String btsTitle) {
		this.btsTitle = btsTitle;
	}

	public String getBtsOcode() {
		return btsOcode;
	}

	public void setBtsOcode(String btsOcode) {
		this.btsOcode = btsOcode;
	}

	public String getBtsUip() {
		return btsUip;
	}

	public void setBtsUip(String btsUip) {
		this.btsUip = btsUip;
	}

	public String getBtsUid() {
		return btsUid;
	}

	public void setBtsUid(String btsUid) {
		this.btsUid = btsUid;
	}

	public String getBtsUdate() {
		return btsUdate;
	}

	public void setBtsUdate(String btsUdate) {
		this.btsUdate = btsUdate;
	}

	public String getBtsRdate() {
		return btsRdate;
	}

	public void setBtsRdate(String btsRdate) {
		this.btsRdate = btsRdate;
	}

	public String getBtsType() {
		return btsType;
	}

	public void setBtsType(String btsType) {
		this.btsType = btsType;
	}
    
   
}
