package com.withus.popup.service;

import java.util.ArrayList;
import java.util.List;
 
import com.withus.commons.paging.PagingHelperService;
import com.withus.popup.dao.PopupmanVO;
 
/**
 * @Class Name : PopupmanService.java
 * @Description : Popupman Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-12
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface PopupmanService  {
	
	/**
	 * popupman을 등록한다.
	 * @param vo - 등록할 정보가 담긴 PopupmanVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    int insertPopupman(PopupmanVO vo) throws Exception;
    
    /**
	 * popupman을 수정한다.
	 * @param vo - 수정할 정보가 담긴 PopupmanVO
	 * @return void형
	 * @exception Exception
	 */
    int updatePopupman(PopupmanVO vo) throws Exception;
    
    /**
	 * popupman을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 PopupmanVO
	 * @return void형 
	 * @exception Exception
	 */
    int deletePopupman(int seq) throws Exception;
    
    /**
	 * popupman을 조회한다.
	 * @param vo - 조회할 정보가 담긴 PopupmanVO
	 * @return 조회한 popupman
	 * @exception Exception
	 */
    PopupmanVO selectPopupman(int seq) throws Exception;
    
    /**
	 * popupman 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return popupman 목록
	 * @exception Exception
	 */
    ArrayList selectPopupmanList(String searchFild, String searchWord, int start, int end) throws Exception;
    
    /**
	 * popupman 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return popupman 총 갯수
	 * @exception
	 */
    int selectPopupmanListTotCnt(String searchFild, String searchWord);
    
 

	ArrayList<PopupmanVO> selectPopupmanList_today(String popFlag);

}
