package com.withus.buseo.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 


import com.withus.buseo.dao.BuseoVO;
 

/**
 * @Class Name : BuseoDAO.java
 * @Description : Buseo DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("buseoMapper")
public interface BuseoMapper {

	/**
	 * buseo을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BuseoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String insertBuseo(BuseoVO vo) throws Exception;

    /**
	 * buseo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BuseoVO
	 * @return void형
	 * @exception Exception
	 */
    public void updateBuseo(BuseoVO vo) throws Exception ;

    /**
	 * buseo을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BuseoVO
	 * @return void형 
	 * @exception Exception
	 */
    public void deleteBuseo(BuseoVO vo) throws Exception ;

    /**
	 * buseo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BuseoVO
	 * @return 조회한 buseo
	 * @exception Exception
	 */
    public BuseoVO selectBuseo(int binx) throws Exception ;

    /**
	 * buseo 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return buseo 목록
	 * @exception Exception
	 */
    public ArrayList<BuseoVO> selectBuseoList(HashMap<String, String> hashmap) throws Exception;

    /**
	 * buseo 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return buseo 총 갯수
	 * @exception
	 */
    public int selectBuseoListTotCnt(HashMap<String, String> hashmap) ;

	public ArrayList<BuseoVO> selectBuseoListAll();

}
