package com.withus.processing.dao;

public class ProcessingVO {
	Integer seq;
	String title;
	String contents;
	String jfile;
	String docId;
	Integer revision;
	String approver;
	String complete="N";
	String delFlag ="N";
	String memo;
	String type;
	String userId;
	String regDate;
	String procDate;
	String deptCd;
	String mailSend;
	String name;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMailSend() {
		return mailSend;
	}
	public void setMailSend(String mailSend) {
		this.mailSend = mailSend;
	}
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public String getJfile() {
		return jfile;
	}
	public void setJfile(String jfile) {
		this.jfile = jfile;
	}
	
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public Integer getRevision() {
		return revision;
	}
	public void setRevision(Integer revision) {
		this.revision = revision;
	}
	public String getApprover() {
		return approver;
	}
	public void setApprover(String approver) {
		this.approver = approver;
	}
	public String getComplete() {
		return complete;
	}
	public void setComplete(String complete) {
		this.complete = complete;
	}
	public String getDelFlag() {
		return delFlag;
	}
	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}
	public String getMemo() {
		return memo;
	}
	public void setMemo(String memo) {
		this.memo = memo;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getProcDate() {
		return procDate;
	}
	public void setProcDate(String procDate) {
		this.procDate = procDate;
	}
	
	public String getDeptCd() {
		return deptCd;
	}
	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}
	@Override
	public String toString() {
		return "ProcessingVO [seq=" + seq + ", title=" + title + ", contents=" + contents + ", jfile=" + jfile
				+ ", docId=" + docId + ", revision=" + revision + ", approver=" + approver + ", complete=" + complete
				+ ", delFlag=" + delFlag + ", memo=" + memo + ", type=" + type + ", userId=" + userId + ", regDate="
				+ regDate + ", procDate=" + procDate + ", deptCd=" + deptCd + ", mailSend=" + mailSend + "]";
	}



	
}
