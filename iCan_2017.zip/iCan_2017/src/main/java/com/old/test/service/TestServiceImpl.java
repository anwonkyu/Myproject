package com.old.test.service;

import java.util.ArrayList;
import java.util.HashMap; 

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
  

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.old.test.dao.TestMapper;
import com.old.test.dao.TestVo;
import com.withus.commons.seed.SEEDUtil;
import com.withus.member.dao.MemberMapper;
import com.withus.member.dao.MemberVo;
import com.withus.question.dao.QuestionVO;
import com.withus.userInfoLog.dao.UserInfoLogVO;
import com.withus.userInfoLog.service.UserInfoLogService;
 

@Service
public class TestServiceImpl   implements TestService {

	@Resource(name="testMapper")
	private TestMapper testMapper;
	
	@Resource
	private UserInfoLogService userInfoService;
 	
	@Override
	public TestVo test() throws Exception{ 
		return (TestVo)testMapper.getTest();
	}

	 

	
}
