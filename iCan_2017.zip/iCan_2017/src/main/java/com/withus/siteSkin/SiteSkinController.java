package com.withus.siteSkin;
 
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
 
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
 


import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
 
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileVo;
 
import com.withus.logo.service.LogoService;
import com.withus.siteSkin.dao.SiteSkinVO;
import com.withus.siteSkin.service.SiteSkinService;
 
/**
 * @Class Name : SiteSkinController.java
 * @Description : SiteSkin Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150323
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class SiteSkinController {

    @Resource(name = "siteSkinService")
    private SiteSkinService siteSkinService;
    
    @Resource(name = "logoService")
	private LogoService logoService;
    
   @Autowired Properties prop;
    
    @Resource
    private PagingHelperService page;
 
    @Resource
	 private UploadFileService uploadFileService;
    
	@Resource(name = "xstreamMarshaller")
	private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView;
  
    @RequestMapping(value="/skin/list.do")
    public String skinList( Integer curPage,
    		ModelMap model)
            throws Exception { 
      	if (curPage == null) curPage = 1;
      	
      	
    	int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());

		int totalRecord = siteSkinService.selectSiteSkinListTotCnt();
		
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
		
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
      
		ArrayList<?> skinList = siteSkinService.selectSiteSkinList(start, end);
       
        Integer no = page.getListNo();
        Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		 
		model.addAttribute("SITE_INFO", logoService.selectLogo());
		 
		model.addAttribute("list",skinList); 
		model.addAttribute("totalRecord", totalRecord);
	    model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
        
        return "/vodman/skin/list";
    } 
    
    @RequestMapping(value="/skin/skinInsert.do", method=RequestMethod.GET)
  	public String write() throws Exception {
      	
      	return "/vodman/skin/skinInsert";
      }
    
    @RequestMapping(value="/skin/skinInsert.do" , method=RequestMethod.POST)
    public String skinInsert( MultipartHttpServletRequest mpRequest, @ModelAttribute("SiteSkinVO") SiteSkinVO siteSkinVo )
            throws Exception {  
    	if (siteSkinService.insertSiteSkin(siteSkinVo) > 0) {
    	
	    	//파일업로드
    		 boolean upload_check = true;
    			Iterator<String> it = mpRequest.getFileNames();

    			while (it.hasNext()) {
    					MultipartFile multiFile = mpRequest.getFile((String) it.next()); 
    				 
    						if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename()) && com.withus.commons.TextUtil.isFileCheck(multiFile.getContentType())) { // 파일 체크 
    							String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename());

	           					multiFile.transferTo(new File(prop.getProperty("SKIN_PATH").trim() + filename));
	           					
	           					UploadFileVo attachFile = new UploadFileVo();
	           				 
	           					attachFile.setFileName(filename);
	           					attachFile.setOrgName(multiFile.getOriginalFilename());
	           					attachFile.setFileSize(multiFile.getSize());
	           					attachFile.setOcode(siteSkinVo.getSeq()+"");
	           					attachFile.setFlag("S");  // S- skin, V - video, B- board, L - live
	       						if (multiFile.getName() != null && multiFile.getName().equals("thumbnail") 
	       								&& com.withus.commons.TextUtil.isFileImage(multiFile.getContentType())) {
	       							attachFile.setType("I"); // 이미지 파일 
	       						} else {
	       							attachFile.setType("N"); // 일반 파일 
	       						}
	       						
	       						uploadFileService.insertAttachFile(attachFile);
    						} else {
    							upload_check = false;
    							break; 
    						} 
    					 
    			}
    	}
		
    	
    	 return "redirect:/vodman/skin/list.do";
    } 
    
    
    
    @RequestMapping(value="/skin/skinUpdate.do", method=RequestMethod.GET)
    public String updateSkinView(
            @RequestParam(value="seq", required=true) int seq ,
            Model model)
            throws Exception {
    	
    	SiteSkinVO siteSkinVo = siteSkinService.selectSiteSkin(seq);
 
        model.addAttribute("siteSkinVo", siteSkinVo);
     
		/*
		 * 첨부파일 정보 읽어 오기
		 */ 
		List<UploadFileVo> uploadFileList = uploadFileService.getUploadFileList(siteSkinVo.getSeq().toString(),"S"); 
		model.addAttribute("uploadFileList", uploadFileList);  // 첨부파일
        
        return "/vodman/skin/skinInsert";
    }
    
    @RequestMapping(value="/skin/skinUpdate.do", method=RequestMethod.POST)
    public String updateSkin(MultipartHttpServletRequest mpRequest,
    		@ModelAttribute("SiteSkinVO") SiteSkinVO siteSkinVo,
    		Integer curPage) throws Exception {
 
 			if (curPage == null) curPage = 1;
 
    		if ( siteSkinService.updateSiteSkin(siteSkinVo) > 0) { 
    		   
	    		//파일업로드
				Iterator<String> it = mpRequest.getFileNames();
	
				while (it.hasNext()) {
						MultipartFile multiFile = mpRequest.getFile((String) it.next()); 
						if ( multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename()) && com.withus.commons.TextUtil.isFileCheck(multiFile.getContentType())) {
							// 기존 이미지 삭제후 
							uploadFileService.deleteFileAll(siteSkinVo.getSeq()+"", "S");
							// 등록
							String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename());
							multiFile.transferTo(new File(prop.getProperty("SKIN_PATH").trim() + filename));
							UploadFileVo attachFile = new UploadFileVo();
							attachFile.setFileName(filename);
							attachFile.setOrgName(multiFile.getOriginalFilename());
							attachFile.setFileSize(multiFile.getSize());
							attachFile.setOcode(siteSkinVo.getSeq()+"");
							attachFile.setFlag("S");
							if (multiFile.getName() != null && multiFile.getName().equals("thumbnail") 
									&& com.withus.commons.TextUtil.isFileImage(multiFile.getContentType())	) {
								attachFile.setType("I"); // 이미지 파일 
								
								
							} else {
								attachFile.setType("N"); // 일반 파일 
							}
							
							uploadFileService.insertAttachFile(attachFile);
						} 
				}  
    		}  
    		return "redirect:/vodman/skin/list.do";
    } 
    @RequestMapping(value="/skin/skinDelete.do" , method=RequestMethod.POST)
    public View skinInsert( @ModelAttribute("seq") Integer seq, Model model )
            throws Exception { 
	 
    	XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
        
    	 
    	if (seq != null) { 
			     if ( siteSkinService.deleteSiteSkin(seq) > 0) { 
			     
			        xml.setMessage("삭제 되었습니다.");
			        xml.setError(true);
			       
			    } else {
			    	xml.setMessage("삭제에 실패하였습니다.");
			 	    xml.setError(false);
			    }
	
	   	} else {
	   		xml.setMessage("정보가 올바르지 않습니다.");
		 	xml.setError(false);
	   	}
		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
    }
    
    
    @RequestMapping(value="/skin/skinSave.do" , method=RequestMethod.POST)
    public View skinSave(@ModelAttribute("path") String path, @ModelAttribute("color") String color , @ModelAttribute("newLimit") String newLimit , @ModelAttribute("boardLimit") String boardLimit ,  Model model)
            throws Exception {
 
    	XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
        
    	if (path != null) { 
		    // if ( siteSkinService.skinSave(path, color) > 0) {  
		    if ( logoService.updateSkin(path, color, newLimit, boardLimit) > 0) {
		        xml.setMessage("적용 되었습니다.");
		        xml.setError(true); 
		    } else {
		    	xml.setMessage("적용에 실패하였습니다.");
		 	    xml.setError(false);
		    }

    	} else {
    		xml.setMessage("정보가 올바르지 않습니다.");
	 	    xml.setError(false);
    	}
	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
    	 
    }
    
	
	
}
