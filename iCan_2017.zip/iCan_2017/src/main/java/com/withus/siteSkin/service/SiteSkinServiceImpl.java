package com.withus.siteSkin.service;

import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

import com.withus.siteSkin.service.SiteSkinService;
 
import com.withus.siteSkin.dao.SiteSkinMapper;
import com.withus.siteSkin.dao.SiteSkinVO;
 

/**
 * @Class Name : SiteSkinServiceImpl.java
 * @Description : SiteSkin Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150323
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("siteSkinService")
public class SiteSkinServiceImpl  implements
        SiteSkinService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(SiteSkinServiceImpl.class);

    @Resource(name="siteSkinMapper")
    private SiteSkinMapper siteSkinDAO;
    
    /** ID Generation */
    //@Resource(name="{egovSiteSkinIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * site_skin을 등록한다.
	 * @param vo - 등록할 정보가 담긴 SiteSkinVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertSiteSkin(SiteSkinVO vo) throws Exception {
     
    	
    	return siteSkinDAO.insertSiteSkin(vo);
    }

    /**
	 * site_skin을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SiteSkinVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateSiteSkin(SiteSkinVO vo) throws Exception {
      return  siteSkinDAO.updateSiteSkin(vo);
    }

    /**
	 * site_skin을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SiteSkinVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteSiteSkin(int seq) throws Exception {
        return siteSkinDAO.deleteSiteSkin(seq);
    }

    /**
	 * site_skin을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SiteSkinVO
	 * @return 조회한 site_skin
	 * @exception Exception
	 */
    public SiteSkinVO selectSiteSkin(int seq) throws Exception {
        SiteSkinVO resultVO = siteSkinDAO.selectSiteSkin(seq);
        
        return resultVO;
    }

    /**
	 * site_skin 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return site_skin 목록
	 * @exception Exception
	 */
    public ArrayList<?> selectSiteSkinList(int start, int end) throws Exception {

		Integer startRownum = start;
		Integer endRownum = end;
 
		HashMap<String, String> hashmap = new HashMap<String, String>();
	  
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
        return siteSkinDAO.selectSiteSkinList(hashmap);
    }

    /**
	 * site_skin 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return site_skin 총 갯수
	 * @exception
	 */
    public int selectSiteSkinListTotCnt() {
		return siteSkinDAO.selectSiteSkinListTotCnt();
	}
    
    public int skinSave(String path, String color){ 
    	
    	Properties prop = new Properties();
    	FileOutputStream fos = null;
    	ClassLoader loader; 
    	int retnr_value = -1;
    	if (path != null) {
	    	try { 
	    		loader = Thread.currentThread().getContextClassLoader();
	    		String proPath = loader.getResource("skin.properties").getPath(); 
	    		//System.out.println(proPath);
	 
	    		fos = new FileOutputStream(proPath);
	    		
	    		prop.setProperty("SKIN_PATH", path); 
	    		prop.setProperty("SKIN_COLOR", color);
	    		prop.store(fos, "skin");
	    		retnr_value = 1; 
	    	 
	    	} catch (IOException ex) {
	    		retnr_value = -1;
	    		ex.printStackTrace();
	    		 
	        }finally{ 
				try{
					fos.close();
				}catch(Exception ex){
					retnr_value = -1;
					ex.printStackTrace();
					 
				}
			}
    	}
    	
    	return retnr_value;
    }
    
}
