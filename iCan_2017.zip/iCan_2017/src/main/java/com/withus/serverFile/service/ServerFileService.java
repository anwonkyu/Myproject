package com.withus.serverFile.service;
import java.util.ArrayList;
 
 
/**
 * @Class Name : BuseoService.java
 * @Description : Buseo Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface ServerFileService  {
 
    /**
	 * buseo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BuseoVO
	 * @return 조회한 buseo
	 * @exception Exception
	 */
 
	ArrayList<?> getFileList()throws Exception;
    
 
    
 
}
