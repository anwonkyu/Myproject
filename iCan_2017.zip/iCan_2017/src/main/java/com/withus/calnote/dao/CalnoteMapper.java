package com.withus.calnote.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;


@Repository("calnoteMapper")
public interface CalnoteMapper {
	public void insertCalnote(CalnoteVO calnoteVo) throws Exception ;
	
	public ArrayList<CalnoteVO> selectCalnoteList(HashMap<String, String> hashmap) throws Exception;
	
	public ArrayList<CalnoteVO> userCalnoteList(HashMap<String, Object> hashmap) throws Exception;

	public ArrayList<CalnoteVO> calNoteNomalDocIdList(HashMap<String, String> hashmap) throws Exception;
	
	public int selectCalnoteListTotCnt(HashMap<String, String> hashmap)throws Exception ;
	
	public int userCalnoteListTotCnt(HashMap<String, Object> hashmap)throws Exception ;
	
	public int calNoteNomalDocIdTotCnt(HashMap<String, String> hashmap)throws Exception ;
	
	public String checkDocId(HashMap<String, String> hashmap)throws Exception ;
	
	public int deleteCalnote(String calnoteId)throws Exception;
	
	public int updateCalnote(CalnoteVO calnoteVo)throws Exception;
	
	public CalnoteVO getCalnote(HashMap<String, String> hashmap) throws Exception;
	
	public int mergeCheck1_1(CalnoteUpdateVO calnoteUpdateVo) throws Exception;
	
	public CalnoteUpdateVO getCalnoteUpdateVo(String calnoteId)throws Exception;
	
	public List<OldFileVO> getOldFileList(HashMap<String, String> hashmap)throws Exception;

	public ArrayList<CalnoteVO> userCalnoteListPanding( HashMap<String, String> hashmap)throws Exception;
	
	public ArrayList<CalnoteVO> userCalnoteListProcessed( HashMap<String, String> hashmap)throws Exception;
	
	public ArrayList<CalnoteVO> userPanding( HashMap<String, String> hashmap)throws Exception;
	
	public ArrayList<CalnoteVO> userProcessed( HashMap<String, String> hashmap)throws Exception;

	public ArrayList<CalnoteVO> userTrListPanding( HashMap<String, String> hashmap)throws Exception;

	public int pandingListTotCnt(HashMap<String, String> hashmap)throws Exception;

	public ArrayList<CalnoteVO> pandingList(HashMap<String, String> hashmap)throws Exception;
	
	public int processedListTotCnt(HashMap<String, String> hashmap)throws Exception;

	public ArrayList<CalnoteVO> processedList(HashMap<String, String> hashmap)throws Exception;

	public int getRevisionMax(HashMap<String, String> hashmap)throws Exception;
 
}
