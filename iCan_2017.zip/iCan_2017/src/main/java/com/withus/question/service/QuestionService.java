package com.withus.question.service;

import java.util.ArrayList;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;

import com.withus.question.dao.QuestionVO;

public interface QuestionService {
	
	@Transactional
	int insertQuestionMember(MultiValueMap<String, String> params) throws Exception;
	
	ArrayList<QuestionVO> questionAllList() throws Exception;
	
	int deleteQuestion(String id, String dcode) throws Exception;
	
	
}
