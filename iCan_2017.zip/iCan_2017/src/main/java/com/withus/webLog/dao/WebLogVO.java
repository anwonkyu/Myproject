package com.withus.webLog.dao;

/**
 * @Class Name : WebLogVO.java
 * @Description : WebLog VO class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 2014-12-24
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class WebLogVO  {
    private static final long serialVersionUID = 1L;
    
    /** log_seq */
    private int logSeq;
    
    /** log_ip */
    private String logIp;
    
    /** log_date */
    private java.util.Date logDate;
    
    /** log_referer */
    private String logReferer;
    
    /** log_uri */
    private String logUri;
    
    /** log_query */
    private String logQuery;
    
    /** log_agent */
    private String logAgent;
    
    /** log_sessionID */
    private String logSessionid;
    
    /** log_day */
    private String logDay;
    
    /** log_method */
    private String logMethod;
    
    public int getLogSeq() {
        return this.logSeq;
    }
    
    public void setLogSeq(int logSeq) {
        this.logSeq = logSeq;
    }
    
    public String getLogIp() {
        return this.logIp;
    }
    
    public void setLogIp(String logIp) {
        this.logIp = logIp;
    }
    
    public java.util.Date getLogDate() {
        return this.logDate;
    }
    
    public void setLogDate(java.util.Date logDate) {
        this.logDate = logDate;
    }
    
    public String getLogReferer() {
        return this.logReferer;
    }
    
    public void setLogReferer(String logReferer) {
        this.logReferer = logReferer;
    }
    
    public String getLogUri() {
        return this.logUri;
    }
    
    public void setLogUri(String logUri) {
        this.logUri = logUri;
    }
    
    public String getLogQuery() {
        return this.logQuery;
    }
    
    public void setLogQuery(String logQuery) {
        this.logQuery = logQuery;
    }
    
    public String getLogAgent() {
        return this.logAgent;
    }
    
    public void setLogAgent(String logAgent) {
        this.logAgent = logAgent;
    }
    
    public String getLogSessionid() {
        return this.logSessionid;
    }
    
    public void setLogSessionid(String logSessionid) {
        this.logSessionid = logSessionid;
    }
    
    public String getLogDay() {
        return this.logDay;
    }
    
    public void setLogDay(String logDay) {
        this.logDay = logDay;
    }
    
    public String getLogMethod() {
        return this.logMethod;
    }
    
    public void setLogMethod(String logMethod) {
        this.logMethod = logMethod;
    }
    
}
