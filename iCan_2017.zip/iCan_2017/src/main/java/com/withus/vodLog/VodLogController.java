package com.withus.vodLog;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
 
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
 
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
  
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;

import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
 
import com.withus.vodLog.service.VodLogService;
 
import com.withus.vodLog.dao.CounterVO;
import com.withus.vodLog.dao.VodLogVO; 
import com.withus.vodLog.ExcelView;
 

/**
 * @Class Name : VodLogController.java
 * @Description : VodLog Controller class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 20150303
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class VodLogController {

	@Autowired
    private VodLogService vodLogService;
 
    @Resource
    private PagingHelperService page;
    @Autowired Properties prop;
 
    /**
	 * vod_log 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 VodLogDefaultVO
	 * @return "/vodLog/VodLogList"
	 * @exception Exception
	 */
    @RequestMapping(value="/site/VodLogList.do")
    public String selectVodLogList(Integer curPage,@ModelAttribute("searchVO") VodLogVO vodLogVo,
    		ModelMap model)
            throws Exception {
    	
    	if (curPage == null) curPage = 1; 
 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim()); 
		int pagePerBlock = Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
 
		int totalRecord = vodLogService.selectVodLogListTotCnt( vodLogVo);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
  
		ArrayList<VodLogVO> list = vodLogService.selectVodLogList(vodLogVo, start, end);
    	
    	Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
 
		
		model.addAttribute("list",list); 
		model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage);  
		model.addAttribute("totalRecord",totalRecord); 
        return "/vodman/site/VodLogList";
    } 
    
    
    // 로그 결과 엑셀받기 
    @RequestMapping(value="/site/VodLogList_excel.do", method=RequestMethod.POST)
    public View vodExcel( @ModelAttribute("searchVO") VodLogVO vodLogVo, ModelMap model) throws Exception {
    	
    	ArrayList<VodLogVO> list = vodLogService.selectVodLogListAll(vodLogVo); 
        model.addAttribute("list", list);
            return new ExcelView();
    }
    
    @RequestMapping(value="/site/VodLogListLive.do")
    public String selectVodLogListLive(Integer curPage,@ModelAttribute("searchVO") VodLogVO vodLogVo,
    		ModelMap model)
            throws Exception {
    	
    	if (curPage == null) curPage = 1; 
 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim()); 
		int pagePerBlock = Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
 
		int totalRecord = vodLogService.selectVodLogListTotCntLive( vodLogVo);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
  
		ArrayList<VodLogVO> list = vodLogService.selectVodLogListLive(vodLogVo, start, end);
    	
    	Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		
		model.addAttribute("list",list); 
		model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage);  
		model.addAttribute("totalRecord",totalRecord); 
        return "/vodman/site/VodLogListLive";
    } 
    
    
    // 로그 결과 엑셀받기 
    @RequestMapping(value="/site/VodLogListLive_excel.do", method=RequestMethod.POST)
    public View liveExcel( @ModelAttribute("searchVO") VodLogVO vodLogVo, ModelMap model) throws Exception {
    	
    	ArrayList<VodLogVO> list = vodLogService.selectVodLogListLiveAll(vodLogVo);
    	
        model.addAttribute("list", list);
            return new ExcelView();
    }
    
    @RequestMapping(value="/site/viewCounter.do")
    public String selectCounterList( String flag, String type,
    		String ViewFlag,String searchDate,String searchDate2,
    		ModelMap model)
            throws Exception {
    
		
//		// 시스템으로부터 현재시간(ms) 가져오기
		long now = System.currentTimeMillis();
		// Data 객체에 시간을 저장한다.
		Date date = new Date(now); 
		
		SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy-MM-dd");
		String strNow = sdfNow.format(date);
		
		String Year = strNow.substring(0,4);
		String Month = strNow.substring(5,7);
		String Day =  strNow.substring(8,10);
		if (searchDate != null) {
			strNow = searchDate;
			Year = strNow.substring(0,4);
		} 
		
		if (ViewFlag != null && ViewFlag.equals("day") ) {
			Month = strNow.substring(5,7);
		} else if (searchDate2 != null && ViewFlag.equals("month")) {
			Month = searchDate2;
			strNow = Year +"-"+ Month;
		}
		
		if (ViewFlag != null && ViewFlag.equals("day")) {
			Day = strNow.substring(8,10);
		}
		
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(Integer.parseInt(Year),  Integer.parseInt(Month)-1,  Integer.parseInt(Day)); 
		int lastDay = calendar.getActualMaximum(Calendar.DATE); // 해당월 마지막일
//		System.out.println("aaaaaa:"+Year+Month+Day);
//		System.out.println("ddddddddd:"+lastDay);
		ArrayList<CounterVO> list =  null;
 
		int[] totalCnt = null;
	 
		if (ViewFlag != null && ViewFlag.equals("year")) {
			list = vodLogService.selectCounterListYear( Integer.parseInt(Year),  flag,  type);
			totalCnt = new int[12];
			for (int i= 0 ; i < list.size(); i++ ) {
				totalCnt[Integer.parseInt(list.get(i).getCountMField())-1 ]=totalCnt[Integer.parseInt(list.get(i).getCountMField())-1 ]+Integer.parseInt(list.get(i).getCounter());
			}
		 
		} else if(ViewFlag != null && ViewFlag.equals("month")) {
			list = vodLogService.selectCounterListMonth( Integer.parseInt(Year),  Integer.parseInt(Month), flag,  type);
			totalCnt = new int[lastDay];
			for (int i= 0 ; i < list.size(); i++ ) {
				totalCnt[Integer.parseInt(list.get(i).getCountDField())-1 ]=totalCnt[Integer.parseInt(list.get(i).getCountDField())-1 ]+Integer.parseInt(list.get(i).getCounter());
			}
			 
		} else {
			list = vodLogService.selectCounterList( Integer.parseInt(Year),  Integer.parseInt(Month),  Integer.parseInt(Day),  flag,  type);
			totalCnt = new int[3];
			for (int i= 0 ; i < list.size(); i++ ) {
				totalCnt[0]=totalCnt[0]+list.get(i).getCday();
				totalCnt[1]=totalCnt[1]+list.get(i).getCmonth();
				totalCnt[2]=totalCnt[2]+list.get(i).getCyear();
			}
		 
		}
		ArrayList<CounterVO> cateList = vodLogService.selectCounterListMenu(type);
		
		model.addAttribute("lastDay",lastDay); 
		model.addAttribute("today",strNow); 
		model.addAttribute("cateList",cateList); 
		model.addAttribute("list",list); 
		model.addAttribute("totalCnt",totalCnt); 
 
        return "/vodman/site/viewCounter";
    } 
    
    @RequestMapping(value="/site/viewCounterLive.do")
    public String selectCounterListLive(  String flag, String type,
    		String ViewFlag,String searchDate,String searchDate2,
    		ModelMap model)
            throws Exception {
 
//		// 시스템으로부터 현재시간(ms) 가져오기
		long now = System.currentTimeMillis();
		// Data 객체에 시간을 저장한다.
		Date date = new Date(now); 
		
		SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy-MM-dd");
		String strNow = sdfNow.format(date); 
 
		String Year = strNow.substring(0,4);
		String Month = strNow.substring(5,7);
		String Day = strNow.substring(8,10);
		
		if (searchDate != null) {
			strNow = searchDate;
			Year = strNow.substring(0,4);
		} 
 
		if (ViewFlag != null && ViewFlag.equals("day") ) {
			Month = strNow.substring(5,7);
		} else if (searchDate2 != null && ViewFlag.equals("month")) {
		 
			Month = searchDate2;
			strNow = Year +"-"+ Month;
		}  
		
		if (ViewFlag != null && ViewFlag.equals("day")) {
			Day = strNow.substring(8,10);
		} 
		
		Calendar calendar = Calendar.getInstance();
		calendar.set(Integer.parseInt(Year),  Integer.parseInt(Month)-1,  Integer.parseInt(Day)); 
		int lastDay = calendar.getActualMaximum(calendar.DATE); // 해당월 마지막일 
 
 
		ArrayList<CounterVO> list =  null;
		if (ViewFlag != null && ViewFlag.equals("year")) {
			list = vodLogService.selectCounterListYearLive( Integer.parseInt(Year),  flag);
		} else if(ViewFlag != null && ViewFlag.equals("month")) {
			list = vodLogService.selectCounterListMonthLive( Integer.parseInt(Year),  Integer.parseInt(Month), flag);
		} else {
			list = vodLogService.selectCounterListLive( Integer.parseInt(Year),  Integer.parseInt(Month),  Integer.parseInt(Day),  flag);
		} 

		model.addAttribute("lastDay",lastDay); 
		model.addAttribute("today",strNow); 
		
		model.addAttribute("list",list); 
 
        return "/vodman/site/viewCounterLive";
    } 
     
    
    @RequestMapping(value="/site/connectCount.do")
    public String connectCount( ModelMap model, String Flag)
            throws Exception {
    	 if(Flag== null) Flag="W";
    	 ArrayList<VodLogVO> list = vodLogService.connectCount(Flag);
    	 long now = System.currentTimeMillis();
 		// Data 객체에 시간을 저장한다.
 		Date date = new Date(now); 
    	 SimpleDateFormat sdfNow = new SimpleDateFormat("yyyy-MM-dd");
 		String strNow = sdfNow.format(date);
 		
    	 model.addAttribute("today",strNow); 
    	 model.addAttribute("list",list); 
    	 return "/vodman/site/connectCount";
    }
    
    @RequestMapping(value="/site/connectCountWeek.do")
    public String connectCountWeek( ModelMap model, String Flag, Integer Idx)
            throws Exception {
    	 if(Flag== null || Flag == "") Flag="W";
    
    	//int iDateSum = 0;  //paramData
    	if (Idx == null)  Idx = 0;
 		int START_DAY_OF_WEEK = 0;
 		Calendar sDay = Calendar.getInstance();       // 시작일 
 		START_DAY_OF_WEEK = sDay.get(Calendar.DAY_OF_WEEK); 
  
 		int iDate = (Idx-START_DAY_OF_WEEK+1);
 		
 		 ArrayList<VodLogVO> list = vodLogService.connectCountWeek(iDate, Flag);
 	//System.out.println("connectCountWeek:"+Flag+iDate);	 
    	 model.addAttribute("list",list); 
    	 model.addAttribute("Flag",Flag); 
    	 return "/vodman/site/connectCountWeek";
    }
    
    @RequestMapping(value="/site/connectCountMonth.do")
    public String connectCountMonth( ModelMap model, String Flag, Integer Idx)
            throws Exception {
    	 if(Flag== null || Flag == "") Flag="W";
    
    	//int iDateSum = 0;  //paramData
    	if (Idx == null)  Idx = 0;
     
    	Calendar calendar = Calendar.getInstance();
		calendar.add(calendar.MONTH, +(Idx));
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
		//String beforeYear = dateFormat.format(calendar.getTime()).substring(0,4); 
		//String beforeMonth = dateFormat.format(calendar.getTime()).substring(4,6); 
		//System.out.println(beforeYear+beforeMonth);
 
		int lastDay = calendar.getActualMaximum(Calendar.DATE); // 해당월 마지막일 
		//System.out.println(lastDay);
 		
 		 ArrayList<VodLogVO> list = vodLogService.connectCountMonth(Idx, Flag);
 	//System.out.println("connectCountWeek:"+Flag+iDate);	 
    	 model.addAttribute("list",list); 
    	 model.addAttribute("Flag",Flag); 
    	 model.addAttribute("lastDay",lastDay); 
    	 model.addAttribute("searchMonth",dateFormat.format(calendar.getTime()).substring(0,6)); 
    	 return "/vodman/site/connectCountMonth";
    }
    
    @RequestMapping(value="/site/connectCountYear.do")
    public String connectCountYear( ModelMap model, String Flag, Integer Idx)
            throws Exception {
    	if(Flag== null || Flag == "") Flag="W";
    	if (Idx == null)  Idx = 0;
    	
    	Calendar calendar = Calendar.getInstance();
		calendar.add(calendar.YEAR,+(Idx));
 
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMM");
		String searchYear = dateFormat.format(calendar.getTime()).substring(0,4); 
	 	
		
    
 		 ArrayList<VodLogVO> list = vodLogService.connectCountYear(searchYear, Flag);
  
    	 model.addAttribute("list",list); 
    	 model.addAttribute("Flag",Flag); 
    	 model.addAttribute("searchYear",searchYear); 
    	 
 
    	 return "/vodman/site/connectCountYear";
    }
   
   
}
