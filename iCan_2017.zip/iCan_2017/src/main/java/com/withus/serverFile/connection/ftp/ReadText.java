package com.withus.serverFile.connection.ftp;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.text.*;
import java.sql.*;
public class ReadText {

	public static void main(String arg[]) throws IOException {
		System.out.println("시작");
		try {
			String strTodayDate = "";// 오늘일자
			Calendar calInfo = Calendar.getInstance();
			// calInfo.add(cal.DATE, -1 );
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			strTodayDate = formatter.format(calInfo.getTime());
System.out.println("ftp_start");
			ServerFtpConn fdf = new ServerFtpConn(); 
			    fdf.connect(1);
	            fdf.login(1);
	            fdf.list();
	           // fdf.get("../InterfaceData/MRO/SKN" + strTodayDate + ".txt", "","Update_Data.txt");
	            
	            fdf.cd("./VOL1");
	            fdf.pwd();
	            fdf.list();
	            
	            fdf.cd("./New_업무폴더");
	            fdf.pwd();
	            fdf.list();
	      
	            fdf.cd("./WITHUS2008");
	            fdf.pwd();
	            fdf.list();
	      
	            fdf.cd("./VOL1");
	            fdf.pwd();
	            fdf.list();

	            
	            fdf.logout();
	 
	          
	        } catch (Exception e) {
	            System.out.println("--------------------------------------------------------------------------------");
	            System.out.println("파일 다운로드 실패 : " + e);
	            System.out.println("--------------------------------------------------------------------------------");
	            return;
	        }

	}
}
