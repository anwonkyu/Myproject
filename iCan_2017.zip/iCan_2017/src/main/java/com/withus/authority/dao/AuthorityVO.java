package com.withus.authority.dao;

/**
 * @Class Name : AuthorityVO.java
 * @Description : Authority VO class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class AuthorityVO {
    private static final long serialVersionUID = 1L;
    
    /** authority */
    private String authority;
    
    /** authority_name */
    private String authorityName;
    
    public String getAuthority() {
        return this.authority;
    }
    
    public void setAuthority(String authority) {
        this.authority = authority;
    }
    
    public String getAuthorityName() {
        return this.authorityName;
    }
    
    public void setAuthorityName(String authorityName) {
        this.authorityName = authorityName;
    }
    
}
