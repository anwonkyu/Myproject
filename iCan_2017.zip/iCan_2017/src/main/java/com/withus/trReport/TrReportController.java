package com.withus.trReport;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.boardlist.dao.BoardListVO;
import com.withus.boardlist.service.BoardListService;
import com.withus.category.dao.CategoryVO;
import com.withus.category.service.CategoryService;
import com.withus.commons.TextUtil;
import com.withus.commons.XmlResult;
import com.withus.commons.seed.SEEDUtil;
import com.withus.commons.seed.WithusSeed;
import com.withus.commons.uploadFile.UploadUtil;
import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileVo;
import com.withus.logo.dao.LogoVO;
import com.withus.logo.service.LogoService;
import com.withus.member.dao.MemberVo;
import com.withus.member.service.MemberService;
import com.withus.popup.dao.PopupmanVO;
import com.withus.popup.service.PopupmanService;

 
import com.withus.vodLog.dao.VodLogVO;
import com.withus.vodLog.service.VodLogService;
 
/**
 * Handles requests for the application home page.
 */
@Controller
public class TrReportController {
	
	private static final Logger logger = LoggerFactory.getLogger(TrReportController.class);
 
	@Resource
	private CategoryService categoryService;
 
	@Resource
    private UploadFileService uploadFileService;
	
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;
	
	// util:properties 로 생성된 빈은 java.util.Properties 의 인스턴스이기 때문에
    // 요렇게 Autowired 해서 쓸 수 있다.
    @Autowired Properties prop;
	
    @RequestMapping(value = "/trReport/trReportList.do", method = RequestMethod.GET)
    public String trReportList( Integer curPage,String searchFild,  String searchWord, Model model, String menuCode, String selectCode, Integer pagelimit) throws Exception  {
    	
    	if (curPage == null) curPage = 1;
    	if (pagelimit == null) pagelimit = 10;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";  
 		
    	return "/trReport/trReportList";
   } 
    
    @RequestMapping(value = "/trReport/trReportAdd.do" )
    public String trReportList( Model model ) throws Exception  {
    	
    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession(false);
 
 		
    	return "/trReport/trReportAdd";
   } 
    
 

     
	    
}

 