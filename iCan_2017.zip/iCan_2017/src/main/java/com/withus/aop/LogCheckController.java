package com.withus.aop;
 
import com.withus.aop.service.AopServiceImpl;


public class LogCheckController {
 
 
	private AopServiceImpl aopService;
	
	public void pageCnnCnt() {
		System.out.println("----------aopTest");
//		aopService.pageCnnCnt("W");
		System.out.println("----------aopTest");
	}
	
}
