package com.withus.calnote;

import java.util.ArrayList;
import java.util.Properties;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.service.CalnoteService;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;

@Controller
@RequestMapping("/vodman")
public class VodmanCalnoteController {
	
	private static final Logger logger = LoggerFactory.getLogger(VodmanCalnoteController.class);
	
	  @Autowired Properties prop;
	  @Autowired CalnoteService calnoteService;
	  @Resource
	  private PagingHelperService page;
	  @Resource(name = "xstreamMarshaller")
	  private XStreamMarshaller xstreamMarshaller;
	  @Resource(name = "xmlView")
	  private View xmlView;
	  
	  @RequestMapping(value="/calnote/calList.do")
	    public String selectcalList(String searchWord, Integer curPage, 
	    		ModelMap model)
	            throws Exception {
	    	
	    	if (curPage == null) curPage = 1;
			if (searchWord == null) searchWord = ""; 
			
			int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
			int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
			
			int totalRecord = calnoteService.selectCalnoteListTotCnt(searchWord);
			PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
	 	
			page.setPagingHelper(pagingHelper);
			int start = pagingHelper.getStartRecord();
			int end = pagingHelper.getEndRecord();
			
			ArrayList<?> calnoteList = calnoteService.selectCalnoteList(searchWord, start, end);
			
			Integer prevLink = page.getPrevLink();
			Integer nextLink = page.getNextLink();
			Integer firstPage = page.getFirstPage();
			Integer lastPage = page.getLastPage();
			int[] pageLinks = page.getPageLinks(); 
			
			model.addAttribute("prevLink", prevLink);
			model.addAttribute("nextLink", nextLink);
			model.addAttribute("firstPage", firstPage);
			model.addAttribute("lastPage", lastPage);
			model.addAttribute("pageLinks", pageLinks);
			model.addAttribute("curPage", curPage); 
			model.addAttribute("totalRecord", totalRecord); 
			
	        model.addAttribute("resultList", calnoteList);
	  
	        return "/vodman/calnote/calList";
	    }
	  
	  @RequestMapping(value="/calnote/calWrite.do", method=RequestMethod.GET)
			public String write( Model model) throws Exception {
		 
				return "/vodman/calnote/addForm";
			}
	  
	  @RequestMapping(value="/calnote/calWrite.do", method=RequestMethod.POST)
	    public String calWrite(CalnoteVO calnoteVo )throws Exception {
	    	calnoteService.insertCalnote(calnoteVo);
	        return "redirect:/vodman/calnote/calList.do";
	    }
	  
	  @RequestMapping(value="/calnote/calUpdate.do", method=RequestMethod.GET)
		public String calUpdate(String calnoteId, Model model) throws Exception {
			CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
			//수정페이지에서의 보일 게시글 정보
			model.addAttribute("thisVo", calnoteVo);
	 		
			return "/vodman/calnote/addForm";
		}
	  
	  @RequestMapping(value="/calnote/calUpdate.do", method=RequestMethod.POST)
		public View calUpdate(@ModelAttribute("calnoteVo") CalnoteVO calnoteVo, Model model ) throws Exception {
		 
			   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     if ( calnoteService.updateCalnote(calnoteVo) > 0) {
				        xml.setMessage(calnoteVo.getCalnoteId());
				        xml.setError(true);
			       
			    } else {
			    	 xml.setMessage(calnoteVo.getCalnoteId());
			 	     xml.setError(false);
			    }

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	  
	  @RequestMapping(value="/calnote/calDelete.do", method=RequestMethod.POST)
		public View deptDelete(@RequestParam(value="calnoteId" ,required=true)String calnoteId, Model model ) {
				   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     try {
					if ( calnoteService.deleteCalnote(calnoteId) > 0) {
					        xml.setMessage("삭제되었습니다.");
					        xml.setError(true);
					   
					} else {
						xml.setMessage("삭제에 실패하였습니다.");
					     xml.setError(false);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	  
	  
	  
	  
	  
}
