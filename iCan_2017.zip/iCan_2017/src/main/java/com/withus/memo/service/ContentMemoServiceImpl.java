package com.withus.memo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

import com.withus.calHistory.dao.CalHistoryVO;
import com.withus.calHistory.service.CalHistoryService;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.seed.WithusSeed;
import com.withus.member.dao.MemberVo;
import com.withus.memo.service.ContentMemoService;
 
import com.withus.memo.dao.ContentMemoMapper;
import com.withus.memo.dao.ContentMemoVO;
 

/**
 * @Class Name : ContentMemoServiceImpl.java
 * @Description : ContentMemo Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("contentMemoService")
public class ContentMemoServiceImpl implements ContentMemoService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(ContentMemoServiceImpl.class);

    @Autowired Properties prop;
    
    @Autowired CalHistoryService calHistoryService;
    
    @Resource(name="contentMemoMapper")
    private ContentMemoMapper contentMemoDAO;
    
    private PagingHelper pagingHelper; //페이징 처리 유틸리티 클래스
    
    /** ID Generation */
    //@Resource(name="{egovContentMemoIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * content_memo을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ContentMemoVO
	 * @return 등록 결과
	 * @exception Exception
	 */

    @Transactional
    public int insertContentMemo(ContentMemoVO vo) throws Exception { 
    	HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();

//		HttpSession session = request.getSession(false); 
//		if(  session != null && session.getAttribute(prop.getProperty("USER_KEY").trim()) != null){
//			MemberVo memberVo = (MemberVo)session.getAttribute(prop.getProperty("USER_KEY").trim());
//			vo.setId(memberVo.getId() );
//			vo.setWname(com.withus.commons.seed.SEEDUtil.getEncrypt(memberVo.getName()) );
//		} else{
//        	 return -1;
//        }
		
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			if(vo.getSystem()){
				vo.setId("System");
			}else{
				vo.setId(((MemberVo)principal).getUsername() );
			} 
			//vo.setWname(com.withus.commons.seed.SEEDUtil.getDecrypt(((MemberVo)principal).getName()) );  
			vo.setWname(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
		} else{
        	 return -1;
        }
		vo.setIp(request.getRemoteAddr());
		
		CalHistoryVO Hvo = new CalHistoryVO(); 
		Hvo.setCalnoteId(vo.getCalnoteId());
		Hvo.setComments(vo.getState());
		if (vo.getState() != null && vo.getState().length() > 0) {
			Hvo.setComments(vo.getState());
			calHistoryService.insertCalHistory(Hvo);
	    
	    	return contentMemoDAO.insertContentMemo(vo);
		} else {  // Tr_Report 일경우 코멘트는 등록하지 않고 history 에만 등록함
			Hvo.setComments(vo.getContents());
			return calHistoryService.insertCalHistory(Hvo);
		}	 
     	
    }

    
    @Transactional
    public int replyContentMemo(ContentMemoVO vo) throws Exception { 
    	HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
 		
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			vo.setId(((MemberVo)principal).getUsername() );
			//vo.setWname(com.withus.commons.seed.SEEDUtil.getDecrypt(((MemberVo)principal).getName()) );
			vo.setWname(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
		} else{
        	 return -1;
        }
    	
		CalHistoryVO Hvo = new CalHistoryVO(); 
		Hvo.setCalnoteId(vo.getCalnoteId());
		Hvo.setComments(vo.getState());
	 
     	calHistoryService.insertCalHistory(Hvo); 
     	
        vo.setIp(request.getRemoteAddr());
    
    	return contentMemoDAO.replyContentMemo(vo);
    }

    
    /**
	 * content_memo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 ContentMemoVO
	 * @return void형
	 * @exception Exception
	 */
    
    @Transactional
    public int updateContentMemo(ContentMemoVO vo) throws Exception {
    	    	
    	 
		int rtn_value = -1;
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			vo.setId(((MemberVo)principal).getUsername() );
			//vo.setWname(com.withus.commons.seed.SEEDUtil.getDecrypt(((MemberVo)principal).getName()) );
			vo.setWname(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
			
			CalHistoryVO Hvo = new CalHistoryVO(); 
			Hvo.setCalnoteId(vo.getCalnoteId());
			Hvo.setComments(vo.getState()+" update");
			
	     	calHistoryService.insertCalHistory(Hvo);  
	     	rtn_value =contentMemoDAO.updateContentMemo(vo);
		}
	     	
       return rtn_value;
    }
    
    public int updateContentMemoFlag(ContentMemoVO vo) throws Exception {
    	    	
       return contentMemoDAO.updateContentMemoFlag(vo);
    }

    /**
	 * content_memo을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ContentMemoVO
	 * @return void형 
	 * @exception Exception
	 */
    @Transactional
    public int deleteContentMemo(ContentMemoVO vo) throws Exception {
         
    	HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		 
	   	
		int rtn_value = -1;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			vo.setId(((MemberVo)principal).getUsername() );
			//vo.setWname(com.withus.commons.seed.SEEDUtil.getDecrypt(((MemberVo)principal).getName()) );
			vo.setWname(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
			
			CalHistoryVO Hvo = new CalHistoryVO(); 
			Hvo.setCalnoteId(vo.getCalnoteId());
			Hvo.setComments(vo.getState());
			
	     	calHistoryService.insertCalHistory(Hvo); 
	     	
			rtn_value = contentMemoDAO.deleteContentMemoUser(vo);
		} 
		
		return rtn_value;
		
    }
    

    
    public int deleteContentMemo_vodman(ContentMemoVO vo) throws Exception { 
		int rtn_value = -1;
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			rtn_value = contentMemoDAO.deleteContentMemo(vo);
		}  
		
		return rtn_value;
		
    }

     
    public int comment_check(ContentMemoVO vo) throws Exception{
	HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
 		
    	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			vo.setId(((MemberVo)principal).getUsername() ); 
		} else{
        	 return -1;
        }
    	  
    	return contentMemoDAO.comment_check(vo);
    }
    
     
    /**
	 * content_memo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ContentMemoVO
	 * @return 조회한 content_memo
	 * @exception Exception
	 */
    public ContentMemoVO selectContentMemo(int muid) throws Exception {
        ContentMemoVO resultVO = contentMemoDAO.selectContentMemo(muid);
        
        return resultVO;
    }

    /**
	 * content_memo 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return content_memo 목록
	 * @exception Exception
	 */
    public ArrayList<ContentMemoVO> selectContentMemoList(String calnoteId, String searchFild, String searchWord,String state,int start, int end) throws Exception {
    	Integer startRownum = start;
		Integer endRownum = end;
  
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("state", state);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		
        return contentMemoDAO.selectContentMemoList(hashmap);
		//return com.withus.commons.seed.WithusSeed.returnSeedListMemo(contentMemoDAO.selectContentMemoList(hashmap));
    }

    /**
	 * content_memo 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return content_memo 총 갯수
	 * @exception
	 */
    public int selectContentMemoListTotCnt(String calnoteId, String searchFild, String searchWord,String state) {
    	 
		 
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("state", state);
		return contentMemoDAO.selectContentMemoListTotCnt(hashmap);
	}
    
    @Override
	public ContentMemoVO selectContentMemoFlag(String calnoteId, String state) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		hashmap.put("state", state);
		return contentMemoDAO.selectContentMemoFlag(hashmap);
	}
    
    public int getListNo() {
		return pagingHelper.getListNo(); 
	}
	
	public int getPrevLink() {
		return pagingHelper.getPrevLink();
	}
	
	public int getFirstPage() {
		return pagingHelper.getFirstPage();
	}
	
	public int getLastPage() {
		return pagingHelper.getLastPage();
	}
	
	public int getNextLink() {
		return pagingHelper.getNextLink();
	}

	public int[] getPageLinks() {
		return pagingHelper.getPageLinks();
	}

	public PagingHelper getPagingHelper() {
		return pagingHelper;
	}

	public void setPagingHelper(PagingHelper pagingHelper) {
		this.pagingHelper = pagingHelper;
	}


	@Override
	public ContentMemoVO codceComment_select(String calonteId, String this_state)
			throws Exception {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
 
			
			String state = "";
		 
			if (this_state != null && ( this_state.equals("A003") || this_state.equals("R002")  )) {  // 독립검토
				state = "ind";				   
			}else if (this_state != null && ( this_state.equals("A004")  || this_state.equals("R003") )) { // 검토 
				state = "rev";				   
			}else if (this_state != null && ( this_state.equals("S002") )) { // 승인
				state = "app";
			}			
			
			
			HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap.put("calnoteId", calonteId); 
			hashmap.put("state", state); 
			hashmap.put("userId", ((MemberVo)principal).getUsername() );
			 
			return contentMemoDAO.codceComment_select(hashmap);
			
		} else{
        	 return null;
        }
		 
	}
}
