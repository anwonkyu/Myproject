package com.withus.group.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 


import com.withus.group.dao.GroupsVO;
 
/**
 * @Class Name : GroupsDAO.java
 * @Description : Groups DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("groupsMapper")
public interface GroupsMapper {

	/**
	 * groups을 등록한다.
	 * @param vo - 등록할 정보가 담긴 GroupsVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertGroups(GroupsVO vo) throws Exception ;

    /**
	 * groups을 수정한다.
	 * @param vo - 수정할 정보가 담긴 GroupsVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateGroups(GroupsVO vo) throws Exception ;

    /**
	 * groups을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 GroupsVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteGroups(int groupId) throws Exception ;

    /**
	 * groups을 조회한다.
	 * @param vo - 조회할 정보가 담긴 GroupsVO
	 * @return 조회한 groups
	 * @exception Exception
	 */
    public GroupsVO selectGroups(int groupId) throws Exception ;

    /**
	 * groups 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return groups 목록
	 * @exception Exception
	 */
    public ArrayList<GroupsVO> selectGroupsList() throws Exception ;

    /**
	 * groups 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return groups 총 갯수
	 * @exception
	 */
    public int selectGroupsListTotCnt() ;

	public ArrayList<GroupsVO> selectGroupsMemberList(int groupId);

	public ArrayList<GroupsVO> selectGroupsAuthorityList(int groupId);

	public int deleteGroupsMember(int seq);

	public int deleteGroupsAuthority(int seq);
	
	public int insertGroupsMember(HashMap<String, Object> hashmap );
	public int insertGroupsAuthority(HashMap<String, Object> hashmap );
}
