package com.withus.category.service;

import java.util.ArrayList;
import java.util.HashMap;
 
import java.util.List;

import javax.annotation.Resource;

import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

import com.withus.category.service.CategoryService;
 
import com.withus.category.dao.CategoryMapper;
import com.withus.category.dao.CategoryVO;
 
/**
 * @Class Name : CategoryServiceImpl.java
 * @Description : Category Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2011-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("categoryService")
public class CategoryServiceImpl  implements
        CategoryService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(CategoryServiceImpl.class);

    @Resource(name="categoryMapper")
    private CategoryMapper categoryDAO;
    
    /** ID Generation */
    //@Resource(name="{egovCategoryIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * category을 등록한다.
	 * @param vo - 등록할 정보가 담긴 CategoryVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    @CacheEvict(value = {"MENU", "CATEGORY"}, allEntries=true)
    public int insertCategory(CategoryVO vo) throws Exception { 
    	CategoryVO temp_cate = new CategoryVO();
    	String temp_cinfo = "A";
		String temp_ccode = "";
		String temp_CparentCode = "";
		HashMap<String, String> hashmap = null;
	 
	 
    	if (vo.getCcode() != null && vo.getCcode().length() > 0) {
    		
    		hashmap = new HashMap<String, String>();
			hashmap.put("ccode",vo.getCcode());
			hashmap.put("ctype", vo.getCtype());
			hashmap.put("cinfo", "");
    		temp_cate = categoryDAO.selectOneCategory(hashmap);
    		
    		if (temp_cate != null) {
    			temp_cinfo = temp_cate.getCinfo();
    			if (temp_cinfo != null && temp_cinfo.equals("A")) {
    				temp_CparentCode = temp_cate.getCcode(); 
    				temp_cinfo = "B";
    				
    				int code = 0;
    				hashmap = new HashMap<String, String>();
    				hashmap.put("ccode","");
    				hashmap.put("ctype", vo.getCtype());
    				hashmap.put("cinfo", "B");
    				temp_cate = categoryDAO.selectOneCategory(hashmap);
    					if (temp_cate != null && temp_cate.getCcode() != null) {
    						code = Integer.parseInt(temp_cate.getCcode().substring(3, 6));
    					}
    				code = code + 1;
    				String tmp_code = com.withus.commons.TextUtil.zeroFill(3, code);
    				temp_ccode = temp_CparentCode.substring(0,3)+tmp_code+"000000";
    				
    			} else if (temp_cinfo != null && temp_cinfo.equals("B")){
    				temp_CparentCode = temp_cate.getCcode(); 
    				temp_cinfo = "C";
    				
    				int code = 0;
    				hashmap = new HashMap<String, String>();
    				hashmap.put("ccode","");
    				hashmap.put("ctype", vo.getCtype());
    				hashmap.put("cinfo", "C");
    				temp_cate = categoryDAO.selectOneCategory(hashmap);
    					if (temp_cate != null && temp_cate.getCcode() != null) {
    						code = Integer.parseInt(temp_cate.getCcode().substring(6, 9));
    					}
    				code = code + 1;
    				String tmp_code = com.withus.commons.TextUtil.zeroFill(3, code);
    				temp_ccode = temp_CparentCode.substring(0,6)+tmp_code+"000";
    				
    			}else if (temp_cinfo != null && temp_cinfo.equals("C")){
    				temp_CparentCode = temp_cate.getCcode(); 
    				temp_cinfo = "D";
    				
    				int code = 0;
    				hashmap = new HashMap<String, String>();
    				hashmap.put("ccode","");
    				hashmap.put("ctype", vo.getCtype());
    				hashmap.put("cinfo", "D");
    				temp_cate = categoryDAO.selectOneCategory(hashmap);
    					if (temp_cate != null && temp_cate.getCcode() != null) {
    						code = Integer.parseInt(temp_cate.getCcode().substring(9, 12));
    					}
    				code = code + 1;
    				String tmp_code = com.withus.commons.TextUtil.zeroFill(3, code);
    				temp_ccode = temp_CparentCode.substring(0,9)+tmp_code;
    			}
    		}
    	} else {
    		hashmap = new HashMap<String, String>();
			hashmap.put("ccode","");
			hashmap.put("ctype", vo.getCtype());
			hashmap.put("cinfo", "A");
			
			int code = 0;
    		temp_cate = categoryDAO.selectOneCategory(hashmap);
    		if (temp_cate != null) {
    			temp_ccode = temp_cate.getCcode();
    			code = Integer.parseInt(temp_ccode.substring(0, 3));
    		}
    		
			code = code + 1;
			String tmp_code = com.withus.commons.TextUtil.zeroFill(3, code);
			temp_ccode = tmp_code+"000000000";
    	}
    	
    	vo.setCinfo(temp_cinfo);
    	vo.setCparentCode(temp_CparentCode);
    	vo.setCcode(temp_ccode);
    	
        return categoryDAO.insertCategory(vo);
    }

    /**
	 * category을 수정한다.
	 * @param vo - 수정할 정보가 담긴 CategoryVO
	 * @return void형
	 * @exception Exception
	 */
    @CacheEvict(value = {"MENU", "CATEGORY"}, allEntries=true)
    public int updateCategory(CategoryVO vo) throws Exception {
      return  categoryDAO.updateCategory(vo);
    }

    /**
	 * category을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 CategoryVO
	 * @return void형 
	 * @exception Exception
	 */
    @CacheEvict(value = {"MENU", "CATEGORY"}, allEntries=true)
    public int deleteCategory(int cuid) throws Exception {
        return categoryDAO.deleteCategory(cuid);
    }

    /**
	 * category을 조회한다.
	 * @param vo - 조회할 정보가 담긴 CategoryVO
	 * @return 조회한 category
	 * @exception Exception
	 */
    public CategoryVO selectCategory(int cuid) throws Exception {
        CategoryVO resultVO = categoryDAO.selectCategory(cuid);
        
        return resultVO;
    }

    /**
	 * category 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return category 목록
	 * @exception Exception
	 */
    public ArrayList<CategoryVO> selectCategoryList(String ccode, String ctype) throws Exception {
        return categoryDAO.selectCategoryList(ccode, ctype);
    }

    /**
	 * category 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return category 총 갯수
	 * @exception
	 */
    public int selectCategoryListTotCnt(String ccode, String ctype) {
		return categoryDAO.selectCategoryListTotCnt( ccode,  ctype);
	}
    
    
    public ArrayList<CategoryVO> selectCategoryList_child(String ccode, String ctype) throws Exception {
    	
    	HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("cparentCode", ccode);
		hashmap.put("ctype", ctype);
        return categoryDAO.selectCategoryList_child(hashmap);
    } 
    
    //@Cacheable(value="CATEGORYAll", key="{ #ccode, #ctype, #cinfo }")
    public ArrayList<CategoryVO> selectCategoryList_cinfo(String ccode, String ctype, String cinfo) throws Exception {
    	String temp_ccode= checkCcode_info(ccode, cinfo);
    	HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ccode", temp_ccode);
		hashmap.put("ctype", ctype);
		hashmap.put("cinfo", cinfo);
        return categoryDAO.selectCategoryList_cinfo(hashmap);
    } 
    
    public ArrayList<CategoryVO> selectCategoryList_Count(String ccode, String ctype, String cinfo) throws Exception {
    	String temp_ccode= checkCcode_info(ccode, cinfo);
    	HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ccode", temp_ccode);
		hashmap.put("ctype", ctype);
		hashmap.put("cinfo", cinfo);
        return categoryDAO.selectCategoryList_Count(hashmap);
    } 
    
    
    
    
    
    @Cacheable(value="CATEGORY", key="{ #ccode, #ctype, #cinfo }")
    public ArrayList<CategoryVO> selectCategoryList_open(String ccode, String ctype, String cinfo) throws Exception {
    	String temp_ccode= checkCcode_info(ccode, cinfo);
    	HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ccode", temp_ccode);
		hashmap.put("ctype", ctype);
		hashmap.put("cinfo", cinfo);
        return categoryDAO.selectCategoryList_open(hashmap);
    } 
    
    
    
	@Override
	public String getCateNm(String ccode, String ctype)throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ccode", ccode);
		hashmap.put("ctype", ctype);
	
		return categoryDAO.getCateNm(hashmap);
	}
	
	@Override
	public String getDeptCode(String cinfo, String ctype, String ctitle)throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("cinfo", cinfo);
		hashmap.put("ctype", ctype);
		hashmap.put("ctitle", ctitle);
	
		return categoryDAO.getDeptCode(hashmap);
	}
	
    @Override
	public String getCateNmAll(String ccode, String ctype) throws Exception {
		
		String return_value = "";
		if (ccode != null && ccode.length() > 11 )
		{ 
			
			if (ccode.substring(3,12).equals("000000000"))
			{ 
				return_value = this.getCateNm(ccode, ctype);

			} else if (ccode.substring(6,12).equals("000000"))
			{
				return_value = this.getCateNm(ccode.substring(0,3)+"000000000", ctype)
						+ " > "+this.getCateNm(ccode, ctype);
				 
			} else  if (ccode.substring(9,12).equals("000"))
			{
				return_value = this.getCateNm(ccode.substring(0,3)+"000000000", ctype)
						+ " > "+this.getCateNm(ccode.substring(0,6)+"000000", ctype)
						+ " > "+this.getCateNm(ccode, ctype);
				 
			} else {
				return_value = this.getCateNm(ccode.substring(0,3)+"000000000", ctype)
						+ " > "+this.getCateNm(ccode.substring(0,6)+"000000", ctype)
						+ " > "+this.getCateNm(ccode.substring(0,9)+"000", ctype)
						+ " > "+this.getCateNm(ccode, ctype);
				
			} 
		}
		
		
		return return_value;
	}
    
    /*
	 *  ccode 를 끈어 읽어서 like 쿼리에 적용하게 만듬
	 */
	public String checkCcode(String ccode){
		
		String temp_ccode = ccode;
		if (ccode != null && ccode.length() > 11 )
		{  
			if (ccode.substring(3,12).equals("000000000"))
			{
				temp_ccode = ccode.substring(0,3);
			} else if (ccode.substring(6,12).equals("000000"))
			{
				temp_ccode = ccode.substring(0,6);
			} else if (ccode.substring(9,12).equals("000"))
			{
				temp_ccode = ccode.substring(0,9);
			}
		}
		
		return temp_ccode;
		
	}
	
public String checkCcode_info(String ccode, String cinfo){
		
		String temp_ccode = ccode;
		if (ccode != null && ccode.length() > 11 )
		{  
			if (cinfo != null && cinfo.equals("B"))
			{
				temp_ccode = ccode.substring(0,3);
			} 
			if (cinfo != null && cinfo.equals("C"))
			{
				temp_ccode = ccode.substring(0,6);
			} 
			if (cinfo != null && cinfo.equals("D"))
			{
				temp_ccode = ccode.substring(0,9);
			}
		}
		
		return temp_ccode;
		
	}

@Override
@Cacheable(value="MENU", key="#cinfo")
public ArrayList<CategoryVO> selectCategoryList_Menu(String cinfo)
		throws Exception {
	
	HashMap<String, String> hashmap = new HashMap<String, String>();
	hashmap.put("cinfo", cinfo);
    return categoryDAO.selectCategoryList_Menu(hashmap);
}
 
public String getMenuNm(String ccode )throws Exception {
	HashMap<String, String> hashmap = new HashMap<String, String>();
	hashmap.put("ccode", ccode);
 
	return categoryDAO.getMenuNm(hashmap);
}

@Override
public String getMenuNmAll(String ccode ) throws Exception {
	
	String return_value = "";
	if (ccode != null && ccode.length() > 11 )
	{ 
		
		if (ccode.substring(3,12).equals("000000000"))
		{ 
			return_value = "<b>"+this.getMenuNm(ccode )+"</b>";

		} else if (ccode.substring(6,12).equals("000000"))
		{
			return_value = this.getMenuNm(ccode.substring(0,3)+"000000000" )
					+ " > <b>"+this.getMenuNm(ccode )+"</b>";
			 
		} else  if (ccode.substring(9,12).equals("000"))
		{
			return_value = this.getMenuNm(ccode.substring(0,3)+"000000000" )
					+ " > "+this.getMenuNm(ccode.substring(0,6)+"000000" )
					+ " > <b>"+this.getMenuNm(ccode )+"</b>";
			 
		} else {
			return_value = this.getMenuNm(ccode.substring(0,3)+"000000000" )
					+ " > "+this.getMenuNm(ccode.substring(0,6)+"000000" )
					+ " > "+this.getMenuNm(ccode.substring(0,9)+"000" )
					+ " > <b>"+this.getMenuNm(ccode )+"</b>"; 
		} 
	}
	
	
	return return_value;
}

@Override
public String getMenuCode(String selectCode, String type) throws Exception {
	HashMap<String, String> hashmap = new HashMap<String, String>();
	hashmap.put("selectCode", selectCode);
	hashmap.put("menuCode", type);
	return categoryDAO.getMenuCode(hashmap);
}
 
@Override
public String getMenuCode2(String selectCode, String menuCode, int boardId) throws Exception {
	HashMap<String, String> hashmap = new HashMap<String, String>();
	hashmap.put("selectCode", selectCode);
	hashmap.put("menuCode", menuCode);
	hashmap.put("boardId", boardId+"");
	return categoryDAO.getMenuCode2(hashmap);
}

@Override
public ArrayList<CategoryVO> selectCode_flag2(String flag2) throws Exception {
	HashMap<String, String> hashmap = new HashMap<String, String>();
	hashmap.put("flag2", flag2);
	return categoryDAO.selectCode_flag2(hashmap);
}

@Override
public String getCate_listNameAll(String selectCode, String type) throws Exception {

	String return_value = "";
	
	if (selectCode != null && selectCode.indexOf('/') > 0 ) {
		String[] xcodeArray = selectCode.split("/");
		for (String str : xcodeArray ) {
			return_value = return_value + this.getCateNm(str,type);
		}	
	} else {
		return_value = this.getCateNm(selectCode,type);
	} 
	
	return return_value;
}
 


}
