package com.withus.besttopsub.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 

import com.withus.besttopsub.dao.BestTopSubVO;
 
/**
 * @Class Name : BestTopSubMapper.java
 * @Description : BestTopSub DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-06
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("bestTopSubMapper")
public interface BestTopSubMapper  {

	/**
	 * best_top_sub을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BestTopSubVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String insertBestTopSub(BestTopSubVO vo);
    /**
	 * best_top_sub을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BestTopSubVO
	 * @return void형
	 * @exception Exception
	 */
    public void updateBestTopSub(BestTopSubVO vo);

    /**
	 * best_top_sub을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BestTopSubVO
	 * @return void형 
	 * @exception Exception
	 */
    public void deleteBestTopSub(String btiId);

    /**
	 * best_top_sub을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BestTopSubVO
	 * @return 조회한 best_top_sub
	 * @exception Exception
	 */
    public BestTopSubVO selectBestTopSub(BestTopSubVO vo);

    /**
	 * best_top_sub 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return best_top_sub 목록
	 * @exception Exception
	 */
    public ArrayList<BestTopSubVO> selectBestTopSubList(int btiId) ;

    /**
	 * best_top_sub 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return best_top_sub 총 갯수
	 * @exception
	 */
    public int selectBestTopSubListTotCnt();
    
	public int insertBestTopSub2(HashMap<String, Object> hashmap );

}
