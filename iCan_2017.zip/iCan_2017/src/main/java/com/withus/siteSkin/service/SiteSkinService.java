package com.withus.siteSkin.service;

import java.util.ArrayList;
import java.util.List;
 

import com.withus.siteSkin.dao.SiteSkinVO;

/**
 * @Class Name : SiteSkinService.java
 * @Description : SiteSkin Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150323
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface SiteSkinService {
	
	/**
	 * site_skin을 등록한다.
	 * @param vo - 등록할 정보가 담긴 SiteSkinVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    int insertSiteSkin(SiteSkinVO vo) throws Exception;
    
    /**
	 * site_skin을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SiteSkinVO
	 * @return void형
	 * @exception Exception
	 */
    int updateSiteSkin(SiteSkinVO vo) throws Exception;
    
    /**
	 * site_skin을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SiteSkinVO
	 * @return void형 
	 * @exception Exception
	 */
    int deleteSiteSkin(int seq) throws Exception;
    
    /**
	 * site_skin을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SiteSkinVO
	 * @return 조회한 site_skin
	 * @exception Exception
	 */
    SiteSkinVO selectSiteSkin(int seq) throws Exception;
    
    /**
	 * site_skin 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return site_skin 목록
	 * @exception Exception
	 */
    ArrayList selectSiteSkinList(int start, int end) throws Exception;
    
    /**
	 * site_skin 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return site_skin 총 갯수
	 * @exception
	 */
    int selectSiteSkinListTotCnt();

	int skinSave(String path, String color) throws Exception;
    
}
