package com.withus.processing.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository("processingMapper")
public interface ProcessingMapper {
	
	public int insertProcessing(ProcessingVO vo)throws Exception;
	
	public int updateProcessing(ProcessingVO vo)throws Exception;
	
	public int AppProcessing(ProcessingVO vo)throws Exception;

	public int deleteProcessing(int seq)throws Exception;
	
	public ProcessingVO getProcessing(int seq)throws Exception;
	
	public ArrayList<ProcessingVO> selectProcessingList(HashMap<String, String> hashmap) throws Exception;
	
	public int selectProcessingTotCnt(HashMap<String, String> hashmap)throws Exception ;

	public ArrayList<ProcessingVO> userProcessing( HashMap<String, String> hashmap)throws Exception ;
}
