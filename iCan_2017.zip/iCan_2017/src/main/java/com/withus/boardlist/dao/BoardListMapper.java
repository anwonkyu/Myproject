package com.withus.boardlist.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 










import com.withus.boardlist.dao.BoardListVO;
 
 
/**
 * @Class Name : BoardListDAO.java
 * @Description : BoardList DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("boardListMapper")
public interface BoardListMapper {

	/**
	 * board_list을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BoardListVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertBoardList(BoardListVO vo) throws Exception ;

    /**
	 * board_list을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BoardListVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateBoardList(BoardListVO vo) throws Exception ;

    /**
	 * board_list을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BoardListVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteBoardList(BoardListVO vo) throws Exception ;

    /**
	 * board_list을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BoardListVO
	 * @return 조회한 board_list
	 * @exception Exception
	 */
    public BoardListVO selectBoardList(int listId) throws Exception ;

    /**
	 * board_list 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return board_list 목록
	 * @exception Exception
	 */
    public ArrayList<BoardListVO> selectBoardListList(HashMap<String, String> hashmap) throws Exception;
    
    /**
	 * board_list 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return board_list 총 갯수
	 * @exception
	 */

    public BoardListVO selectCheckRow(HashMap<String, String> hashmap) throws Exception;

    public int selectBoardListListTotCnt(HashMap<String, String> hashmap) ;

	public ArrayList<BoardListVO> selectBoardListList_notice(Integer boardId) throws Exception;

	public void updateReadCount(Integer listId);

	public int deleteBoardListId(Integer boardId);

	public BoardListVO selectBoardListVodman(int listId);

	public ArrayList<BoardListVO> selectBoardListListVodman(
			HashMap<String, String> hashmap);

	public int selectBoardListListTotCntVodman(HashMap<String, String> hashmap);
    
	public int insertBoardListReply(BoardListVO vo) throws Exception ;

	public int update_ListStep(HashMap<String, String> hashmap);

	public BoardListVO getNextBoard(HashMap<String, String> hashmap);

	public BoardListVO getPrevBoard(HashMap<String, String> hashmap);

	public int pwdCheck(HashMap<String, String> hashmap);

	public int dupCheck(HashMap<String, String> hashmap);

	public ArrayList<BoardListVO> selectNotice_limit(
			HashMap<String, String> hashmap);

	public BoardListVO fileCheck(int listId); 
	
	 public int selectBoardListListTotCntAll(HashMap<String, String> hashmap) ;
	 public ArrayList<BoardListVO> selectBoardListListAll(HashMap<String, String> hashmap) throws Exception;

	public int selectInDept(HashMap<String, String> hashmap);
}
