package com.withus.userInfoLog;

import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
 
import org.springframework.web.bind.annotation.RequestMapping;
 

import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.userInfoLog.service.UserInfoLogService;
 
import com.withus.userInfoLog.dao.UserInfoLogVO;

/**
 * @Class Name : UserInfoLogController.java
 * @Description : UserInfoLog Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2015-01-19
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class UserInfoLogController {

    @Resource(name = "userInfoLogService")
    private UserInfoLogService userInfoLogService;
	
	@Autowired Properties prop;
	
	@Resource
	private PagingHelperService page;
    /**
	 * user_info_log 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 UserInfoLogDefaultVO
	 * @return "/userInfoLog/UserInfoLogList"
	 * @exception Exception
	 */
    @RequestMapping(value="/member/UserInfoLogList.do")
    public String selectUserInfoLogList(Integer curPage, String searchFild,String searchWord, Model model)
            throws Exception {
    	
    	if (curPage == null) curPage = 1;
		if (searchFild == null) searchFild = "";
		if (searchWord == null) searchWord = "";
 
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		
		int totalRecord = userInfoLogService.selectUserInfoLogListTotCnt(searchFild, searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
		
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord(); 
		
        List<UserInfoLogVO> userInfoLogList = userInfoLogService.selectUserInfoLogList(searchFild, searchWord,start, end);
        
    	Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		
		model.addAttribute("list",userInfoLogList); 
		
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
        
        return "/vodman/member/UserInfoLogList";
    } 
    
     
    @RequestMapping("/userInfoLog/deleteUserInfoLog.do")
    public String deleteUserInfoLog( String userid, Model model )
            throws Exception {
        userInfoLogService.deleteUserInfoLog(userid);
        //return "forward:/userInfoLog/UserInfoLogList.do";
        return "redirect:/vodman/member/UserInfoLogList.do";
    }

}
