package com.withus.memo;

import java.util.ArrayList;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
 
import com.withus.memo.service.ContentMemoService;
 
import com.withus.memo.dao.ContentMemoVO;

/**
 * @Class Name : ContentMemoController.java
 * @Description : ContentMemo Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class VodmanContentMemoController {
	
    @Autowired Properties prop;

    @Resource(name = "contentMemoService")
    private ContentMemoService contentMemoService;
     
    @Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;
    @Resource
	  private PagingHelperService page;
	
    /**
	 * content_memo 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 ContentMemoDefaultVO
	 * @return "/contentMemo/ContentMemoList"
	 * @exception Exception
	 */
    
    @RequestMapping(value="/memo/listAll.do")
    public String selectContentMemoList( String flag , Integer curPage,String searchFild,  String searchWord, Model model, String state)
            throws Exception {
    	 
    	if (flag == null) return null;
    	
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";

//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		int totalRecord = contentMemoService.selectContentMemoListTotCnt(
				 "",   searchFild,  searchWord, state );
		
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		Integer no = page.getListNo();
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		
        ArrayList<?> contentMemoList = contentMemoService.selectContentMemoList(
        		 "",  searchFild,  searchWord , state,  start,  end );
        model.addAttribute("resultList", contentMemoList);
        model.addAttribute("no", no);
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
        
        return "/vodman/memo/listAll";
    } 
    
    
    @RequestMapping(value="/memo/list.do")
    public String selectContentMemoList(String calnoteId, String flag , Integer curPage,String searchFild,  String searchWord, Model model,String state)
            throws Exception {
    	
    	if (calnoteId == null) calnoteId="";
    	if (flag == null) return null;
    	
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";

//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_5").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK_5").trim());
		
		int totalRecord = contentMemoService.selectContentMemoListTotCnt(
				 calnoteId,   searchFild,  searchWord, state );
		
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		
        ArrayList<?> contentMemoList = contentMemoService.selectContentMemoList(
        		 calnoteId,  searchFild,  searchWord , state,  start,  end );
        model.addAttribute("resultList", contentMemoList);
        
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
        
        return "/vodman/memo/list";
    } 
    
    @RequestMapping(value="/memo/write.do", method=RequestMethod.GET)
    public String addContentMemoView( Model model)
            throws Exception { 
        return "/vodman/memo/writeForm";
    }
    
    @RequestMapping(value="/memo/write.do", method=RequestMethod.POST)
    public View addContentMemo(
    		@ModelAttribute("contentMemoVO") ContentMemoVO contentMemoVO , Model model)
            throws Exception {
    	
	    	XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult();

		        if (contentMemoService.insertContentMemo(contentMemoVO) > 0) {
			        xml.setMessage("등록 되었습니다.");
			        xml.setError(false);
		        } else {
		        	 xml.setMessage("등록에 실패하였습니다.");
		 	         xml.setError(true);
		        } 
    	    model.addAttribute("xmlData", xml);
	        return xmlView;
    }
    
    @RequestMapping(value="/memo/update.do", method=RequestMethod.GET)
    public String updateContentMemoView(
            @RequestParam(value="muid",required=true) int muid ,
            int curPage , String serchFild, String serchWrod , Model model)
            throws Exception {
        ContentMemoVO contentMemoVO = contentMemoService.selectContentMemo(muid);
        
        model.addAttribute("contentMemoVO", contentMemoVO);
        model.addAttribute("serchFild", serchFild);
        model.addAttribute("serchWrod", serchWrod);
        model.addAttribute("curPage", curPage);
        return "/vodman/memo/writeForm";
    }
 

    @RequestMapping(value="/memo/update.do", method=RequestMethod.POST)
    public String updateContentMemo(
    		@ModelAttribute("contentMemoVO")  ContentMemoVO contentMemoVO,
    		int curPage , String serchFild, String serchWrod 
    		)
            throws Exception {
           contentMemoService.updateContentMemo(contentMemoVO);
        
        return "forward:/vodman/memo/list.do";
    }
    
    @RequestMapping("/memo/delete.do")
    public View deleteContentMemo(
    		  @ModelAttribute("contentMemoVO") ContentMemoVO contentMemoVO , Model model
    		  )
            throws Exception {
 
    	XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult();

	        if (contentMemoService.deleteContentMemo_vodman(contentMemoVO) > 0) {
		        xml.setMessage("삭제 되었습니다.");
		        xml.setError(false);
	        } else {
	        	xml.setMessage("삭제에 실패하였습니다.");
	 	        xml.setError(true);
	        } 
	    model.addAttribute("xmlData", xml);
        return xmlView;
    }

}
 