package com.withus.secured.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 





import com.withus.secured.dao.SecuredResourcesVO;
 
/**
 * @Class Name : SecuredResourcesDAO.java
 * @Description : SecuredResources DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("securedResourcesMapper")
public interface SecuredResourcesMapper  {

	/**
	 * secured_resources을 등록한다.
	 * @param vo - 등록할 정보가 담긴 SecuredResourcesVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertSecuredResources(SecuredResourcesVO vo) throws Exception;

    /**
	 * secured_resources을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SecuredResourcesVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateSecuredResources(SecuredResourcesVO vo) throws Exception ;

    /**
	 * secured_resources을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SecuredResourcesVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteSecuredResources(String resourceId) throws Exception ;

    /**
	 * secured_resources을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SecuredResourcesVO
	 * @return 조회한 secured_resources
	 * @exception Exception
	 */
    public SecuredResourcesVO selectSecuredResources(String resourceId) throws Exception ;

    /**
	 * secured_resources 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return secured_resources 목록
	 * @exception Exception
	 */
    public ArrayList<SecuredResourcesVO> selectSecuredResourcesList() throws Exception ;

    /**
	 * secured_resources 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return secured_resources 총 갯수
	 * @exception
	 */
    public int selectSecuredResourcesListTotCnt() ;

	public int deleteSecuredResourcesAuthority(int seq);

	public int insertSecuredAuthority(HashMap<String, Object> hashmap );

	public ArrayList<SecuredResourcesVO> selectSecuredResourcesAuthorityList(
			String resourceId);
	
}
