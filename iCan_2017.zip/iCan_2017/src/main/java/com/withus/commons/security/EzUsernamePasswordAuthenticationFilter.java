package com.withus.commons.security;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

public class EzUsernamePasswordAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
	private static Logger log = LoggerFactory.getLogger(EzUsernamePasswordAuthenticationFilter.class);

	public static String IS_CUSTOM_PARAMETER_KEY = "*****is_custom_parameterMap*****";

	private ObjectMapper objectMapper = null;
	public EzUsernamePasswordAuthenticationFilter() {
		objectMapper = new ObjectMapper();
	}


	@Override
    protected String obtainUsername(HttpServletRequest request) {
		 
 
        String jsonUsername = "";
		try {
 
			if (request.getParameter("ssoId") != null && request.getParameter("ssoId").length() > 0 ) {
				System.out.println("ssoId : "+request.getParameter("ssoId"));
				jsonUsername = request.getParameter("ssoId");
			}
		} catch (Exception e) {
			throw new RuntimeException("JSON Style username 처리 실패", e);
		}
		 
        return jsonUsername;
    }
}
