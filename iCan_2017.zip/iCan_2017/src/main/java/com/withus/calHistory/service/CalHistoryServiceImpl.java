package com.withus.calHistory.service;

import java.util.ArrayList;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.withus.calHistory.dao.CalHistoryMapper;
import com.withus.calHistory.dao.CalHistoryVO;
import com.withus.member.dao.MemberVo;
import com.withus.memo.service.ContentMemoServiceImpl;

@Service("calHistoryService")
public class CalHistoryServiceImpl implements CalHistoryService{
	
	 private static final Logger LOGGER = LoggerFactory.getLogger(ContentMemoServiceImpl.class);
	 
	 @Resource(name="calHistoryMapper")
	 private CalHistoryMapper calHistoryDAO;
	 
	@Override
	public int insertCalHistory(CalHistoryVO vo) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		if(principal != null && principal instanceof MemberVo){ 
			vo.setUserId(((MemberVo)principal).getUsername() );
		} else{
        	 return -1;
        }
		return calHistoryDAO.insertCalHistory(vo);
	}

	@Override
	public ArrayList<CalHistoryVO> selectCalHistoryList(String calnoteId, String ctype, String searchFild, String searchWord,int start,int end) throws Exception {
		Integer startRownum = start;
		Integer endRownum = end;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		hashmap.put("ctype", ctype);
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		
		return calHistoryDAO.selectCalHistoryList(hashmap);
	}

	@Override
	public int selectCalHistoryListTotCnt(String calnoteId, String state, String searchFild, String searchWord) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		hashmap.put("state", state);
		hashmap.put("srarchFild", searchFild);
		hashmap.put("searchWord", searchWord);
	 
		return calHistoryDAO.selectCalHistoryListTotCnt(hashmap);
	}

	@Override
	public ArrayList<?> selectCalHistoryListAll(String calnoteId, String ctype)
			throws Exception {
	 
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		hashmap.put("ctype", ctype);
		return calHistoryDAO.selectCalHistoryListAll(hashmap);
	}

}
