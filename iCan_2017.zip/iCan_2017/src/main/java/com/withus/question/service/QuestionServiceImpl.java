package com.withus.question.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.MultiValueMap;

import com.withus.group.dao.GroupsMapper;
import com.withus.group.service.GroupsServiceImpl;
import com.withus.question.dao.QuestionMapper;
import com.withus.question.dao.QuestionVO;

@Service("questionService")
public class QuestionServiceImpl implements QuestionService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(QuestionServiceImpl.class);
	
	@Resource(name="questionMapper")
    private QuestionMapper questionDAO;

	@Override
	public int insertQuestionMember(MultiValueMap<String, String> params)
			throws Exception { 
		HashMap<String, String> param = null;
		ArrayList<Object> mArrayList;
		mArrayList = new ArrayList<Object>();

		for (int i = 0; i < params.get("chkValue").size(); i++) {
			param = new HashMap<String, String>();
			
		param.put("dcode",params.get("dcode").toString().substring(1, 13));
			/*param.put("dcode",params.get("dcode").toString());*/
			param.put("memberId", params.get("chkValue").get(i).toString()); 
			mArrayList.add(param);  
 		}  
			HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
			hashmap.put("list", mArrayList);
			
			return questionDAO.insertQuestionMember(hashmap);
	        
	}

	@Override
	public ArrayList<QuestionVO> questionAllList() throws Exception {
		
		return questionDAO.questionAllList();
	}

	@Override
	public int deleteQuestion(String id, String dcode) throws Exception {
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		hashmap.put("id",id);
		hashmap.put("dcode",dcode);
		
		return questionDAO.deleteQuestion(hashmap);
	}



}
