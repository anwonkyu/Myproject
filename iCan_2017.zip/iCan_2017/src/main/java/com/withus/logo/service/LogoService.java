package com.withus.logo.service;

import java.util.List;
 
import com.withus.logo.dao.LogoVO;

/**
 * @Class Name : LogoService.java
 * @Description : Logo Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-12-31
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface LogoService {
	
 
    
    /**
	 * logo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 LogoVO
	 * @return void형
	 * @exception Exception
	 */
    int updateLogo(LogoVO vo) throws Exception;
    int updateSkin(String path, String color, String newLimit, String boardLimit) throws Exception;
  
    /**
	 * logo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 LogoVO
	 * @return 조회한 logo
	 * @exception Exception
	 */
    LogoVO selectLogo() throws Exception;
    
    
}
