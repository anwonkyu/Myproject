package com.withus.aop.service;

import java.util.HashMap;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.withus.aop.dao.AopMapper;

@Service
public class AopServiceImpl implements AopService {
	
	@Resource(name="aopMapper")
	public AopMapper aopMapper; 
	@Override
	public void pageCnnCnt(String flag)  {
		
		System.out.println("==============aopServiceImpl==========");

		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("flag", flag);
		 
		aopMapper.pageCnnCnt(hashmap);
	}

	
}
