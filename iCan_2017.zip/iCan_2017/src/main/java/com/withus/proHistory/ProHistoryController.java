package com.withus.proHistory;

import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.web.servlet.View;

import com.withus.commons.paging.PagingHelperService;
import com.withus.processing.service.ProcessingService;

public class ProHistoryController {
@Autowired Properties prop;
	
	@Autowired ProcessingService processingService;
	
    @Resource
	private PagingHelperService page;
	 
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;
	  
	@Resource(name = "xmlView")
	private View xmlView;
	
	

}
