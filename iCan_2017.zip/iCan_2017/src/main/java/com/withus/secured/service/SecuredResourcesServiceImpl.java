package com.withus.secured.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 






import com.withus.secured.service.SecuredResourcesService;
 
import com.withus.secured.dao.SecuredResourcesVO;
import com.withus.secured.dao.SecuredResourcesMapper;

/**
 * @Class Name : SecuredResourcesServiceImpl.java
 * @Description : SecuredResources Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("securedResourcesService")
public class SecuredResourcesServiceImpl implements
        SecuredResourcesService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(SecuredResourcesServiceImpl.class);

    @Resource(name="securedResourcesMapper")
    private SecuredResourcesMapper securedResourcesDAO;
    
    /** ID Generation */
    //@Resource(name="{egovSecuredResourcesIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * secured_resources을 등록한다.
	 * @param vo - 등록할 정보가 담긴 SecuredResourcesVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertSecuredResources(SecuredResourcesVO vo) throws Exception {
    	return securedResourcesDAO.insertSecuredResources(vo);
    	 
    }

    /**
	 * secured_resources을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SecuredResourcesVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateSecuredResources(SecuredResourcesVO vo) throws Exception {
      return  securedResourcesDAO.updateSecuredResources(vo);
    }

    /**
	 * secured_resources을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SecuredResourcesVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteSecuredResources(String resourceId) throws Exception {
        return securedResourcesDAO.deleteSecuredResources(resourceId);
    }

    /**
	 * secured_resources을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SecuredResourcesVO
	 * @return 조회한 secured_resources
	 * @exception Exception
	 */
    public SecuredResourcesVO selectSecuredResources(String resourceId) throws Exception {
        SecuredResourcesVO resultVO = securedResourcesDAO.selectSecuredResources(resourceId);
      
        return resultVO;
    }

    /**
	 * secured_resources 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return secured_resources 목록
	 * @exception Exception
	 */
    public ArrayList<SecuredResourcesVO> selectSecuredResourcesList() throws Exception {
        return securedResourcesDAO.selectSecuredResourcesList();
    }

    /**
	 * secured_resources 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return secured_resources 총 갯수
	 * @exception
	 */
    public int selectSecuredResourcesListTotCnt( ) {
		return securedResourcesDAO.selectSecuredResourcesListTotCnt();
	}

	@Override
	public int deleteSecuredResourcesAuthority(int seq) {
		return securedResourcesDAO.deleteSecuredResourcesAuthority(seq);
	}
	
	
	@Override
	public int insertSecuredAuthority(MultiValueMap<String, String> params)
			throws Exception { 
 
		HashMap<String, String> param = null;
		ArrayList<Object> mArrayList;
		mArrayList = new ArrayList<Object>();
	
		String resourceId = params.get("resourceId").get(0).toString();
 	
		for (int i = 0; i < params.get("chkValue").size(); i++) {
			param = new HashMap<String, String>();
			param.put("authority", params.get("chkValue").get(i).toString()); 
			param.put("resourceId", resourceId);
			mArrayList.add(param);  
 		}  
			
			HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
			hashmap.put("list", mArrayList);  
 
			return securedResourcesDAO.insertSecuredAuthority(hashmap);
	        
	}

	@Override
	public ArrayList<SecuredResourcesVO> selectSecuredResourcesAuthorityList(
			String resourceId) {
		return securedResourcesDAO.selectSecuredResourcesAuthorityList(resourceId);
	}
    
}
