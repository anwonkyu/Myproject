package com.withus.member.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityCoreVersion;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.Assert;

public class MemberVo implements UserDetails {

	private static final long serialVersionUID = 1L;

	/** code */
	private Integer code;

	/** id */
	private String id;

	/** pwd */
	private String userpassword;

	/** name */
	private String name;

	/** email */
	private String email;

	/** sex */
	private String sex;

	/** tel */
	private String tel;

	/** hp */
	private String hp;

	/** zip */
	private String zip;

	/** address1 */
	private String address1;

	/** address2 */
	private String address2;

	/** level */
	private Integer levels = 1;

	/** office_name */
	private String officeName;

	/** use_mailling */
	private String useMailling;

	/** login_count */
	private Integer loginCount;

	/** join_date */
	private String joinDate;

	/** auth_key */
	private String authKey;

	/** approval */
	private String approval;

	/** pwd_ask_num */
	private Integer pwdAskNum;

	/** pwd_answer */
	private String pwdAnswer;

	/** member_group */
	private String memberGroup;

	/** buseo */
	private String buseo;

	/** gray */
	private String gray;

	/** del_flag */
	private String delFlag;

	/** ssn */
	private String ssn;

	/** leave_date */
	private String leaveDate;

	/** lastlogin_date */
	private String lastloginDate;

	/** passchange_date */
	private String passchangeDate;

	private String dept;

	private Set<GrantedAuthority> authorities; // 계정이 가지고 있는 권한 목록

	private String ipost;
	
	private String dept_cd_;
	

	public String getDept_cd_() {
		return dept_cd_;
	}

	public void setDept_cd_(String dept_cd_) {
		this.dept_cd_ = dept_cd_;
	}

	public MemberVo() {
		super();
	}

	// spring-security 로그인 정보
	// security-context.xml 에 추가 (로그인 쿼리문) customJdbcDaoImpl
	// CustomJdbcDaoImpl.java 파일에 추가 loadUsersByUsername

	public MemberVo(String id, String password, String name, Integer level, String buseo, String gray,
			String memberGroup, Collection<? extends GrantedAuthority> authorities) {
		this.id = id;
		this.userpassword = password;
		this.name = name;
		this.levels = level;
		this.buseo = buseo;
		this.gray = gray;
		this.memberGroup = memberGroup;
		this.authorities = Collections.unmodifiableSet(sortAuthorities(authorities));
	}

	public String getDept() {
		return dept;
	}

	public void setDept(String dept) {
		this.dept = dept;
	}

	public String getIpost() {
		return ipost;
	}

	public void setIpost(String ipost) {
		this.ipost = ipost;
	}

	public Integer getCode() {
		return this.code;
	}

	public void setCode(Integer code) {
		this.code = code;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getUserpassword() {
		return this.userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return this.email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public String getTel() {
		return this.tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getHp() {
		return this.hp;
	}

	public void setHp(String hp) {
		this.hp = hp;
	}

	public String getZip() {
		return this.zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	public String getAddress1() {
		return this.address1;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public String getAddress2() {
		return this.address2;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public Integer getLevels() {
		return levels;
	}

	public void setLevels(Integer levels) {
		this.levels = levels;
	}

	public String getOfficeName() {
		return this.officeName;
	}

	public void setOfficeName(String officeName) {
		this.officeName = officeName;
	}

	public String getUseMailling() {
		return this.useMailling;
	}

	public void setUseMailling(String useMailling) {
		this.useMailling = useMailling;
	}

	public Integer getLoginCount() {
		return this.loginCount;
	}

	public void setLoginCount(Integer loginCount) {
		this.loginCount = loginCount;
	}

	public String getJoinDate() {
		return this.joinDate;
	}

	public void setJoinDate(String joinDate) {
		this.joinDate = joinDate;
	}

	public String getAuthKey() {
		return this.authKey;
	}

	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}

	public String getApproval() {
		return this.approval;
	}

	public void setApproval(String approval) {
		this.approval = approval;
	}

	public Integer getPwdAskNum() {
		return this.pwdAskNum;
	}

	public void setPwdAskNum(Integer pwdAskNum) {
		this.pwdAskNum = pwdAskNum;
	}

	public String getPwdAnswer() {
		return this.pwdAnswer;
	}

	public void setPwdAnswer(String pwdAnswer) {
		this.pwdAnswer = pwdAnswer;
	}

	public String getMemberGroup() {
		return this.memberGroup;
	}

	public void setMemberGroup(String memberGroup) {
		this.memberGroup = memberGroup;
	}

	public String getBuseo() {
		return this.buseo;
	}

	public void setBuseo(String buseo) {
		this.buseo = buseo;
	}

	public String getGray() {
		return this.gray;
	}

	public void setGray(String gray) {
		this.gray = gray;
	}

	public String getDelFlag() {
		return this.delFlag;
	}

	public void setDelFlag(String delFlag) {
		this.delFlag = delFlag;
	}

	public String getSsn() {
		return this.ssn;
	}

	public void setSsn(String ssn) {
		this.ssn = ssn;
	}

	public String getLeaveDate() {
		return this.leaveDate;
	}

	public void setLeaveDate(String leaveDate) {
		this.leaveDate = leaveDate;
	}

	public String getLastloginDate() {
		return this.lastloginDate;
	}

	public void setLastloginDate(String lastloginDate) {
		this.lastloginDate = lastloginDate;
	}

	public String getPasschangeDate() {
		return this.passchangeDate;
	}

	public void setPasschangeDate(String passchangeDate) {
		this.passchangeDate = passchangeDate;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// TODO Auto-generated method stub
		return authorities;
	}

	public void setAuthorities(Collection<? extends GrantedAuthority> authorities) {
		this.authorities = Collections.unmodifiableSet(sortAuthorities(authorities));
	}

	@Override
	public String getPassword() {
		// TODO Auto-generated method stub
		return getUserpassword();
	}

	@Override
	public String getUsername() {
		// TODO Auto-generated method stub
		return getId();
	}

	@Override
	public boolean isAccountNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isAccountNonLocked() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isCredentialsNonExpired() {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean isEnabled() {
		// TODO Auto-generated method stub
		return true;
	}

	private static SortedSet<GrantedAuthority> sortAuthorities(Collection<? extends GrantedAuthority> authorities) {
		Assert.notNull(authorities, "Cannot pass a null GrantedAuthority collection");
		// Ensure array iteration order is predictable (as per
		// UserDetails.getAuthorities() contract and SEC-717)
		SortedSet<GrantedAuthority> sortedAuthorities = new TreeSet<GrantedAuthority>(new AuthorityComparator());

		for (GrantedAuthority grantedAuthority : authorities) {
			Assert.notNull(grantedAuthority, "GrantedAuthority list cannot contain any null elements");
			sortedAuthorities.add(grantedAuthority);
		}

		return sortedAuthorities;
	}

	private static class AuthorityComparator implements Comparator<GrantedAuthority>, Serializable {
		private static final long serialVersionUID = SpringSecurityCoreVersion.SERIAL_VERSION_UID;

		public int compare(GrantedAuthority g1, GrantedAuthority g2) {
			// Neither should ever be null as each entry is checked before
			// adding it to the set.
			// If the authority is null, it is a custom authority and should
			// precede others.
			if (g2.getAuthority() == null) {
				return -1;
			}

			if (g1.getAuthority() == null) {
				return 1;
			}

			return g1.getAuthority().compareTo(g2.getAuthority());
		}
	}

}
