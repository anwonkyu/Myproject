package com.withus.module.ftp;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.text.*;
import java.sql.*;
public class ReadText {

	public static void main(String arg[]) throws IOException {
		System.out.println("시작");
		try {
			String strTodayDate = "";// 오늘일자
			Calendar calInfo = Calendar.getInstance();
			// calInfo.add(cal.DATE, -1 );
			SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMdd");
			strTodayDate = formatter.format(calInfo.getTime());

			FtpDownloadFile fdf = new FtpDownloadFile();
			fdf.connect();
			fdf.login();
			fdf.list();
			fdf.get("C:\ftpTest" + strTodayDate + ".txt", "","Update_Data.txt");
			fdf.logout();
		} catch (Exception e) {
			System.out.println("--------------------------------------------------------------------------------");
			System.out.println("파일 다운로드 실패 : " + e);
			System.out.println("--------------------------------------------------------------------------------");
			return;
		}

	}
}
