package com.withus.calHistory;

import java.util.ArrayList;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.calHistory.dao.CalHistoryVO;
import com.withus.calHistory.service.CalHistoryService;
 
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.service.CalnoteService;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;

@Controller
@RequestMapping("/calHistory")
public class CalHistoryController {
	
	 @Autowired Properties prop;
	 
	 @Resource(name = "calHistoryService")
	 private CalHistoryService calHistoryService;
	 
	 @Resource(name = "xstreamMarshaller")
	 private XStreamMarshaller xstreamMarshaller;
	 
	 @Autowired 
	 private CalnoteService calnoteService;

	 @Resource(name = "xmlView")
	 private View xmlView;
	 
	  @Resource
	  private PagingHelperService page;
	  
	 
	  
	  @RequestMapping(value="/write.do", method=RequestMethod.GET)
	    public String addContentMemoView( Model model)
	            throws Exception { 
	        return "/calHistory/writeForm";
	    }
	  
	  @RequestMapping(value="/write.do", method=RequestMethod.POST)
	    public View addContentMemo(
	    		@ModelAttribute("calHistoryVo") CalHistoryVO calHistortVo , Model model)
	            throws Exception { 
	    	
		    	XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult();

			        if (calHistoryService.insertCalHistory(calHistortVo) > 0) {
				        xml.setMessage("등록 되었습니다.");
				        xml.setError(false);
			        } else {
			        	 xml.setMessage("등록에 실패하였습니다.");
			 	         xml.setError(true);
			        } 
	    	    model.addAttribute("xmlData", xml);
		        return xmlView;
	    }
	  

}
