package com.withus.commons.seed;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import com.withus.member.dao.MemberVo;
import com.withus.memo.dao.ContentMemoVO;

public class WithusSeed {

	public static MemberVo returnSeedDe(MemberVo memberVo){
 
		memberVo.setName(SEEDUtil.getDecrypt(memberVo.getName()));
		memberVo.setEmail(SEEDUtil.getDecrypt(memberVo.getEmail()));
		memberVo.setTel(SEEDUtil.getDecrypt(memberVo.getTel()));
		memberVo.setHp(SEEDUtil.getDecrypt(memberVo.getHp()));
		memberVo.setZip(SEEDUtil.getDecrypt(memberVo.getZip()));
		memberVo.setAddress1(SEEDUtil.getDecrypt(memberVo.getAddress1()));
		memberVo.setAddress2(SEEDUtil.getDecrypt(memberVo.getAddress2()));
		memberVo.setPwdAnswer(SEEDUtil.getDecrypt(memberVo.getPwdAnswer()));
		memberVo.setBuseo(SEEDUtil.getDecrypt(memberVo.getBuseo())); 
		return memberVo;
		
	}
	
	public static MemberVo returnSeedEn(MemberVo memberVo){
		 
		memberVo.setName(SEEDUtil.getEncrypt(memberVo.getName()));
		memberVo.setEmail(SEEDUtil.getEncrypt(memberVo.getEmail()));
		memberVo.setTel(SEEDUtil.getEncrypt(memberVo.getTel()));
		memberVo.setHp(SEEDUtil.getEncrypt(memberVo.getHp()));
		memberVo.setZip(SEEDUtil.getEncrypt(memberVo.getZip()));
		memberVo.setAddress1(SEEDUtil.getEncrypt(memberVo.getAddress1()));
		memberVo.setAddress2(SEEDUtil.getEncrypt(memberVo.getAddress2()));
		memberVo.setPwdAnswer(SEEDUtil.getEncrypt(memberVo.getPwdAnswer()));
		memberVo.setBuseo(SEEDUtil.getEncrypt(memberVo.getBuseo())); 
		return memberVo;
		
	}
	
	
	public static ArrayList<MemberVo> returnSeedList(ArrayList<MemberVo> list){
 
	 MemberVo memberlist = null;
		//for (MemberVo memberlist : list){
		for (int i = 0; i < list.size() ; i++) {
			
				memberlist = list.get(i);
		  
		    	memberlist.setName(SEEDUtil.getDecrypt(memberlist.getName()));
		    	memberlist.setEmail(SEEDUtil.getDecrypt(memberlist.getEmail()));
		    	memberlist.setTel(SEEDUtil.getDecrypt(memberlist.getTel()));
		    	memberlist.setHp(SEEDUtil.getDecrypt(memberlist.getHp()));
		    	memberlist.setZip(SEEDUtil.getDecrypt(memberlist.getZip()));
		    	memberlist.setAddress1(SEEDUtil.getDecrypt(memberlist.getAddress1()));
		    	memberlist.setAddress2(SEEDUtil.getDecrypt(memberlist.getAddress2()));
		    	memberlist.setPwdAnswer(SEEDUtil.getDecrypt(memberlist.getPwdAnswer()));
		    	memberlist.setBuseo(SEEDUtil.getDecrypt(memberlist.getBuseo()));  
		 
		    list.set(i, memberlist); 
			
		}
 
		
		return list;
		
	}
	
	public static ArrayList<ContentMemoVO> returnSeedListMemo(ArrayList<ContentMemoVO> list){
		 
		ContentMemoVO memolist = null;
			for (int i = 0; i < list.size() ; i++) {
				
				memolist = list.get(i);
			  
				memolist.setWname(com.withus.commons.seed.SEEDUtil.getDecrypt(memolist.getWname()));
			     
			    list.set(i, memolist); 
				
			}
	  
			return list;
			
		}
	
	
	public static String returnSeedDeStr(String str){
		 
		
		if (str != null && str.length() > 0) {
			
			return SEEDUtil.getDecrypt(str);
		} else {
			return null;
		}
	 
	}
	
	public static String returnSeedEnStr(String str){
		 
		
		if (str != null && str.length() > 0) {
			
			return SEEDUtil.getEncrypt(str);
		} else {
			return null;
		}
	 
	}
	
}
