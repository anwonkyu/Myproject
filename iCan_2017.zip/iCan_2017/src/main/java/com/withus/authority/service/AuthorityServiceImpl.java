package com.withus.authority.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.withus.authority.service.AuthorityService;
import com.withus.authority.dao.AuthorityVO;
import com.withus.authority.dao.AuthorityMapper;

/**
 * @Class Name : AuthorityServiceImpl.java
 * @Description : Authority Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("authorityService")
public class AuthorityServiceImpl  implements
        AuthorityService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(AuthorityServiceImpl.class);

    @Resource(name="authorityMapper")
    private AuthorityMapper authorityDAO;
    
    /** ID Generation */
    //@Resource(name="{egovAuthorityIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * authority을 등록한다.
	 * @param vo - 등록할 정보가 담긴 AuthorityVO
	 * @return int
	 * @exception Exception
	 */
    public int insertAuthority(AuthorityVO vo) throws Exception {
    	 
    	return authorityDAO.insertAuthority(vo);
     
    }

    /**
	 * authority을 수정한다.
	 * @param vo - 수정할 정보가 담긴 AuthorityVO
	 * @return int형
	 * @exception Exception
	 */
    public int updateAuthority(AuthorityVO vo) throws Exception {
       return authorityDAO.updateAuthority(vo);
    }

    /**
	 * authority을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 AuthorityVO
	 * @return int형 
	 * @exception Exception
	 */
    public int deleteAuthority(String authority) throws Exception {
       return authorityDAO.deleteAuthority(authority);
    }

    /**
	 * authority을 조회한다.
	 * @param vo - 조회할 정보가 담긴 AuthorityVO
	 * @return 조회한 authority
	 * @exception Exception
	 */
    public AuthorityVO selectAuthority(String authority) throws Exception {
        AuthorityVO resultVO = authorityDAO.selectAuthority(authority);
        
        return resultVO;
    }

    /**
	 * authority 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return authority 목록
	 * @exception Exception
	 */
    public ArrayList<AuthorityVO> selectAuthorityList() throws Exception {
        return authorityDAO.selectAuthorityList();
    }

    /**
	 * authority 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return authority 총 갯수
	 * @exception
	 */
    public int selectAuthorityListTotCnt() {
		return authorityDAO.selectAuthorityListTotCnt();
	}

 
    
}
