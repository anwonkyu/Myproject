package com.withus.boardHistory.dao;

public class BoardHistoryVO {
	private Integer seq;
	private Integer listId;
	private String title;
	private String state;
	private String regDate;
	private String userId;
	private String ip;
	private String name;
	private Integer boardId;
	
	
	public Integer getBoardId() {
		return boardId;
	}
	public void setBoardId(Integer boardId) {
		this.boardId = boardId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getIp() {
		return ip;
	}
	public void setIp(String ip) {
		this.ip = ip;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public Integer getSeq() {
		return seq;
	}
	public void setSeq(Integer seq) {
		this.seq = seq;
	}
	
	public Integer getListId() {
		return listId;
	}
	public void setListId(Integer listId) {
		this.listId = listId;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	@Override
	public String toString() {
		return "BoardHistoryVO [seq=" + seq + ", listId=" + listId + ", title="
				+ title + ", state=" + state + ", regDate=" + regDate
				+ ", userId=" + userId + ", ip=" + ip + ", name=" + name
				+ ", boardId=" + boardId + "]";
	}
	
	
}
