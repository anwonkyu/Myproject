package com.withus.vodLog.dao;

/**
 * @Class Name : VodLogVO.java
 * @Description : VodLog VO class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 20150303
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public class CounterVO {
    private static final long serialVersionUID = 1L;
    
    private String gubunCode;
    
    private String countYField;       
    private String countMField;       
    private String countWField;       
    private String countDField;       
    private String counter;               
    private String countFlag;         
    private String gubunCtn;
    
    private Integer cyear = 0;
    private Integer cmonth = 0;
    private Integer cday = 0;
    private String ctitle;
    private String ccode;
    
    
    
    
	public String getCcode() {
		return ccode;
	}
	public void setCcode(String ccode) {
		this.ccode = ccode;
	}
	public String getCtitle() {
		return ctitle;
	}
	public void setCtitle(String ctitle) {
		this.ctitle = ctitle;
	}
	public Integer getCyear() {
		return cyear;
	}
 
	
	
	public Integer getCmonth() {
		return cmonth;
	}
	public void setCmonth(Integer cmonth) {
		this.cmonth = cmonth;
	}
	public Integer getCday() {
		return cday;
	}
	public void setCday(Integer cday) {
		this.cday = cday;
	}
	public void setCyear(Integer cyear) {
		this.cyear = cyear;
	}
	public String getGubunCode() {
		return gubunCode;
	}
	public void setGubunCode(String gubunCode) {
		this.gubunCode = gubunCode;
	}
	public String getCountYField() {
		return countYField;
	}
	public void setCountYField(String countYField) {
		this.countYField = countYField;
	}
	public String getCountMField() {
		return countMField;
	}
	public void setCountMField(String countMField) {
		this.countMField = countMField;
	}
	public String getCountWField() {
		return countWField;
	}
	public void setCountWField(String countWField) {
		this.countWField = countWField;
	}
	public String getCountDField() {
		return countDField;
	}
	public void setCountDField(String countDField) {
		this.countDField = countDField;
	}
	public String getCounter() {
		return counter;
	}
	public void setCounter(String counter) {
		this.counter = counter;
	}
	public String getCountFlag() {
		return countFlag;
	}
	public void setCountFlag(String countFlag) {
		this.countFlag = countFlag;
	}
	public String getGubunCtn() {
		return gubunCtn;
	}
	public void setGubunCtn(String gubunCtn) {
		this.gubunCtn = gubunCtn;
	}  

    
    
}
