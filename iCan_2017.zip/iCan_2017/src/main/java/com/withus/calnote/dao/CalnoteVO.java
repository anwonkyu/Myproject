package com.withus.calnote.dao;

public class CalnoteVO {
	private String calnoteId;
	private String docId;
	private String docName;
	private String unitNum;
	private Integer chngCoreCycleNum;
	private String state;
	private String bodyPageNum;
	private String totalPageNum;
	private String regDate;
	private String modDate;
	private String appDate;
	private String bizCd;
	private String userId;
	private String calCatCd;
	private String docTypeCd;
	private String autoGenFlag;
	private String plantCd;
	private String deptCd;
	private String edmsDocId;
	private String revision;
	private String deleteFlag;
	private String deleteReason;
	private String jfile;
	private String field;
	private String independent;
	private String reviewer;
	private String approver;
	private String datepicker;
	private String noteFlag;
	private String stat;
	private String biz_cd_;
	private String plant_cd_;
	private String field_;
	private String dept_cd_;
	private String name;
	private String cal_cat_cd_;
	private String sortField;
	private String sortOrder;
	private String designVerification;
	private String independentDate;
	private String reviewerDate;
	private String approverDate;
	private Integer realTotalPage;
	private String orderName;
	
	private String owner;
	
	private String hAppDate; 
	
	
 
	public String gethAppDate() {
		return hAppDate;
	}
	public void sethAppDate(String hAppDate) {
		this.hAppDate = hAppDate;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getOrderName() {
		return orderName;
	}
	public void setOrderName(String orderName) {
		this.orderName = orderName;
	}
	public Integer getRealTotalPage() {
		return realTotalPage;
	}
	public void setRealTotalPage(Integer realTotalPage) {
		this.realTotalPage = realTotalPage;
	}
	public String getIndependentDate() {
		return independentDate;
	}
	public void setIndependentDate(String independentDate) {
		this.independentDate = independentDate;
	}
	public String getReviewerDate() {
		return reviewerDate;
	}
	public void setReviewerDate(String reviewerDate) {
		this.reviewerDate = reviewerDate;
	}
	public String getApproverDate() {
		return approverDate;
	}
	public void setApproverDate(String approverDate) {
		this.approverDate = approverDate;
	}
	public String getDesignVerification() {
		return designVerification;
	}
	public void setDesignVerification(String designVerification) {
		this.designVerification = designVerification;
	}
	public String getSortField() {
		return sortField;
	}
	public void setSortField(String sortField) {
		this.sortField = sortField;
	}
	public String getSortOrder() {
		return sortOrder;
	}
	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}
	public String getCal_cat_cd_() {
		return cal_cat_cd_;
	}
	public void setCal_cat_cd_(String cal_cat_cd_) {
		this.cal_cat_cd_ = cal_cat_cd_;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDept_cd_() {
		return dept_cd_;
	}
	public void setDept_cd_(String dept_cd_) {
		this.dept_cd_ = dept_cd_;
	}
	public String getNoteFlag() {
		return noteFlag;
	}
	public void setNoteFlag(String noteFlag) {
		this.noteFlag = noteFlag;
	}
	public String getBiz_cd_() {
		return biz_cd_;
	}
	public void setBiz_cd_(String biz_cd_) {
		this.biz_cd_ = biz_cd_;
	}
	public String getPlant_cd_() {
		return plant_cd_;
	}
	public void setPlant_cd_(String plant_cd_) {
		this.plant_cd_ = plant_cd_;
	}
	public String getField_() {
		return field_;
	}
	public void setField_(String field_) {
		this.field_ = field_;
	}
	public String getStat() {
		return stat;
	}
	public void setStat(String stat) {
		this.stat = stat;
	}
	public String getDatepicker() {
		return datepicker;
	}
	public void setDatepicker(String datepicker) {
		this.datepicker = datepicker;
	}
	public String getReviewer() {
		return reviewer;
	}
	public void setReviewer(String reviewer) {
		this.reviewer = reviewer;
	}
	public String getApprover() {
		return approver;
	}
	public void setApprover(String approver) {
		this.approver = approver;
	}
	public String getIndependent() {
		return independent;
	}
	public void setIndependent(String independent) {
		this.independent = independent;
	}
	public String getField() {
		return field;
	}
	public void setField(String field) {
		this.field = field;
	}
	public String getJfile() {
		return jfile;
	}
	public void setJfile(String jfile) {
		this.jfile = jfile;
	}
	public String getCalnoteId() {
		return calnoteId;
	}
	public void setCalnoteId(String calnoteId) {
		this.calnoteId = calnoteId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocName() {
		return docName;
	}
	public void setDocName(String docName) {
		this.docName = docName;
	}
	public String getUnitNum() {
		return unitNum;
	}
	public void setUnitNum(String unitNum) {
		this.unitNum = unitNum;
	}
	public Integer getChngCoreCycleNum() {
		return chngCoreCycleNum;
	}
	public void setChngCoreCycleNum(Integer chngCoreCycleNum) {
		this.chngCoreCycleNum = chngCoreCycleNum;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public String getBodyPageNum() {
		return bodyPageNum;
	}
	public void setBodyPageNum(String bodyPageNum) {
		this.bodyPageNum = bodyPageNum;
	}
	public String getTotalPageNum() {
		return totalPageNum;
	}
	public void setTotalPageNum(String totalPageNum) {
		this.totalPageNum = totalPageNum;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getModDate() {
		return modDate;
	}
	public void setModDate(String modDate) {
		this.modDate = modDate;
	}
	public String getAppDate() {
		return appDate;
	}
	public void setAppDate(String appDate) {
		this.appDate = appDate;
	}
	public String getBizCd() {
		return bizCd;
	}
	public void setBizCd(String bizCd) {
		this.bizCd = bizCd;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getCalCatCd() {
		return calCatCd;
	}
	public void setCalCatCd(String calCatCd) {
		this.calCatCd = calCatCd;
	}
	public String getDocTypeCd() {
		return docTypeCd;
	}
	public void setDocTypeCd(String docTypeCd) {
		this.docTypeCd = docTypeCd;
	}
	public String getAutoGenFlag() {
		return autoGenFlag;
	}
	public void setAutoGenFlag(String autoGenFlag) {
		this.autoGenFlag = autoGenFlag;
	}
	public String getPlantCd() {
		return plantCd;
	}
	public void setPlantCd(String plantCd) {
		this.plantCd = plantCd;
	}
	public String getDeptCd() {
		return deptCd;
	}
	public void setDeptCd(String deptCd) {
		this.deptCd = deptCd;
	}
	public String getEdmsDocId() {
		return edmsDocId;
	}
	public void setEdmsDocId(String edmsDocId) {
		this.edmsDocId = edmsDocId;
	}
	public String getRevision() {
		return revision;
	}
	public void setRevision(String revision) {
		this.revision = revision;
	}
	public String getDeleteFlag() {
		return deleteFlag;
	}
	public void setDeleteFlag(String deleteFlag) {
		this.deleteFlag = deleteFlag;
	}
	public String getDeleteReason() {
		return deleteReason;
	}
	public void setDeleteReason(String deleteReason) {
		this.deleteReason = deleteReason;
	}
	@Override
	public String toString() {
		return "CalnoteVO [calnoteId=" + calnoteId + ", docId=" + docId
				+ ", docName=" + docName + ", unitNum=" + unitNum
				+ ", chngCoreCycleNum=" + chngCoreCycleNum + ", state=" + state
				+ ", bodyPageNum=" + bodyPageNum + ", totalPageNum="
				+ totalPageNum + ", regDate=" + regDate + ", modDate="
				+ modDate + ", appDate=" + appDate + ", bizCd=" + bizCd
				+ ", userId=" + userId + ", calCatCd=" + calCatCd
				+ ", docTypeCd=" + docTypeCd + ", autoGenFlag=" + autoGenFlag
				+ ", plantCd=" + plantCd + ", deptCd=" + deptCd
				+ ", edmsDocId=" + edmsDocId + ", revision=" + revision
				+ ", deleteFlag=" + deleteFlag + ", deleteReason="
				+ deleteReason + ", jfile=" + jfile + ", field=" + field
				+ ", independent=" + independent + ", reviewer=" + reviewer
				+ ", approver=" + approver + ", datepicker=" + datepicker
				+ ", noteFlag=" + noteFlag + ", stat=" + stat + ", biz_cd_="
				+ biz_cd_ + ", plant_cd_=" + plant_cd_ + ", field_=" + field_
				+ ", dept_cd_=" + dept_cd_ + "]";
	}
 
	
	
	
}
