package com.withus.department.service;

import java.util.ArrayList;

import com.withus.department.dao.DepartmentVO;


public interface DepartmentService {
 void insertDepartment(DepartmentVO departmentVo) throws Exception;
	 
	 ArrayList<DepartmentVO> selectDepartmentList(String searchWord, int start, int end) throws Exception;
	 
	 int selectDepartmentListTotCnt(String searchWord)throws Exception;
	 
	 int deleteDepartment(String deptCd)throws Exception;
	 
	 int updateDepartment(DepartmentVO departmentVo)throws Exception;
	 
	 public DepartmentVO getDepartment(String deptCd)throws Exception;
}
