package com.withus.commons;


import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

public class XSSFilter implements Filter {

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {

	}

	@Override
	public void destroy() {

	}
	
	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain)

	throws IOException, ServletException {
        System.out.println("doFilter");
		chain.doFilter(new XSSRequestWrapper((HttpServletRequest) request),
				response);

	}

	
//		Public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
//		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
//		if(isFileUploadRequest(httpServletRequest)) {
//			System.out.println("mult_part");
//			chain.doFilter(new XSSMultipartRequestWrapper(httpServletRequest), response);
//		} else {
//			System.out.println("do_filter");
//			chain.doFilter(new XSSRequestWrapper(httpServletRequest), response);
//		}
//	}
//	  
//	
//	private boolean isFileUploadRequest(HttpServletRequest request){
//		return request.getMethod().equalsIgnoreCase("POST") && request.getContentType().startsWith("multipart/form-data");
//	}
	
}