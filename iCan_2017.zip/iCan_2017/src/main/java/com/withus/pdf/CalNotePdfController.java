package com.withus.pdf;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.ext.jfile.JProperties;
import com.ext.jfile.service.JFile;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Element;
import com.itextpdf.text.Image;
import com.lowagie.text.Cell;
import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;
import com.lowagie.text.pdf.draw.LineSeparator;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.member.dao.MemberVo;

public class CalNotePdfController extends AbstractPdfView {
	 @Override
	    public void buildPdfDocument(Map<String, Object> map,
	            Document document, PdfWriter writer, HttpServletRequest request,
	            HttpServletResponse response ) throws Exception {
    	String explanation ="본 서류는 한전원자력연료㈜가 통제 또는 소유하고 있는 지적소유정보를 포함하고 있으므로, "
    			          + "본 서류의 제공은 제공 받는 자가 그 기밀을 유지할 것에 동의한 것으로 간주됩니다. "
    			          + "사전 서면 승인을 받지 않고 본 자료의 내용 전체 또는 그 일부를 무단 사용하거나 공개하는 것은 물론 무단 복제나 그것을 제 3자에게 전파하는 것은 금지되어 있습니다."
    			          + "This document is the property of and contains Proprietary Information owned or controlled by KEPCO Nuclear Fuel Co., LTD. "
    			          + "It is transmitted to you in confidence and trust, and you agree to treat it in strict confidence. Re-production of this document and/or transmittal thereof to third parties, "
    			          + "as well as utilization or disclosure of the contents thereof, in whole or in part, is not permitted unless express authorization is given in writing. ";
    	CalnoteVO vo = (CalnoteVO) map.get("calnoteVo");
    	MemberVo independentVo = (MemberVo) map.get("independentVo");
    	MemberVo reviewerVo = (MemberVo) map.get("reviewerVo");
    	MemberVo approverVo = (MemberVo) map.get("approverVo");
    	JFile downloadFile = (JFile) map.get("downloadFile");
    	String dFilePath = downloadFile.toString();
    	
    	String docId = vo.getDocId();
    	String revision = vo.getRevision();
    	String plantCd = vo.getPlant_cd_();
    	String unitNum = vo.getUnitNum();
    	SimpleDateFormat formatter = new SimpleDateFormat ( "yy-MM-dd", Locale.KOREA );
    	Date currentTime = new Date ( );
    	String dTime = formatter.format ( currentTime );
    	String savePath = JProperties.getString("system.calnote");
    	FileOutputStream fos = new FileOutputStream(new File(savePath, vo.getCalnoteId()+".pdf"));
    	writer = PdfWriter.getInstance(document, fos);
    	
    	document.open();
    	
    	 BaseFont bfKorean = BaseFont.createFont("c:/windows/fonts/MALGUN.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
    	 Chunk linebreak = new Chunk(new LineSeparator());
    	 Font font22 = new Font(bfKorean, 22);
         Font font12 = new Font(bfKorean, 12);
         Font font10 = new Font(bfKorean, 10);
         Font font8 = new Font(bfKorean, 8); 
         
         formatter = new SimpleDateFormat ( "yyyy", Locale.KOREA );
         dTime = formatter.format ( currentTime );
        /* Paragraph title2 = new Paragraph("Calculation Note",font22);*/
         Paragraph title = new Paragraph("Calculation Note", FontFactory.getFont(FontFactory.HELVETICA, 22, Font.BOLD)); /*Font.bold*/
        
         /*Chunk chunk = new Chunk("This text is underlined", FontFactory.getFont(FontFactory.HELVETICA, 22, Font.UNDERLINE));*/
         //중간정렬
        /* title2.setAlignment(Element.ALIGN_CENTER);*/
         title.setAlignment(Element.ALIGN_CENTER);
         /*title2.setAlignment(HSSFCellStyle.ALIGN_CENTER);*/
         //문서에 추가
         /*document.add(title2);*/
         document.add(title);
         document.add(linebreak);
         Paragraph enter = new Paragraph(" ",font12);
         document.add(enter);
         
         com.itextpdf.text.pdf.PdfReader reader = new com.itextpdf.text.pdf.PdfReader(dFilePath);
         int pagenumber = reader.getNumberOfPages();
         int pageNumber = 0;
         for(int i = 1; i<= pagenumber; i++) {
             /*String text = PdfTextExtractor.getTextFromPage(reader,i);*/
             pageNumber = i;
         }
         int totalPage = pageNumber+4;
         
        
        
         Paragraph pagePara = new Paragraph("Total Page : "+totalPage+"             ",font12);
         pagePara.setAlignment(Element.ALIGN_RIGHT);
         document.add(pagePara);
         
         document.add(enter);
         document.add(enter);
         Paragraph knfFont = new Paragraph("           KNF Class                                    :  ",font12);
         knfFont.setAlignment(Element.ALIGN_LEFT);
         document.add(knfFont);
         
         Paragraph docIdFont = new Paragraph("           Calcualtion Note Number                :  "+docId+" Rev."+revision,font12);
         document.add(docIdFont);
         
         Paragraph plantNameFont = new Paragraph("           Plant Name                                  :  "+plantCd+"  unit  "+unitNum,font12);
         document.add(plantNameFont);
         document.add(enter);
         document.add(enter);
         Paragraph docName = new Paragraph(vo.getDocName(),font12);
         Table table1 = new Table(4, 2);
         Cell cellTitle = new Cell(new Paragraph(vo.getDocName(),new Font(bfKorean, 12 /*, Font.BOLD*/)));
         cellTitle.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellTitle.setColspan(3);
         table1.addCell("TITLE");
         table1.addCell(cellTitle);
         table1.setPadding(3);
         document.add(table1);
         document.add(enter);
         
         
         Paragraph independent = new Paragraph(independentVo.getName(),font12);
         Paragraph reviewer = new Paragraph(reviewerVo.getName(),font12);
         Paragraph approver = new Paragraph(approverVo.getName(),font12);
         Table table2 = new Table(4, 5);
         
         Cell cellMan = new Cell(new Paragraph("MANAGER",new Font(bfKorean, 10, Font.BOLD)));
         cellMan.setHeader(true);
         cellMan.setBorderWidthTop(0.6f);  //제일 위에 테두리
         cellMan.setHorizontalAlignment(Element.ALIGN_CENTER);
         cellMan.setColspan(4);
         table2.addCell(cellMan);
         table2.setAlignment(Element.ALIGN_CENTER);
         table2.addCell("Independent Reviwer");
         table2.addCell(independent);
         table2.addCell("Electrically signed");
         table2.addCell("2017/04/25");
         
         table2.addCell("Reviwer");
         table2.addCell(reviewer);
         table2.addCell("Electrically signed");
         table2.addCell("2017/04/25");
         
         table2.addCell("Aprrover");
         table2.addCell(approver);
         table2.addCell("Electrically signed");
         table2.addCell("2017/04/25");
         table2.setPadding(5);
         document.add(table2);
         document.add(enter);
         Paragraph explan = new Paragraph(explanation,font8);
         Table table3 = new Table(1, 2);
         table3.addCell(explan);
         table3.setPadding(3);
         document.add(table3);
         
         Paragraph Endtitle = new Paragraph("           KEPCO NUCLEAR FUEL CO., LTD          Technology & Engineering Division ",font12);
         Paragraph Endtitle2 = new Paragraph("             QAP-03-03-01a                                                                                  Cover Page ",font10);
         document.add(enter);
         document.add(enter);
         document.add(enter);
         
         
         document.add(linebreak);
         document.add(Endtitle);
         document.add(Endtitle2);
         
         /*Phrase p = new Phrase("this is a footer");*/
         
    	document.close();
    	
    }
	 
	 
	 
	 
	 
	 
public static void  buildPdfDocument2(Map<String, Object> map ) throws Exception {
	Document document = new Document();
	PdfWriter writer = null;
 	String explanation ="본 서류는 한전원자력연료㈜가 통제 또는 소유하고 있는 지적소유정보를 포함하고 있으므로, "
 			          + "본 서류의 제공은 제공 받는 자가 그 기밀을 유지할 것에 동의한 것으로 간주됩니다. "
 			          + "사전 서면 승인을 받지 않고 본 자료의 내용 전체 또는 그 일부를 무단 사용하거나 공개하는 것은 물론 무단 복제나 그것을 제 3자에게 전파하는 것은 금지되어 있습니다."
 			          + "This document is the property of and contains Proprietary Information owned or controlled by KEPCO Nuclear Fuel Co., LTD. "
 			          + "It is transmitted to you in confidence and trust, and you agree to treat it in strict confidence. Re-production of this document and/or transmittal thereof to third parties, "
 			          + "as well as utilization or disclosure of the contents thereof, in whole or in part, is not permitted unless express authorization is given in writing. ";
 	CalnoteVO vo = (CalnoteVO) map.get("calnoteVo");
 	MemberVo independentVo = (MemberVo) map.get("independentVo");
 	MemberVo reviewerVo = (MemberVo) map.get("reviewerVo");
 	MemberVo approverVo = (MemberVo) map.get("approverVo");
 	String totalPageNum = (String) map.get("totalPageNum");
 	
 	String docId = vo.getDocId();
 	String revision = vo.getRevision();
 	String plantCd = vo.getPlant_cd_();
 	String unitNum = vo.getUnitNum();
 	SimpleDateFormat formatter = new SimpleDateFormat ( "yy-MM-dd", Locale.KOREA );
 	Date currentTime = new Date ( );
 	String dTime = formatter.format ( currentTime );
 	String savePath = JProperties.getString("system.calnote");
 	FileOutputStream fos = new FileOutputStream(new File(savePath, vo.getCalnoteId()+".pdf"));
 	writer = PdfWriter.getInstance(document, fos);
 	
 	document.open();
 	
 	 BaseFont bfKorean = BaseFont.createFont("c:/windows/fonts/MALGUN.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
 	 Chunk linebreak = new Chunk(new LineSeparator());
 	 Font font22 = new Font(bfKorean, 22);
      Font font12 = new Font(bfKorean, 12);
      Font font10 = new Font(bfKorean, 10);
      Font font8 = new Font(bfKorean, 8); 
      
      formatter = new SimpleDateFormat ( "yyyy", Locale.KOREA );
      dTime = formatter.format ( currentTime );
     /* Paragraph title2 = new Paragraph("Calculation Note",font22);*/
      Paragraph title = new Paragraph("Calculation Note", FontFactory.getFont(FontFactory.HELVETICA, 22, Font.BOLD)); /*Font.bold*/
     
      /*Chunk chunk = new Chunk("This text is underlined", FontFactory.getFont(FontFactory.HELVETICA, 22, Font.UNDERLINE));*/
      //중간정렬
     /* title2.setAlignment(Element.ALIGN_CENTER);*/
      title.setAlignment(Element.ALIGN_CENTER);
      /*title2.setAlignment(HSSFCellStyle.ALIGN_CENTER);*/
      //문서에 추가
      /*document.add(title2);*/
      document.add(title);
      document.add(linebreak);
      Paragraph enter = new Paragraph(" ",font12);
      document.add(enter);
      
      /*com.itextpdf.text.pdf.PdfReader reader = new com.itextpdf.text.pdf.PdfReader(dFilePath);
      int pagenumber = reader.getNumberOfPages();
      int pageNumber = 0;
      for(int i = 1; i<= pagenumber; i++) {
          String text = PdfTextExtractor.getTextFromPage(reader,i);
          pageNumber = i;
      }
      int totalPage = pageNumber+4;*/
      
     
     
      Paragraph pagePara = new Paragraph("Total Page : "+totalPageNum+"             ",font12);
      pagePara.setAlignment(Element.ALIGN_RIGHT);
      document.add(pagePara);
      
      document.add(enter);
      document.add(enter);
      Paragraph knfFont = new Paragraph("           KNF Class                                    :  ",font12);
      knfFont.setAlignment(Element.ALIGN_LEFT);
      document.add(knfFont);
      
      Paragraph docIdFont = new Paragraph("           Calcualtion Note Number                :  "+docId+" Rev."+revision,font12);
      document.add(docIdFont);
      
      Paragraph plantNameFont = new Paragraph("           Plant Name                                  :  "+plantCd+"  unit  "+unitNum,font12);
      document.add(plantNameFont);
      document.add(enter);
      document.add(enter);
      Paragraph docName = new Paragraph(vo.getDocName(),font12);
      Table table1 = new Table(5, 2);
      Cell cellTitle = new Cell(new Paragraph(vo.getDocName(),new Font(bfKorean, 12 /*, Font.BOLD*/)));
      cellTitle.setHorizontalAlignment(Element.ALIGN_CENTER);
      cellTitle.setColspan(4);
      table1.addCell("TITLE");
      table1.addCell(cellTitle);
      table1.setPadding(3);
      document.add(table1);
      document.add(enter);
      
      
      Paragraph independent = new Paragraph(independentVo.getName(),font12);
      Paragraph reviewer = new Paragraph(reviewerVo.getName(),font12);
      Paragraph approver = new Paragraph(approverVo.getName(),font12);
      Table table2 = new Table(4, 5);
      
      Cell cellMan = new Cell(new Paragraph("MANAGER",new Font(bfKorean, 10, Font.BOLD)));
      cellMan.setHeader(true);
      cellMan.setBorderWidthTop(0.6f);  //제일 위에 테두리
      cellMan.setHorizontalAlignment(Element.ALIGN_CENTER);
      cellMan.setColspan(4);
      table2.addCell(cellMan);
      table2.setAlignment(Element.ALIGN_CENTER);
      table2.addCell("Independent Reviwer");
      table2.addCell(independent);
      table2.addCell("Electrically signed");
      table2.addCell("2017/04/25");
      
      table2.addCell("Reviwer");
      table2.addCell(reviewer);
      table2.addCell("Electrically signed");
      table2.addCell("2017/04/25");
      
      table2.addCell("Aprrover");
      table2.addCell(approver);
      table2.addCell("Electrically signed");
      table2.addCell("2017/04/25");
      table2.setPadding(5);
      document.add(table2);
      document.add(enter);
      Paragraph explan = new Paragraph(explanation,font8);
      Table table3 = new Table(1, 2);
      table3.addCell(explan);
      table3.setPadding(3);
      document.add(table3);
      
      Paragraph Endtitle = new Paragraph("           KEPCO NUCLEAR FUEL CO., LTD          Technology & Engineering Division ",font12);
      Paragraph Endtitle2 = new Paragraph("             QAP-03-03-01a                                                                                  Cover Page ",font10);
      document.add(enter);
      document.add(enter);
      document.add(enter);
      
      
      document.add(linebreak);
      document.add(Endtitle);
      document.add(Endtitle2);
      
      /*Phrase p = new Phrase("this is a footer");*/
      
 	document.close();
 	
 }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
}
