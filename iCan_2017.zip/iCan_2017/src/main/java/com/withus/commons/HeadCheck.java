package com.withus.commons;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

public class HeadCheck {

	public static String user_agent(){
		HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		String userAgent = req.getHeader("user-agent").toLowerCase();
		
//		String apple[] = {"iphone", "ipop", "ipad"};
//		String android = "android";
//		
//		String app = "";
//		
//		for(int i=0; i<apple.length; i++){
//			if(StringUtils.indexOf(userAgent, apple[i]) > 0){
//				app = "apple";
//				break;
//			}else if(StringUtils.indexOf(userAgent, android) > 0){
//				app = "android";
//			}else{
//				app = "web";
//			}
//		}
		
		String browser[] = {"iphone", "ipod", "ipad", "android", "windows phone", "chrome/", "safari/", "navigator/", "firefox/", "opera/", "msie" };
	 
		String app = "";
		
		for(int i=0; i<browser.length; i++){
			if(StringUtils.indexOf(userAgent, browser[i]) > 0){
				app = browser[i];
				break;
			}else{
				app = "etc";
			}
		}
		
		if (app != null && app.equals("msie")) {  
			if(StringUtils.indexOf(userAgent, "trident") > 0){  // IE 11 
				app = "trident"; 
			} else if(StringUtils.indexOf(userAgent, "edge/") > 0){  // Microsoft Edge  
				app = "edge"; 
			} else {
				app = "msie";
			}
		}
		
		 return app;
	}
}
