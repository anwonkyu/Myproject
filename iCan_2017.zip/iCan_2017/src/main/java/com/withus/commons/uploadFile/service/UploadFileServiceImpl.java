package com.withus.commons.uploadFile.service;

import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.withus.commons.uploadFile.dao.UploadFileMapper;


@Service
public class UploadFileServiceImpl implements UploadFileService {

	@Resource(name="uploadFileMapper")
	private UploadFileMapper uploadFileMapper;
	 
	
	@Override
	public int insertAttachFile(UploadFileVo attachFile) {
		return uploadFileMapper.insertAttachFile(attachFile);
		
	}

	@Override
	public int insertAttachFile2(UploadFileVo attachFile) {
		return uploadFileMapper.insertAttachFile2(attachFile);
		
	}

	
	@Override
	public List<UploadFileVo> getUploadFileList(String ocode, String flag) {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ocode", ocode);
		hashmap.put("flag", flag);
		
		return uploadFileMapper.getUploadFileList(hashmap);
	}

	@Override
	public UploadFileVo getUploadFile(int seq) {
		 
		return uploadFileMapper.getUploadFile(seq);
	}

	@Override
	public int deleteFile(int seq) throws Exception {
		return uploadFileMapper.deleteAttachFile(seq);

	}
	
	public int deleteFileAll(String ocode , String flag) throws Exception {
		
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ocode", ocode);
		hashmap.put("flag", flag);
		return uploadFileMapper.deleteAttachFileAll(hashmap);

	}

	public void deleteSelect(List<String> attachDel) throws Exception {
		
		HashMap<String, Object> hashmap = new HashMap<String, Object>();
		 
		hashmap.put("list", attachDel); 
		
		uploadFileMapper.deleteSelect(hashmap);
	}

	@Override
	public List<UploadFileVo> getUploadFileListType(String ocode, String flag, String type) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ocode", ocode);
		hashmap.put("flag", flag);
		hashmap.put("type", type);
		
		return uploadFileMapper.getUploadFileListType(hashmap);
	}

	@Override
	public List<UploadFileVo> getUploadFileListReAll(String ocode, String flag)
			throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("ocode", ocode);
		hashmap.put("flag", flag);
		
		return uploadFileMapper.getUploadFileListReAll(hashmap);
	}

}
