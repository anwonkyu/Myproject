package com.withus.pdf;
 
import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.ext.jfile.service.JFileDetails;
import com.itextpdf.text.Element;
import com.lowagie.text.Cell;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.Table;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfWriter;
import com.withus.tr.dao.TrVO;
 
public class TrPdfController extends AbstractPdfView {
 
    @Override
    public void buildPdfDocument(Map<String, Object> map,
            Document document, PdfWriter writer, HttpServletRequest request,
            HttpServletResponse response ) throws Exception {
        //파일뒤에 날짜를 입력하기위해 포맷함.
    	TrVO vo = (TrVO) map.get("trVo");
    	SimpleDateFormat formatter = new SimpleDateFormat ( "yy-MM-dd", Locale.KOREA );
    	Date currentTime = new Date ( );
    	String dTime = formatter.format ( currentTime );
    	
    	//pdf가 저장될 경로 
		String savePath = "D:/icanPDF/tr";
		//지정된 경로에 document와 파일경로를 저장시킨다.
		FileOutputStream fos = new FileOutputStream(new File(savePath, vo.getTrId()+".pdf"));
		writer = PdfWriter.getInstance(document, fos);
		
		
		//document를 연다.
		document.open();
		//table생성 및 폰트, 패딩 설정
		/*List<RA_DSUSEVO> list = (List<RA_DSUSEVO>) map.get("getRA_DSUSEList");//받아온 데이터
		List<RA_DSUSEVO> list2 = (List<RA_DSUSEVO>) map.get("getPDF_AMOUNT_NAMEList");*/
		
       /*Table table = new Table(6, list.size() + 1);*/
		/*Table table = new Table(2, 2);
        table.setPadding(5);*/
		
		String loginUser = (String) map.get("loginUser");
        BaseFont bfKorean = BaseFont.createFont("c:/windows/fonts/MALGUN.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        Font font = new Font(bfKorean, 10);
       
        formatter = new SimpleDateFormat ( "yyyy", Locale.KOREA );
        dTime = formatter.format ( currentTime );
        Paragraph title = new Paragraph("TR Report",font);
        //중간정렬ㅅ
        title.setAlignment(Element.ALIGN_LEFT);
        //문서에 추가
        document.add(title);
        Paragraph docName = new Paragraph(vo.getDocName(),font);
        Paragraph dept = new Paragraph(vo.getDept_cd_(),font);
        
        Table table1 = new Table(2, 2);
        table1.addCell("title");
        table1.addCell(docName);
        table1.setPadding(3);
        document.add(table1);
        
        Table table2 = new Table(4, 2);
        table2.addCell("Dept");
        table2.addCell(dept);
        table2.addCell("Doc.No.");
        table2.addCell(vo.getDocId());
        table2.setPadding(3);
        document.add(table2);
        
        Table table3 = new Table(6, 2);
        table3.addCell("Year");
        table3.addCell(String.valueOf(vo.getYear()));
        table3.addCell("number");
        table3.addCell(String.valueOf(vo.getBodyPageNum()));
        table3.addCell("Last Number");
        table3.addCell(String.valueOf(vo.getTotalPageNum()));
        table3.setPadding(3);
        document.add(table3);
        
        
        
        @SuppressWarnings("unchecked")
		List<JFileDetails> list = (List<JFileDetails>) map.get("jfileVo");
        if(list != null){
        Paragraph file = new Paragraph("Body File",font);
        file.setAlignment(Element.ALIGN_LEFT);
        document.add(file);	
        Table table4 = new Table(4,list.size()+1);
        table4.setPadding(3);
        
        for(JFileDetails jfile : list){
        table4.addCell("fileName");
        table4.addCell(new Paragraph(jfile.getFileName(), font));
        table4.addCell("size");
        table4.addCell(new Paragraph(jfile.getFileSize()/1000+"kb", font));
        }
        document.add(table4);
        }
        
        
        
        
        Paragraph approval = new Paragraph("Approval Info.",font);
        //중간정렬
        approval.setAlignment(Element.ALIGN_LEFT);
        document.add(approval);
        Table table5 = new Table(6, 2);
        table5.addCell("Co-writer");
        table5.addCell(vo.getCowriter());
        table5.addCell("Reviewer");
        table5.addCell(vo.getReviewer());
        table5.addCell("Approver");
        table5.addCell(vo.getApprover());
        table5.setPadding(3);
        document.add(table5);
        
        Table table6 = new Table(2, 2);
        table6.addCell("Hope Approve Date");
        table6.addCell(vo.getAppDate());
        table6.setPadding(3);
        document.add(table6);
        /* 
        Cell cell = new Cell(new Paragraph("(" + dTime + ") 년도 폐기물 판매 보고서",new Font(bfKorean, 20, Font.BOLD)));
        cell.setHeader(true);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setColspan(6);
        cell.setBorderWidthTop(0.6f);
        table.addCell(cell);
        cell = new Cell(new Paragraph("(판매자 / 구매자 용 )", new Font(bfKorean, 14, Font.UNDERLINE)));
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBorderWidthTop(0f);
        cell.setColspan(6);
        table.addCell(cell);
        /*
        formatter = new SimpleDateFormat ( "yyyy년 MM월 dd일", Locale.KOREA );
        dTime = formatter.format ( currentTime );
        cell = new Cell(new Paragraph("문서작성일 : "+dTime ,font));
        cell.setColspan(6);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setBorderWidthTop(0f);
        table.addCell(cell);
        
        formatter = new SimpleDateFormat ( "yyMMdd", Locale.KOREA );
        dTime = formatter.format ( currentTime );
        cell = new Cell(new Paragraph("문 서 번 호 : CWPS-"+dTime ,font));
        cell.setBorderWidthTop(0f);
        cell.setColspan(3);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        table.addCell(cell);
        cell = new Cell(new Paragraph("작 성 자 : "+loginUser ,font));
        cell.setColspan(3);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setBorderWidthTop(0f);
        table.addCell(cell);
        
        cell = new Cell(new Paragraph("발 신 지 : 대정광역시 중구 대흥동 500 영민빌딩 2층 203호 / 대표자:김용경" ,font));
        cell.setColspan(6);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setBorderWidthTop(0f);
        table.addCell(cell);
        
        String result = (String) map.get("result");
        cell = new Cell(new Paragraph("수신자 : "+result ,font));
        cell.setColspan(6);
        cell.setHorizontalAlignment(Element.ALIGN_LEFT);
        cell.setBorderWidthTop(0f);
        table.addCell(cell);
        
        table.endHeaders();
        
        cell = new Cell(new Paragraph("거래처\n담당자 ", font));
        table.addCell(cell);
        cell = new Cell(new Paragraph("판매\n물품명", font));
        table.addCell(cell);
        cell = new Cell(new Paragraph("판매금액", font));
        table.addCell(cell);
        cell = new Cell(new Paragraph("판매일자 ", font));
        table.addCell(cell);
        cell = new Cell(new Paragraph("결제 구분", font));
        table.addCell(cell);
        cell = new Cell(new Paragraph("대금정산구분", font));
        table.addCell(cell);
       

        
        for (RA_DSUSEVO sub : list) {
        	table.addCell(new Paragraph(sub.getRprsntv_nm(), font));
        	table.addCell(new Paragraph(sub.getRa_name(), font));
        	DecimalFormat df = new DecimalFormat("#,##0원");
        	table.addCell(new Paragraph(df.format(sub.getSle_amount()), font));
        	String sle_de = new SimpleDateFormat("yyyy-MM-dd").format(sub.getSle_de());
        	table.addCell(new Paragraph(sle_de, font));
        	table.addCell(new Paragraph(sub.getBox(), font));
        	table.addCell(new Paragraph(sub.getPric_cal_se(), font));
        }
        
        cell = new Cell(new Paragraph("총금액 결산",font));
        cell.setColspan(6);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBorderWidthTop(0f);
        table.addCell(cell);
        
        for(RA_DSUSEVO plus : list2){
        	cell = new Cell(new Paragraph("거래처 담당자 : "+plus.getRprsntv_nm(),font));
        	cell.setColspan(3);
        	cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        	table.addCell(cell);
        	DecimalFormat df = new DecimalFormat("#,##0원");
        	cell = new Cell(new Paragraph(" 총금액 : "+df.format(plus.getSle_amount()),font));
        	cell.setColspan(3);
        	cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        	table.addCell(cell);
        }
        cell = new Cell(new Paragraph(" 대금 청구일자를 확인 하여주세요",font));
        cell.setColspan(6);
        cell.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell.setBorderWidthTop(0f);
        table.addCell(cell);
        cell = new Cell(new Paragraph(" (기업은행) 123-45678-789 , (00은행) 789-456-12-456 \n 대표자: 김용경 tel: 010-7899-1234",font));
        cell.setColspan(6);
        cell.setHorizontalAlignment(Element.ALIGN_RIGHT);
        cell.setBorderWidthTop(0f);
        table.addCell(cell);
        */
        

        formatter = new SimpleDateFormat ( "yy년 MM월 dd일", Locale.KOREA );
        dTime = formatter.format ( currentTime );
        Paragraph Endtitle = new Paragraph("ⓒ 2017 KEPCO NF. All rights reserved. "+dTime,font);
        Paragraph Endtitle2 = new Paragraph("ⓒ대전광역시 유성구 대덕대로 989번길 242(덕진동) TEL: 042-868-1000 / FAX : 042-808-1219. ",font);
        Endtitle.setAlignment(Element.ALIGN_CENTER);
        Endtitle2.setAlignment(Element.ALIGN_CENTER);
        document.add(Endtitle);
        document.add(Endtitle2);
        document.close();
    }

     
    public static void buildPdfDocument2(Map<String, Object> map ) throws Exception {
    	Document document = new Document();
    	PdfWriter writer = null;
    	TrVO vo = (TrVO) map.get("trVo");
        //파일뒤에 날짜를 입력하기위해 포맷함.
    	SimpleDateFormat formatter = new SimpleDateFormat ( "yy-MM-dd", Locale.KOREA );
    	Date currentTime = new Date ( );
    	String dTime = formatter.format ( currentTime );
    	//pdf가 저장될 경로
    	String savePath = "D:/icanPDF/tr";
		//지정된 경로에 document와 파일경로를 저장시킨다.
		FileOutputStream fos = new FileOutputStream(new File(savePath, vo.getTrId()+".pdf"));
		writer = PdfWriter.getInstance(document, fos);
		//document를 연다.
		document.open();
		
        BaseFont bfKorean = BaseFont.createFont("c:/windows/fonts/MALGUN.TTF", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
        Font font = new Font(bfKorean, 10);
       
        formatter = new SimpleDateFormat ( "yyyy", Locale.KOREA );
        dTime = formatter.format ( currentTime );
        Paragraph title = new Paragraph("TR Report",font);
        //중간정렬
        title.setAlignment(Element.ALIGN_LEFT);
        //문서에 추가
        document.add(title);
        Paragraph docName = new Paragraph(vo.getDocName(),font);
        Paragraph dept = new Paragraph(vo.getDept_cd_(),font);
        Table table1 = new Table(2, 2);
        table1.addCell("title");
        table1.addCell(docName);
        table1.setPadding(3);
        document.add(table1);
        Table table2 = new Table(4, 2);
        table2.addCell("Dept");
        table2.addCell(dept);
        table2.addCell("Doc.No.");
        table2.addCell(vo.getDocId());
        table2.setPadding(3);
        document.add(table2);
        Table table3 = new Table(6, 2);
        table3.addCell("Year");
        table3.addCell(String.valueOf(vo.getYear()));
        table3.addCell("number");
        table3.addCell(String.valueOf(vo.getBodyPageNum()));
        table3.addCell("Last Number");
        table3.addCell(String.valueOf(vo.getTotalPageNum()));
        table3.setPadding(3);
        document.add(table3);
        
        
        
        @SuppressWarnings("unchecked")
		List<JFileDetails> list = (List<JFileDetails>) map.get("jfileVo");
        
        if(list != null){
        Paragraph file = new Paragraph("Body File",font);
        file.setAlignment(Element.ALIGN_LEFT);
        document.add(file);	
        Table table4 = new Table(4,list.size()+1);
        table4.setPadding(3);
        for(JFileDetails jfile : list){
        table4.addCell("fileName");
        table4.addCell(new Paragraph(jfile.getFileName(), font));
        table4.addCell("size");
        table4.addCell(new Paragraph(jfile.getFileSize()/1000+"kb", font));
        }
        document.add(table4);
        }
        
        
        
        Paragraph approval = new Paragraph("Approval Info.",font);
        //중간정렬
        approval.setAlignment(Element.ALIGN_LEFT);
        document.add(approval);
        Table table5 = new Table(6, 2);
        table5.addCell("Co-writer");
        table5.addCell(vo.getCowriter());
        table5.addCell("Reviewer");
        table5.addCell(vo.getReviewer());
        table5.addCell("Approver");
        table5.addCell(vo.getApprover());
        table5.setPadding(3);
        document.add(table5);
        Table table6 = new Table(2, 2);
        table6.addCell("Hope Approve Date");
        table6.addCell(vo.getAppDate());
        table6.setPadding(3);
        document.add(table6);
        
        formatter = new SimpleDateFormat ( "yy년 MM월 dd일", Locale.KOREA );
        dTime = formatter.format ( currentTime );
        Paragraph Endtitle = new Paragraph("ⓒ 2017 KEPCO NF. All rights reserved. "+dTime,font);
        Paragraph Endtitle2 = new Paragraph("ⓒ대전광역시 유성구 대덕대로 989번길 242(덕진동) TEL: 042-868-1000 / FAX : 042-808-1219. ",font);
        Endtitle.setAlignment(Element.ALIGN_CENTER);
        Endtitle2.setAlignment(Element.ALIGN_CENTER);
        document.add(Endtitle);
        document.add(Endtitle2);
        
        
        
        
        
        document.close();
    }

    

}