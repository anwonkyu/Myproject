package com.withus.boardinfo.dao;

import java.util.ArrayList;
 
import org.springframework.stereotype.Repository;
 
import com.withus.boardinfo.dao.BoardInfoVO;
 
/**
 * @Class Name : BoardInfoDAO.java
 * @Description : BoardInfo DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("boardInfoMapper")
public interface BoardInfoMapper  {

	/**
	 * board_info을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BoardInfoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertBoardInfo(BoardInfoVO vo) throws Exception ; 

    /**
	 * board_info을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BoardInfoVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateBoardInfo(BoardInfoVO vo) throws Exception ; 

    /**
	 * board_info을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BoardInfoVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteBoardInfo(int boardId) throws Exception ;
    /**
	 * board_info을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BoardInfoVO
	 * @return 조회한 board_info
	 * @exception Exception
	 */
    public BoardInfoVO selectBoardInfo(int boardId) throws Exception;

    /**
	 * board_info 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return board_info 목록
	 * @exception Exception
	 */
    public ArrayList<BoardInfoVO> selectBoardInfoList() throws Exception;

    /**
	 * board_info 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return board_info 총 갯수
	 * @exception
	 */
    public int selectBoardInfoListTotCnt();

}
