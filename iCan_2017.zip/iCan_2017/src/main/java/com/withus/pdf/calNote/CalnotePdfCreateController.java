package com.withus.pdf.calNote;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.view.document.AbstractPdfView;

import com.ext.jfile.JProperties;
import com.lowagie.text.Document;
import com.lowagie.text.Font;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.BaseFont;
import com.lowagie.text.pdf.PdfCopyFields;
import com.lowagie.text.pdf.PdfReader;
import com.lowagie.text.pdf.PdfWriter;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.tr.dao.TrVO;

public class CalnotePdfCreateController extends AbstractPdfView{

    @Override
    public void buildPdfDocument(Map<String, Object> map,
            Document document, PdfWriter writer, HttpServletRequest request,
            HttpServletResponse response ) throws Exception {
        //파일뒤에 날짜를 입력하기위해 포맷함.
    	CalnoteVO calnoteVo = (CalnoteVO) map.get("calnoteVo");
    	//pdf가 저장될 경로 
		String savePath = "D:/report";
		//지정된 경로에 document와 파일경로를 저장시킨다.
		FileOutputStream fos = new FileOutputStream(new File(savePath, calnoteVo.getCalnoteId()+".pdf"));
		writer = PdfWriter.getInstance(document, fos);
		
		
		//document를 연다.
		PdfCopyFields copy = new PdfCopyFields(new FileOutputStream("D://report//"+calnoteVo.getCalnoteId()+".pdf"));
		String calnotePath = JProperties.getString("system.calnote");
		 PdfReader reader1 = new PdfReader(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
		document.open();
		 String malgunFont = JProperties.getString("malgun.font");
    	 BaseFont bfKorean = BaseFont.createFont(malgunFont, BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
		Font font8 = new Font(bfKorean, 8);
		 Paragraph explan = new Paragraph("explanation",font8);
		 document.add(explan);
		 copy.open();
			copy.addDocument(reader1);
			copy.close();
        document.close();
    }
}