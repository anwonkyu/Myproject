package com.withus.vodLog.service;

import java.util.ArrayList;
 






import com.withus.vodLog.dao.CounterVO;
import com.withus.vodLog.dao.VodLogVO;

/**
 * @Class Name : VodLogService.java
 * @Description : VodLog Business class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 20150303
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

public interface VodLogService {
	
	 
    /**
	 * vod_log 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return vod_log 목록
	 * @exception Exception
	 */
    ArrayList<VodLogVO> selectVodLogList(VodLogVO vo,int start, int end) throws Exception;
    
    ArrayList<VodLogVO> selectVodLogListAll(VodLogVO vo ) throws Exception;
    
    /**
	 * vod_log 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return vod_log 총 갯수
	 * @exception
	 */
    int selectVodLogListTotCnt(VodLogVO vo);
    
    
    ArrayList<VodLogVO> selectVodLogListLive(VodLogVO vo,int start, int end) throws Exception;
    
    ArrayList<VodLogVO> selectVodLogListLiveAll(VodLogVO vo) throws Exception;
 
    int selectVodLogListTotCntLive(VodLogVO vo);
    
    
    ArrayList<CounterVO> selectCounterListMenu(String type) throws Exception;
    ArrayList<CounterVO> selectCounterList(Integer Year, Integer Month, Integer Day, String flag, String type) throws Exception;
    ArrayList<CounterVO> selectCounterListMonth(Integer Year, Integer Month,  String flag, String type) throws Exception;
    ArrayList<CounterVO> selectCounterListYear(Integer Year,  String flag, String type) throws Exception;
    
    ArrayList<CounterVO> selectCounterListLive(Integer Year, Integer Month, Integer Day, String flag ) throws Exception;
    ArrayList<CounterVO> selectCounterListMonthLive(Integer Year, Integer Month,  String flag ) throws Exception;
    ArrayList<CounterVO> selectCounterListYearLive(Integer Year,  String flag ) throws Exception;
    
    ArrayList<VodLogVO> connectCount(String Flag) throws Exception;
    
    ArrayList<VodLogVO> connectCountWeek(int iDate, String Flag) throws Exception ;

	ArrayList<VodLogVO> connectCountMonth(Integer idx, String flag) throws Exception ;

	ArrayList<VodLogVO> connectCountYear(String idx, String flag)throws Exception ;
	
	public void webLogInsert() throws Exception;
	// 페이지 접속 카운트 (단순 접속 카운트, W,M)-page_cnn_cnt 현재 메인페이지에서만 적용
	//public void pageCnnCnt(String flag)throws Exception;
	public void pageCnnCnt()throws Exception;	
	//접속 통계
	public void contactStatInsert()throws Exception;
    
}
