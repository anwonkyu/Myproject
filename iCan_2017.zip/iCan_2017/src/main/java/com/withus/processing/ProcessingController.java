package com.withus.processing;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;

import com.ext.jfile.service.JFileDetails;
import com.ext.jfile.service.JFileService;
import com.itextpdf.text.log.SysoCounter;
import com.thoughtworks.xstream.XStream;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.proHistory.service.ProHistoryService;
import com.withus.processing.dao.ProcessingVO;
import com.withus.processing.service.ProcessingService;

@Controller
@RequestMapping("/processing")
public class ProcessingController {
	@Autowired Properties prop;
	
	@Autowired ProcessingService processingService;
	
    @Resource
	private PagingHelperService page;
	 
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;
	  
	@Resource(name = "xmlView")
	private View xmlView;
	
	@Resource(name="proHistoryService")
	private ProHistoryService proHistoryService;
	
    @Resource
    private JFileService jfileService;
	
	@RequestMapping(value="/processingList.do")
    public String selectContentMemoList(String datepicker, String datepicker2,ProcessingVO processingVo,  Integer curPage,String searchFild,  String searchWord, Model model,String sortField, String sortOrder)
            throws Exception {
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = ""; 
 
		String type = processingVo.getType();
		String docId = processingVo.getDocId();
		String title = processingVo.getTitle(); 
		
		processingVo.setType(type);
		processingVo.setDocId(docId);
		processingVo.setTitle(title);
		
//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		int totalRecord = processingService.selectProcessingTotCnt(searchWord, searchFild,type,docId,title,datepicker,datepicker2,"");
		
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		
        ArrayList<ProcessingVO> processingList = processingService.selectProcessingList( searchFild, searchWord, start, end,type,docId,title,datepicker,datepicker2,sortField,sortOrder,"");
        model.addAttribute("resultList", processingList);
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("datepicker", datepicker);
		model.addAttribute("datepicker2", datepicker2);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("thisVo", processingVo);
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
        return "/processing/processingList";
    } 
	
	  @RequestMapping(value = "/processingAdd.do", method=RequestMethod.GET )
	    public String processingAdd( Model model) throws Exception  {
			return "/processing/processingAdd";
	  }
	  
	  @RequestMapping(value="/processingAdd.do", method=RequestMethod.POST)
	    public String calWrite(ProcessingVO ProcessingVo )throws Exception {
	 
	    	processingService.insertProcessing(ProcessingVo);
	        return "redirect:/processing/processingList.do";
	    }
	  
	  @RequestMapping(value="/processingUpdate.do", method=RequestMethod.GET)
		public String processingUpdate( Integer seq, Model model) throws Exception {
			ProcessingVO processingVo = processingService.getProcessing(seq);
			model.addAttribute("thisVo", processingVo);
			return "/processing/processingAdd";
		}
	  
	  @RequestMapping(value="/processingView.do", method=RequestMethod.GET)
		public String processingView( Integer seq, Model model) throws Exception {
			ProcessingVO processingVo = processingService.getProcessing(seq);
			System.out.println("processingVo.getJfile()==="+processingVo.getJfile());
			if(processingVo.getJfile() != null){
				List<JFileDetails> jfileVo = jfileService.getAttachFiles(processingVo.getJfile());
 
				model.addAttribute("jfileList", jfileVo);  // 파일목록
				}
			model.addAttribute("thisVo", processingVo);
			return "/processing/processingView";
		}
	  
	    @RequestMapping(value="/processingUpdate.do", method=RequestMethod.POST)
		public String calUpdate(@ModelAttribute("processingVo") ProcessingVO processingVo, Model model ) throws Exception {
				processingService.updateProcessing(processingVo);
				return "redirect:/processing/processingList.do";
		}
	    
	    @RequestMapping(value="/processingDelete.do", method=RequestMethod.POST)
		public View deptDelete(@RequestParam(value="seq" ,required=true)Integer seq, Model model ) {
				   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     try {
					if ( processingService.deleteProcessing(seq) > 0) {
					        xml.setMessage("삭제되었습니다.");
					        xml.setError(true);
					   
					} else {
						xml.setMessage("삭제에 실패하였습니다.");
					     xml.setError(false);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	    
	    
	    @RequestMapping(value="/proHistory/list.do")
	    public String selectContentMemoList(Integer seq, String state , Integer curPage,String searchFild,  String searchWord, Model model)
	            throws Exception {
	    	if (String.valueOf(seq) == "" || seq==null){
	    		return "redirect:/processing/processingAdd.do";
	    	}
	    	if (curPage == null) curPage = 1;
			if (searchWord == null) searchWord = "";
			if (searchFild == null) searchFild = "";
	 
//			int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//			int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
			
			int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
			int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
			
			int totalRecord = proHistoryService.selectProHistoryListTotCnt(seq, state, searchFild, searchWord);
			PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
	 	
			page.setPagingHelper(pagingHelper);
			int start = pagingHelper.getStartRecord();
			int end = pagingHelper.getEndRecord();
			
			Integer prevLink = page.getPrevLink();
			Integer nextLink = page.getNextLink();
			Integer firstPage = page.getFirstPage();
			Integer lastPage = page.getLastPage();
			int[] pageLinks = page.getPageLinks();  
			
	        ArrayList<?> calHistoryList = proHistoryService.selectProHistoryList(seq, state, searchFild, searchWord, start, end);
	        model.addAttribute("resultList", calHistoryList);
	        
	        model.addAttribute("totalRecord", totalRecord);
	        model.addAttribute("prevLink", prevLink);
			model.addAttribute("nextLink", nextLink);
			model.addAttribute("firstPage", firstPage);
			model.addAttribute("lastPage", lastPage);
			model.addAttribute("pageLinks", pageLinks);
			model.addAttribute("curPage", curPage); 
			
			
			if (seq == null) seq=null;
	    	/*if (flag == null) return null;*/ 
			
			ProcessingVO processingVo = processingService.getProcessing(seq);
			model.addAttribute("thisVo", processingVo);
			/*model.addAttribute("stateName", this.thisStateName(calnoteVo.getState()));
			model.addAttribute("nextState", this.nextStateName(calnoteVo.getState()));
			model.addAttribute("nextStateCode", this.nextStateCode(calnoteVo.getState()));
			model.addAttribute("preStateCode", this.preStateCode(calnoteVo.getState()));*/
	        
	        return "/proHistory/list";
	    }
	  
}
