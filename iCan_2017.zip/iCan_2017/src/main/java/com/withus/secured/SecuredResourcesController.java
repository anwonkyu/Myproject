package com.withus.secured;

import java.util.ArrayList;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 
 

import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.commons.XmlResult;
import com.withus.secured.service.SecuredResourcesService; 
import com.withus.secured.dao.SecuredResourcesVO;

/**
 * @Class Name : SecuredResourcesController.java
 * @Description : SecuredResources Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class SecuredResourcesController {

    @Autowired
    private SecuredResourcesService securedResourcesService;
    @Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView; 
    @RequestMapping(value="/site/securied.do")
    public String selectSecuriedList(
    		ModelMap model)
            throws Exception { 
		
    	ArrayList<SecuredResourcesVO> ahtuRoleList = securedResourcesService.selectSecuredResourcesList(); 
        model.addAttribute("result", ahtuRoleList);
        
        return "/vodman/site/securied";
    } 
    
    @RequestMapping(value="/site/securiedWrite.do", method=RequestMethod.GET)
	public String write() throws Exception {
    	
    	return "/vodman/site/securiedWrite";
    }
    
    @RequestMapping(value="/site/securiedWrite.do" , method=RequestMethod.POST)
    public String addSecuried( @ModelAttribute("SecuredResourcesVO") SecuredResourcesVO securedResourcesVo )
            throws Exception {
    	 securedResourcesService.insertSecuredResources(securedResourcesVo);
    	 return "redirect:/vodman/site/securied.do";
    }
    
    @RequestMapping(value="/site/securiedUpdate.do" , method=RequestMethod.GET)
    public String updateSecuried(
            @RequestParam(value="resourceId", required=true)  String resourceId , Model model)
            throws Exception {
    	SecuredResourcesVO securedResourcesVo = securedResourcesService.selectSecuredResources(resourceId);
    	
        model.addAttribute("securedResourcesVo", securedResourcesVo);
       
        return "/vodman/site/authWrite";
    }
    
    @RequestMapping(value="/site/securiedDelete.do" , method={RequestMethod.GET, RequestMethod.POST})
    public String deleteSecuried(
    		   @RequestParam(value="resourceId", required=true)  String resourceId )
            throws Exception {
    		securedResourcesService.deleteSecuredResources(resourceId);
    		return "redirect:/vodman/site/securied.do";
    } 
    
    @RequestMapping(value="/site/securiedAuthority.do")
    public String selectSecuriedAuthorityList( @RequestParam(value="resourceId", required=true)  String resourceId, 
    		ModelMap model)
            throws Exception { 
		
    	ArrayList<SecuredResourcesVO> ahtuRoleList = securedResourcesService.selectSecuredResourcesAuthorityList(resourceId); 
        model.addAttribute("result", ahtuRoleList);
        
        return "/vodman/site/securiedAuthority";
    } 
    
    @RequestMapping(value="/site/securiedAuthorityDelete.do" , method={RequestMethod.GET, RequestMethod.POST})
    public String deleteSecuriedAuthority(
    		  @RequestParam(value="resourceId" ,required=true)  String resourceId , @RequestParam("seq")  Integer seq )
            throws Exception {
    		securedResourcesService.deleteSecuredResourcesAuthority(seq);
    		return "redirect:/vodman/site/securiedAuthority.do?resourceId="+resourceId;
    } 
    
    @RequestMapping(value="/site/insertSecuredAuthority.do" , method=RequestMethod.POST)
    public View addGroupsMember( @RequestParam MultiValueMap<String, String> params, Model model )
            throws Exception {
  
    	 XStream xst = xstreamMarshaller.getXStream();
     	 xst.alias("result", XmlResult.class); 
      
         XmlResult xml = new XmlResult(); 
         
         if (securedResourcesService.insertSecuredAuthority(params) > 0) { 
        	xml.setMessage("등록 되었습니다!");
  	 	    xml.setError(true);
    	 
         }else {
 			xml.setMessage("등록에 실패하였습니다!");
 	 	    xml.setError(false);
 		}

 	        model.addAttribute("xmlData", xml);
 	        return xmlView;
 	    // return "redirect:/vodman/site/securiedAuthority.do?resourceId="+params.get("resourceId").get(0);
    } 

 
}
