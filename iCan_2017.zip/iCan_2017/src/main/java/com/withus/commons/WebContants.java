package com.withus.commons;

import java.io.Closeable;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

public class WebContants {
	 
	 public final static String SEED_SECURITY = "vodcaster.co.kr.";
  
	 public static Properties readProperties(String filename) {
		 
		 	ClassLoader cl;  
	        cl = Thread.currentThread().getContextClassLoader();  
	        if( cl == null )  
	        cl = ClassLoader.getSystemClassLoader();  
	          
	        
			// Properties 클래스를 이용하면 확장자가 properties인 파일의 내용을 쉅게 가져올수 있다.
			Properties pro = new Properties();
			FileInputStream fis = null;
			try {
				// 파일스트림 자체가 복잡한데 그냥 파일이름 넘기고 load하면 불러온다.
				fis = new FileInputStream(cl.getResource(filename).getFile()); 
				// 아래방법으로 가져오면 한글은 깨짐 -_-;;
				//pro.load(fis); 
				pro.load(new InputStreamReader(fis));
			} catch (IOException e) {
				e.printStackTrace();
			} finally {
//				try {
//					fis.close();
//				} catch (IOException e) { 
//					e.printStackTrace();
//				}
				close(fis);
			}
			return pro;
		} 
	 
	    protected static void close(Closeable closable) { 
	   		if (closable != null) { 
	    			try { 
	    				closable.close(); 
	    			} catch (IOException ignore) { 
	    				 System.out.println("IGNORE: " + ignore); 
	    				 
	    		} 
	    	} 
	    } 
}
