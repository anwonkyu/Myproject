package com.withus.webLog;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
  
import org.springframework.web.servlet.View;
 
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
 
import com.withus.webLog.service.WebLogService;
 
import com.withus.webLog.dao.WebLogVO;

/**
 * @Class Name : WebLogController.java
 * @Description : WebLog Controller class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 2014-12-24
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */


@Controller
@RequestMapping("/vodman")
public class VodmanWebLogController {

    @Autowired
    private WebLogService webLogService;
    
    @Autowired Properties prop;
    
    @Resource
    private PagingHelperService page;
    
 
    /**
	 * web_log 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 WebLogDefaultVO
	 * @return "/webLog/WebLogList"
	 * @exception Exception
	 */
    
    //웹로그
    @RequestMapping(value="/site/WebLogList.do",method={RequestMethod.GET, RequestMethod.POST})
    public String selectWebLogList(Integer curPage,String searchFild, String searchWord,
    		String sdate, String edate,
    		Model model)
            throws Exception {
 
		if (curPage == null) curPage = 1;
		if (searchFild == null) searchFild = "";
		if (searchWord == null) searchWord = "";
		
		if (sdate == null) sdate = "";
		if (edate == null) edate = "";
 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim()); 
		int pagePerBlock = Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
 
		int totalRecord = webLogService.selectWebLogListTotCnt( searchFild, searchWord, sdate, edate);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock);
 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
  
		ArrayList<WebLogVO> list = webLogService.selectWebLogList(searchFild, searchWord,sdate, edate, start, end);
		
		Integer no = page.getListNo();
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		 
	 
		model.addAttribute("list",list); 
		model.addAttribute("no", no);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage);  
		
        return "/vodman/site/WebLogList";
		 
    } 
    
    // 웹로그 결과 엑셀받기 
    @RequestMapping(value="/site/WebLogList_excel.do", method=RequestMethod.POST)
    public View excel(String searchFild, String searchWord,
    		String sdate, String edate,
    		ModelMap model) {
    	
    	ArrayList<WebLogVO> list = webLogService.selectWebLogListAll(searchFild, searchWord, sdate, edate);
    	
        model.addAttribute("list", list);
            return new ExcelView();
    }
 
    
    @RequestMapping(value="/webLog/addWebLog.do",method=RequestMethod.POST)
    public void addWebLog(
            WebLogVO webLogVO  )
            throws Exception {
        webLogService.insertWebLog(webLogVO); 
    }
    
     

}


