package com.withus.serverFile.connection.ftp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.net.ftp.FTPFile;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

import com.withus.ftpServer.service.FtpServerService;
 

 
@Service("serverFtpService")
public class ServerFtpServiceImpl  implements  ServerFtpService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(ServerFtpServiceImpl.class);
    @Autowired
    private FtpServerService ftpServerService;
 
	@Override
	public HashMap<String, Object> getFileList(String path) throws Exception {
		
		int serverNo = ftpServerService.selectFtpServer();
		
		ServerFtpConn fdf = new ServerFtpConn(); 
		fdf.connect(serverNo);
        fdf.login(serverNo);
 
        System.out.println("폴더 이동 경로:"+path);
        System.out.println("현재 위치:"+fdf.pwd()); 
        
        if (path != null && path.length() > 0) {
        	 fdf.cd(path);
        }
        
        String this_pwd = "/";       
        this_pwd = fdf.pwd();
      //  fdf.list(); 
        FTPFile[] list = fdf.list();
         
        ArrayList<ServerFtpVO> return_list = new ArrayList<ServerFtpVO>();
 
        for ( FTPFile f : list) {
        	//System.out.println(  f.getName()+":"+f.getType() );
        	ServerFtpVO tmp_vo = new ServerFtpVO(); 
        	tmp_vo.setName(f.getName());
        	tmp_vo.setType(f.getType());
        	tmp_vo.setSize(f.getSize());
        	tmp_vo.setLink(f.getLink());
           
        	return_list.add(tmp_vo);
         
        } 
        
        fdf.disconnect();
        
        HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
        hashmap.put("fileList", return_list);
        hashmap.put("thisPwd", this_pwd);
		return hashmap;
	}

 

}
