package com.withus.commons;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.withus.commons.uploadFile.service.UploadFileService;
import com.withus.commons.uploadFile.service.UploadFileVo;
import com.withus.logo.dao.LogoVO;
import com.withus.logo.service.LogoService;
import com.withus.member.dao.MemberVo;
 
@Controller
public class ImageView {
	private static final Logger logger = LoggerFactory.getLogger(ImageView.class);
	
	@Resource
    private UploadFileService uploadFileService;
	
	@Resource
    private LogoService logoService;
	 
	
	@Autowired Properties prop;
	 
	@RequestMapping("/getImage.do")
    public void getImageInf( ModelMap model, Integer seq, HttpServletResponse response) throws Exception {

		//@RequestParam("atchFileId") String atchFileId,
		//@RequestParam("fileSn") String fileSn,
	  
		UploadFileVo uplaodFileVo = new UploadFileVo();
		uplaodFileVo = uploadFileService.getUploadFile(seq);
	 

		//String fileLoaction = fvo.getFileStreCours() + fvo.getStreFileNm();
		
		boolean fileCheck = false;
		// 0. 로그인 체크
		int userLevel = 0;
		// 1. 파일 공개구분, 삭제 구분
		// 2. 접근 가능 레벨 확인
		// 3. 비밀글 확인(게시판)
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			 userLevel =(((MemberVo)principal).getLevels());
		}
		     
//		if (uplaodFileVo.getFlag().equals("V")) {
//			fileCheck = videoService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		} else if (uplaodFileVo.getFlag().equals("B")) {
//			fileCheck = boardListService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		} else if (uplaodFileVo.getFlag().equals("L")) {
//			fileCheck = liveMediaService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		}
		
		String orgname = uplaodFileVo.getOrgName();
        String newname = uplaodFileVo.getFileName();
        
        int fileIndex = StringUtils.lastIndexOf(orgname, '.');

        // 파일명과 확장자를 분리
        String extension = null;
        if (fileIndex != -1) {
            extension = StringUtils.substring(orgname, fileIndex + 1); 
        } 
        

		File file = null;
		FileInputStream fis = null;

		BufferedInputStream in = null;
		ByteArrayOutputStream bStream = null;

		try {
			file = new File(prop.getProperty("BASE_PATH").trim()+File.separator, newname);
		    fis = new FileInputStream(file);
		    in = new BufferedInputStream(fis);
		    bStream = new ByteArrayOutputStream();

		    int imgByte;
		    while ((imgByte = in.read()) != -1) {
		    	bStream.write(imgByte);
		    }

			String type = "";

			if (extension != null && !"".equals(extension)) {
			    if ("jpg".equals(extension.toLowerCase())) {
				type = "image/jpeg";
			    } else {
			    	type = "image/" + extension.toLowerCase();
			    }
			    type = "image/" + extension.toLowerCase();

			} else {
				System.out.println("Image fileType is null.");
			}

			response.setHeader("Content-Type", type);
			response.setContentLength(bStream.size());

			bStream.writeTo(response.getOutputStream());

			response.getOutputStream().flush();
			response.getOutputStream().close();

		} finally {
 			close(bStream);
			close(in);
			close(fis);
		}
    }
	
	@RequestMapping("/getImageM.do")
    public void getImageInfMiddle( ModelMap model, Integer seq, HttpServletResponse response) throws Exception {

		//@RequestParam("atchFileId") String atchFileId,
		//@RequestParam("fileSn") String fileSn,
	  
		UploadFileVo uplaodFileVo = new UploadFileVo();
		uplaodFileVo = uploadFileService.getUploadFile(seq);
	 

		//String fileLoaction = fvo.getFileStreCours() + fvo.getStreFileNm();
		
		boolean fileCheck = false;
		// 0. 로그인 체크
		int userLevel = 0;
		// 1. 파일 공개구분, 삭제 구분
		// 2. 접근 가능 레벨 확인
		// 3. 비밀글 확인(게시판)
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			 userLevel =(((MemberVo)principal).getLevels());
		}
		     
//		if (uplaodFileVo.getFlag().equals("V")) {
//			fileCheck = videoService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		} else if (uplaodFileVo.getFlag().equals("B")) {
//			fileCheck = boardListService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		} else if (uplaodFileVo.getFlag().equals("L")) {
//			fileCheck = liveMediaService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		}
		
		String orgname = uplaodFileVo.getOrgName();
        String newname = uplaodFileVo.getFileName();
        
        int fileIndex = StringUtils.lastIndexOf(orgname, '.');

        // 파일명과 확장자를 분리
        String extension = null;
        if (fileIndex != -1) {
            extension = StringUtils.substring(orgname, fileIndex + 1); 
        } 
        

		File file = null;
		FileInputStream fis = null;

		BufferedInputStream in = null;
		ByteArrayOutputStream bStream = null;

		try {
		    //file = new File(prop.getProperty("BASE_PATH").trim()+File.separator+"thumb2/", newname);
		    //fis = new FileInputStream(file);
		    fis = new FileInputStream(prop.getProperty("BASE_PATH").trim() + File.separator+"thumb2/" + newname+"."+extension);

		    in = new BufferedInputStream(fis);
		    bStream = new ByteArrayOutputStream();

		    int imgByte;
		    while ((imgByte = in.read()) != -1) {
		    	bStream.write(imgByte);
		    }

			String type = "";

			if (extension != null && !"".equals(extension)) {
			    if ("jpg".equals(extension.toLowerCase())) {
				type = "image/jpeg";
			    } else {
			    	type = "image/" + extension.toLowerCase();
			    }
			    type = "image/" + extension.toLowerCase();

			} else {
				System.out.println("Image fileType is null.");
			}

			response.setHeader("Content-Type", type);
			response.setContentLength(bStream.size());

			bStream.writeTo(response.getOutputStream());

			response.getOutputStream().flush();
			response.getOutputStream().close();

		} finally {
 			close(bStream);
			close(in);
			close(fis);
		}
    }
	
	
	@RequestMapping("/getImageS.do")
    public void getImageInfSmall( ModelMap model, Integer seq, HttpServletResponse response) throws Exception {

		//@RequestParam("atchFileId") String atchFileId,
		//@RequestParam("fileSn") String fileSn,
	  
		UploadFileVo uplaodFileVo = new UploadFileVo();
		uplaodFileVo = uploadFileService.getUploadFile(seq);
	 

		//String fileLoaction = fvo.getFileStreCours() + fvo.getStreFileNm();
		
		boolean fileCheck = false;
		// 0. 로그인 체크
		int userLevel = 0;
		// 1. 파일 공개구분, 삭제 구분
		// 2. 접근 가능 레벨 확인
		// 3. 비밀글 확인(게시판)
		
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			 userLevel =(((MemberVo)principal).getLevels());
		}
		     
//		if (uplaodFileVo.getFlag().equals("V")) {
//			fileCheck = videoService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		} else if (uplaodFileVo.getFlag().equals("B")) {
//			fileCheck = boardListService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		} else if (uplaodFileVo.getFlag().equals("L")) {
//			fileCheck = liveMediaService.fileCheck(uplaodFileVo.getOcode() ,userLevel );
//		}
		
		String orgname = uplaodFileVo.getOrgName();
        String newname = uplaodFileVo.getFileName();
        
        int fileIndex = StringUtils.lastIndexOf(orgname, '.');

        // 파일명과 확장자를 분리
        String extension = null;
        if (fileIndex != -1) {
            extension = StringUtils.substring(orgname, fileIndex + 1); 
        } 
        

		File file = null;
		FileInputStream fis = null;

		BufferedInputStream in = null;
		ByteArrayOutputStream bStream = null;

		try {
			//file = new File(prop.getProperty("BASE_PATH").trim()+File.separator+"thumb1/", newname);
		    //fis = new FileInputStream(file);
		    fis = new FileInputStream(prop.getProperty("BASE_PATH").trim() + File.separator+"thumb1/" + newname+"."+extension);

		    in = new BufferedInputStream(fis);
		    bStream = new ByteArrayOutputStream();

		    int imgByte;
		    while ((imgByte = in.read()) != -1) {
		    	bStream.write(imgByte);
		    }

			String type = "";

			if (extension != null && !"".equals(extension)) {
			    if ("jpg".equals(extension.toLowerCase())) {
				type = "image/jpeg";
			    } else {
			    	type = "image/" + extension.toLowerCase();
			    }
			    type = "image/" + extension.toLowerCase();

			} else {
				System.out.println("Image fileType is null.");
			}

			response.setHeader("Content-Type", type);
			response.setContentLength(bStream.size());

			bStream.writeTo(response.getOutputStream());

			response.getOutputStream().flush();
			response.getOutputStream().close();

		} finally {
 			close(bStream);
			close(in);
			close(fis);
		}
    }
	 
	
	@RequestMapping("/getImageLogoTop.do")
    public void getImageLogoTop( ModelMap model,  HttpServletResponse response) throws Exception {

		//@RequestParam("atchFileId") String atchFileId,
		//@RequestParam("fileSn") String fileSn,
	  
		LogoVO logoVO = new LogoVO();
		logoVO = logoService.selectLogo();

		
		String topImg = logoVO.getTopLogo();
        String topExt = logoVO.getTopLogoExt();
   

		File file = null;
		FileInputStream fis = null;

		BufferedInputStream in = null;
		ByteArrayOutputStream bStream = null;

		try {
			file = new File(prop.getProperty("LOGO_PATH").trim()+File.separator, topImg);
		    fis = new FileInputStream(file);
		    in = new BufferedInputStream(fis);
		    bStream = new ByteArrayOutputStream();

		    int imgByte;
		    while ((imgByte = in.read()) != -1) {
		    	bStream.write(imgByte);
		    }

			String type = "";

			if (topExt != null && !"".equals(topExt)) {
			    if ("jpg".equals(topExt.toLowerCase())) {
				type = "image/jpeg";
			    } else {
			    	type = "image/" + topExt.toLowerCase();
			    }
			    type = "image/" + topExt.toLowerCase();

			} else {
				System.out.println("Image fileType is null.");
			}

			response.setHeader("Content-Type", type);
			response.setContentLength(bStream.size());

			bStream.writeTo(response.getOutputStream());

			response.getOutputStream().flush();
			response.getOutputStream().close();

		} finally {
 			close(bStream);
			close(in);
			close(fis);
		}
    }
	
	@RequestMapping("/getImageLogoBottom.do")
    public void getImageLogoBottom( ModelMap model,  HttpServletResponse response) throws Exception {

		//@RequestParam("atchFileId") String atchFileId,
		//@RequestParam("fileSn") String fileSn,
	  
		LogoVO logoVO = new LogoVO();
		logoVO = logoService.selectLogo();

		
		String topImg = logoVO.getFooterLogo();
        String topExt = logoVO.getFooterLogoExt();
   

		File file = null;
		FileInputStream fis = null;

		BufferedInputStream in = null;
		ByteArrayOutputStream bStream = null;

		try {
			file = new File(prop.getProperty("LOGO_PATH").trim()+File.separator, topImg);
		    fis = new FileInputStream(file);
		    in = new BufferedInputStream(fis);
		    bStream = new ByteArrayOutputStream();

		    int imgByte;
		    while ((imgByte = in.read()) != -1) {
		    	bStream.write(imgByte);
		    }

			String type = "";

			if (topExt != null && !"".equals(topExt)) {
			    if ("jpg".equals(topExt.toLowerCase())) {
				type = "image/jpeg";
			    } else {
			    	type = "image/" + topExt.toLowerCase();
			    }
			    type = "image/" + topExt.toLowerCase();

			} else {
				System.out.println("Image fileType is null.");
			}

			response.setHeader("Content-Type", type);
			response.setContentLength(bStream.size());

			bStream.writeTo(response.getOutputStream());

			response.getOutputStream().flush();
			response.getOutputStream().close();

		} finally {
 			close(bStream);
			close(in);
			close(fis);
		}
    }
	
    protected static void close(Closeable closable) { 
   		if (closable != null) { 
    			try { 
    				closable.close(); 
    			} catch (IOException ignore) { 
    				 //System.out.println("IGNORE: " + ignore); 
    				 logger.info(ignore.toString()); 
    		} 
    	} 
    } 

}
