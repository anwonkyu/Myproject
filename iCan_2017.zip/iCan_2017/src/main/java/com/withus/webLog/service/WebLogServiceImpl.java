package com.withus.webLog.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 











import com.withus.commons.paging.PagingHelperServiceImpl;
import com.withus.webLog.service.WebLogService;
 
import com.withus.webLog.dao.WebLogVO;
 
import com.withus.webLog.dao.WebLogMapper;

/**
 * @Class Name : WebLogServiceImpl.java
 * @Description : WebLog Business Implement class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 2014-12-24
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service 
public class WebLogServiceImpl  implements  WebLogService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(WebLogServiceImpl.class);

    @Resource(name="webLogMapper")
    private WebLogMapper webLogMapper;
    
    /** ID Generation */
    //@Resource(name="{egovWebLogIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * web_log을 등록한다.
	 * @param vo - 등록할 정보가 담긴 WebLogVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String insertWebLog(WebLogVO vo) throws Exception { 
    	
    	webLogMapper.insertWebLog(vo);
    	//TODO 해당 테이블 정보에 맞게 수정    	
        return null;
    } 
 

    /**
	 * web_log 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return web_log 목록
	 * @exception Exception
	 */
    public ArrayList<WebLogVO> selectWebLogList(String searchFild,String searchWord, String sdate,String edate, int start,int end) throws Exception {
    	
    	Integer startRownum = start;
		Integer endRownum = end;
		
    	HashMap<String, String> hashmap = new HashMap<String, String>();
    	 
    	hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("sdate", sdate);
		hashmap.put("edate", edate);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		
        return webLogMapper.selectWebLogList(hashmap);
    }

    /**
	 * web_log 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return web_log 총 갯수
	 * @exception
	 */
    public int selectWebLogListTotCnt(String searchFild, String searchWord,String sdate,String edate) {
    	
    	HashMap<String, String> hashmap = new HashMap<String, String>();
 
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("sdate", sdate);
		hashmap.put("edate", edate);
 
		return webLogMapper.selectWebLogListTotCnt(hashmap);
	}


	@Override
	public ArrayList<WebLogVO> selectWebLogListAll(String searchFild, String searchWord, String sdate,String edate) {

    	HashMap<String, String> hashmap = new HashMap<String, String>();
 
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("sdate", sdate);
		hashmap.put("edate", edate);
 
		return webLogMapper.selectWebLogListAll(hashmap);
	}
    
}
