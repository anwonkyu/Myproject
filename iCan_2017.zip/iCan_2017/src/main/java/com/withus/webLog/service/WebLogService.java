package com.withus.webLog.service;

import java.util.ArrayList;
import java.util.List;
 



import com.withus.commons.paging.PagingHelperService;
import com.withus.webLog.dao.WebLogVO;

/**
 * @Class Name : WebLogService.java
 * @Description : WebLog Business class
 * @Modification Information
 *
 * @author joohyun2004
 * @since 2014-12-24
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface WebLogService   {
	
	/**
	 * web_log을 등록한다.
	 * @param vo - 등록할 정보가 담긴 WebLogVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    String insertWebLog(WebLogVO vo) throws Exception;
    
 
    /**
	 * web_log 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return web_log 목록
	 * @exception Exception
	 */
    ArrayList<WebLogVO> selectWebLogList(String searchFild,String searchWord,String sdate,String edate,int start,int end) throws Exception;
    
    /**
	 * web_log 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return web_log 총 갯수
	 * @exception
	 */
    int selectWebLogListTotCnt(String searchFild, String searchWord, String sdate,String edate);


	ArrayList<WebLogVO> selectWebLogListAll(String searchFild, String searchWord, String sdate,String edate);
    
}
