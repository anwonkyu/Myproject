package com.withus.commons.paging; 
 
public interface PagingHelperService {

    /*
     * 페이징 관리
     */
    public int getListNo();
	
	public int getPrevLink();
	
	public int getFirstPage();
	
	public int getLastPage();
	
	public int getLastPage2();
	
	public int getNextLink();

	public int[] getPageLinks();

	public void setPagingHelper(PagingHelper pagingHelper)throws Exception;
	
}
