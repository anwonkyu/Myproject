package com.withus.vodLog;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

import org.springframework.web.servlet.view.document.AbstractJExcelView;

import com.withus.vodLog.dao.VodLogVO;
 

public class ExcelView extends AbstractJExcelView {
    protected void buildExcelDocument
       (Map<String, Object> model, WritableWorkbook workbook, HttpServletRequest request,
        HttpServletResponse response) throws Exception {
        String fileName = createFileName();
        setFileNameToResponse(request, response, fileName);       
       
        List<VodLogVO> list = (List<VodLogVO>)model.get("list");
        WritableSheet sheet = workbook.createSheet("시청로그", 0);
        
        sheet.addCell(new jxl.write.Label(0, 0, "seq"));
        sheet.addCell(new jxl.write.Label(1, 0, "제목"));
        sheet.addCell(new jxl.write.Label(2, 0, "아이디"));
        sheet.addCell(new jxl.write.Label(3, 0, "시청일"));
        sheet.addCell(new jxl.write.Label(4, 0, "아이피"));
 
        
        int row = 1;
        for (Iterator iterator = list.iterator(); iterator.hasNext();) {
        	VodLogVO logvo = (VodLogVO) iterator.next();
            sheet.addCell(new jxl.write.Number(0, row,logvo.getNo()  ));
            sheet.addCell(new jxl.write.Label(1, row, logvo.getTitle()));
            sheet.addCell(new jxl.write.Label(2, row, logvo.getVodId()));
            sheet.addCell(new jxl.write.DateTime(3, row, logvo.getRegdate()));
            sheet.addCell(new jxl.write.Label(4, row, logvo.getIp()));
 
            row++;
        }
    }
    private void setFileNameToResponse
       (HttpServletRequest request, HttpServletResponse response, String fileName) {
        String userAgent = request.getHeader("User-Agent");
        if (userAgent.indexOf("MSIE 5.5") >= 0) {
            response.setContentType("doesn/matter");
            response.setHeader("Content-Disposition","filename=\""+fileName+"\"");
        } else {
            response.setHeader("Content-Disposition","attachment; filename=\""+fileName+"\"");
        }
    }
    private String createFileName() {
        SimpleDateFormat fileFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        return new StringBuilder("vodLog").append("_").append(fileFormat.format(new Date())).append(".xls").toString();
    }
}
