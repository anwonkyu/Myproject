package com.withus.member.service;

import java.util.ArrayList;
import java.util.HashMap; 
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.StandardPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
  

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.withus.commons.seed.SEEDUtil;
import com.withus.member.dao.MemberMapper;
import com.withus.member.dao.MemberVo;
import com.withus.question.dao.QuestionVO;
import com.withus.userInfoLog.dao.UserInfoLogVO;
import com.withus.userInfoLog.service.UserInfoLogService;
 

@Service
public class MemberServiceImpl   implements MemberService {

	@Resource(name="memberMapper")
	private MemberMapper memberMapper;
	
	@Resource
	private UserInfoLogService userInfoService;
 	
	@Override
	public ArrayList<MemberVo> getMemberList(  String searchFild, String searchWord,
			int start, int end,  String searchLevel, String deptMemo) {
		Integer startRownum = start;
		Integer endRownum = end;
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		
		if (searchFild != null && (searchFild.equals("name") || searchFild.equals("email") ) ) {
			searchWord = SEEDUtil.getEncrypt(searchWord); // 암호화
		}
		hashmap.put("searchLevel", searchLevel);
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
	 
		if (deptMemo != null && deptMemo.length() > 0) {
			String[] dept = deptMemo.split(",");
			hashmap.put("dept", dept);
		}
		 
		
		//return memberMapper.getMemberList(hashmap);
		
		return com.withus.commons.seed.WithusSeed.returnSeedList(memberMapper.getMemberList(hashmap));
	}

	@Override
	public int getTotalRecord(String searchFild,  String searchWord,  String searchLevel, String deptMemo) throws Exception {
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		if (searchFild != null && (searchFild.equals("name") || searchFild.equals("email") ) ) {
			searchWord = SEEDUtil.getEncrypt(searchWord); // 암호화
		}
		hashmap.put("searchLevel", searchLevel);
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		
		String[] dept = deptMemo.split(",");
		hashmap.put("dept", dept);
		
		return memberMapper.getTotalRecord(hashmap);
	}
	
	@Override
	
	public int insert(MemberVo memberVo) throws Exception{
		
		 StandardPasswordEncoder passwordEncoder = new StandardPasswordEncoder(); 
 
	     String password = passwordEncoder.encode(memberVo.getUserpassword());  // spring security 적용을 위한 패스워드 암호화
	     
	     memberVo.setUserpassword(password);
	     if (memberVo.getAuthKey() == null) {
	    	 memberVo.setAuthKey("USER");
	     }
	     if (memberVo.getApproval() == null) {
	    	 memberVo.setApproval("N");
	     }
	     
		//return memberMapper.insert(memberVo);
	     int rtn_value = memberMapper.insert(com.withus.commons.seed.WithusSeed.returnSeedEn(memberVo));
	     
	     if(rtn_value > 0) {
	    	 this.insertAuthority(memberVo.getId(), memberVo.getAuthKey());
	     }
	     return rtn_value;
	     
	}
	
	public int insert2(MemberVo memberVo) throws Exception{
		
		 StandardPasswordEncoder passwordEncoder = new StandardPasswordEncoder(); 

	     String password = passwordEncoder.encode(memberVo.getUserpassword());  // spring security 적용을 위한 패스워드 암호화
	     
	     memberVo.setUserpassword(password);
	     if (memberVo.getAuthKey() == null) {
	    	 memberVo.setAuthKey("USER");
	     }
	     if (memberVo.getApproval() == null) {
	    	 memberVo.setApproval("N");
	     }
	     
		//return memberMapper.insert(memberVo);
	     int rtn_value = memberMapper.insert2(com.withus.commons.seed.WithusSeed.returnSeedEn(memberVo));
	     
	     if(rtn_value > 0) {
	    	 this.insertAuthority(memberVo.getId(), memberVo.getAuthKey());
	     }
	     return rtn_value;
	     
	}

	@Override
	public MemberVo login(String id, String pwd) {
	 
		return memberMapper.login(id, pwd);
	}

	@Override
	
	public int update(MemberVo memberVo) throws Exception {
		//return memberMapper.update(memberVo);
		
		// 기존 정보 조회 해서 변경된 이력 저장
		MemberVo temp_member = memberInfo(memberVo.getId());
		
		int rtn_value = memberMapper.update(com.withus.commons.seed.WithusSeed.returnSeedEn(memberVo));
		if(rtn_value > 0 && temp_member != null) {
			
			HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			
			UserInfoLogVO temp_logoVo = new UserInfoLogVO();
			
			temp_logoVo.setUserid(memberVo.getId());
			temp_logoVo.setUsername(memberVo.getId());
			temp_logoVo.setIp(req.getRemoteAddr()); 
			
			// 생년월일  pwd_answer
			if (memberVo.getSsn() != null &&  memberVo.getSsn().equals(temp_member.getSsn())) {
				temp_logoVo.setBirthday("X");
			} else {
				temp_logoVo.setBirthday("O");	
			}
		 	// 성별 sex
			if (memberVo.getSex() != null && memberVo.getSex().equals(temp_member.getSex())) {
				temp_logoVo.setSex("X");
			} else {
				temp_logoVo.setSex("O");	
			}
		 	//전화번호 tel
			if (memberVo.getTel() != null && memberVo.getTel().equals(temp_member.getTel())) {
				temp_logoVo.setTel("X");
			} else {
				temp_logoVo.setTel("O");	
			}
		 	//휴대전화번호 hp
			if (memberVo.getHp() != null && memberVo.getHp().equals(temp_member.getHp())) {
				temp_logoVo.setMobile("X");
			} else {
				temp_logoVo.setMobile("O");	
			}
		 	// 우편번호 zip
			if (memberVo.getZip() != null && memberVo.getZip().equals(temp_member.getZip())) {
				temp_logoVo.setZipcode("X");
			} else {
				temp_logoVo.setZipcode("O");	
			}
		 	// 주소1 address1
			if (memberVo.getAddress1() != null && memberVo.getAddress1().equals(temp_member.getAddress1())) {
				temp_logoVo.setAddr1("X");
			} else {
				temp_logoVo.setAddr1("O");	
			}
		 	//주소2 address2
			if (memberVo.getAddress2() != null && memberVo.getAddress2().equals(temp_member.getAddress2())) {
				temp_logoVo.setAddr2("X");
			} else {
				temp_logoVo.setAddr2("O");	
			}
		 	//이메일 email
			if (memberVo.getEmail() != null &&memberVo.getEmail().equals(temp_member.getEmail())) {
				temp_logoVo.setEmail("X");
			} else {
				temp_logoVo.setEmail("O");	
			}
		 	//직업 buseo
			if (memberVo.getBuseo() != null && memberVo.getBuseo().equals(temp_member.getBuseo())) {
				temp_logoVo.setDeptcode("X");
			} else {
				temp_logoVo.setDeptcode("O");	
			}
			if (authentication.getName() != null && authentication.getName().length() > 0) {
				temp_logoVo.setEtc(authentication.getName());
			} 
			
			int a = userInfoService.insertUserInfoLog(temp_logoVo);
			 
			 if (memberVo.getAuthKey() == null  || (memberVo.getAuthKey() != null && memberVo.getAuthKey().equals(temp_member.getAuthKey())) ) {  // 권한 설정
			 } else {
				 this.deleteAuthority(memberVo.getId());
		    	 this.insertAuthority(memberVo.getId(), memberVo.getAuthKey());
			 }
	     } 
 
		 
		
		return rtn_value;
	}

	@Override
	public void changePwd(MemberVo memberVo) {
		 memberMapper.changePwd(memberVo);

	}

	@Override
	public void bye(MemberVo memberVo) {
		memberMapper.bye(memberVo);

	}


	@Override
	public MemberVo memberInfo(String id) {
		//return memberMapper.memberInfo(id);
		return com.withus.commons.seed.WithusSeed.returnSeedDe((MemberVo)memberMapper.memberInfo(id));
	}

	@Override
	public void insertAuthority(String id, String role) {
		
//		memberMapper.insertAuthority(id, role);
		if (role != null && role.equals("VODMAN")) {
			memberMapper.insertAuthority(id, "ROLE_USER");
			memberMapper.insertAuthority(id, "ROLE_MANAGER");
			memberMapper.insertAuthority(id, "ROLE_VODMAN");
		}  else if (role != null && role.equals("MANAGER") ) {
			memberMapper.insertAuthority(id, "ROLE_USER");
			memberMapper.insertAuthority(id, "ROLE_MANAGER");
		}else {
			memberMapper.insertAuthority(id, "ROLE_USER"); 
		} 
		
	}
	
	@Override
	public void deleteAuthority(String id) {
		memberMapper.deleteAuthority(id);
		
	}

	@Override
	public int checkId(String id) {
		// TODO Auto-generated method stub
		return memberMapper.checkId(id);
	}

	@Override
	public String selectDept(String id) {
		
		return memberMapper.selectDept(id);
	}
	
	@Override
	public int deleteMember(String id) {
		// TODO Auto-generated method stub
		return memberMapper.deleteMember(id);
	}

	@Override
	public int loginHistory(String id, String flag) {
		
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		String ip = request.getRemoteAddr(); 
		
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("id", id);
		hashmap.put("flag", flag); 
		hashmap.put("ip", ip);
 
		
		// TODO Auto-generated method stub
		return memberMapper.loginHistory(hashmap);
	}

	
	@Override
	public int pwdUpdate(String id, String pwd) throws Exception {

		StandardPasswordEncoder passwordEncoder = new StandardPasswordEncoder(); 
	    String password = passwordEncoder.encode(pwd);  // spring security 적용을 위한 패스워드 암호화
	     
	    HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("id", id);
		hashmap.put("userpassword", password);  
		int rtn_value = memberMapper.pwdUpdate(hashmap);
		
		// 기존 정보 조회 해서 변경된 이력 저장
		MemberVo temp_member = memberInfo(id);
		
		if(rtn_value > 0 && temp_member != null ) {
			 
			HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			
			UserInfoLogVO temp_logoVo = new UserInfoLogVO();
			
			temp_logoVo.setUserid(temp_member.getId());
			temp_logoVo.setUsername(temp_member.getId());
			temp_logoVo.setIp(req.getRemoteAddr()); 
			temp_logoVo.setUserpwd("O");			
			if (authentication.getName() != null && authentication.getName().length() > 0) {
				temp_logoVo.setEtc(authentication.getName());
			} 
			int a = userInfoService.insertUserInfoLog(temp_logoVo);
			
		}
		return rtn_value;
	}

	@Override
	public int updateApproval(String approval, String id) {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("id", id);
		hashmap.put("approval", approval); 
	 
		// TODO Auto-generated method stub
		return memberMapper.updateApproval(hashmap);
	}

	@Override
	public int pwdUpdate_user( String pwd, String old_pwd) throws Exception {
		StandardPasswordEncoder passwordEncoder = new StandardPasswordEncoder(); 
	    String password = passwordEncoder.encode(pwd);  // spring security 적용을 위한 패스워드 암호화 
	     
        Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal(); 
		if(principal != null && principal instanceof MemberVo){ 
			String vod_id = ((MemberVo)principal).getUsername();
	 
			if (passwordEncoder.matches(old_pwd, ((MemberVo)principal).getPassword())){  // 기존 비밀번화와 입력한 비밀번호 확인
			//System.out.println("matches"); 
			
			    HashMap<String, String> hashmap = new HashMap<String, String>();
				hashmap.put("id", vod_id);
				hashmap.put("userpassword", password);  

				int rtn_value = memberMapper.pwdUpdate(hashmap);  //비밀번호 변경
			
				// 기존 정보 조회 해서 변경된 이력 저장
				MemberVo temp_member = memberInfo(vod_id);
			
				if(rtn_value > 0 && temp_member != null ) {
					 
					HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
					Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
					
					UserInfoLogVO temp_logoVo = new UserInfoLogVO();
					
					temp_logoVo.setUserid(temp_member.getId());
					temp_logoVo.setUsername(temp_member.getId());
					temp_logoVo.setIp(req.getRemoteAddr());
					temp_logoVo.setUserpwd("O");			
					if (authentication.getName() != null && authentication.getName().length() > 0) {
						temp_logoVo.setEtc(authentication.getName());
					} 
					int a = userInfoService.insertUserInfoLog(temp_logoVo);
					
				}
				return rtn_value;
		    } else {
		    	 
		    	return -1;
		    }
		} else {
			return -1;
		}
	}

	@Override
	public MemberVo findMember(String userName, String userEmail) {
		MemberVo membervo = (MemberVo)memberMapper.findMember(SEEDUtil.getEncrypt(userName), SEEDUtil.getEncrypt(userEmail)); 
		if (membervo != null) {
			return com.withus.commons.seed.WithusSeed.returnSeedDe(membervo);
		} else {
			return null;
		}
	 
	}
	
	@Override
	public MemberVo findMemberId(String userId, String userName, String userEmail) {
		MemberVo membervo = (MemberVo)memberMapper.findMemberId(userId, SEEDUtil.getEncrypt(userName), SEEDUtil.getEncrypt(userEmail)); 
		if (membervo != null) {
			return com.withus.commons.seed.WithusSeed.returnSeedDe(membervo);
		} else {
			return null;
		}
 
	}
	
	@Override
	public MemberVo findMemberId_Hp( String userName, String hp) {
		MemberVo membervo = (MemberVo)memberMapper.findMemberId_Hp(SEEDUtil.getEncrypt(userName), SEEDUtil.getEncrypt(hp)); 
		if (membervo != null) {
			return com.withus.commons.seed.WithusSeed.returnSeedDe(membervo);
		} else {
			return null;
		}
	}
  
	@Override
	public ArrayList<MemberVo> getMemberListAll(  String searchFild, String searchWord,
			  String searchLevel) {
		 
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		
		if (searchFild != null && (searchFild.equals("name") || searchFild.equals("email") ) ) {
			searchWord = SEEDUtil.getEncrypt(searchWord); // 암호화
		}
		hashmap.put("searchLevel", searchLevel);
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
	 
		
		//return memberMapper.getMemberList(hashmap);
		
		return com.withus.commons.seed.WithusSeed.returnSeedList(memberMapper.getMemberList(hashmap));
	}


	@Override


	public int insert_visit(String userId, String userName) {
		HashMap<String, String> hashmap = new HashMap<String, String>();




		hashmap.put("mem_id", userId);
		hashmap.put("inman", userName);





		return memberMapper.insert_visit(hashmap);
	}


	@Override
	public int total_visit() {
		return memberMapper.total_visit();
	}

	@Override
	public int today_visit() {
		return memberMapper.today_visit();
	}
	
		@Override
	public ArrayList<MemberVo> questionList_Dcode(String Dcode)
			throws Exception {

		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
				
		if (Dcode != null && Dcode.length() > 0) {
			String[] list = Dcode.split("/");
		

			hashmap.put("dcodeList",list);
			return com.withus.commons.seed.WithusSeed.returnSeedList(memberMapper.questionList_Dcode(hashmap));
		} else {
			return null;
		} 
		

	}

		@Override
		public ArrayList<MemberVo> readUserInfoList(String[] userIds) throws Exception {
			HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
			hashmap.put("userIds", userIds);

			return memberMapper.readUserInfoList(hashmap);
		}


	
}
