package com.withus.userInfo.dao;

public class UserInfoVo {
	String id ;
	String empId ;
	String img ;
	String regDate ;
	String authKey ;
	String approval;
	Integer revels ;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getImg() {
		return img;
	}
	public void setImg(String img) {
		this.img = img;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getAuthKey() {
		return authKey;
	}
	public void setAuthKey(String authKey) {
		this.authKey = authKey;
	}
	public String getApproval() {
		return approval;
	}
	public void setApproval(String approval) {
		this.approval = approval;
	}
	public Integer getRevels() {
		return revels;
	}
	public void setRevels(Integer revels) {
		this.revels = revels;
	}
	
}
