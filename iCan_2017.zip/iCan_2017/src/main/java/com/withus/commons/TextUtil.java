package com.withus.commons;

import org.apache.commons.lang.StringUtils;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Map;

public class TextUtil {

/*
*	매개변수에 문자열 "0"을 원하는 길이(length)만큼 붙혀서 String 형으로 리턴.
*	mysql의 zerofill 과 같음.
*/
	public static String zeroFill(int length, String str) {
		String returnValue;
	
		if(str.length() >= length) returnValue = str;
		else {
			int loopcnt = length - str.length();
			StringBuffer strbfr = new StringBuffer(length);
	
			for(int i=0; i<loopcnt; i++) {
				strbfr.append("0");
			}
			strbfr.append(str);
			returnValue = strbfr.toString();
		}
	
		return returnValue;
	}
	
	/*
	*	매개변수에 문자열 "0"을 원하는 길이(length)만큼 붙혀서 String 형으로 리턴.
	*	mysql의 zerofill 과 같음.
	*/
	public static String zeroFill(int length, int intstr) {
		String returnValue;
		Integer objInt = new Integer(intstr);
		String str = objInt.toString();
	
		if(str.length() >= length) returnValue = str;
		else {
			int loopcnt = length - str.length();
			StringBuffer strbfr = new StringBuffer(length);
	
			for(int i=0; i<loopcnt; i++) {
				strbfr.append("0");
			}
			strbfr.append(str);
			returnValue = strbfr.toString();
		}
	
		return returnValue;
	}
	

	public static boolean getEnableExtension(String extension, String strType){
		if(extension == null || extension.length()<= 0 || extension.equals("") || extension.equals("null")){
			return false;
		}
		if(strType.equals("thumbnail")){
			if(extension.toUpperCase().equals("JPG") ||
					extension.toUpperCase().equals("BMP") ||
					extension.toUpperCase().equals("JPEG") ||
					extension.toUpperCase().equals("TIF") ||
					extension.toUpperCase().equals("GIF") ||
					extension.toUpperCase().equals("TIFF") ||
					extension.toUpperCase().equals("PNG")){
				return true;
				
			}else{
				return false;
			}
		}else{
			if(!extension.toUpperCase().equals("JSP") ||
					!extension.toUpperCase().equals("PHP") ||
					!extension.toUpperCase().equals("CGI") || 
					!extension.toUpperCase().equals("CPL") ||
					!extension.toUpperCase().equals("DCP") ||
					!extension.toUpperCase().equals("DRV") ||
					!extension.toUpperCase().equals("EML") ||
					!extension.toUpperCase().equals("HTA") ||
					!extension.toUpperCase().equals("ASP") ||
					!extension.toUpperCase().equals("ASPX") ||
					!extension.toUpperCase().equals("EXE") || 
					!extension.toUpperCase().equals("COM") || 
					!extension.toUpperCase().equals("DLL") ||
					!extension.toUpperCase().equals("LNK") ||
					!extension.toUpperCase().equals("OCX") ||
					!extension.toUpperCase().equals("JS") ||
					!extension.toUpperCase().equals("BIN") ||
					!extension.toUpperCase().equals("AS") || 
					!extension.toUpperCase().equals("PL") ||
					!extension.toUpperCase().equals("BAK") ||
					!extension.toUpperCase().equals("PHP3") ||
					!extension.toUpperCase().equals("SWF") ||
					!extension.toUpperCase().equals("VBS") ||
					!extension.toUpperCase().equals("SQL") ||
					!extension.toUpperCase().equals("URL") ||
					!extension.toUpperCase().equals("HTML") ||
					!extension.toUpperCase().equals("HTM") ||
					!extension.toUpperCase().equals("XML") ||
					!extension.toUpperCase().equals("BAT") ||
					!extension.toUpperCase().equals("MSI") || 
					!extension.toUpperCase().equals("CLASS") ||
					!extension.toUpperCase().equals("SH")){
				return true;
			}
		}
		return false;

	}
	
	/*
	 * boolean 
	 * param: String
	 * 값 없거나 null 이면 true 
	 */
	public static boolean emptyCheck(String str){
		
		boolean check = true;
		
		if (str != null && !str.equals("") && str.length() > 0) {
			check = false;
		}
		
		return check;
	}
	
	/*
	 * String 
	 * param: String
	 * 입력값값이 not null이고 특수문자가 있어면  html 코드값으로 변경해서 리턴 
	 */
	public static String getValue(String value){
		 
    	if (value != null && value.length() > 0 && !value.equals("null")) {
    	
	    	value = value
	    	.replaceAll("&","&amp;")
	    	.replaceAll("#","&#35;")
	    	.replaceAll("\"","&#34;")
	    	.replaceAll("<","&lt;")
	    	.replaceAll(">","&gt;")
			.replaceAll("`","&#39;")			
			.replaceAll("′","&#39;")
			.replaceAll("'","&#39;")
			.replaceAll("’","&#39;")
			.replaceAll("‘","&#39;")
			.replaceAll("%","&#37;")
	    	.replaceAll("\\(","&#40;")
	    	.replaceAll("\\)","&#41;");
	    	
	    	return value;
    	} else {
    		return "";
    	}
    }
	
	
	/*
	 * String 
	 * param: String
	 * 입력값값이 not null이고 특수문자가 있어면  html 코드값으로 변경해서 리턴 
	 */
	public static String getValueMiddot(String value){
		 
    	if (value != null && value.length() > 0 && !value.equals("null")) {
    	
	    	value = value
	    	.replaceAll("∙","&#183;");
	    	 
	    	
	    	return value;
    	} else {
    		return "";
    	}
    }
	
	
	/*
	 * String 
	 * param: String
	 * 입력값값이 not null이고 특수문자가 있어면  빈('')값으로 변경해서 리턴 
	 */
	public static String getValueNull(String value){
		 
    	if (value != null && value.length() > 0 && !value.equals("null")) {
    	
	    	value = value
	    	.replaceAll("&","")
	    	.replaceAll("#","")
	    	.replaceAll("\"","")
	    	.replaceAll("<","")
	    	.replaceAll(">","")
			.replaceAll("`","")			
			.replaceAll("′","")
			.replaceAll("'","")
			.replaceAll("’","")
			.replaceAll("‘","")
			.replaceAll("%","")
	    	.replaceAll("\\(","")
	    	.replaceAll("\\)","");
	    	
	    	return value;
    	} else {
    		return "";
    	}
    }
	
	/*
	 * Boolean
	 * parma: String
	 * 입력받은 값이 숫자인체크 해서 숫자형이면 true
	 * 
	 */
	public static boolean isNumber(String arg)
	{
		if(arg == null || arg.equals("")){
			return false;
		}

		boolean isNumber = true;
		for( int i=0; i < arg.length() ; i++ ){
			char a=arg.charAt(i);
			if( !Character.isDigit(a) ){
				isNumber = false;
				break;
			}
		}
		return isNumber;
	}
	
	/*
	 * Boolean
	 * parma: String
	 * 입력받은 값이 영상코드인지 확인
	 * 13자리 숫자형 이면 true
	 * 
	 */
	public static boolean isOcode(String arg)
	{
		if(arg == null || arg.equals("")){
			return false;
		}

		boolean isNumber = true;
		if (arg.length() != 17) {
			return false;
		}
		for( int i=0; i < arg.length() ; i++ ){
			char a=arg.charAt(i);
			if( !Character.isDigit(a) ){
				isNumber = false;
				break;
			}
		}
		
		return isNumber;
	}
	
	
	public static boolean isFileCheck(String arg)
	{
		if(arg == null || arg.equals("")){
			return false;
		}

		boolean isValue = false;
		 String checkValue[] = { "video/", "audio/", "image/" ,"application/pdf","application/msword","application/vnd.ms-excel","application/vnd.ms-powerpoint"};
		for( int i=0; i < checkValue.length ; i++ ){ 
			if( arg.startsWith(checkValue[i])  ){
				isValue = true;
			}  
		}
		return isValue;
	}
	
	public static boolean isFileImage(String arg)
	{
		if(arg == null || arg.equals("")){
			return false;
		}
		if (arg.startsWith("image")) {
			 return true;
		} else {
			 return false;
		}
	}
	
	public static boolean isFileNameCheck(String arg)
	{
		if(arg == null || arg.equals("")){
			return false;
		} else {
			arg = arg.toLowerCase();
		}
 
		boolean isValue = false;
		 String checkValue[] = { ";", "%00", "%zz"};
		for( int i=0; i < checkValue.length ; i++ ){ 
			if( arg.indexOf(checkValue[i]) > 0  ){
				isValue = false;
			}  else {
				
				 	int fileIndex = StringUtils.lastIndexOf(arg, '.');
				 	 String checkName[] = { "zip", "pdf","png", "jpg", "jpeg", "gif", "bmp", "psd","tiff", "avi", "f4v", "jpgv","m4v","asf","wmv","mp4","ogv","webm","movie", "m3u", "wma", "wax", "mpga", "mp4a", "weba", "mp3", "doc", "docx", "xls","xlsx", "ppt","pptx","hwp"};
				 	 
			        // 파일명과 확장자를 분리
			        if (fileIndex != -1) {
			            String extension = StringUtils.substring(arg, fileIndex + 1);
			            
			            for( int j=0; j < checkName.length ; j++ ){ 
			            	if (extension.equals(checkName[j])) {
			            		isValue = true;
			            	}
			            }
			        }  
			}
		}
 	
		return isValue;
	}
	
	public static boolean isFileNameCheckPDF(String arg)
	{
		if(arg == null || arg.equals("")){
			return false;
		} else {
			arg = arg.toLowerCase();
		}

		boolean isValue = false;
		 String checkValue[] = { ";", "%00", "%zz"};
		for( int i=0; i < checkValue.length ; i++ ){ 
			if( arg.indexOf(checkValue[i]) > 0  ){
				isValue = false;
			}  else {
				
				 	int fileIndex = StringUtils.lastIndexOf(arg, '.');
				 	 
			        // 파일명과 확장자를 분리
			        if (fileIndex != -1) {
			            String extension = StringUtils.substring(arg, fileIndex + 1);
			    
			            	if (extension.equals("pdf")) {
			            		isValue = true;
			            	}
			        
			        }  
			}
		}
		return isValue;
	}
	
	
	
	public static String getContent(String context, String html ){
		String temp = context;
 
		if(html.equals("false")){
			temp = temp
			.replaceAll("&","&amp;")
	    	.replaceAll("#","&#35;")
	    	.replaceAll("\"","&#34;")
	    	.replaceAll("<","&lt;")
	    	.replaceAll(">","&gt;")
	    	.replaceAll("%","&37;")
	    	.replaceAll("‘","&#39;")
			.replaceAll("`","&#39;")			
			.replaceAll("′","&#39;")
			.replaceAll("'","&#39;")
			.replaceAll("’","&#39;")
			.replaceAll("‘","&#39;")
			.replaceAll(";","&#59")
			.replaceAll("'","&#39;")
	    	.replaceAll("\\(","&#40;")
	    	.replaceAll("\\)","&#41;");
		} else {
			temp = temp
			.replaceAll("&amp;","&")
			.replaceAll("&quot;","'")
	    	.replaceAll("&#35;","#")
	    	.replaceAll("&#34;","\"")
	    	.replaceAll("&lt;","<")
	    	.replaceAll("&gt;",">")
	    	.replaceAll("&#39;","'")
	    	.replaceAll("&#37;","%")
	    	.replaceAll("&#40;","\\(")
	    	.replaceAll("&#41;","\\)");

			
		}
 
			int pos;
			pos = 0;
			while((pos = temp.indexOf("\n")) != -1) {
				String left = temp.substring(0, pos);
				String right = temp.substring(pos + 1, temp.length());
				temp = left + "<br>" + right;
			}
		
		return temp;
	 }
	 
	

	/**
	 * Base64Encoding 방식으로 바이트 배열을 아스키 문자열로 인코딩한다.
	 *
	 * @param strOrgin 대상 문자열
	 * @return 인코딩된 아스키 문자열
	 */
	public static String encode(String strOrgin) {
		byte[] encodeBytes = strOrgin.getBytes();
		byte[] buf = null;
		String strResult = null;

		BASE64Encoder base64Encoder = new BASE64Encoder();
		ByteArrayInputStream bin = new ByteArrayInputStream(encodeBytes);
		ByteArrayOutputStream bout = new ByteArrayOutputStream();

		try {
			base64Encoder.encodeBuffer(bin, bout);

		} catch (Exception e) {
			System.out.println("Exception encoding");
			e.printStackTrace();
		}

		buf = bout.toByteArray();
		strResult = new String(buf).trim();

		return strResult;
	}

	/**
	 * Base64Encoding 방식으로 아스키 문자열을 바이트 배열로 디코딩한다.
	 * 
	 * @param strDecode 대상 문자열
	 * @return 디코딩된 바이트 배열
	 */
	public static String decode(String strDecode) {
		byte[] buf = null;

		BASE64Decoder base64Decoder = new BASE64Decoder();
		ByteArrayInputStream bin = new ByteArrayInputStream(
				strDecode.getBytes());
		ByteArrayOutputStream bout = new ByteArrayOutputStream();

		try {
			base64Decoder.decodeBuffer(bin, bout);
		} catch (Exception e) {
			System.out.println("Exception decoding");
			e.printStackTrace();
		}

		buf = bout.toByteArray();
		return new String(buf);
	}

	/**
	 * 주어진 parameter Object가 Null이면 공백문자를 반환한다.
	 * 
	 * @param parameter Object
	 * @return  String
	 */
	public static String toString(Object parameter) {
		return (parameter == null) ? "" : parameter.toString();
	}

	/**
	 * 주어진 parameter Object가 Null이면 대체문자열(replacement)을 반환한다.
	 * 
	 * @param parameter Object
	 * @param replacement Null인경우 대체문자열
	 * @return  String
	 */
	public static String toString(Object parameter, String replacement) {
		return (parameter == null) ? replacement : parameter.toString();
	}
	
	/**
	 * 주어진 key에 해당하는 value를 반환한다.
	 * 
	 * @param map 대상Map
	 * @param key Key값
	 * @param defaultValue 데이터가 없는 경우 기본값
	 * @return Value
	 */
	public static String getMapValue(Map map, String key, String defaultValue) {
		if (map == null)
			return "";
		Object value = map.get(key);
		if (value == null)
			return defaultValue;
		if (StringUtils.isEmpty("" + value))
			return defaultValue;
		return "" + value;
	}
	
	

	/**
	 * 주어진 userString, type에 해당하는 문서 Owner 문자열을 조회한다.
	 *
	 * @param userString 사용자 목록 문자열
	 * @param type 문서 Owner 유형
	 * @return 문서 Owner 문자열
	 */
	public static String getOwners(String userString, String type) {
		StringBuffer ownersStr = new StringBuffer();
		if (userString != null && userString.length() > 0) {
			String[] users = TextUtil.toString(userString).split("\n");
	
			if (users != null) {
				for (int i = 0; i < users.length; i++) {
					String user = users[i];
	
					if (!"".equals(user)) {
						// userNm + "(" + userId + ")"로 되어있는 userString에서 id 또는
						// name을 조회한다. (문서 Owner의 양식에 맞게 변경)
						if ("name".equals(type)) {
							ownersStr.append(user.substring(0, user.indexOf("(")));
						} else if ("id".equals(type)) {
							ownersStr.append(user.substring(user.indexOf("(") + 1,
									user.indexOf(")")));
						}
	
						if (i + 1 != (users.length))
							ownersStr.append(",");
					} // end if !"".equals(user)
				} // end for i
			} // end if users != null

		} 
		return ownersStr.toString();
	}
	
 

}
