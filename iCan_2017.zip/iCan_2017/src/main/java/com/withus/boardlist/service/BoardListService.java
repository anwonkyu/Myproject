package com.withus.boardlist.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;

import com.withus.boardlist.dao.BoardListVO;
 
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;

/**
 * @Class Name : BoardListService.java
 * @Description : BoardList Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface BoardListService  {
	
	/**
	 * board_list을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BoardListVO
	 * @return 등록 결과
	 * @exception Exception
	 */
	@Transactional
	int insertBoardList(BoardListVO vo) throws Exception;
    
    /**
	 * board_list을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BoardListVO
	 * @return void형
	 * @exception Exception
	 */
	@Transactional
    int updateBoardList(BoardListVO vo) throws Exception;
    
    /**
	 * board_list을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BoardListVO
	 * @return void형 
	 * @exception Exception
	 */
	@Transactional
    int deleteBoardList(BoardListVO vo) throws Exception;
    
    /**
	 * board_list을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BoardListVO
	 * @return 조회한 board_list
	 * @exception Exception
	 */
    BoardListVO selectBoardList(int listId) throws Exception;
    BoardListVO selectBoardListVodman(int listId) throws Exception;
    BoardListVO selectCheckRow(int listRef , int listReLevel, int listStep) throws Exception;

    /**
	 * board_list 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return board_list 목록
	 * @exception Exception
	 */
    ArrayList<BoardListVO> selectBoardListList(int boardId, String searchFild, String searchWord, int start, int end ) throws Exception;
    ArrayList<BoardListVO> selectBoardListList(int boardId, String searchFild, String searchWord, int start, int end, String selectCode ) throws Exception;
    ArrayList<BoardListVO> selectBoardListListVodman(int boardId, String searchFild, String searchWord, int start, int end, String hcode ) throws Exception;
    
    /**
	 * board_list 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return board_list 총 갯수
	 * @exception
	 */
    int selectBoardListListTotCnt(int boardId, String searchFild, String searchWord );
    int selectBoardListListTotCnt(int boardId, String searchFild, String searchWord, String selectCode );
    int selectBoardListListTotCntVodman(int boardId, String searchFild, String searchWord, String hcode);
 
   
	ArrayList<BoardListVO> selectBoardListList_notice(Integer boardId) throws Exception;

	/*
	 * 게시판 조회수 증가
	 */
	void updateReadCount(Integer listId);
	
	
	int deleteBoardListId(Integer boardId) throws Exception;
	
 
	/*
	 * 답글 등록
	 */
	@Transactional
	int insertBoardListReply(BoardListVO vo) throws Exception;

	BoardListVO getNextBoard(Integer listId, String searchFild,
			String searchWord);

	BoardListVO getPrevBoard(Integer listId, String searchFild,
			String searchWord);

	int pwdCheck(String listPasswd, Integer listId);

	int dupCheck(String userId, Integer listId);

	ArrayList<BoardListVO> selectNotice_limit(String boardId, Integer limit);

	boolean fileCheck(String ocode, int userLevel)  throws Exception;

	int selectBoardListListTotCntAll(String searchFild, String searchWord);

	ArrayList<BoardListVO> selectBoardListListAll(String searchFild,
			String searchWord, int start, int end ) throws Exception;
	
	ArrayList<BoardListVO> selectBoardListListAll(String searchFild,
			String searchWord, int start, int end, String selectCode) throws Exception;

	int selectInDept(String doc_type, String nowyear, String h_name,
			String mode, String create_num)throws Exception;
}
