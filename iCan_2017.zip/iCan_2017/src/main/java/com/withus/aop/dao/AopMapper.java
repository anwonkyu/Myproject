package com.withus.aop.dao;

import java.util.HashMap;
 
import org.springframework.stereotype.Repository;
 
@Repository(value="aopMapper")
public interface AopMapper {

	public void pageCnnCnt(HashMap<String, String> hashmap) ;
}
