package com.old.test;

import java.util.List;
 
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.View;

import com.old.test.dao.TestVo;
import com.old.test.service.TestService;
import com.thoughtworks.xstream.XStream;
import com.withus.commons.WebContants;
import com.withus.commons.XmlResult;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
 

import com.withus.member.dao.MemberVo;

import org.springframework.oxm.xstream.XStreamMarshaller;

 
@Controller
@RequestMapping("/test")
public class TestColtroller {

private static final Logger logger = LoggerFactory.getLogger(TestColtroller.class);
	
	@Autowired
	private TestService testService;
	
	@Autowired Properties prop;
	
	@Resource
	private PagingHelperService page;
	

	@Resource(name = "xstreamMarshaller")
	private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView;

	
//	@RequestMapping(value="/login.do", method=RequestMethod.GET)
//	public String login(){
//		return "/member/login";		
//	}
	
	@RequestMapping(value="/test.do", method=RequestMethod.GET)
	public String test() throws Exception{

		TestVo testVo = testService.test();
		
		System.out.println("aaaaaaaaaaa:"+testVo.toString());
		return "/test/test";		
	}
	
	// 일반 로그인 사용 (스프링 시큐리티사용시 적용하면 오류)
	 
}
