package com.withus.commons;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.mail.internet.MimeMessage;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
 
import org.springframework.core.io.InputStreamSource;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.withus.member.dao.MemberVo;
import com.withus.member.service.MemberService;
 
@Controller
@RequestMapping("/email")
public class SendEmailController {
	
	@Autowired Properties mailProp;
	
    @Autowired
    private JavaMailSender mailSender; 
    
    @Autowired
	private MemberService memberService;
    
    @RequestMapping(value = "/emailForm.do",  method = {RequestMethod.GET, RequestMethod.POST})
    public String emailForm( Model model) throws Exception  {
      return "/vodman/email/emailForm";
   }
    
    @RequestMapping(value = "/emailAttachForm.do",  method = {RequestMethod.GET, RequestMethod.POST})
    public String emailAttachForm( Model model) throws Exception  {
      return "/vodman/email/emailAttachForm";
   }
    
 
    @RequestMapping(value="/send.do", method = RequestMethod.POST) 
    public String doSendEmail(HttpServletRequest request) {
        // takes input from e-mail form
        String mailTo = request.getParameter("mailTo");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");
         
        // prints debug info
//        System.out.println("To: " + mailTo);
//        System.out.println("Subject: " + subject);
//        System.out.println("Message: " + message);
         
        // creates a simple e-mail object
        SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(mailTo);
        email.setSubject(subject);
        email.setText(message);
        email.setFrom(mailProp.getProperty("mail.username"));
        // sends the e-mail
        mailSender.send(email);
         
        // forwards to the view named "Result"
        return "/sendMail";
    }
    
 
    @RequestMapping(value="/sendAttach.do", method = RequestMethod.POST) 
    public String sendEmail(HttpServletRequest request,
            final @RequestParam CommonsMultipartFile attachFile) {
 
        // reads form input
        final String emailTo = request.getParameter("mailTo");
        final String subject = request.getParameter("subject");
        final String message = request.getParameter("message");
 
        // for logging
//        System.out.println("emailTo: " + emailTo);
//        System.out.println("subject: " + subject);
//        System.out.println("message: " + message);
//        System.out.println("attachFile: " + attachFile.getOriginalFilename());
 
        mailSender.send(new MimeMessagePreparator() {
 
            @Override
            public void prepare(MimeMessage mimeMessage) throws Exception {
                MimeMessageHelper messageHelper = new MimeMessageHelper(
                mimeMessage, true, "UTF-8");
                messageHelper.setTo(emailTo);
                messageHelper.setSubject(subject);
                messageHelper.setText(message);
                messageHelper.setFrom(mailProp.getProperty("mail.username")); 
                // determines if there is an upload file, attach it to the e-mail
                String attachName = attachFile.getOriginalFilename();
                if (!attachFile.equals("")) {
 
                    messageHelper.addAttachment(attachName, new InputStreamSource() {
                         
                        @Override
                        public InputStream getInputStream() throws IOException {
                            return attachFile.getInputStream();
                        }
                    });
                }
                 
            }
 
        });
 
        return "/sendMail";
    }
    
    

    @RequestMapping(value = "/PwdFind.do",  method = {RequestMethod.GET, RequestMethod.POST})
    public String PwdFind() throws Exception  {
      return "/member/sendMailPwd";
   }
    
    @RequestMapping(value="/pwdCheck.do", method = RequestMethod.POST) 
    @Transactional
    public String pwdChange(
    		@RequestParam(value="userId" ,required=true)String userId ,
    		@RequestParam(value="userName" ,required=true)String userName , 
    		@RequestParam(value="userEmail" ,required=true)String userEmail ,
    		Model model) throws Exception {
        // takes input from e-mail form
    	
    	
    	MemberVo thisMember = memberService.findMemberId(userId, userName, userEmail);
    	
    	char[] word = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
    	char[] num = {'1','2','3','4','5','6','7','8','9','0'};
    	
    	String secWords = "";
    	
    	for (int i = 0; i < 6; i++) {
    		if (i % 2 == 0) {
    			int n = (int)(Math.random() * 25);
    			secWords += word[n];
    		} else {
    			int n = (int)(Math.random() * 9);
    			secWords += num[n];
    		}
    	} 
    	
    	String returnUrl = "/member/sendMailPwd";
    	System.out.println("초기화---::::"+secWords);    
    	try{
    	if ( memberService.pwdUpdate(thisMember.getId(), secWords) > 0) {
    	 
        String mailTo = thisMember.getEmail();
        String subject = "비밀번호 초기화 안내";
        String message = "변경된 비밀번호는 ("+secWords+") 입니다. 로그인후 변경하세요!";
         
        // prints debug info
//        System.out.println("To: " + mailTo);
//        System.out.println("Subject: " + subject);
//        System.out.println("Message: " + message);
         
        // creates a simple e-mail object
        SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(mailTo);
        email.setSubject(subject);
        email.setText(message);
        email.setFrom(mailProp.getProperty("mail.username"));
        // sends the e-mail
        mailSender.send(email);
        
        returnUrl = "/member/sendMailPwd";
        
        model.addAttribute("thisMember", thisMember);
      
    	}
    } catch (Exception e) {
    	System.out.println(e);
    	returnUrl = "/error/mailError";
    	
    }    
        // forwards to the view named "Result"
        return returnUrl;
    }
    
    
    @RequestMapping(value = "/IdFind.do",  method = {RequestMethod.GET, RequestMethod.POST})
    public String IdFind() throws Exception  {
      return "/member/sendMailId";
   }
    
    @RequestMapping(value="/IdCheck.do", method = RequestMethod.POST) 
    public String IdFind(@RequestParam(value="userName" ,required=true)String userName, @RequestParam(value="userEmail" ,required=true)String userEmail,
    		Model model) throws Exception {
        // takes input from e-mail form 
 
    	MemberVo thisMember = memberService.findMember(userName, userEmail);
 
   
        String mailTo = thisMember.getEmail();
        String subject = "아이디 안내";
        String message = "요청하신 사이트 아이디는 ("+thisMember.getId()+") 입니다.";
         
        // prints debug info
//        System.out.println("To: " + mailTo);
//        System.out.println("Subject: " + subject);
//        System.out.println("Message: " + message);
         
        // creates a simple e-mail object
        SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(mailTo);
        email.setSubject(subject);
        email.setText(message);
        email.setFrom(mailProp.getProperty("mail.username"));
        // sends the e-mail
        mailSender.send(email);
         
        // forwards to the view named "Result"
        
        model.addAttribute("thisMember", thisMember);
        
        return "/member/sendMailId";
    }
    
    
    @RequestMapping(value="/IdFind_hp.do", method = RequestMethod.POST) 
    public String IdFindReturn(@RequestParam(value="userName" ,required=true)String userName, @RequestParam(value="hp" ,required=true)String hp,
    		Model model) throws Exception {
        // takes input from e-mail form 
 
    	MemberVo thisMember = memberService.findMemberId_Hp(userName, hp);
        
    	if (thisMember != null && thisMember.getId().length() > 0) {
    		model.addAttribute("thisMember", thisMember);
    	} else {
    		thisMember = new MemberVo();
    		thisMember.setId("none");
    		model.addAttribute("thisMember", thisMember);
    	}
        
        return "/member/sendMailId";
    }
    
    
}