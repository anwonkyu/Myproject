package com.withus.category.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 









import com.withus.category.dao.CategoryVO;
 
 

/**
 * @Class Name : CategoryDAO.java
 * @Description : Category DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2011-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("categoryMapper")
public interface CategoryMapper {

	/**
	 * category을 등록한다.
	 * @param vo - 등록할 정보가 담긴 CategoryVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertCategory(CategoryVO vo) throws Exception ;

    /**
	 * category을 수정한다.
	 * @param vo - 수정할 정보가 담긴 CategoryVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateCategory(CategoryVO vo) throws Exception;

    /**
	 * category을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 CategoryVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteCategory(int cuid) throws Exception ;

    /**
	 * category을 조회한다.
	 * @param vo - 조회할 정보가 담긴 CategoryVO
	 * @return 조회한 category
	 * @exception Exception
	 */
    public CategoryVO selectCategory(int cuid) throws Exception ;

    /**
	 * category 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return category 목록
	 * @exception Exception
	 */
    public ArrayList<CategoryVO> selectCategoryList(String ccode, String ctype) throws Exception ;
    
    /*
     * ccode 에 해당하는 카테고리 하나만 가져 온다
     */
    public CategoryVO selectOneCategory(HashMap<String, String> hashmap) throws Exception ;

    /**
	 * category 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return category 총 갯수
	 * @exception
	 */
    public int selectCategoryListTotCnt(String ccode, String ctype) ;
    
    public ArrayList<CategoryVO> selectCategoryList_child(HashMap<String, String> hashmap) throws Exception ;

	//카테고리 이름 리턴
	public String getCateNm(HashMap<String, String> hashmap);

	public String getDeptCode(HashMap<String, String> hashmap);
	
	public ArrayList<CategoryVO> selectCategoryList_cinfo( HashMap<String, String> hashmap);
	
	public ArrayList<CategoryVO> selectCategoryList_open( HashMap<String, String> hashmap);
	
	public ArrayList<CategoryVO> selectCategoryList_Count( HashMap<String, String> hashmap);
	
	public ArrayList<CategoryVO> selectCategoryList_Menu(
			HashMap<String, String> hashmap);

	public String getMenuNm(HashMap<String, String> hashmap);

	public String getMenuCode(HashMap<String, String> hashmap);

	public String getMenuCode2(HashMap<String, String> hashmap);

	public ArrayList<CategoryVO> selectCode_flag2(HashMap<String, String> hashmap);

  
}
