package com.withus.logo.dao;

 
import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;
 
import com.withus.logo.dao.LogoVO;
 
/**
 * @Class Name : LogoDAO.java
 * @Description : Logo DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-12-31
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("logoMapper")
public interface LogoMapper {

	/**
	 * logo을 등록한다.
	 * @param vo - 등록할 정보가 담긴 LogoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
  
    public int updateLogo(LogoVO vo) throws Exception ;
 
    public int updateSkin(HashMap<String, String> hashmap) throws Exception ;
    /**
	 * logo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 LogoVO
	 * @return 조회한 logo
	 * @exception Exception
	 */
    public LogoVO selectLogo() throws Exception ;

   

}
