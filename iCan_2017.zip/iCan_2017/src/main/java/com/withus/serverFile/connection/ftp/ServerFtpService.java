package com.withus.serverFile.connection.ftp;
import java.util.ArrayList;
import java.util.HashMap;
 
 
public interface ServerFtpService  {
 
   /*
    * 파일 목록 리턴
    */
 
	public HashMap<String, Object> getFileList(String path) throws Exception;
 
 
}
