package com.withus.calnote.dao;

public class OldFileVO {
	
	private Integer attachSeq   ;
	private String  fileName  ;
	private String  filePath  ;
	private String  extName   ;
	private String  edmsDocId ;
	private String  calnoteId  ;
	private String  regDate  ;
	private String  edmsState ;
	private String  edmsCatId   ;
	private String  edmsRegDate ;
	private String  fileDivCd  ;
	private String  saveDivCd   ;
	private String  linkUrl   ;
	private String  saveName  ;
	private String  fileSize ;
	public Integer getAttachSeq() {
		return attachSeq;
	}
	public void setAttachSeq(Integer attachSeq) {
		this.attachSeq = attachSeq;
	}
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getExtName() {
		return extName;
	}
	public void setExtName(String extName) {
		this.extName = extName;
	}
	public String getEdmsDocId() {
		return edmsDocId;
	}
	public void setEdmsDocId(String edmsDocId) {
		this.edmsDocId = edmsDocId;
	}
	public String getCalnoteId() {
		return calnoteId;
	}
	public void setCalnoteId(String calnoteId) {
		this.calnoteId = calnoteId;
	}
	public String getRegDate() {
		return regDate;
	}
	public void setRegDate(String regDate) {
		this.regDate = regDate;
	}
	public String getEdmsState() {
		return edmsState;
	}
	public void setEdmsState(String edmsState) {
		this.edmsState = edmsState;
	}
	public String getEdmsCatId() {
		return edmsCatId;
	}
	public void setEdmsCatId(String edmsCatId) {
		this.edmsCatId = edmsCatId;
	}
	public String getEdmsRegDate() {
		return edmsRegDate;
	}
	public void setEdmsRegDate(String edmsRegDate) {
		this.edmsRegDate = edmsRegDate;
	}
	public String getFileDivCd() {
		return fileDivCd;
	}
	public void setFileDivCd(String fileDivCd) {
		this.fileDivCd = fileDivCd;
	}
	public String getSaveDivCd() {
		return saveDivCd;
	}
	public void setSaveDivCd(String saveDivCd) {
		this.saveDivCd = saveDivCd;
	}
	public String getLinkUrl() {
		return linkUrl;
	}
	public void setLinkUrl(String linkUrl) {
		this.linkUrl = linkUrl;
	}
	public String getSaveName() {
		return saveName;
	}
	public void setSaveName(String saveName) {
		this.saveName = saveName;
	}
	public String getFileSize() {
		return fileSize;
	}
	public void setFileSize(String fileSize) {
		this.fileSize = fileSize;
	}
	@Override
	public String toString() {
		return "OldFileVO [attachSeq=" + attachSeq + ", fileName=" + fileName
				+ ", filePath=" + filePath + ", extName=" + extName
				+ ", edmsDocId=" + edmsDocId + ", calnoteId=" + calnoteId
				+ ", regDate=" + regDate + ", edmsState=" + edmsState
				+ ", edmsCatId=" + edmsCatId + ", edmsRegDate=" + edmsRegDate
				+ ", fileDivCd=" + fileDivCd + ", saveDivCd=" + saveDivCd
				+ ", linkUrl=" + linkUrl + ", saveName=" + saveName
				+ ", fileSize=" + fileSize + "]";
	}
	
	
	
}
