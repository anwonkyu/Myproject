package com.withus.commons.paging;

public class PagingHelper {
	private int firstPage; // 첫번째 페이지 번호 (현제블럭의 첫페이지번호)
	private int lastPage2; // 마지막 페이지 번호 (현제블럭의 마지막페이지번호)
	private int lastPage; // 마지막 페이지 번호 --> 전체 페이지 카운트로변경
 
	private int prevLink; // [이전] 링크 
	private int nextLink; // [다음] 링크
	private int startRecord; // 목록을 구할때 쓰이는 ROWNUM 시작
	private int endRecord; // 목록을 구할때 쓰이는 ROWNUM 끝
	private int listNo; // 목록에서 위에서 순서대로 붙여지는 번호
	private int[] pageLinks; // 첫번쩨 페이지 번호부터 시작하여 1씩 증가하여 마지막 페이지번호까지 int[] 배열 

	public PagingHelper(int totalRecord, int curPage, int numPerPage, int pagePerBlock) { //totalRecord : 1 , curpage : 1 ,numPerPage : 10, pagePerBlock: 10
		int totalPage = ((totalRecord % numPerPage) == 0) ? 
			totalRecord / numPerPage : totalRecord / numPerPage + 1;
		int totalBlock = ((totalPage % pagePerBlock) == 0) ? 
			totalPage / pagePerBlock : totalPage / pagePerBlock + 1;
//		if(numPerPage >=numPerPage){
//			totalBlock = totalBlock+1;
//		}
		//int sortNum = ((numPerPage / 10 == 0) ? 1 : (numPerPage / 10));
 
		int sortNum = ((pagePerBlock/ numPerPage   == 0) ? 1 : (pagePerBlock / numPerPage   ));		
		int block = ((curPage % (pagePerBlock/(sortNum))) == 0) ? curPage / (pagePerBlock/(sortNum)) : curPage / (pagePerBlock/(sortNum)) + 1;
		this.firstPage = (block - 1) * pagePerBlock/(sortNum) + 1;
		this.lastPage2 = block * pagePerBlock /(sortNum);		
		
		if (block >= totalBlock) {
			this.lastPage2 = totalPage;
		}
		
		
		pageLinks = makeArray(firstPage, lastPage2);
		if (block > 1) {
			this.prevLink = firstPage - 1;
		}
		if (block < totalBlock) {
			this.nextLink = lastPage2 + 1;
		}
System.out.println("sortNum:"+sortNum+"block:"+block+"totalblock:"+totalBlock+"firstPage:"+firstPage+"lastPage:"+lastPage2+"nextLink:"+nextLink);		
		this.listNo = totalRecord - (curPage - 1) * numPerPage;
		//this.startRecord = (curPage - 1) * numPerPage + 1;  // oracle
		//this.endRecord = startRecord + numPerPage - 1;      // oracle
		this.startRecord = numPerPage ;   				   //mysql (limit)
		this.endRecord = (curPage - 1) * numPerPage;       //mysql ( offset)
		
		this.lastPage=totalPage;
	}
	 
	
	private int[] makeArray(int first, int last) {
		int size = last - first + 1;
		int[] ret = new int[size]; 
		for (int i = 0; i < size; i++) {
			ret[i] = first++;
		}
		
		return ret;
	}

	public int getFirstPage() {
		return firstPage;
	}

	public int getLastPage() {
		return lastPage;
	}

	public int getPrevLink() {
		return prevLink;
	}

	public int getNextLink() {
		return nextLink;
	}

	public int getStartRecord() {
		return startRecord;
	}

	public int getEndRecord() {
		return endRecord;
	}

	public int getListNo() {
		return listNo;
	}

	public int[] getPageLinks() {
		return pageLinks;
	}

	public int getLastPage2() {
		return lastPage2;
	}
	

	
}