package com.withus.secured.service;

import java.util.ArrayList;
import java.util.List;
 





import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;

import com.withus.secured.dao.SecuredResourcesVO;

/**
 * @Class Name : SecuredResourcesService.java
 * @Description : SecuredResources Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface SecuredResourcesService {
	
	/**
	 * secured_resources을 등록한다.
	 * @param vo - 등록할 정보가 담긴 SecuredResourcesVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    int insertSecuredResources(SecuredResourcesVO vo) throws Exception;
    
    /**
	 * secured_resources을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SecuredResourcesVO
	 * @return void형
	 * @exception Exception
	 */
    int updateSecuredResources(SecuredResourcesVO vo) throws Exception;
    
    /**
	 * secured_resources을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SecuredResourcesVO
	 * @return void형 
	 * @exception Exception
	 */
    int deleteSecuredResources(String resourceId) throws Exception;
    
    /**
	 * secured_resources을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SecuredResourcesVO
	 * @return 조회한 secured_resources
	 * @exception Exception
	 */
    SecuredResourcesVO selectSecuredResources(String resourceId) throws Exception;
    
    /**
	 * secured_resources 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return secured_resources 목록
	 * @exception Exception
	 */
    ArrayList<SecuredResourcesVO> selectSecuredResourcesList() throws Exception;
    
    /**
	 * secured_resources 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return secured_resources 총 갯수
	 * @exception
	 */
    int selectSecuredResourcesListTotCnt();

	int deleteSecuredResourcesAuthority(int seq);
	@Transactional
	int insertSecuredAuthority(MultiValueMap<String, String> params)
			throws Exception;

	ArrayList<SecuredResourcesVO> selectSecuredResourcesAuthorityList(
			String resourceId);
    
}
