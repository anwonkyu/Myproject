package com.withus.webLog.dao;

import java.util.ArrayList;
 
import java.util.HashMap;

import org.springframework.stereotype.Repository;
 

@Repository(value="webLogMapper")
public interface WebLogMapper {

	/**
	 * web_log을 등록한다.
	 * @param vo - 등록할 정보가 담긴 WebLogVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String insertWebLog(WebLogVO vo) throws Exception ;

 
    /**
	 * web_log 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return web_log 목록
	 * @exception Exception
	 */
    public ArrayList<WebLogVO> selectWebLogList(HashMap<String, String> hashmap) throws Exception ;

    /**
	 * web_log 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return web_log 총 갯수
	 * @exception
	 */
    public int selectWebLogListTotCnt(HashMap<String, String> hashmap) ;


	public ArrayList<WebLogVO> selectWebLogListAll( HashMap<String, String> hashmap);

}
