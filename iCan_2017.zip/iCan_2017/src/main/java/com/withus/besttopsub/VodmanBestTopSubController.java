package com.withus.besttopsub;

import java.util.ArrayList;
 
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 
 



import com.withus.besttopsub.service.BestTopSubService;
 
import com.withus.besttopsub.dao.BestTopSubVO;

/**
 * @Class Name : BestTopSubController.java
 * @Description : BestTopSub Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-06
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class VodmanBestTopSubController {

	@Autowired
	private BestTopSubService bestTopSubService;
	
    /**
	 * best_top_sub 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 BestTopSubDefaultVO
	 * @return "/bestTopSub/BestTopSubList"
	 * @exception Exception
	 */
    @RequestMapping(value="/best/bestList.do")
    public String selectBestTopSubList(@RequestParam(value="btiId",required=true) Integer btiId, ModelMap model)
            throws Exception { 
    	if (btiId == null) return null;
        ArrayList<BestTopSubVO> bestTopSubList = bestTopSubService.selectBestTopSubList(btiId);
        model.addAttribute("bestList", bestTopSubList);
        
        return "/vodman/best/bestList";
    } 
    
	@RequestMapping(value="/best/addBest.do", method=RequestMethod.GET)
    public String addBestTopSubView( Model model)
            throws Exception {
        return "/vodman/best/bestForm";
    }
    
	@RequestMapping(value="/best/addBest.do", method=RequestMethod.POST)
    public String addBestTopSub(
            BestTopSubVO bestTopSubVO)
            throws Exception {
		
		//System.out.println(bestTopSubVO.toString());
        bestTopSubService.insertBestTopSub(bestTopSubVO); 
        return "forward:/vodman/best/bestList.do";
    }
	
	@RequestMapping(value="/best/addBest2.do", method=RequestMethod.POST)
    public String addBestTopSub2(@RequestParam MultiValueMap<String, String> params)
            throws Exception {
	 
		int rtn= bestTopSubService.insertBestTopSub2(params);
		 
        //return "forward:/vodman/best/bestList.do?btiId="+params.get("btiId").get(0);
        return "redirect:/vodman/best/bestList.do?btiId="+params.get("btiId").get(0);
    }
    
    @RequestMapping("/best/bestInfo.do")
    public String updateBestTopSubView(
            @RequestParam(value="btsId",required=true) int btsId ,
            @RequestParam(value="btiId",required=true) int btiId ,
            Model model)
            throws Exception {
        BestTopSubVO bestTopSubVO = new BestTopSubVO();
        bestTopSubVO.setBtsId(btsId);
        bestTopSubVO.setBtiId(btiId);
      
        model.addAttribute(selectBestTopSub(bestTopSubVO ));
        return "/vodman/best/bestInfo.do?bstId="+btsId
        		+"&btiId="+btiId;
    }

    @RequestMapping("/best/selectBest.do")
    public @ModelAttribute("bestTopSubVO")
    BestTopSubVO selectBestTopSub(
            BestTopSubVO bestTopSubVO) throws Exception {
        return bestTopSubService.selectBestTopSub(bestTopSubVO);
    }

    @RequestMapping("/best/updateBest.do")
    public String updateBestTopSub(
            BestTopSubVO bestTopSubVO )
            throws Exception {
        bestTopSubService.updateBestTopSub(bestTopSubVO);
        
        return "forward:/vodman/best/selectBest.do?bstId="+bestTopSubVO.getBtsId()
        		+"&btiId="+bestTopSubVO.getBtiId();
    }
 
}
