package com.withus.taglib;

import java.util.HashMap;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoaderListener;

import com.withus.category.dao.CategoryMapper;
 
public class WithusFunLib  { 
	
	  public static String Ctitle(String ccode, String ctype) throws Exception {
		 
		  return getCtitle(ccode, ctype);
	  }
	 
 
	    public static String getCtitle(String ccode, String ctype) throws Exception {
	    	
	    	ApplicationContext appContext = ContextLoaderListener.getCurrentWebApplicationContext();
	    	CategoryMapper categoryMapper = (CategoryMapper)appContext.getBean("categoryMapper");	 	 
     	
	    	HashMap<String, String> hashmap = new HashMap<String, String>();
			hashmap.put("ccode", ccode);
			hashmap.put("ctype", ctype);
			//System.out.println("CategorySeriveImpl:getCateNm:"+ccode+ctype);
			return categoryMapper.getCateNm(hashmap);
	    }
	    
	    
	    public static String Ctitle2(String ccode, String ctype) throws Exception {
	    	
			  return getCtitle2(ccode, ctype);
		  }
		 
	 
		    public static String getCtitle2(String ccode, String ctype) throws Exception {
		    	
		    	ApplicationContext appContext = ContextLoaderListener.getCurrentWebApplicationContext();
		    	CategoryMapper categoryMapper = (CategoryMapper)appContext.getBean("categoryMapper");	 	 
	    
				
				String return_value = "";
				
				if (ccode != null && ccode.indexOf('/') > 0 ) {
					String[] xcodeArray = ccode.split("/");
					for (String str : xcodeArray ) {
						HashMap<String, String> hashmap = new HashMap<String, String>();
						hashmap.put("ccode", str);
						hashmap.put("ctype", ctype);
						return_value = return_value + " / "+categoryMapper.getCateNm(hashmap);
					}	
				} else {
					HashMap<String, String> hashmap = new HashMap<String, String>();
					hashmap.put("ccode", ccode);
					hashmap.put("ctype", ctype);
					return_value = categoryMapper.getCateNm(hashmap);
				} 
				
				return return_value;
				
		    }
	    
} 
 
 