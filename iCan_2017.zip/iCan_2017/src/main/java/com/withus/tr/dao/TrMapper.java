package com.withus.tr.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository("trMapper")
public interface TrMapper {
	public void insertTr(TrVO trVo) throws Exception;
	
	public ArrayList<TrVO> selectTr(HashMap<String, Object> hashmap) throws Exception;
	
	public int selectTrTotCnt(HashMap<String, String> hashmap) throws Exception;
	
	public TrVO getTr(HashMap<String, String> hashmap) throws Exception;
	
	public TrVO getTrDocId(HashMap<String, String> hashmap) throws Exception;
	
	public int updateTr(TrVO trVo)throws Exception;
	
	public int deleteTr(String trId)throws Exception;
	
	public ArrayList<TrVO> pandingTr(HashMap<String, String> hashmap) throws Exception;
	
	public int pandingTrTotCnt(HashMap<String, String> hashmap) throws Exception;
	
	public ArrayList<TrVO> processedTr(HashMap<String, String> hashmap) throws Exception;
	
	public int processedTrTotCnt(HashMap<String, String> hashmap) throws Exception;
	
	public String lastNumberCheck(HashMap<String, String> hashmap)throws Exception ;
}
