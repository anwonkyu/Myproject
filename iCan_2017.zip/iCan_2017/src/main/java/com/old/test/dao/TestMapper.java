package com.old.test.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
 
@Repository(value="testMapper")
public interface TestMapper {
	
	public TestVo getTest()throws Exception;
	
	 
	
}
