package com.withus.serverFile.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 

import com.withus.serverFile.connection.ftp.ServerFtpConn;
 

 
@Service("serverFileService")
public class ServerFileServiceImpl  implements  ServerFileService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(ServerFileServiceImpl.class);

 
	@Override
	public ArrayList getFileList() throws Exception {
 
		return null;
	}

}
