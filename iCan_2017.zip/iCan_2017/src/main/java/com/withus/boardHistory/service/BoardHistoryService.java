package com.withus.boardHistory.service;

import java.util.ArrayList;

import com.withus.boardHistory.dao.BoardHistoryVO;


public interface BoardHistoryService {

int insertBoardHistory(BoardHistoryVO vo) throws Exception;
	
	ArrayList<BoardHistoryVO> selectBoardHistoryList(String state, String searchFild, String searchWord,int start, int end) throws Exception;
	
	int selectBoardHistoryListTotCnt(String state, String searchFild, String searchWord)throws Exception;
	
	int selectBoardDeleteCnt(int listId)throws Exception;
}
