package com.withus.department.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;


@Repository("departmentMapper")
public interface DepartmentMapper {
public void insertDepartment(DepartmentVO departmentVo) throws Exception ;
	
	public ArrayList<DepartmentVO> selectDepartmentList(HashMap<String, String> hashmap) throws Exception;
	
	public int selectDepartmentListTotCnt(HashMap<String, String> hashmap)throws Exception ;
	
	public int deleteDepartment(String deptCd)throws Exception;
	
	public int updateDepartment(DepartmentVO departmentVo)throws Exception;
	
	public DepartmentVO getDepartment(HashMap<String, String> hashmap) throws Exception;

}
