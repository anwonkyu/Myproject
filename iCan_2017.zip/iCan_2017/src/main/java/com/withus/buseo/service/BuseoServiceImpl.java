package com.withus.buseo.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory; 
import com.withus.buseo.service.BuseoService;
 
import com.withus.buseo.dao.BuseoMapper;
import com.withus.buseo.dao.BuseoVO;
 
import com.withus.commons.paging.PagingHelperServiceImpl;
 
/**
 * @Class Name : BuseoServiceImpl.java
 * @Description : Buseo Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("buseoService")
public class BuseoServiceImpl  implements  BuseoService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(BuseoServiceImpl.class);

    @Resource(name="buseoMapper")
    private BuseoMapper buseoDAO;
      /** ID Generation */
    //@Resource(name="{egovBuseoIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * buseo을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BuseoVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String insertBuseo(BuseoVO vo) throws Exception {
 
    	buseoDAO.insertBuseo(vo);
    	//TODO 해당 테이블 정보에 맞게 수정    	
        return null;
    }

    /**
	 * buseo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BuseoVO
	 * @return void형
	 * @exception Exception
	 */
    public void updateBuseo(BuseoVO vo) throws Exception {
        buseoDAO.updateBuseo(vo);
    }

    /**
	 * buseo을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BuseoVO
	 * @return void형 
	 * @exception Exception
	 */
    public void deleteBuseo(BuseoVO vo) throws Exception {
        buseoDAO.deleteBuseo(vo);
    }

    /**
	 * buseo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BuseoVO
	 * @return 조회한 buseo
	 * @exception Exception
	 */
    public BuseoVO selectBuseo(int binx) throws Exception {
        BuseoVO resultVO = buseoDAO.selectBuseo(binx);
      
        return resultVO;
    }

    /**
	 * buseo 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return buseo 목록
	 * @exception Exception
	 */
    public ArrayList<BuseoVO> selectBuseoList(String searchWord, int start, int end) throws Exception {
    	
    	HashMap<String, String> hashmap = new HashMap<String, String>(); 
    	
    	Integer startRownum = start;
		Integer endRownum = end;
  
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
 
    	 
		hashmap.put("searchWord", searchWord);
        return buseoDAO.selectBuseoList(hashmap);
    }

    /**
	 * buseo 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return buseo 총 갯수
	 * @exception
	 */
    public int selectBuseoListTotCnt( String searchWord) {
    	HashMap<String, String> hashmap = new HashMap<String, String>(); 
   	 
		hashmap.put("searchWord", searchWord);
		return buseoDAO.selectBuseoListTotCnt(hashmap);
	}
 
  

	@Override
	public ArrayList<BuseoVO> selectBuseoListAll() throws Exception {
		 
		return buseoDAO.selectBuseoListAll();
		
	}

}
