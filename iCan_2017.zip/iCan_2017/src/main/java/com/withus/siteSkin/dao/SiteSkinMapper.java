package com.withus.siteSkin.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 


import com.withus.siteSkin.dao.SiteSkinVO;
 
/**
 * @Class Name : SiteSkinDAO.java
 * @Description : SiteSkin DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150323
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("siteSkinMapper")
public interface SiteSkinMapper   {

	/**
	 * site_skin을 등록한다.
	 * @param vo - 등록할 정보가 담긴 SiteSkinVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertSiteSkin(SiteSkinVO vo) throws Exception;

    /**
	 * site_skin을 수정한다.
	 * @param vo - 수정할 정보가 담긴 SiteSkinVO
	 * @return void형
	 * @exception Exception
	 */
    public int updateSiteSkin(SiteSkinVO vo) throws Exception ;

    /**
	 * site_skin을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 SiteSkinVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deleteSiteSkin(int seq) throws Exception ;

    /**
	 * site_skin을 조회한다.
	 * @param vo - 조회할 정보가 담긴 SiteSkinVO
	 * @return 조회한 site_skin
	 * @exception Exception
	 */
    public SiteSkinVO selectSiteSkin(int seq) throws Exception ;

    /**
	 * site_skin 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return site_skin 목록
	 * @exception Exception
	 */
    public ArrayList<?> selectSiteSkinList(HashMap<String, String> hashmap) throws Exception ;

    /**
	 * site_skin 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return site_skin 총 갯수
	 * @exception
	 */
    public int selectSiteSkinListTotCnt();

}
