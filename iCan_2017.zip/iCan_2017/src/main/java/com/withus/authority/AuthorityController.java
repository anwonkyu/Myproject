package com.withus.authority;

import java.util.ArrayList;
 

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
 

import com.withus.authority.service.AuthorityService;
 
import com.withus.authority.dao.AuthorityVO;
 
 

/**
 * @Class Name : AuthorityController.java
 * @Description : Authority Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 20150319
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class AuthorityController {

    @Autowired
    private AuthorityService authorityService; 
    
    @RequestMapping(value="/site/authority.do")
    public String selectAhtuRoleList(
    		ModelMap model)
            throws Exception { 
		
    	ArrayList<AuthorityVO> ahtuRoleList = authorityService.selectAuthorityList(); 
        model.addAttribute("result", ahtuRoleList);
        
        return "/vodman/site/authority";
    } 
    
    @RequestMapping(value="/site/pop_authority.do")
    public String popAuthroity(
    		ModelMap model)
            throws Exception { 
		
    	ArrayList<AuthorityVO> ahtuRoleList = authorityService.selectAuthorityList(); 
        model.addAttribute("result", ahtuRoleList);
        
        return "/vodman/site/pop_authority";
    } 
    
    
    @RequestMapping(value="/site/authorityWrite.do", method=RequestMethod.GET)
	public String write() throws Exception {
    	
    	return "/vodman/site/authWrite";
    }
    
    @RequestMapping(value="/site/authorityWrite.do" , method=RequestMethod.POST)
    public String addAuthority( @ModelAttribute("AuthorityVO") AuthorityVO authorityVo )
            throws Exception {
    	 
    	 authorityService.insertAuthority(authorityVo);
    	 return "redirect:/vodman/site/authority.do";
    }
    
    @RequestMapping(value="/site/authorityUpdate.do" , method=RequestMethod.GET)
    public String updateAuthority(
            @RequestParam(value="authority",required=true)  String authority , Model model)
            throws Exception {
    	AuthorityVO authorityVo = authorityService.selectAuthority(authority);
    	
        model.addAttribute("authorityVo", authorityVo);
       
        return "/vodman/site/authWrite";
    }
    
    @RequestMapping(value="/site/authorityDelete.do" ,method={RequestMethod.GET, RequestMethod.POST})
    public String deleteAuthority(
    		@RequestParam(value="authority",required=true)  String authority )
            throws Exception {
    		authorityService.deleteAuthority(authority);
    		return "redirect:/vodman/site/authority.do";
    } 
    
    
}
