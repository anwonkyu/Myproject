package com.withus.commons.uploadFile.dao;
 
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.withus.commons.uploadFile.service.UploadFileVo;
 
/**
 * @Class Name : BoardListDAO.java
 * @Description : BoardList DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("uploadFileMapper")
public interface UploadFileMapper { 
    
	public int insertAttachFile(UploadFileVo attachFile);

	public List<UploadFileVo> getUploadFileList(HashMap<String, String> hashmap);

	public UploadFileVo getUploadFile(int seq);
	
	public int deleteAttachFile(int seq);

	public int deleteAttachFileAll(HashMap<String, String> hashmap); 
	
	public int deleteSelect(HashMap<String, Object> hashmap );

	public List<UploadFileVo> getUploadFileListType( HashMap<String, String> hashmap);

	public int insertAttachFile2(UploadFileVo attachFile);
	
	public List<UploadFileVo> getUploadFileListReAll(HashMap<String, String> hashmap);
	
}
