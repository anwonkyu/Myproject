package com.withus.member.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
 
@Repository(value="memberMapper")
public interface MemberMapper {
	
	public int insert(MemberVo memberVo)throws Exception;
	
	public int insert2(MemberVo memberVo)throws Exception;
	
	public MemberVo login(@Param("id") String id, @Param("pwd") String pwd );
	
	public int update(MemberVo memberVo);
	
	public void changePwd(MemberVo memberVo);
	
	public void bye(MemberVo memberVo);
	
	public List<MemberVo> getAllMember();
	
	public MemberVo memberInfo(String id);

	public ArrayList<MemberVo> getMemberList(HashMap<String, Object> hashmap);

	public int getTotalRecord(HashMap<String, Object> hashmap)throws Exception ;
	
	public void insertAuthority(@Param("id") String id,	@Param("authority") String authority);

	public void deleteAuthority(String id);
	
	public String selectDept(String id);
	
	public int checkId(String id);

	public int deleteMember(String id);

	public int loginHistory(HashMap<String, String> hashmap);

	public int pwdUpdate(HashMap<String, String> hashmap);

	public int updateApproval(HashMap<String, String> hashmap);

	public int pwdUpdate_user(HashMap<String, String> hashmap);

	public MemberVo findMember(@Param("name") String name, @Param("email") String email );
	
	public MemberVo findMemberId_Hp(@Param("name") String name, @Param("hp") String hp );
	
	public MemberVo findMemberId(@Param("id") String id, @Param("name") String name, @Param("email") String email);
	
	public ArrayList<MemberVo> getMemberListAll(HashMap<String, String> hashmap);

	public ArrayList<MemberVo> questionList_Dcode(HashMap<String, Object> hashmap);
		
	public int insert_visit(HashMap<String, String> hashmap);
	
	public int total_visit();
	
	public int today_visit();

	public ArrayList<MemberVo> readUserInfoList(HashMap<String, Object> hashmap);
	
}
