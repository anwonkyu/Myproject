package com.withus.userInfoLog.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.withus.userInfoLog.service.UserInfoLogService;
import com.withus.userInfoLog.dao.UserInfoLogVO;
import com.withus.userInfoLog.dao.UserInfoLogMapper;

/**
 * @Class Name : UserInfoLogServiceImpl.java
 * @Description : UserInfoLog Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2015-01-19
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("userInfoLogService")
public class UserInfoLogServiceImpl implements
        UserInfoLogService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(UserInfoLogServiceImpl.class);

    @Resource(name="userInfoLogMapper")
    private UserInfoLogMapper userInfoLogDAO;
    
    /** ID Generation */
    //@Resource(name="{egovUserInfoLogIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * user_info_log을 등록한다.
	 * @param vo - 등록할 정보가 담긴 UserInfoLogVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertUserInfoLog(UserInfoLogVO vo) throws Exception {
 
        return userInfoLogDAO.insertUserInfoLog(vo);
    }

 

    /**
	 * user_info_log을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 UserInfoLogVO
	 * @return void형 
	 * @exception Exception
	 */
    public void deleteUserInfoLog(String userid) throws Exception {
        userInfoLogDAO.deleteUserInfoLog(userid);
    }

    /**
	 * user_info_log을 조회한다.
	 * @param vo - 조회할 정보가 담긴 UserInfoLogVO
	 * @return 조회한 user_info_log
	 * @exception Exception
	 */
    public UserInfoLogVO selectUserInfoLog(String userid) throws Exception {
        UserInfoLogVO resultVO = userInfoLogDAO.selectUserInfoLog(userid);
      
        return resultVO;
    }

    /**
	 * user_info_log 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return user_info_log 목록
	 * @exception Exception
	 */
    public ArrayList<UserInfoLogVO> selectUserInfoLogList(
    	 String searchFild, String searchWord,
			int start, int end) throws Exception { 
		Integer startRownum = start;
		Integer endRownum = end;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		
        return userInfoLogDAO.selectUserInfoLogList(hashmap);
    }

    /**
	 * user_info_log 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return user_info_log 총 갯수
	 * @exception
	 */
    public int selectUserInfoLogListTotCnt(String searchFild, String searchWord) {
    	HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		return userInfoLogDAO.selectUserInfoLogListTotCnt(hashmap);
	}

 
    
}
