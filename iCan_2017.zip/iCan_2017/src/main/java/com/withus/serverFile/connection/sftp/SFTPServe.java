package com.withus.serverFile.connection.sftp;
import java.io.File;

import java.io.FileInputStream;

import java.io.FileNotFoundException;

import java.io.FileOutputStream;

import java.io.IOException;

import java.io.InputStream;

public class SFTPServe{

	public static void main(String args[]) {



		String host = "106.255.241.77";

		int port = 22;

		String userName = "withus_nrf";

		String password = "withustech00";

		String dir = "/home/teemo/tmp"; //접근할 폴더가 위치할 경로

		String file = "/reserve";



		SFTPUtil util = new SFTPUtil();

		util.init(host, userName, password, port);

		util.upload(dir, new File(file));
		


		String fileName="/home/teemo/tmp/teemo.txt"; //ex. "test.txt"

		String saveDir="/home/rocksea/teemo.txt";//ex. "f:\\test3.txt"



		util.download(dir, fileName, saveDir);



		util.disconnection();

		System.exit(0);



	}

}
