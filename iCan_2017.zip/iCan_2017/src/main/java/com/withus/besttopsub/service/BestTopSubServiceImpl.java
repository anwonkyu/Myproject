package com.withus.besttopsub.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.MultiValueMap;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 









import com.withus.besttopsub.service.BestTopSubService;
 
import com.withus.besttopsub.dao.BestTopSubVO;
import com.withus.besttopsub.dao.BestTopSubMapper;

/**
 * @Class Name : BestTopSubServiceImpl.java
 * @Description : BestTopSub Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-06
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service
public class BestTopSubServiceImpl implements BestTopSubService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(BestTopSubServiceImpl.class);

    @Resource(name="bestTopSubMapper")
    private BestTopSubMapper bestTopSubMapper;
    
    /** ID Generation */
    //@Resource(name="{egovBestTopSubIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * best_top_sub을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BestTopSubVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public String insertBestTopSub(BestTopSubVO vo) throws Exception { 
    	
    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		vo.setBtsUip(req.getRemoteAddr()); 
		if (authentication.getName() != null && authentication.getName().length() > 0) {
			vo.setBtsUid(authentication.getName());
		} 
		
        return bestTopSubMapper.insertBestTopSub(vo);
    }

    /**
	 * best_top_sub을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BestTopSubVO
	 * @return void형
	 * @exception Exception
	 */
    public void updateBestTopSub(BestTopSubVO vo) throws Exception {
    	bestTopSubMapper.updateBestTopSub(vo);
    }

    /**
	 * best_top_sub을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BestTopSubVO
	 * @return void형 
	 * @exception Exception
	 */
    public void deleteBestTopSub(String btiId) throws Exception {
    	bestTopSubMapper.deleteBestTopSub(btiId);
    }

    /**
	 * best_top_sub을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BestTopSubVO
	 * @return 조회한 best_top_sub
	 * @exception Exception
	 */
    public BestTopSubVO selectBestTopSub(BestTopSubVO vo) throws Exception {
        BestTopSubVO resultVO = bestTopSubMapper.selectBestTopSub(vo);
      
        return resultVO;
    }

	@Override
	public ArrayList selectBestTopSubList(int btiId) throws Exception {
		 
		return bestTopSubMapper.selectBestTopSubList(btiId);
	}

	@Override
	public int selectBestTopSubListTotCnt() {
		 
		return bestTopSubMapper.selectBestTopSubListTotCnt();
	}

	@Override
	
	public int insertBestTopSub2(MultiValueMap<String, String> params)
			throws Exception { 
	
		
		HashMap<String, String> param = null;
		ArrayList<Object> mArrayList;
		 mArrayList = new ArrayList<Object>();
	
		 String bti_id = "";
		for (int i = 0; i < params.get("btsTitle").size(); i++) {
			param = new HashMap<String, String>();
			param.put("btsTitle", params.get("btsTitle").get(i).toString());
			param.put("btsOcode",params.get("btsOcode").get(i).toString());
			param.put("btsType",params.get("btsType").get(i).toString());
			param.put("btiId",params.get("btiId").get(i).toString());
			param.put("btsOrder",params.get("btsOrder").get(i).toString());
			bti_id =params.get("btiId").get(i).toString(); 
			mArrayList.add(param); 
//			
//			 System.out.println(mArrayList.size());
//			 System.out.println(param);
//			 System.out.println(mArrayList.toString());
 		} 
		  
	    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
			Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
			String uip = req.getRemoteAddr(); 
			String uid ="";
			if (authentication.getName() != null && authentication.getName().length() > 0) {
				uid=authentication.getName();
			} 
			
			HashMap<String, Object> hashmap = new HashMap<String, Object>();
 
			hashmap.put("list", mArrayList); 
//			System.out.println(hashmap.values());
//			System.out.println(hashmap.toString());
			
			// 이전 정보 삭제후 등록
			if (bti_id != null) {
			bestTopSubMapper.deleteBestTopSub(bti_id);
			}
			return bestTopSubMapper.insertBestTopSub2(hashmap);
	        
	}
    
}
