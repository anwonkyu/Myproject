package com.withus.commons.mail;

public class DefaultMailMessage {
	/** Mail CharacterSet. */
	private String charset;
	
	/** Mail 제목. */
	private String subject;
	
	/** Mail 내용(HTML). */
	private String htmlContent;
	
	/** 보내는 사람 메일 주소. */
	private String from;
	
	/** 받는 사람 메일 주소. */
	private String to;
	
	/** 보내는 사람 성명. */
	private String fromName;
	
	/** 받는 사람 성명. */
	private String toName;
	
	/** 파일명 배열. */
	private String[] files;

	/**
	 * Mail CharacterSet을 반환한다.
	 *
	 * @return Mail CharacterSet
	 */
	public String getCharset() {
		return charset;
	}
	
	/**
	 * 주어진 charset에 해당하는 Mail CharacterSet을 설정한다.
	 *
	 * @param charset Mail CharacterSet
	 */
	public void setCharset(String charset) {
		this.charset = charset;
	}
	
	/**
	 * Mail 제목을 반환한다.
	 *
	 * @return Mail 제목
	 */
	public String getSubject() {
		return subject;
	}
	
	/**
	 * 주어진 subject에 해당하는 Mail 제목을 설정한다.
	 *
	 * @param subject Mail 제목
	 */
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	/**
	 * Mail 내용(HTML)을 반환한다.
	 *
	 * @return Mail 내용(HTML)
	 */
	public String getHtmlContent() {
		return htmlContent;
	}
	
	/**
	 * 주어진 htmlContent에 해당하는 Mail 내용(HTML)을 설정한다.
	 *
	 * @param htmlContent Mail 내용(HTML)
	 */
	public void setHtmlContent(String htmlContent) {
		this.htmlContent = htmlContent;
	}
	
	/**
	 * 보내는 사람 메일 주소를 반환한다.
	 *
	 * @return 보내는 사람 메일 주소
	 */
	public String getFrom() {
		return from;
	}
	
	/**
	 * 주어진 from에 해당하는 보내는 사람 메일 주소를 설정한다.
	 *
	 * @param from 보내는 사람 메일 주소
	 */
	public void setFrom(String from) {
		this.from = from;
	}
	
	/**
	 * 받는 사람 메일 주소를 반환한다.
	 *
	 * @return 받는 사람 메일 주소
	 */
	public String getTo() {
		return to;
	}
	
	/**
	 * 주어진 to에 해당하는 받는 사람 메일 주소를 설정한다.
	 *
	 * @param to 받는 사람 메일 주소
	 */
	public void setTo(String to) {
		this.to = to;
	}
	
	/**
	 * 보내는 사람 성명을 반환한다.
	 *
	 * @return 보내는 사람 성명
	 */
	public String getFromName() {
		return fromName;
	}
	
	/**
	 * 주어진 fromName에 해당하는 보내는 사람 성명을 설정한다.
	 *
	 * @param fromName 보내는 사람 성명
	 */
	public void setFromName(String fromName) {
		this.fromName = fromName;
	}
	
	/**
	 * 받는 사람 성명을 반환한다.
	 *
	 * @return 받는 사람 성명
	 */
	public String getToName() {
		return toName;
	}
	
	/**
	 * 주어진 toName에 해당하는 받는 사람 성명을 설정한다.
	 *
	 * @param toName 받는 사람 성명
	 */
	public void setToName(String toName) {
		this.toName = toName;
	}	
	
	/**
	 * 파일명 배열을 반환한다.
	 *
	 * @return 파일명 배열
	 */
	public String[] getFiles() {
		return files;
	}
	
	/**
	 * 주어진 files에 해당하는 파일명 배열 정보를 설정한다.
	 *
	 * @param files 파일명 배열
	 */
	public void setFiles(String[] files) {
		this.files = files;
	}
}
