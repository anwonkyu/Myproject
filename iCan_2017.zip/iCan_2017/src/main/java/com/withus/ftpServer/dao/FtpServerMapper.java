package com.withus.ftpServer.dao;

import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository("ftpServerMapper")
public interface FtpServerMapper {
	public int updateFtpServer(HashMap<String, String> hashmap)throws Exception;
	
	public int selectFtpServer()throws Exception;
}


