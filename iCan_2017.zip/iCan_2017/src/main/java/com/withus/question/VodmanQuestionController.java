package com.withus.question;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.boardinfo.VodmanBoardInfoController;
import com.withus.commons.XmlResult;
import com.withus.question.dao.QuestionVO;
import com.withus.question.service.QuestionService;


@Controller
@RequestMapping("/vodman")
public class VodmanQuestionController {
	
	 @Autowired
	 private QuestionService questionService;
	 
	 @Resource(name = "xstreamMarshaller")
	    private XStreamMarshaller xstreamMarshaller;
	 @Resource(name = "xmlView")
	    private View xmlView; 
	
	 private static final Logger LOGGER = LoggerFactory.getLogger(VodmanQuestionController.class);
	 
	 @RequestMapping(value="/question/questionList.do" ,method={RequestMethod.GET, RequestMethod.POST})
	 public String questionAllList(Model model) throws Exception{
		 
		 ArrayList<QuestionVO> questionVO = questionService.questionAllList();
		 model.addAttribute("questionVO", questionVO);  
		 return "/vodman/ipost/questionList";
		 
	 }
	 
	 @RequestMapping(value="/question/questionDelete.do" ,method={RequestMethod.GET, RequestMethod.POST})
	 public String questionDelete(@RequestParam(value="id",required=true)  String id, @RequestParam(value="dcode",required=true)  String dcode) throws Exception{
//		System.out.println("id="+id);
//		System.out.println("dcode="+dcode);
		 questionService.deleteQuestion(id,dcode);
		return "redirect:/vodman/question/questionList.do";
		 
	 }
	
	 
	 
	 @RequestMapping(value="/question/questionInsert.do" , method=RequestMethod.POST)
     public View addGroupsMember(   @RequestParam MultiValueMap<String, String> params, Model model )
             throws Exception {
   	  XStream xst = xstreamMarshaller.getXStream();
     	  xst.alias("result", XmlResult.class); 
      
         XmlResult xml = new XmlResult(); 
         
         if (questionService.insertQuestionMember(params) > 0) { 
        	xml.setMessage("등록 되었습니다!");
  	 	    xml.setError(true);
    	 
         }else {
 			xml.setMessage("등록에 실패하였습니다!");
 	 	    xml.setError(false);
 		}

 	        model.addAttribute("xmlData", xml);
 	        return xmlView;
   	  
     	 //return "redirect:/vodman/site/groupsMember.do?groupId="+params.get("groupId").get(0);
     }
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	
}
