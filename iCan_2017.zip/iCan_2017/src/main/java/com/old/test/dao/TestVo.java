package com.old.test.dao;

import java.io.Serializable;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.SpringSecurityCoreVersion;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.util.Assert;

public class TestVo implements Serializable {

	 private static final long serialVersionUID = 1L;
	    
	    /** code */
	    private String calnoteId;
	    
	    /** id */
	    private String calCatCd;
	    
	    private String docId;

		public String getCalnoteId() {
			return calnoteId;
		}

		public void setCalnoteId(String calnoteId) {
			this.calnoteId = calnoteId;
		}

		public String getCalCatCd() {
			return calCatCd;
		}

		public void setCalCatCd(String calCatCd) {
			this.calCatCd = calCatCd;
		}

		public String getDocId() {
			return docId;
		}

		public void setDocId(String docId) {
			this.docId = docId;
		}

		@Override
		public String toString() {
			return "TestVo [calnoteId=" + calnoteId + ", calCatCd=" + calCatCd
					+ ", docId=" + docId + "]";
		}

		 
	    
	    
}
