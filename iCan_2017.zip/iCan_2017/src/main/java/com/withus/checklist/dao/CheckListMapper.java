package com.withus.checklist.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;
 
@Repository("checkListMapper")
public interface CheckListMapper {

    public int check_list_update(Object parameter) throws Exception;

	public ArrayList<?> checklist_item(HashMap<String, Object> hashmap) throws Exception;
}
