package com.withus.serverFile;
 
 
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties; 

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest; 
 






import org.springframework.web.servlet.View;

import com.ext.jfile.GlobalVariables;
import com.ext.jfile.JProperties;
import com.ext.jfile.service.JFileDetails;
import com.ext.jfile.service.JFileService;
import com.ext.jfile.service.impl.JFileVO;
import com.thoughtworks.xstream.XStream;
import com.withus.commons.XmlResult;
import com.withus.serverFile.connection.ftp.ServerFtpService;
import com.withus.serverFile.service.ServerFileService;
 

/**
 * @Class Name : LogoController.java
 * @Description : Logo Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-12-31
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
public class ServerFileController {

	
	 private static final Logger logger = LoggerFactory.getLogger(ServerFileController.class);
	
	@Autowired
	private JFileService jfileService;
	 
    @Resource(name = "serverFileService")
    private ServerFileService serverFileService;
    
    @Resource(name = "serverFtpService")
    private ServerFtpService serverFtpService;
    
    @Autowired Properties prop;
    
    @Resource(name = "xmlView")
    private View xmlView;
    
    @Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;
    
    
    @RequestMapping(value="/serverFile/fileList.do", method={RequestMethod.GET,RequestMethod.POST })
    public String serverFileList(String path , String flag, String elementId,
            Model model)
            throws Exception {
   
    	 
    	 String tmp_path = "";
    	 if (path != null && path.length() > 0) {
    	 tmp_path = URLDecoder.decode(path, "UTF-8");  
    	 }
    	 
    	 HashMap<String, Object> map= (HashMap) serverFtpService.getFileList(tmp_path); 
    	 
    	 model.addAttribute("flag",flag);
    	 model.addAttribute("elementId",elementId);
    	 model.addAttribute("resultList", map.get("fileList"));
    	 model.addAttribute("thisPwd", map.get("thisPwd"));
    	 
        return "/jfile/server/fileList";
    }

   
 
    /*   
     * 같은 서버에서 해당 경로에 첨부파일을 복사
     */
    @RequestMapping(value="/serverFile/fileCopy.do", method={RequestMethod.GET,RequestMethod.POST })
    public View serverFileCopy(String path ,String fileName,
    		@RequestParam(value="fileId", required=true) String fileId, String flag, String elementId,
            Model model)
            throws Exception {
   
    	 String sDir = JProperties.getString("system.uploadpath");  // PROPERTIES 에서 읽어오기 //
         	 
    	 String tmp_path = "";
    	 if (path != null && path.length() > 0) {
    	 tmp_path = URLDecoder.decode(path, "UTF-8");  
    	 }
    	 
    	 String tmp_fileName = "";
    	 if (fileName != null && fileName.length() > 0) {
    		 tmp_fileName = URLDecoder.decode(fileName, "UTF-8");  
    	 }
    	 
    	// temp_path == FTP root 경로가 어디인지 체크
    	 // 테스트 서버에서는 현재 /VOL1  부터 시작 하고 심볼릭 링크는 /VOL1/New_업무폴더/  다음부터 연결 되어 있음
    	 tmp_path = tmp_path.replace("/VOL1/New_업무폴더","Z:\\");  // 심볼릭 링크 루트 경로 확인 필요
    	 String org_file = ""+tmp_path+File.separator+tmp_fileName;  

    	 //String copy_file = "D:\\test\\upload\\"+tmp_fileName; //  파일 복사될 경로 생성 필요    	 
    	/* String copy_file = sDir+tmp_fileName; //  파일 복사될 경로 생성 필요*/   
    	 JFileVO fileVo = new JFileVO();
    	 fileVo.setFileMask(jfileService.getFileMask(tmp_fileName, 0, fileVo.getUploadMode(), JProperties.getString(GlobalVariables.DEFAULT_FILE_UPLOAD_PATH_KEY)));
    	 String copy_file = jfileService.getUploadDirectoryPath(JProperties.getString(GlobalVariables.DEFAULT_FILE_UPLOAD_PATH_KEY), fileVo.getUploadMode());

    	int size = this.fileCopy(org_file, copy_file+fileVo.getFileMask());
    	if (size > 0) {
    		//size fileSize (DB save)
    		System.out.println(size);
    		System.out.println(org_file+"::"+copy_file);
    		//jfile  DB 에 insert

    		fileVo.setFileName(tmp_fileName);  // 파일명
    		fileVo.setFileSize(size);

    		fileVo.setFileId(fileId);
    		fileVo.setFlag(flag);
    		
    		System.out.println("fileVO:"+fileVo.toString());
    		jfileService.addAttachFile(fileVo);
    	}
    	 
    	XStream xst = xstreamMarshaller.getXStream();
      	xst.alias("result", XmlResult.class); 
       
          XmlResult xml = new XmlResult(); 
    	 // 파일 복사후 첨부파일 DB 에 정보 저장
    	 
    	 if (size > 0){
			  xml.setMessage("등록되었습니다.");
		      xml.setError(true);
		 } else { 
             xml.setMessage("정보가 올바르지 않습니다.");
             xml.setError(false);
        } 
       model.addAttribute("elementId", elementId);
       model.addAttribute("xmlData", xml);
       return xmlView; 
    }

   

    /*
     * 파일 복사
     */
    
    protected int fileCopy(String org_file, String copy_file){
     
    	int value = -1;
    	FileChannel fcin = null ;
    	FileChannel fcout = null;
    	try{
    	FileInputStream inputStream = new FileInputStream(org_file);        
    	FileOutputStream outputStream = new FileOutputStream(copy_file);
    	  
    	fcin =  inputStream.getChannel();
    	fcout = outputStream.getChannel();
    	  
    	long size = fcin.size();
    	fcin.transferTo(0, size, fcout);
    	  
//    	fcout.close();
//    	fcin.close();
    	outputStream.flush();  
    	outputStream.close();
    	inputStream.close();
    	value = (int) size;
    	} catch (IOException ioe) {
    		 System.out.println("파일 복사 실패"+ioe);
    		 value = -1;
    	} finally{
    		this.close(fcout);
    		this.close(fcin);
    	}
    	
    	return value;
 
    }
    
    protected void close(Closeable closable) { 
   		if (closable != null) { 
    			try { 
    				closable.close(); 
    			} catch (IOException ignore) { 
    				 System.out.println("IGNORE: " + ignore); 
    			} 
    	} 
    } 
    
}
