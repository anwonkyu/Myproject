package com.withus.calnote.service;

import java.util.ArrayList;
import java.util.List;

import com.withus.calnote.dao.CalnoteUpdateVO;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.dao.OldFileVO;


public interface CalnoteService {
	void insertCalnote(CalnoteVO calnoteVo) throws Exception;
	 
	 ArrayList<CalnoteVO> selectCalnoteList(String searchWord, int start, int end) throws Exception;
	 
	 ArrayList<CalnoteVO> userCalnoteList(String plantCd, String docName, int chngCoreCycleNum, String datepicker,
			 String datepicker2,String unitNum,String deptCd,String state, int start, int end, String sortField,String sortOrder, String searchUnit,String docId,String name) throws Exception;

	 ArrayList<CalnoteVO> calNoteNomalDocIdList(String docId, int start, int end) throws Exception;
	 
	 int selectCalnoteListTotCnt(String searchWord)throws Exception;
	 
	 int userCalnoteListTotCnt(String plantCd,String docName,int chngCoreCycleNum,String datepicker, String datepicker2, String unitNum, String deptCd,String state , String searchUnit,String docId,String name)throws Exception;
	 
	 int calNoteNomalDocIdTotCnt(String docId)throws Exception;
	 
	 int deleteCalnote(String calnoteId)throws Exception;
	 
	 int updateCalnote(CalnoteVO calnoteVo)throws Exception;
	 
	 public CalnoteVO getCalnote(String calnoteId)throws Exception;

	 String checkDocId(String docId) throws Exception;

	 int mergeCheck1_1(CalnoteUpdateVO calnoteUpdateVo)throws Exception;

	 public CalnoteUpdateVO getCalnoteUpdateVo(String calnoteId)throws Exception;
	 
	 List<OldFileVO> getOldFileList(String calnoteId)throws Exception;

	 ArrayList<CalnoteVO> userCalnoteListPanding( int start, int end) throws Exception;
	 
	 ArrayList<CalnoteVO> userCalnoteListProcessed( int start, int end) throws Exception;

	ArrayList<CalnoteVO> userPanding(int start, int end)throws Exception;
	 
	ArrayList<CalnoteVO> userProcessed(int start, int end)throws Exception;

	ArrayList<CalnoteVO> userTrListPanding(int video_limit, int i) throws Exception ;

	int pandingListTotCnt(String searchFild, String searchWord) throws Exception;

	ArrayList<CalnoteVO> pandingList(int start, int end, String searchFild, String searchWord, String sortField, String sortOrder  )throws Exception;
	
	int processedListTotCnt(String searchFild, String searchWord) throws Exception;

	ArrayList<CalnoteVO> processedList(int start, int end, String searchFild, String searchWord, String sortField, String sortOrder  )throws Exception;

	int getRevisionMax(String docId) throws Exception;
}
