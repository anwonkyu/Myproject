package com.withus.calnote.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.itextpdf.text.log.SysoCounter;
import com.withus.calHistory.dao.CalHistoryVO;
import com.withus.calHistory.service.CalHistoryService;
import com.withus.calnote.dao.CalnoteMapper;
import com.withus.calnote.dao.CalnoteUpdateVO;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.dao.OldFileVO;
 
import com.withus.commons.seed.WithusSeed;
import com.withus.member.dao.MemberVo;
@Service("calnoteService")
public class CalnoteServiceImpl implements CalnoteService{
	private static final Logger LOGGER = LoggerFactory.getLogger(CalnoteServiceImpl.class);
	
	@Resource(name="calnoteMapper")
	private CalnoteMapper calnoteMapper;
	
	@Autowired CalHistoryService calHistoryService;
	
	@Override
	@Transactional
	public void insertCalnote(CalnoteVO calnoteVo) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		Authentication auth = (Authentication)request.getUserPrincipal();
		if(auth == null){
	          
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	calnoteVo.setUserId(((MemberVo)principal).getId());  //아이디
	        	calnoteVo.setName(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	        	
	        	calnoteMapper.insertCalnote(calnoteVo);
	        	CalHistoryVO vo = new CalHistoryVO();
	         	vo.setCalnoteId(calnoteVo.getCalnoteId());
	         	vo.setState(calnoteVo.getState());
	         	//vo.setComments(calnoteVo.getStat());
	         	calHistoryService.insertCalHistory(vo);
	         }
	     }  		
	}

	@Override
	public ArrayList<CalnoteVO> selectCalnoteList(String searchWord, int start, int end) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		Integer startRownum = start;
		Integer endRownum = end;
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("searchWord", searchWord);
		return calnoteMapper.selectCalnoteList(hashmap);
	}
	
	@Override
	public ArrayList<CalnoteVO> calNoteNomalDocIdList(String docId, int start, int end) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		Integer startRownum = start;
		Integer endRownum = end;
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("docId", docId);
		return calnoteMapper.calNoteNomalDocIdList(hashmap);
	}
	
	
	
	@Override
	public ArrayList<CalnoteVO> userCalnoteList(String plantCd,String docName,int chngCoreCycleNum, String datepicker, String datepicker2,
			String unitNum,String deptCd,String state, int start,int end, String sortField,String sortOrder, String searchUnit,String docId,String name) throws Exception {
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		Integer startRownum = start;
		Integer endRownum = end;
		Integer chngCoreCycle = chngCoreCycleNum;
		if (unitNum != null && unitNum.length() > 0 && searchUnit != null && searchUnit.equals("or")) {
			String[] unitNumList = unitNum.split("/");
			hashmap.put("unitNum",unitNumList);
		} else if (unitNum != null && unitNum.length() > 0 && searchUnit != null && searchUnit.equals("and")) {
			String unitNumList = unitNum.replaceAll("/", "");
			hashmap.put("unitNum",unitNumList);
		}
		
		
		String[] sortFieldList = sortField.split(",");
		String[] sortOrderList = sortOrder.split(",");
		
		/*Map<String, Object> sortListMap = new HashMap<String, Object>();
		for (int i = 0; i < sortFieldList.length; i++) { 
			sortListMap.put("field"+i, sortFieldList[i]);
			sortListMap.put("order"+i, sortOrderList[i]);
		}
		
		List<CalnoteVO> list = new ArrayList<CalnoteVO>();
		 for (String mapkey : sortListMap.keySet()){
		        System.out.println("key:"+mapkey+",value:"+sortListMap.get(mapkey));
		        list.add(arg0)
		    }*/
		/*Map<String, Object> sortListMap = new HashMap<String, Object>();*/
		
		List<CalnoteVO> list = new ArrayList<CalnoteVO>();
		
		for (int i = 0; i < sortFieldList.length; i++) { 
			CalnoteVO sortListVo = new CalnoteVO();
			sortListVo.setSortField(sortFieldList[i]);
			sortListVo.setSortOrder(sortOrderList[i]);
			list.add(sortListVo);
			/*hashmap.put("sortField", sortFieldList[i]);
			hashmap.put("sortOrder", sortOrderList[i]);*/
		}
		
		hashmap.put("plantCd", plantCd);
		hashmap.put("docName", docName);
		hashmap.put("chngCoreCycleNum", chngCoreCycle.toString());
		hashmap.put("datepicker", datepicker);
		hashmap.put("datepicker2", datepicker2);
		hashmap.put("deptCd", deptCd);
		hashmap.put("state", state);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("sortField", sortField);
		hashmap.put("sortOrder", sortOrder);
		hashmap.put("sortList", list);
		hashmap.put("searchUnit", searchUnit);
		hashmap.put("docId", docId);
		hashmap.put("name", name);
		return calnoteMapper.userCalnoteList(hashmap);
	}

	@Override
	public int selectCalnoteListTotCnt(String searchWord) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("searchWord", searchWord);
		return calnoteMapper.selectCalnoteListTotCnt(hashmap);
	}
	
	@Override
	public int userCalnoteListTotCnt(String plantCd, String docName, int chngCoreCycleNum, String datepicker, String datepicker2,
			String unitNum,String deptCd,String state , String searchUnit,String docId,String name) throws Exception {
		HashMap<String, Object> hashmap = new HashMap<String, Object>(); 
		Integer chngCoreCycle = chngCoreCycleNum;
		if (unitNum != null && unitNum.length() > 0 && searchUnit != null && searchUnit.equals("or")) {
			String[] unitNumList = unitNum.split("/");
			hashmap.put("unitNum",unitNumList);
		} else if (unitNum != null && unitNum.length() > 0 && searchUnit != null && searchUnit.equals("and")) {
			String unitNumList = unitNum.replaceAll("/", "");
			hashmap.put("unitNum",unitNumList);
		}
		hashmap.put("plantCd", plantCd);
		hashmap.put("docName", docName);
		hashmap.put("chngCoreCycleNum", chngCoreCycle.toString());
		hashmap.put("datepicker", datepicker);
		hashmap.put("datepicker2", datepicker2);
		hashmap.put("deptCd", deptCd);
		hashmap.put("state", state);
		hashmap.put("searchUnit", searchUnit);
		hashmap.put("docId", docId);
		hashmap.put("name", name);
		System.out.println("userCalnoteListTotCnt::"+hashmap.toString());
		return calnoteMapper.userCalnoteListTotCnt(hashmap);
	}
	
	@Override
	public int calNoteNomalDocIdTotCnt(String docId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("docId", docId);
		return calnoteMapper.calNoteNomalDocIdTotCnt(hashmap);
	}
	
	@Override
	public String checkDocId(String docId) throws Exception{
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("docId", docId);
		return calnoteMapper.checkDocId(hashmap);
	}

	@Override
	public int deleteCalnote(String calnoteId) throws Exception {
		return calnoteMapper.deleteCalnote(calnoteId);
	}

	@Override
	@Transactional
	public int updateCalnote(CalnoteVO calnoteVo) throws Exception {
 
		CalHistoryVO vo = new CalHistoryVO(); 
     	vo.setCalnoteId(calnoteVo.getCalnoteId()); 
     	vo.setState(calnoteVo.getState()); 
      	//vo.setComments("Update");
 
     	calHistoryService.insertCalHistory(vo); 
		return calnoteMapper.updateCalnote(calnoteVo);
	}
	

	@Override
	public CalnoteVO getCalnote(String calnoteId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		return calnoteMapper.getCalnote(hashmap);
	}
	@Override
	@Transactional
 	public int mergeCheck1_1(CalnoteUpdateVO calnoteUpdateVo)throws Exception{
		Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
		Object principal = auth.getPrincipal();
		if(principal != null && principal instanceof MemberVo){ 
			calnoteUpdateVo.setUserId(((MemberVo)principal).getUsername() );	
			CalHistoryVO vo = new CalHistoryVO(); 
	     	vo.setCalnoteId(calnoteUpdateVo.getCalnoteId()); 
 	     	vo.setComments("checklist write"); 
 	       	calHistoryService.insertCalHistory(vo); 
		} else{
        	 return -1;
        }
		return calnoteMapper.mergeCheck1_1(calnoteUpdateVo);
	}

	@Override
	public CalnoteUpdateVO getCalnoteUpdateVo(String calnoteId) throws Exception {
		return calnoteMapper.getCalnoteUpdateVo(calnoteId);
	}

	@Override
	public List<OldFileVO> getOldFileList(String calnoteId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("calnoteId", calnoteId);
		return calnoteMapper.getOldFileList(hashmap);
	}

	@Override
	public ArrayList<CalnoteVO> userCalnoteListPanding(
			int start, int end) throws Exception {
		  HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		  Authentication auth = (Authentication)request.getUserPrincipal();
		    
		     if(auth == null){
		          return null;
		     }else{
		         Object principal = auth.getPrincipal();
		         if(principal != null && principal instanceof MemberVo){
		        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디
 
		        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
		     		
		     		Integer startRownum = start;
		     		Integer endRownum = end;
		     		//hashmap.put("userId", ((MemberVo)principal).getId());
		     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
		     		hashmap.put("start", startRownum.toString());
		     		hashmap.put("end", endRownum.toString());
		     		return calnoteMapper.userCalnoteListPanding(hashmap);
		     		 
		         } else {
		        	 return null;
		         }
		     } 
		     
		
	}

	@Override
	public ArrayList<CalnoteVO> userCalnoteListProcessed(
			int start, int end) throws Exception {
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	     		return calnoteMapper.userCalnoteListProcessed(hashmap);
	     		 
	         } else {
	        	 return null;
	         }
	     }
	     
	}

	@Override
	public ArrayList<CalnoteVO> userPanding(int start, int end)
			throws Exception {
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	     	 
	     		return calnoteMapper.userPanding(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

	@Override
	public ArrayList<CalnoteVO> userProcessed(int start, int end)
			throws Exception {
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	      
	     		return calnoteMapper.userProcessed(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

	@Override
	public ArrayList<CalnoteVO> userTrListPanding(int start, int end) throws Exception {
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	     	 
	     		return calnoteMapper.userTrListPanding(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

	@Override
	public int pandingListTotCnt(String searchFild, String searchWord ) throws Exception{
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return 0;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디
	        	//hashmap.put("userId", ((MemberVo)principal).getId());
	        	hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
				hashmap.put("searchFild", searchFild);
				hashmap.put("searchWord", searchWord);
				return calnoteMapper.pandingListTotCnt(hashmap);
	         } else {
	        	 return 0;
	         }
	     }
	}

	@Override
	public ArrayList<CalnoteVO> pandingList(int start, int end, String searchFild, String searchWord, String sortField, String sortOrder ) throws Exception{
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	     		hashmap.put("sortField", sortField);
	     		hashmap.put("sortOrder", sortOrder);
	     		hashmap.put("searchFild", searchFild);
	     		hashmap.put("searchWord", searchWord);
	     		return calnoteMapper.pandingList(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

	@Override
	public int processedListTotCnt(String searchFild, String searchWord ) throws Exception{
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return 0;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디
	        	//hashmap.put("userId", ((MemberVo)principal).getId());
	        	hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
				hashmap.put("searchFild", searchFild);
				hashmap.put("searchWord", searchWord);
				return calnoteMapper.processedListTotCnt(hashmap);
	         } else {
	        	 return 0;
	         }
	     }
	}

	@Override
	public ArrayList<CalnoteVO> processedList(int start, int end, String searchFild, String searchWord, String sortField, String sortOrder ) throws Exception{
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		 Authentication auth = (Authentication)request.getUserPrincipal();
				  
	     if(auth == null){
	          return null;
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디

	        	HashMap<String, String> hashmap = new HashMap<String, String>(); 
	     		
	     		Integer startRownum = start;
	     		Integer endRownum = end;
	     		//hashmap.put("userId", ((MemberVo)principal).getId());
	     		hashmap.put("userId", WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	     		hashmap.put("start", startRownum.toString());
	     		hashmap.put("end", endRownum.toString());
	     		hashmap.put("sortField", sortField);
	     		hashmap.put("sortOrder", sortOrder);
	     		hashmap.put("searchFild", searchFild);
	     		hashmap.put("searchWord", searchWord);
	     	 
	     		return calnoteMapper.processedList(hashmap);
	         } else {
	        	 return null;
	         }
	     }
	}

	@Override
	public int getRevisionMax(String docId) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>(); 
		hashmap.put("docId", docId);
		return calnoteMapper.getRevisionMax(hashmap);
	}
	

}
