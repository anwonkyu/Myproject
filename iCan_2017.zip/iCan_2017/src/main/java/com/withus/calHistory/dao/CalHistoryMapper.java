package com.withus.calHistory.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository("calHistoryMapper")
public interface CalHistoryMapper {

	public int insertCalHistory(CalHistoryVO vo)throws Exception;
	
	public ArrayList<CalHistoryVO> selectCalHistoryList(HashMap<String, String> hashmap) throws Exception;
	
	public int selectCalHistoryListTotCnt(HashMap<String, String> hashmap);

	public ArrayList<?> selectCalHistoryListAll(HashMap<String, String> hashmap);
}
