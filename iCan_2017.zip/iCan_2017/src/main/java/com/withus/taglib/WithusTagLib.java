package com.withus.taglib;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;
 

public class WithusTagLib extends TagSupport{ 
	
	   private String context; 
	   private String t_f; 
	    
	   public int doStartTag() throws JspException {
	      try { 
	    	  
	    	 String new_context = com.withus.commons.TextUtil.getContent(this.context, this.t_f);
	         JspWriter out = pageContext.getOut(); 
	         //out.println(this.content);  // jsp Body에 출력
	         out.println(new_context);
	      } catch(IOException e){          
	         e.printStackTrace(); 
	      } 
	      return SKIP_BODY; // jsp Body에 출력 안함
	   } 
	    
	   public void setContext(String value) { //  TLD 어트리뷰트명 을 함수명으로 생성
	      this.context = value; 
	   }
	   
	   public void setT_f(String value) { //  TLD 어트리뷰트명 을 함수명으로 생성
		  this.t_f = value; 
	   }
	} 
 
 