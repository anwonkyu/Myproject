package com.withus.question.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.springframework.stereotype.Repository;

@Repository("questionMapper")
public interface QuestionMapper {
	
	public int insertQuestionMember(HashMap<String, Object> hashmap )throws Exception ;
	
	public ArrayList<QuestionVO> questionAllList()throws Exception ;
	
	public int deleteQuestion(HashMap<String, Object> hashmap)throws Exception;

	
}
