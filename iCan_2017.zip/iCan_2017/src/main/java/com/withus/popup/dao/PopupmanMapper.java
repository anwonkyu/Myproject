package com.withus.popup.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.springframework.stereotype.Repository;
 


import com.withus.popup.dao.PopupmanVO;
 
 

/**
 * @Class Name : PopupmanDAO.java
 * @Description : Popupman DAO Class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-12
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Repository("popupmanMapper")
public interface PopupmanMapper {

	/**
	 * popupman을 등록한다.
	 * @param vo - 등록할 정보가 담긴 PopupmanVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    public int insertPopupman(PopupmanVO vo) throws Exception ;

    /**
	 * popupman을 수정한다.
	 * @param vo - 수정할 정보가 담긴 PopupmanVO
	 * @return void형
	 * @exception Exception
	 */
    public int updatePopupman(PopupmanVO vo) throws Exception;

    /**
	 * popupman을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 PopupmanVO
	 * @return void형 
	 * @exception Exception
	 */
    public int deletePopupman(int seq) throws Exception;

    /**
	 * popupman을 조회한다.
	 * @param vo - 조회할 정보가 담긴 PopupmanVO
	 * @return 조회한 popupman
	 * @exception Exception
	 */
    public PopupmanVO selectPopupman(int seq) throws Exception ;

    /**
	 * popupman 목록을 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return popupman 목록
	 * @exception Exception
	 */
    public ArrayList<PopupmanVO> selectPopupmanList(HashMap<String, String>hashmap) throws Exception;

    /**
	 * popupman 총 갯수를 조회한다.
	 * @param searchMap - 조회할 정보가 담긴 Map
	 * @return popupman 총 갯수
	 * @exception
	 */
    public int selectPopupmanListTotCnt(HashMap<String, String>hashmap) ;

	public ArrayList<PopupmanVO> selectPopupmanList_today(String popFlag);
 
}
