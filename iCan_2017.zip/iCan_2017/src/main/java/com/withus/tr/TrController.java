package com.withus.tr;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.View;

import com.ext.jfile.service.JFileDetails;
import com.ext.jfile.service.JFileService;
import com.itextpdf.text.Document;
import com.itextpdf.text.pdf.PdfCopyFields;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfWriter;
 
import com.old.test.service.TestService;
import com.thoughtworks.xstream.XStream;
import com.withus.calHistory.service.CalHistoryService;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.dao.OldFileVO;
import com.withus.calnote.service.CalnoteService;
import com.withus.category.service.CategoryService;
import com.withus.commons.TextUtil;
import com.withus.commons.XmlResult;
import com.withus.commons.mail.DefaultMailMessage;
import com.withus.commons.mail.MailNotifier;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
import com.withus.member.dao.MemberVo;
import com.withus.member.service.MemberService;
import com.withus.tr.dao.TrVO;
import com.withus.tr.service.TrService;

@Controller
public class TrController {
	
	private static final Logger logger = LoggerFactory.getLogger(TrController.class);
	
	@Autowired 
	private CalnoteService calnoteService;
	
	@Autowired Properties prop;
	
	@Autowired TrService trService;
	
	@Autowired Properties prop_state;

	@Resource
	private PagingHelperService page;
	
	@Resource
    private JFileService jfileService;
	
	@Resource(name = "calHistoryService")
	private CalHistoryService calHistoryService;
	
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;
	
    @Autowired
	private MemberService memberService;
    
    @Resource(name = "mailNotifier")
	private MailNotifier mailNotifier;    
    
    @Autowired Properties mailProp;
	

    @Resource(name = "xmlView")
    private View xmlView;
	
    @RequestMapping(value = "/tr/trList.do", method={RequestMethod.GET, RequestMethod.POST})
    public String trList(TrVO trVo, Integer curPage, String datepicker, String datepicker2, String searchFild,  String searchWord,
    		String sortField, String sortOrder,Model model, Integer pagelimit, Integer selectSort) throws Exception  {
    	String docName = trVo.getDocName();
    	String docId = trVo.getDocId();
    	String deptCd = trVo.getDeptCd();
    	String userDept = trVo.getUserDept();
    	String state = trVo.getState();
    	if (curPage == null) curPage = 1;
    	if (selectSort == null) selectSort = 10;
		if (searchWord == null) searchWord = ""; 
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = "";
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		if(selectSort == 20){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_20").trim());
		 
		} else if(selectSort == 50){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_50").trim());
 
		}else if(selectSort == 100){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_100").trim());
	 
		}
		int totalRecord = trService.selectTrTotCnt(docName,docId,datepicker,datepicker2,deptCd,userDept,state);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		ArrayList<?> trList = trService.selectTr(start, end, docName, docId, datepicker, datepicker2, deptCd, userDept, sortField, sortOrder,state);
 
		model.addAttribute("thisVo", trVo);
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
        model.addAttribute("resultList", trList);
        model.addAttribute("datepicker", datepicker);
		model.addAttribute("datepicker2", datepicker2);   
		 model.addAttribute("selectSort", selectSort);
    	return "/tr/trList";
   } 
	
    @RequestMapping(value = "/tr/trSearech.do", method={RequestMethod.GET, RequestMethod.POST})
    public String trSearech(TrVO trVo, Integer curPage, String datepicker, String datepicker2, String searchFild,  String searchWord,
    		String sortField, String sortOrder,Model model, Integer pagelimit, Integer selectSort) throws Exception  {
    	String docName = trVo.getDocName();
    	String docId = trVo.getDocId();
    	String deptCd = trVo.getDeptCd();
    	String userDept = trVo.getUserDept();
        String state = trVo.getState();
    	if (curPage == null) curPage = 1;
    	if (selectSort == null) selectSort = 10;
		if (searchWord == null) searchWord = ""; 
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = "";
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		if(selectSort == 20){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_20").trim());
		 
		} else if(selectSort == 50){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_50").trim());
 
		}else if(selectSort == 100){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_100").trim());
	 
		}
		int totalRecord = trService.selectTrTotCnt(docName,docId,datepicker,datepicker2,deptCd,userDept,state);
		int totalCalnoteRecord = calnoteService.userCalnoteListTotCnt("", docName, 0,"","","","","","","","" );
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		ArrayList<?> trList = trService.selectTr(start, end, docName, docId, datepicker, datepicker2, deptCd, userDept, sortField, sortOrder,state);
 
		model.addAttribute("thisVo", trVo);
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		model.addAttribute("totalCalnoteRecord", totalCalnoteRecord); 
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
        model.addAttribute("resultList", trList);
        model.addAttribute("datepicker", datepicker);
		model.addAttribute("datepicker2", datepicker2);   
		 model.addAttribute("selectSort", selectSort);
    	return "/tr/trSearech";
   }  
    
    
    
    
    @RequestMapping(value = "/tr/trAdd.do", method=RequestMethod.GET )
    public String trAdd( Model model) throws Exception  {
    	
    	model.addAttribute("stateName", this.thisStateName(""));
		model.addAttribute("nextState", this.nextStateName(""));
		model.addAttribute("nextStateCode", this.nextStateCode(""));
    	
    	return "/tr/trAdd";
   } 
    
    @RequestMapping(value="/tr/trAdd.do", method=RequestMethod.POST)
    public String trWrite(TrVO trVo )throws Exception {
    	List<JFileDetails> jfileVo = jfileService.getAttachFiles(trVo.getJfile());
    	trService.insertTr(trVo);
    	
    	Map<String, Object> map = new HashMap<String, Object>();
 
    	map.put("trVo", trVo);
    	map.put("jfileVo", jfileVo);
    	/*com.withus.pdf.TrPdfController.buildPdfDocument2(map);*/
    	
        return "redirect:/tr/trList.do";
    }
    
    
    @RequestMapping(value="/tr/trUpdate.do", method=RequestMethod.GET)
	public String trUpdate(String trId, Model model) throws Exception {
    	
		TrVO trVo = trService.getTr(trId);
		model.addAttribute("thisVo", trVo);
		model.addAttribute("stateName", this.thisStateName(trVo.getState()));
		model.addAttribute("nextState", this.nextStateName(trVo.getState()));
		model.addAttribute("nextStateCode", this.nextStateCode(trVo.getState()));
		model.addAttribute("preStateCode", this.preStateCode(trVo.getState()));	
		return "/tr/trAdd";
	}
    
    @RequestMapping(value="/tr/trUpdate.do", method=RequestMethod.POST)
	public View calUpdate(@ModelAttribute("trVo") TrVO trVo, Model model ) throws Exception {
 
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
		     if ( trService.updateTr(trVo) > 0) {
			        xml.setMessage(trVo.getTrId());
			        xml.setError(true);
			        
//메일 발송  (해당 단계 - 담당자, 완료 - 등록된 담당자, 작성자 전체)
			    	
			    	ArrayList<MemberVo> userInfoList = null;
					SimpleMailMessage email = new SimpleMailMessage(); 			
				 	
					String userIds = "";
					String mail_title = "iCan TR Report";
					String mail_content_link = "http://localhost:8088/tr/trUpdate.do?trId="+trVo.getTrId();
					String mail_content_sub = "";
					if ( trVo.getState() != null && (trVo.getState().equals("R000") ) ) {  //   작성자에게 리턴
						mail_title = trVo.getStat()+ "";
						mail_content_sub = "";
						userIds = TextUtil.getOwners(trVo.getName(), "id");
						
					} else if (trVo.getState() != null && (trVo.getState().equals("A002") )) { // 독립검토요청
						mail_title = trVo.getStat()+ " ";
						userIds = TextUtil.getOwners(trVo.getCowriter(), "id");
					 
					} else if (trVo.getState() != null && (trVo.getState().equals("A003") )) { // 검토요청
						mail_title = trVo.getStat()+ " ";
						userIds = TextUtil.getOwners(trVo.getReviewer(), "id");
						
					} else if (trVo.getState() != null && (trVo.getState().equals("A004") )) { // 승인요청
						mail_title = trVo.getStat()+ " ";
						userIds = TextUtil.getOwners(trVo.getApprover(), "id");
						
					} else if (trVo.getState() != null && (trVo.getState().equals("S002") )) { // 등록완료
						mail_title = trVo.getStat()+ " ";
						userIds = TextUtil.getOwners(trVo.getName(), "id");
						userIds = userIds +","+TextUtil.getOwners(trVo.getCowriter(), "id");
						userIds = userIds +","+TextUtil.getOwners(trVo.getReviewer(), "id");
						userIds = userIds +","+TextUtil.getOwners(trVo.getApprover(), "id");
						 
					}
			 
					if (userIds != null && userIds.length() > 0) {
						userInfoList = memberService.readUserInfoList(userIds.split(",")); // 배열로 넘김
					}
					
					int mail_send = 0;
					int mail_false = 0;
						if (userInfoList != null  ) {   
							
								DefaultMailMessage mailMsg = new DefaultMailMessage();
								mailMsg.setCharset("euc-kr");
								mailMsg.setSubject(mail_title);  // 메일 타이틀
								
								StringBuffer mailContent = new StringBuffer(); // 메일 내용
								mailContent.append("mail_title"); 
								mailContent.append("<br>"); 
								mailContent.append( mail_content_link );
								mailContent.append("<br>");		
								
							 for (MemberVo value: userInfoList){
								 try{
								 	if (value.getEmail() != null && value.getEmail().length() > 0) { 
								 	  
				 		    				mailMsg.setFrom(mailProp.getProperty("mail.username"));  // 보내는 메일 주소 
				 		    				mailMsg.setFromName("i-Can");
				 		    		 		
				 		    				mailMsg.setHtmlContent(mailContent.toString());
				 	    					mailMsg.setTo(value.getEmail());
				 	    					mailMsg.setToName(value.getName());
				 	    					mailNotifier.sendEmailTo(mailMsg);
				 	    					
				 	    					mail_send ++;
									}
								 	
								 	System.out.println("mailMessage::"+mailMsg.toString());
						    		 
								 // test 메일 발송 (SimpleMailMessage)
				//				email.setTo("dolhyun@withustech.com");  //이메일 복호화
				//	       	        email.setSubject(boardListVO.getListTitle());
				//	       	        email.setText(mail_contents);
				//	       	        email.setFrom(mailProp.getProperty("mail.username"));
				
				//	       	        mailSender.send(email);
				
								 
								 //html 메일 전송
				//				mailMsg.setFrom(mailProp.getProperty("mail.username"));  // 보내는 메일 주소
				//	    				mailMsg.setFromName("i-can"); 
				//	    			 
				// 					mailMsg.setHtmlContent(mailContent.toString());
				// 					mailMsg.setTo("dolhyun@withustech.com");
				// 					mailMsg.setToName("주현");
				// 					mailNotifier.sendEmailTo(mailMsg); 
								 	
								 	
							 } catch (Exception e) {
							    	System.out.println(e);
							    	mail_false++; 
							}  
						} 
				    } 
			        
		       
		    } else {
		    	 xml.setMessage(trVo.getTrId());
		 	     xml.setError(false);
		    }

	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
    
    @RequestMapping(value="/tr/trDelete.do", method=RequestMethod.POST)
	public View deptDelete(@RequestParam(value="trId" ,required=true)String trId, Model model ) {
			   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     try {
				if ( trService.deleteTr(trId) > 0) {
				        xml.setMessage("삭제되었습니다.");
				        xml.setError(true);
				   
				} else {
					xml.setMessage("삭제에 실패하였습니다.");
				     xml.setError(false);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
    
    
    @RequestMapping(value="/tr/trDocIdCheck.do", method=RequestMethod.POST)
	public View trDocIdCheck(@RequestParam(value="docId" ,required=true)String docId, Model model ) {
			   

			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
		     try {
				if (trService.getTrDocId(docId) != null) {
				        xml.setError(true);
				   
				} else {
				     xml.setError(false);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
     
    
    
    @RequestMapping(value="/tr/history.do")
    public String selectHisotryList(@RequestParam(value="trId", defaultValue="", required=true) String trId, String ctype , Integer curPage,String searchFild,  String searchWord, Model model)
            throws Exception {
    
    	if (trId == "" || trId==null){
    		 
    	}
    	
    	if (curPage == null) curPage = 1;
		if (searchWord == null) searchWord = "";
		if (searchFild == null) searchFild = "";
		if (ctype == null) ctype = "T";  //A = calnote , T = trReport
 
//		int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//		int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		
		int totalRecord = calHistoryService.selectCalHistoryListTotCnt(trId, ctype, searchFild, searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
 	
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();  
		
        ArrayList<?> calHistoryList = calHistoryService.selectCalHistoryList(trId, ctype, searchFild, searchWord, start, end);
        model.addAttribute("resultList", calHistoryList);
        
        model.addAttribute("totalRecord", totalRecord);
        model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage);  
	 
		TrVO trVo = trService.getTr(trId);
		 
		model.addAttribute("thisVo", trVo);
		model.addAttribute("stateName", this.thisStateName(trVo.getState()));
		model.addAttribute("nextState", this.nextStateName(trVo.getState()));
		model.addAttribute("nextStateCode", this.nextStateCode(trVo.getState()));
		model.addAttribute("preStateCode", this.preStateCode(trVo.getState()));
        
        return "/tr/history";
    }
    
    
	@RequestMapping(value="/tr/historyAll.do")
    public String selectHistoryListAll(@RequestParam(value="trId", defaultValue="", required=true) String trId, String ctype , Model model)
            throws Exception {
    
    	if (trId == "" || trId==null){
    		 
    	} 
    	if (ctype == null) ctype = "T";  //A = calnote , T = trReport
        ArrayList<?> calHistoryList = calHistoryService.selectCalHistoryListAll(trId, ctype );
        model.addAttribute("resultList", calHistoryList);
        
        
        return "/tr/historyAll";
    }
    
    public String thisStateName (String state){
   	 
    	String thisStateName = prop_state.getProperty("TR_THISSTATE0");  //작성중
    	
    	 if (state != null && state.equals("R") ) {
    		thisStateName = prop_state.getProperty("TR_THISSTATE_R"); // 작성중
    	} else if (state != null && state.equals("R000") ) {
    		thisStateName = prop_state.getProperty("TR_THISSTATE_R000"); // Return
    	} else if (state != null && state.equals("A002")) {
    		thisStateName = prop_state.getProperty("TR_THISSTATE_A002");  //Co.Writer 
    	} else if (state != null && state.equals("A003")) {
    		thisStateName = prop_state.getProperty("TR_THISSTATE_A003");  //Reviewer 
    	} else if (state != null && state.equals("A004")) {
    		thisStateName = prop_state.getProperty("TR_THISSTATE_A004");  //Approver 
    	} else if (state != null && state.equals("S002")) {
    		thisStateName = prop_state.getProperty("TR_THISSTATE_S002");  // 결제완료
    	}
//    	System.out.println(state+"::thisStateName::"+thisStateName);
    	return thisStateName;
    }
    
    public String nextStateName (String state){
   	 
    	String nextStateName =prop_state.getProperty("TR_NEXTSTATE_R") ;  //독립검토 요청
    	if (state != null &&  ( state.equals("R") )) {
    		nextStateName = prop_state.getProperty("TR_NEXTSTATE_R"); // 독립검토 요청
    	} else if (state != null && state.equals("A002")   ) {
    		nextStateName = prop_state.getProperty("TR_NEXTSTATE_A002");  //검토 요청
    	} else if (state != null && state.equals("A003")   ) {
    		nextStateName = prop_state.getProperty("TR_NEXTSTATE_A003");  //검토 요청
    	} else if (state != null && state.equals("A004")) {
    		nextStateName = prop_state.getProperty("TR_NEXTSTATE_A004");  //승인 요청
    	}else if (state != null && state.equals("R000")) {
    	    nextStateName = prop_state.getProperty("TR_NEXTSTATE_R000");  //승인 요청
    	}
    	//System.out.println(state+"::nextStateName::"+nextStateName);
    	return nextStateName;
    }
    
    public String nextStateCode (String state){
      	 
    	String nextStateCode = "";
    	if (state != null && (state.equals("R") || state.equals("R000")) ) {
    		nextStateCode = "A002"; // 기본정보 저장
    	} else if (state != null && state.equals("A002")  ) {
    		nextStateCode = "A003";  //독립검토
    	} else if (state != null && state.equals("A003") ) { 
    		nextStateCode = "S004"; // 작성자 검토
    	} else if (state != null && state.equals("A004") ) { 
    		nextStateCode = "S002"; // 작성자 검토
    	}  
    	//System.out.println(state+"::nextStateCode::"+nextStateCode);
    	return nextStateCode;
    }
    
    public String preStateCode (String state){
     	 
    	String preStateCode = "";
    	if (state != null && state.equals("A002")) {
    		preStateCode = "R002";  
    	} else if (state != null && state.equals("A003")) {
    		preStateCode = "R003";   
    	} else if (state != null && state.equals("A004")) {
    		preStateCode = "R004"; 
    	} else if (state != null && state.equals("S002")) {
    		preStateCode = "R000"; 
    	}  
//    	System.out.println(state+"::nextStateName::"+nextStateName);
    	return preStateCode;
    }
    
    
    
    @RequestMapping(value = "/tr/panding_tr.do", method={RequestMethod.GET, RequestMethod.POST})
    public String pandingList( Integer curPage, String searchFild,  String searchWord,
    		String sortField, String sortOrder,Model model, Integer pagelimit) throws Exception  {
     
    	if (curPage == null) curPage = 1;
    	if (searchFild == null) searchFild = ""; 
		if (searchWord == null) searchWord = ""; 
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = ""; 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		int totalRecord = trService.pandingTrTotCnt(searchFild, searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		ArrayList<?> trList = trService.pandingTr(start, end, searchFild, searchWord, sortField, sortOrder);
 
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
		model.addAttribute("searchFild", searchFild); 
		model.addAttribute("searchWord", searchWord); 
        model.addAttribute("resultList", trList);
 
 		
        return "/myWork/panding_tr";
   } 
    
    
    @RequestMapping(value = "/tr/processed_tr.do", method={RequestMethod.GET, RequestMethod.POST})
    public String processedList( Integer curPage, String searchFild,  String searchWord,
    		String sortField, String sortOrder,Model model, Integer pagelimit) throws Exception  {
     
    	if (curPage == null) curPage = 1;
    	if (searchFild == null) searchFild = ""; 
		if (searchWord == null) searchWord = ""; 
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = ""; 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		int totalRecord = trService.processedTrTotCnt(searchFild, searchWord);
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		ArrayList<?> trList = trService.processedTr(start, end, searchFild, searchWord, sortField, sortOrder);
 
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
		model.addAttribute("searchFild", searchFild); 
		model.addAttribute("searchWord", searchWord); 
        model.addAttribute("resultList", trList);
 
 		
        return "/myWork/processed_tr";
   } 
    
    
    @RequestMapping(value="/tr/lastNumberCheck.do", method={RequestMethod.GET, RequestMethod.POST})
    public View lastNumberCheck(Model model, String docId ) throws Exception {
    	String lastNumber = trService.lastNumberCheck(docId);

		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
        if(lastNumber != null){
        	lastNumber = ""+Integer.parseInt(lastNumber);
        }else{
        	lastNumber = "0";
        }
    	xml.setMessage(lastNumber);
 	    xml.setError(true);

	    model.addAttribute("xmlData", xml);

	    return xmlView;

    	} 
    
    @RequestMapping(value = "/tr/pdfCreate.do")
    public String pdfCreate(HttpServletRequest req, ModelMap modelMap,String trId,Model model) throws Exception {
      TrVO trVo = trService.getTr(trId);
      List<JFileDetails> jfileVo = jfileService.getAttachFiles(trVo.getJfile());

     /* String fileName="";
      String dir="D:/report";
      fileName = "simple_table.pdf";
      File directory = new File(dir);
      if(!directory.exists()) directory.mkdirs(); //파일경로 없으면 생성
       
       Document document = new Document();
         PdfWriter.getInstance(document, new FileOutputStream(dir+"/"+fileName));
           
          document.open();
          PdfPTable table = new PdfPTable(5);
   
          for(int i = 0; i < 16; i++){
            table.addCell("cellNumber:" + trVo.getDocId());
          }
              table.addCell("cellNumber:" + trVo.getDocName());
              table.addCell("cellNumber:" + trVo.getDocName());
              table.addCell("cellNumber:" + trVo.getDocName());
              table.addCell("cellNumber:" + trVo.getDocName());
          document.add(table);
          document.close();*/
      model.addAttribute("trVo", trVo);
      model.addAttribute("jfileVo", jfileVo);
      return "trPdfController";
    }
    
    @RequestMapping(value = "/tr/pdfAbsorption.do")
    public String pdfAbsorption(HttpServletRequest req, ModelMap modelMap,Model model) throws Exception {
    	
    	File file = new File("c://Example//File//existFile.txt");
    	boolean isExists = file.exists();
    	if(isExists){
    		
    	} 
    	
    	 PdfReader reader1 = new PdfReader("D://report//simple_table.pdf");
    	 PdfReader reader2 = new PdfReader("D://report//TrReport17-08-30.pdf");
    	 PdfCopyFields copy = new PdfCopyFields(new FileOutputStream("D://report//pdfAbsorption.pdf"));
    	 copy.addDocument(reader1);
    	 copy.addDocument(reader2);
    	 copy.close();
      return "/tr/trList";
    }
    
    
}
