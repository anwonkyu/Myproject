package com.withus.boardlist.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.withus.boardHistory.dao.BoardHistoryVO;
import com.withus.boardHistory.service.BoardHistoryService;
import com.withus.boardinfo.dao.BoardInfoVO;
import com.withus.boardlist.service.BoardListService;
 
import com.withus.boardlist.dao.BoardListMapper;
import com.withus.boardlist.dao.BoardListVO;
 
import com.withus.commons.paging.PagingHelperServiceImpl;
import com.withus.commons.seed.WithusSeed;
import com.withus.member.dao.MemberVo;
 
/**
 * @Class Name : BoardListServiceImpl.java
 * @Description : BoardList Business Implement class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-07
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Service("boardListService")
public class BoardListServiceImpl  implements BoardListService {
        
    private static final Logger LOGGER = LoggerFactory.getLogger(BoardListServiceImpl.class);

    @Resource(name="boardListMapper")
    private BoardListMapper boardListDAO;
  
    @Autowired BoardHistoryService boardHistoryService;
    
    /** ID Generation */
    //@Resource(name="{egovBoardListIdGnrService}")    
    //private EgovIdGnrService egovIdGnrService;

	/**
	 * board_list을 등록한다.
	 * @param vo - 등록할 정보가 담긴 BoardListVO
	 * @return 등록 결과
	 * @exception Exception
	 */
    @Transactional
    public int insertBoardList(BoardListVO vo) throws Exception { 
    	  HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
    	  Authentication auth = (Authentication)request.getUserPrincipal();
		    
		     if(auth == null){
		          
		     }else{
		         Object principal = auth.getPrincipal();
		         if(principal != null && principal instanceof MemberVo){
 		        	// vo.setListName(((MemberVo)principal).getUsername());  // 아이디
 
		        	 vo.setListName(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
 		        	 vo.setMem_id(((MemberVo)principal).getId());  //아이디
		         }
		     } 
		    int result =  boardListDAO.insertBoardList(vo);
		    BoardHistoryVO boardHistoryVo = new BoardHistoryVO();
		    boardHistoryVo.setListId(vo.getListId());
		    boardHistoryVo.setState("I");
		    boardHistoryVo.setTitle(vo.getListTitle());
		    boardHistoryVo.setIp(request.getRemoteAddr());
		    boardHistoryService.insertBoardHistory(boardHistoryVo);
//    	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//		if (authentication.getName() != null && authentication.getName().length() > 0 && !authentication.getName().equals("anonymousUser")) {
//			vo.setListName(authentication.getName());
//		}
    	return result;
    }

    /**
	 * board_list을 수정한다.
	 * @param vo - 수정할 정보가 담긴 BoardListVO
	 * @return void형
	 * @exception Exception
	 */
    @Transactional
    public int updateBoardList(BoardListVO vo) throws Exception {
    	
		  	  HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
		  	  Authentication auth = (Authentication)request.getUserPrincipal();
		    
		     if(auth == null){
		          
		     }else{
		         Object principal = auth.getPrincipal();
		         if(principal != null && principal instanceof MemberVo){
		        	 //vo.setListName(((MemberVo)principal).getUsername());  //아이디
		        	 vo.setMem_id(((MemberVo)principal).getId());  //아이디
		        	 vo.setListName(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
	 		        	
		         }
		     } 
		     
//    	Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//		if (authentication.getName() != null && authentication.getName().length() > 0 && !authentication.getName().equals("anonymousUser")) {
//			vo.setListName(authentication.getName());
//		} 
	 
		int result = boardListDAO.updateBoardList(vo);   
		BoardHistoryVO boardHistoryVo = new BoardHistoryVO();
	    boardHistoryVo.setListId(vo.getListId());
	    boardHistoryVo.setBoardId(vo.getBoardId()); 
	    boardHistoryVo.setState("U");
	    boardHistoryVo.setTitle(vo.getListTitle());
	    boardHistoryVo.setIp(request.getRemoteAddr());
	   // System.out.println(boardHistoryVo);
	    boardHistoryService.insertBoardHistory(boardHistoryVo);
       return result;
    }

    /**
	 * board_list을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 BoardListVO
	 * @return void형 
	 * @exception Exception
	 */
    @Transactional
    public int deleteBoardList(BoardListVO vo) throws Exception {
    	int result =  boardListDAO.deleteBoardList(vo);
    	BoardHistoryVO boardHistoryVo = new BoardHistoryVO();
	    boardHistoryVo.setListId(vo.getListId());
	    boardHistoryVo.setState("D");
	    boardHistoryVo.setTitle(vo.getListTitle());
	    HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
	    boardHistoryVo.setIp(request.getRemoteAddr());
	    boardHistoryService.insertBoardHistory(boardHistoryVo);
    	
        return result;
    }

    /**
	 * board_list을 조회한다.
	 * @param vo - 조회할 정보가 담긴 BoardListVO
	 * @return 조회한 board_list
	 * @exception Exception
	 */
    public BoardListVO selectBoardList(int listId) throws Exception {
        BoardListVO resultVO = boardListDAO.selectBoardList(listId);
        return resultVO;
    }

    public BoardListVO selectCheckRow(int listRef , int listReLevel , int listStep) throws Exception{
    	HashMap<String, String> hashmap = new HashMap<String, String>();
    	Integer list_ref = listRef;
    	Integer list_re_level = listReLevel;
    	Integer list_step = listStep;
    	hashmap.put("listRef", list_ref.toString());
		hashmap.put("listReLevel", list_re_level.toString());
		hashmap.put("listStep", list_step.toString());
    	return boardListDAO.selectCheckRow(hashmap);
    }


    /**
	 * board_list 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return board_list 목록
	 * @exception Exception
	 */
    public ArrayList<BoardListVO> selectBoardListList(int boardId, String searchFild, String searchWord, int start, int end ) throws Exception {
    	Integer startRownum = start;
		Integer endRownum = end;
		Integer board_id = boardId;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("boardId", board_id.toString());
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
	 
		//System.out.println("selectCode="+selectCode);
        return boardListDAO.selectBoardListList( hashmap);
    }

    public ArrayList<BoardListVO> selectBoardListList(int boardId, String searchFild, String searchWord, int start, int end, String selectCode) throws Exception {
    	Integer startRownum = start;
		Integer endRownum = end;
		Integer board_id = boardId;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("boardId", board_id.toString());
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("selectCode", selectCode);
		//System.out.println("selectCode="+selectCode);
        return boardListDAO.selectBoardListList( hashmap);
    }

    
    /**
	 * board_list 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return board_list 총 갯수
	 * @exception
	 */
    public int selectBoardListListTotCnt(int boardId, String searchFild, String searchWord ) {
    	HashMap<String, String> hashmap = new HashMap<String, String>();
    	Integer board_id = boardId;
    	hashmap.put("boardId", board_id.toString());
    	hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
	 
 
		return boardListDAO.selectBoardListListTotCnt( hashmap);
	}
    
    public int selectBoardListListTotCnt(int boardId, String searchFild, String searchWord, String selectCode) {
    	HashMap<String, String> hashmap = new HashMap<String, String>();
    	Integer board_id = boardId;
    	hashmap.put("boardId", board_id.toString());
    	hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("selectCode", selectCode);
 
		return boardListDAO.selectBoardListListTotCnt( hashmap);
	}
 

	@Override
	public ArrayList<BoardListVO> selectBoardListList_notice(Integer boardId) throws Exception {
		return boardListDAO.selectBoardListList_notice( boardId);
	}

	@Override
	public void updateReadCount(Integer listId) {
		boardListDAO.updateReadCount(listId);
		
	}

	@Override
	public int deleteBoardListId(Integer boardId) throws Exception {
		 
		return boardListDAO.deleteBoardListId(boardId);
	}

	@Override
	public BoardListVO selectBoardListVodman(int listId) throws Exception {
		 BoardListVO resultVO = boardListDAO.selectBoardListVodman(listId);
	     return resultVO;
	}

	@Override
	public ArrayList<BoardListVO> selectBoardListListVodman(int boardId,
			String searchFild, String searchWord, int start, int end, String hcode)
			throws Exception {
		Integer startRownum = start;
		Integer endRownum = end;
		Integer board_id = boardId;
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("boardId", board_id.toString());
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("hcode",hcode);
 
        return boardListDAO.selectBoardListListVodman( hashmap);
	}

	@Override
	public int selectBoardListListTotCntVodman(int boardId, String searchFild,
			String searchWord, String hcode) {
		HashMap<String, String> hashmap = new HashMap<String, String>();
    	Integer board_id = boardId;
    	hashmap.put("boardId", board_id.toString());
    	hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("hcode", hcode);
	 
		return boardListDAO.selectBoardListListTotCntVodman( hashmap);
	}

	@Override
	
	public int insertBoardListReply(BoardListVO vo) throws Exception {
		
		
		 HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();  
	  	  Authentication auth = (Authentication)request.getUserPrincipal();
	    
	     if(auth == null){
	          
	     }else{
	         Object principal = auth.getPrincipal();
	         if(principal != null && principal instanceof MemberVo){
	        	 //vo.setListName(((MemberVo)principal).getUsername());  //아이디
	        	// vo.setListName( WithusSeed.returnSeedDeStr(((MemberVo)principal).getName()) );  //이름
	        	 vo.setListName(WithusSeed.returnSeedDeStr(((MemberVo)principal).getName())+"("+((MemberVo)principal).getId()+")");  //이름 + (ID)
		        	
	         }
	     } 
	     
//		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
//		if (authentication.getName() != null && authentication.getName().length() > 0) {
//			vo.setListName(authentication.getName());
//			///////////////////
//		} 

		int return_value = -1;
		HashMap<String, String> hashmap = new HashMap<String, String>();
    	hashmap.put("listRef", vo.getListRef().toString());
    	hashmap.put("listStep", vo.getListStep().toString());
    	if(vo.getHcode() != null && vo.getHcode() != ""){
    	hashmap.put("hcode", vo.getHcode().toString());
    	}

		boardListDAO.update_ListStep(hashmap); 
		
		if (boardListDAO.insertBoardListReply(vo) > 0){
			// 답변한 게시물과 관련된 게시물들의 list_step을 1씩 증가
//			System.out.println("step:"+vo.getListStep());
//			System.out.println("ref:"+vo.getListRef());
			return_value = 1;
		}
    	
    	return return_value;
	}

	@Override
	public BoardListVO getNextBoard(Integer listId, String searchFild,
			String searchWord) {
		
		HashMap<String, String> hashmap = new HashMap<String, String>();
		Integer list_id = listId;
    	hashmap.put("listId", list_id.toString());
    	hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		return boardListDAO.getNextBoard(hashmap);
	}

	@Override
	public BoardListVO getPrevBoard(Integer listId, String searchFild,
			String searchWord) {
		
		HashMap<String, String> hashmap = new HashMap<String, String>();
    	Integer list_id = listId;
    	hashmap.put("listId", list_id.toString());
    	hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		return boardListDAO.getPrevBoard(hashmap);
	}

	@Override
	public int pwdCheck(String listPasswd, Integer listId) {
		 
		HashMap<String, String> hashmap = new HashMap<String, String>();
    	Integer list_id = listId;
    	hashmap.put("listId", list_id.toString());
    	hashmap.put("listPasswd", listPasswd);
		
		return boardListDAO.pwdCheck(hashmap);
	}

	@Override
	public int dupCheck(String userId, Integer listId) {
		HashMap<String, String> hashmap = new HashMap<String, String>();
    	Integer list_id = listId;
    	hashmap.put("listId", list_id.toString());
    	hashmap.put("dupinfo", userId);
		
		return boardListDAO.dupCheck(hashmap);
	}

	@Override
	public ArrayList<BoardListVO> selectNotice_limit(String boardId,
			Integer limit) {
		
		HashMap<String, String> hashmap = new HashMap<String, String>();
    	hashmap.put("boardId", boardId);
    	hashmap.put("limit", limit.toString());
		
		return boardListDAO.selectNotice_limit(hashmap);
	}

	@Override
	public boolean fileCheck(String ocode, int userLevel) throws Exception{
		
		 boolean fileCheck = false;
		 BoardListVO resultVO = boardListDAO.fileCheck(Integer.parseInt(ocode)); //del_flag='N' and list_open='Y' 
		 
		 if (resultVO != null &&  resultVO.getListReLevel() <= userLevel) {
			 
			 if ( resultVO.getListSecurity().equals("Y") ) {  // 비밀글 본인 확인체크
				 String username ="";
				 	Authentication auth = SecurityContextHolder.getContext().getAuthentication(); 
					Object principal = auth.getPrincipal(); 
					if(principal != null && principal instanceof MemberVo){ 
						 username =((MemberVo)principal).getUsername();  //아이디
						 if (username.equals(resultVO.getMem_id())) {
							 fileCheck = true;
						 }
					}
				  
				 
			 } else {
				 fileCheck = true;
			 }
		 }
		return fileCheck;
	}

	
	 public int selectBoardListListTotCntAll(  String searchFild, String searchWord) {
	    	HashMap<String, String> hashmap = new HashMap<String, String>();
	     
	    	hashmap.put("searchFild", searchFild);
			hashmap.put("searchWord", searchWord);
	 
			return boardListDAO.selectBoardListListTotCntAll( hashmap);
		}
	 
	 public ArrayList<BoardListVO> selectBoardListListAll( String searchFild, String searchWord, int start, int end) throws Exception {
	    	Integer startRownum = start;
			Integer endRownum = end;
		 
			HashMap<String, String> hashmap = new HashMap<String, String>();
		 
			hashmap.put("searchFild", searchFild);
			hashmap.put("searchWord", searchWord);
			hashmap.put("start", startRownum.toString());
			hashmap.put("end", endRownum.toString());
	 
	        return boardListDAO.selectBoardListListAll( hashmap);
	    }

	@Override
	public ArrayList<BoardListVO> selectBoardListListAll(String searchFild,
			String searchWord, int start, int end, String selectCode)
			throws Exception {
		Integer startRownum = start;
		Integer endRownum = end;
	 
		HashMap<String, String> hashmap = new HashMap<String, String>();
	 
		hashmap.put("searchFild", searchFild);
		hashmap.put("searchWord", searchWord);
		hashmap.put("start", startRownum.toString());
		hashmap.put("end", endRownum.toString());
		hashmap.put("selectCode", selectCode);
 
        return boardListDAO.selectBoardListListAll( hashmap);
	}

	@Override
	public int selectInDept(String doc_type, String nowyear, String h_name,
			String mode, String create_num) throws Exception {
		HashMap<String, String> hashmap = new HashMap<String, String>();
		hashmap.put("doc_type", doc_type);
		hashmap.put("nowyear", nowyear);
		hashmap.put("h_name", h_name);
		hashmap.put("mode", mode);
		hashmap.put("create_num", create_num);
		return boardListDAO.selectInDept(hashmap);
	}

 
}
