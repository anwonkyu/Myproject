package com.withus.calnote;

 
import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
 









import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
 
import javax.servlet.http.HttpSession;
 








import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.oxm.xstream.XStreamMarshaller;
 
import org.springframework.security.core.Authentication;
 
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
 
import org.springframework.web.servlet.View;

import com.ext.jfile.JProperties;
import com.ext.jfile.service.JFile;
import com.ext.jfile.service.JFileDetails;
import com.ext.jfile.service.JFileService;
import com.ext.jfile.service.impl.JFileVO;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;
import com.lowagie.text.pdf.PdfCopyFields;
import com.lowagie.text.pdf.PdfReader;
import com.thoughtworks.xstream.XStream;
  
import com.withus.calHistory.dao.CalHistoryVO;
import com.withus.calHistory.service.CalHistoryService;
import com.withus.calnote.dao.CalnoteUpdateVO;
import com.withus.calnote.dao.CalnoteVO;
import com.withus.calnote.dao.OldFileVO;
import com.withus.calnote.service.CalnoteService;
 
import com.withus.category.service.CategoryService;
import com.withus.checklist.service.CheckListService;
 
import com.withus.commons.TextUtil;
import com.withus.commons.XmlResult;
import com.withus.commons.mail.DefaultMailMessage;
import com.withus.commons.mail.MailNotifier;
import com.withus.commons.paging.PagingHelper;
import com.withus.commons.paging.PagingHelperService;
 
import com.withus.commons.uploadFile.service.UploadFileService;
 
import com.withus.member.dao.MemberVo;
import com.withus.member.service.MemberService;
import com.withus.memo.service.ContentMemoService;
import com.withus.tr.dao.TrVO;
import com.withus.tr.service.TrService;
 
 
/**
 * Handles requests for the application home page.
 */
@Controller
public class CalculationNoteController {
	
	private static final Logger logger = LoggerFactory.getLogger(CalculationNoteController.class);
	  
	@Resource
	private CategoryService categoryService;
	@Autowired 
	private CalnoteService calnoteService;

	@Autowired 
	TrService trService;
	
	@Resource
    private UploadFileService uploadFileService;
	@Resource
	private PagingHelperService page;
	
	@Resource(name = "xstreamMarshaller")
    private XStreamMarshaller xstreamMarshaller;

    @Resource(name = "xmlView")
    private View xmlView;
    @Autowired
	private MemberService memberService;
    
    @Autowired Properties prop;
    @Autowired Properties prop_state;
    
    @Resource(name = "checkListService")
    private CheckListService checkListService;
    
    @Resource(name = "contentMemoService")
    private ContentMemoService contentMemoService;
    
	 @Resource(name = "calHistoryService")
	 private CalHistoryService calHistoryService;
	 
	 @Resource
	 private JFileService jfileService;
	 
    @Resource(name = "mailNotifier")
	private MailNotifier mailNotifier;    
    
    @Autowired Properties mailProp;
	
    @RequestMapping(value = "/calNote/calNoteList.do", method={RequestMethod.GET, RequestMethod.POST})
    public String calnoteList(CalnoteVO calnoteVo, Integer curPage, String datepicker, String datepicker2,String searchFild,  String searchWord,
    		String sortField, String sortOrder, String searchUnit,
    		Model model, Integer pagelimit, Integer selectSort ) throws Exception  {    	
    	
    	if (searchUnit == null || searchUnit == "") searchUnit="or";
    	String plantCd = calnoteVo.getPlantCd();
        String docName = calnoteVo.getDocName();
        String deptCd = calnoteVo.getDeptCd();
        String state = calnoteVo.getState();
        String docId = calnoteVo.getDocId();
        String name = calnoteVo.getName();
        int chngCoreCycleNum = 0;
        if( calnoteVo.getChngCoreCycleNum()!= null){
        	chngCoreCycleNum = calnoteVo.getChngCoreCycleNum();	
        }
        String unitNum = calnoteVo.getUnitNum();
        calnoteVo.setPlantCd(plantCd);
        calnoteVo.setDocName(docName);
        calnoteVo.setChngCoreCycleNum(chngCoreCycleNum);
        calnoteVo.setDeptCd(deptCd);
        calnoteVo.setState(state);
        calnoteVo.setName(name);
        if (curPage == null) curPage = 1;
    	if (selectSort == null) selectSort = 10;
		if (searchWord == null) searchWord = ""; 
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = ""; 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		if(selectSort == 20){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_20").trim());
		 
		} else if(selectSort == 50){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_50").trim());
 
		}else if(selectSort == 100){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_100").trim());
	 
		}
		int totalRecord = calnoteService.userCalnoteListTotCnt(plantCd, docName, chngCoreCycleNum,datepicker,datepicker2,unitNum,deptCd,state,searchUnit,docId,name );
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		/*PagingHelper pagingHelperLink = new PagingHelper(totalRecord, curPage, 10, 10); */
		
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		ArrayList<?> calnoteList = calnoteService.userCalnoteList(plantCd, docName, chngCoreCycleNum, datepicker, datepicker2,unitNum,deptCd,state, start, end, sortField, sortOrder, searchUnit,docId,name);
		model.addAttribute("thisVo", calnoteVo);
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("datepicker", datepicker);
		model.addAttribute("datepicker2", datepicker2);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
        model.addAttribute("resultList", calnoteList);
        model.addAttribute("searchUnit", searchUnit);
        model.addAttribute("selectSort", selectSort);
  		
    	return "/calNote/calNoteList";
   } 
    
    
    
    @RequestMapping(value = "/calNote/calNoteSearch.do", method={RequestMethod.GET, RequestMethod.POST})
    public String calNoteSearch(CalnoteVO calnoteVo, Integer curPage, String datepicker, String datepicker2,String searchFild,  String searchWord,
    		String sortField, String sortOrder, String searchUnit,
    		Model model, Integer pagelimit, Integer selectSort ) throws Exception  {    	
    	
    	if (searchUnit == null || searchUnit == "") searchUnit="or";
    	String plantCd = calnoteVo.getPlantCd();
        String docName = calnoteVo.getDocName();
        String deptCd = calnoteVo.getDeptCd();
        String state = calnoteVo.getState();
        String docId = calnoteVo.getDocId();
        String name = calnoteVo.getName();
        int chngCoreCycleNum = 0;
        if( calnoteVo.getChngCoreCycleNum()!= null){
        	chngCoreCycleNum = calnoteVo.getChngCoreCycleNum();	
        }
        String unitNum = calnoteVo.getUnitNum();
        calnoteVo.setPlantCd(plantCd);
        calnoteVo.setDocName(docName);
        calnoteVo.setChngCoreCycleNum(chngCoreCycleNum);
        calnoteVo.setDeptCd(deptCd);
        calnoteVo.setState(state);
        calnoteVo.setName(name);
        if (curPage == null) curPage = 1;
    	if (selectSort == null) selectSort = 10;
		if (searchWord == null) searchWord = ""; 
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = ""; 
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		if(selectSort == 20){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_20").trim());
		 
		} else if(selectSort == 50){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_50").trim());
 
		}else if(selectSort == 100){
			numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE_100").trim());
	 
		}
		int totalRecord = calnoteService.userCalnoteListTotCnt(plantCd, docName, chngCoreCycleNum,datepicker,datepicker2,unitNum,deptCd,state,searchUnit,docId,name );
		int totalTrRecord = trService.selectTrTotCnt(docName,"","","","","","");
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		/*PagingHelper pagingHelperLink = new PagingHelper(totalRecord, curPage, 10, 10); */
		
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		ArrayList<?> calnoteList = calnoteService.userCalnoteList(plantCd, docName, chngCoreCycleNum, datepicker, datepicker2,unitNum,deptCd,state, start, end, sortField, sortOrder, searchUnit,docId,name);
		model.addAttribute("thisVo", calnoteVo);
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("datepicker", datepicker);
		model.addAttribute("datepicker2", datepicker2);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
        model.addAttribute("resultList", calnoteList);
        model.addAttribute("searchUnit", searchUnit);
        model.addAttribute("selectSort", selectSort);
        model.addAttribute("totalTrRecord", totalTrRecord);
		   
 		
    	return "/calNote/calNoteSearch";
   } 
    
    
    @RequestMapping(value = "/calNote/docListSearch.do", method={RequestMethod.GET, RequestMethod.POST})
    public String calNoteDocList(CalnoteVO calnoteVo, Integer curPage, String datepicker, String datepicker2,String searchFild,  String searchWord, 
    		String sortField, String sortOrder, String searchUnit,
    		Model model, Integer pagelimit ) throws Exception  {
    	if (searchUnit == null || searchUnit == "") searchUnit="or";
    	String plantCd = calnoteVo.getPlantCd();
        String docName = calnoteVo.getDocName();
        String deptCd = calnoteVo.getDeptCd();
        String state = calnoteVo.getState();
        String docId = calnoteVo.getDocId();
        int chngCoreCycleNum = 0;
        if( calnoteVo.getChngCoreCycleNum()!= null){
        	chngCoreCycleNum = calnoteVo.getChngCoreCycleNum();	
        }
        String unitNum = calnoteVo.getUnitNum();
        calnoteVo.setPlantCd(plantCd);
        calnoteVo.setDocName(docName);
        calnoteVo.setChngCoreCycleNum(chngCoreCycleNum);
        calnoteVo.setDeptCd(deptCd);
        calnoteVo.setState(state);
        if (curPage == null)
    	if (curPage == null) curPage = 1;
		if (searchWord != null){
			calnoteVo.setDocName(searchWord);
		}
		
		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
		int totalRecord = calnoteService.userCalnoteListTotCnt(plantCd, docName, chngCoreCycleNum,datepicker,datepicker2,unitNum,deptCd,state, searchUnit,docId,"");
		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
		
		
		page.setPagingHelper(pagingHelper);
		int start = pagingHelper.getStartRecord();
		int end = pagingHelper.getEndRecord();
		if (sortField == null) sortField = ""; 
		if (sortOrder == null) sortOrder = ""; 
		
		ArrayList<?> calnoteList = calnoteService.userCalnoteList(plantCd, docName, chngCoreCycleNum, datepicker, datepicker2,unitNum,deptCd,state, start, end, sortField, sortOrder, searchUnit,docId,"");
		model.addAttribute("thisVo", calnoteVo);
		Integer prevLink = page.getPrevLink();
		Integer nextLink = page.getNextLink();
		Integer firstPage = page.getFirstPage();
		Integer lastPage = page.getLastPage();
		int[] pageLinks = page.getPageLinks();
		model.addAttribute("datepicker", datepicker);
		model.addAttribute("datepicker2", datepicker2);
		model.addAttribute("prevLink", prevLink);
		model.addAttribute("nextLink", nextLink);
		model.addAttribute("firstPage", firstPage);
		model.addAttribute("lastPage", lastPage);
		model.addAttribute("pageLinks", pageLinks);
		model.addAttribute("curPage", curPage); 
		model.addAttribute("totalRecord", totalRecord); 
		
		
		model.addAttribute("sortField", sortField); 
		model.addAttribute("sortOrder", sortOrder); 
		model.addAttribute("searchUnit", searchUnit); 
		
        model.addAttribute("resultList", calnoteList);
		   
 		
    	return "/processing/docListSearch";
   } 
    
    
 

    @RequestMapping(value = "/calNote/calNoteAdd.do", method=RequestMethod.GET )
    public String calnoteAdd( Model model) throws Exception  {
    	HttpServletRequest req = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = req.getSession(false); 
 
		model.addAttribute("stateName", this.thisStateName(""));
		model.addAttribute("nextState", this.nextStateName(""));
		model.addAttribute("nextStateCode", this.nextStateCode(""));
		 
	 
    	return "/calNote/calNoteAdd";
   } 
    
    @RequestMapping(value="/calNote/calNoteAdd.do", method=RequestMethod.POST)
    public String calWrite(CalnoteVO calnoteVo )throws Exception {
    	
    	Map<String, Object> map = new HashMap<String, Object>();
    	/*if(calnoteVo.getJfile().length()){
    		System.out.println("null이 아님");
    	}else{
    		System.out.println("null이 맞음");
    	}*/ 
    	
    	
    	int pdf_cnt =  Integer.parseInt(prop.getProperty("PDF_CNT").trim());
    	
    	if(calnoteVo.getJfile().length() > 0){
    		List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
    		JFileVO jdVo = (JFileVO) jfileDivision.get(0);
    		String extension = jdVo.getFileName().substring(jdVo.getFileName().length()-3, jdVo.getFileName().length());
    		if(extension.equals("pdf")){
    			JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
    			String dFilePath = downloadFile.toString();
    			com.itextpdf.text.pdf.PdfReader reader = new com.itextpdf.text.pdf.PdfReader(dFilePath);
    			int pagenumber = reader.getNumberOfPages();
    			int totalPageNum = 0;
    			for(int i = 1; i<= pagenumber; i++) {
    	            String text = PdfTextExtractor.getTextFromPage(reader,i);
    	            totalPageNum = i;
    	        }
    	   	totalPageNum = totalPageNum +pdf_cnt;
    	   	calnoteVo.setTotalPageNum( String.valueOf(totalPageNum)); 	 	
    	   	map.put("totalPageNum", String.valueOf(totalPageNum));
    	   	map.put("downloadFile", downloadFile);
    		}else{
    			calnoteVo.setTotalPageNum(pdf_cnt+""); 	 	
        	   	map.put("totalPageNum", pdf_cnt);
        	   	map.put("downloadFile", "notPdf");	
    		}
    		
    	   	
    	}else{
    		calnoteVo.setTotalPageNum(pdf_cnt+""); 	 	
    	   	map.put("totalPageNum", pdf_cnt);
    	   	map.put("downloadFile", "notPdf");	
    	}
    	
//    	int indBracketOpen = calnoteVo.getIndependent().indexOf("(");
//    	int indBracketClose = calnoteVo.getIndependent().indexOf(")");
//    	String independent = calnoteVo.getIndependent().substring(indBracketOpen+1, indBracketClose);
//    	
//    	int revBracketOpen = calnoteVo.getReviewer().indexOf("(");
//    	int revBracketClose = calnoteVo.getReviewer().indexOf(")");
//    	String reviewer = calnoteVo.getReviewer().substring(revBracketOpen+1, revBracketClose);
//    	
//    	int appBracketOpen = calnoteVo.getApprover().indexOf("(");
//    	int appBracketClose = calnoteVo.getApprover().indexOf(")");
//    	String approver = calnoteVo.getApprover().substring(appBracketOpen+1, appBracketClose);
    	
//    	calnoteVo.setIndependent(independent);
//    	calnoteVo.setReviewer(reviewer);
//    	calnoteVo.setApprover(approver);
//    	calnoteVo.setOrderName(independent);
    	
    	calnoteService.insertCalnote(calnoteVo); 
    	
    	CalnoteVO Vo = calnoteService.getCalnote(calnoteVo.getCalnoteId());
//    	MemberVo independentVo = memberService.memberInfo(calnoteVo.getIndependent());
//        MemberVo reviewerVo = memberService.memberInfo(calnoteVo.getReviewer());
//        MemberVo approverVo = memberService.memberInfo(calnoteVo.getApprover());
    	 map.put("calnoteVo", Vo);
//    	 map.put("independentVo", independentVo);
//    	 map.put("reviewerVo", reviewerVo);
//    	 map.put("approverVo", approverVo);
    	 
    	com.withus.pdf.calNote.CalNotePdfController.buildPdfDocument2(map);
    	com.withus.pdf.calNote.CalnoteEndPageController.buildPdfDocument2(map);    	
    	
        return "redirect:/calNote/calNoteList.do";
    }
    
    
    @RequestMapping(value="/calNote/calNoteUpdate.do", method=RequestMethod.GET)
	public String calUpdate(String calnoteId, Model model) throws Exception {
    	
		CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
		String return_rul = "redirect:/calNote/calNoteUpdate_info.do?calnoteId="+calnoteVo.getCalnoteId();
     
    	 return return_rul;
    	
	}
    
    @RequestMapping(value="/calNote/calNoteUpdate_copy.do", method={RequestMethod.GET, RequestMethod.POST})
   	public String calUpdateinfo_copy(String calnoteId, Model model) throws Exception {
       	
   		CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
   		
   		String temp_date = calnoteVo.getRegDate();
   		temp_date = temp_date.substring(0,10).replaceAll("-", "");
   		
   		int rev_ = 1;
   		
   		int rev_max = calnoteService.getRevisionMax(calnoteVo.getDocId());
   		
   		if (rev_max > 0) {
   			rev_ =rev_max+ 1;
   		} 
   		 
   		calnoteVo.setRevision(rev_+"");
   		calnoteVo.setCalnoteId(null);
   		calnoteVo.setJfile(null);
   		calnoteVo.setAppDate(null);
   		calnoteVo.setRegDate(null);
   		calnoteVo.setName(null);
   		calnoteVo.setUserId(null);
   		calnoteVo.setTotalPageNum(null);
   		calnoteVo.setRealTotalPage(null);
   		calnoteVo.setState(null);
   		calnoteVo.setStat(null);   		
 
   		 
   		model.addAttribute("stateName", this.thisStateName(""));
   		model.addAttribute("nextState", this.nextStateName(""));
   		model.addAttribute("nextStateCode", this.nextStateCode(""));
   		model.addAttribute("preStateCode", this.preStateCode(""));	
   		model.addAttribute("thisVo", calnoteVo);	
   		return "/calNote/calNoteAdd";
   	}
    
    
    @RequestMapping(value="/calNote/calNoteUpdate_info.do", method=RequestMethod.GET)
	public String calUpdateinfo(String calnoteId, Model model) throws Exception {
    	
		CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
		
		//수정페이지에서의 보일 게시글 정보
		model.addAttribute("thisVo", calnoteVo);
		
		String temp_date = calnoteVo.getRegDate();
		temp_date = temp_date.substring(0,10).replaceAll("-", "");
		 
		if (calnoteVo.getRegDate()!= null ){
			if ( Integer.parseInt(temp_date.trim()) <  Integer.parseInt(prop.getProperty("VIEW_DATE").trim()) ) {
				 
				List<OldFileVO> oldFileList = calnoteService.getOldFileList(calnoteVo.getCalnoteId() ); 
				model.addAttribute("oldFileList", oldFileList);  // 파일목록   
				model.addAttribute("temp_date", temp_date);
				 
			}			
		}
	
		 
		model.addAttribute("stateName", this.thisStateName(calnoteVo.getState()));
		model.addAttribute("nextState", this.nextStateName(calnoteVo.getState()));
		model.addAttribute("nextStateCode", this.nextStateCode(calnoteVo.getState()));
		model.addAttribute("preStateCode", this.preStateCode(calnoteVo.getState()));	
		return "/calNote/calNoteAdd";
	}
    
    
    @Transactional
    @RequestMapping(value="/calNote/calNoteUpdate.do", method=RequestMethod.POST)
	public View calUpdate(@ModelAttribute("calnoteVo") CalnoteVO calnoteVo, Model model ) throws Exception {
    		Map<String, Object> map = new HashMap<String, Object>();
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
 
	        int pdf_cnt =  Integer.parseInt(prop.getProperty("PDF_CNT").trim());
	        
		     if ( calnoteService.updateCalnote(calnoteVo) > 0) {
			        xml.setMessage(calnoteVo.getState());
			        xml.setError(true);
			        CalnoteVO vo = calnoteService.getCalnote(calnoteVo.getCalnoteId()); 
			        if(calnoteVo.getJfile().length() > 0){
			    		List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
			    		JFileVO jdVo = (JFileVO) jfileDivision.get(0);
			    		String extension = jdVo.getFileName().substring(jdVo.getFileName().length()-3, jdVo.getFileName().length());
			    		if(extension.equals("pdf")){
			    			JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
			    			String dFilePath = downloadFile.toString();
			    			com.itextpdf.text.pdf.PdfReader reader = new com.itextpdf.text.pdf.PdfReader(dFilePath);
			    			int pagenumber = reader.getNumberOfPages();
			    			int totalPageNum = 0;
			    			for(int i = 1; i<= pagenumber; i++) {
			    	            String text = PdfTextExtractor.getTextFromPage(reader,i);
			    	            totalPageNum = i;
			    	        }
			    	   	totalPageNum = totalPageNum +pdf_cnt;
			    	   	calnoteVo.setTotalPageNum( String.valueOf(totalPageNum)); 	 	
			    	   	map.put("totalPageNum", String.valueOf(totalPageNum));
			    	   	map.put("downloadFile", downloadFile);
			    		}else{
			    			calnoteVo.setTotalPageNum(pdf_cnt+""); 	 	
			        	   	map.put("totalPageNum", pdf_cnt);
			        	   	map.put("downloadFile", "notPdf");	
			    		}
			    	   	
			    	}else{
			    		calnoteVo.setTotalPageNum(pdf_cnt+""); 	 	
			    	   	map.put("totalPageNum", pdf_cnt);
			    	   	map.put("downloadFile", "notPdf");	
			    	}
			        
			        
//			        MemberVo independentVo = memberService.memberInfo(calnoteVo.getIndependent());
//			        MemberVo reviewerVo = memberService.memberInfo(calnoteVo.getReviewer());
//			        MemberVo approverVo = memberService.memberInfo(calnoteVo.getApprover());
			    	 map.put("calnoteVo", vo);
//			    	 map.put("independentVo", independentVo);
//			    	 map.put("reviewerVo", reviewerVo);
//			    	 map.put("approverVo", approverVo);
			    	com.withus.pdf.calNote.CalNotePdfController.buildPdfDocument2(map);
			    	com.withus.pdf.calNote.CalnoteEndPageController.buildPdfDocument2(map); 

			    	
//메일 발송  (해당 단계 - 담당자, 완료 - 등록된 담당자, 작성자 전체)
			    	
			    	ArrayList<MemberVo> userInfoList = null;
					SimpleMailMessage email = new SimpleMailMessage(); 			
				 	
					String userIds = "";
					String mail_title = "iCan Calculation Note";
					String mail_content_link = "http://localhost:8088/calNote/calNoteUpdate_info.do?calnoteId="+calnoteVo.getCalnoteId();
					String mail_content_sub = "";
					if ( calnoteVo.getState() != null && (calnoteVo.getState().equals("R001") ) ) {  //   작성자에게 리턴
						mail_title = calnoteVo.getStat()+ "";
						mail_content_sub = "";
						userIds = TextUtil.getOwners(calnoteVo.getName(), "id");
						
					} else if (calnoteVo.getState() != null && (calnoteVo.getState().equals("A002") )) { // 독립검토요청
						mail_title = calnoteVo.getStat()+ " ";
						userIds = TextUtil.getOwners(calnoteVo.getIndependent(), "id");
						
					} else if (calnoteVo.getState() != null && (calnoteVo.getState().equals("R002") || calnoteVo.getState().equals("R003") )) { // 독립검토자에게 리턴
						mail_title = calnoteVo.getStat()+ " ";
						userIds = TextUtil.getOwners(calnoteVo.getIndependent(), "id");						
					 
					} else if (calnoteVo.getState() != null && (calnoteVo.getState().equals("A003") )) { // 검토요청
						mail_title = calnoteVo.getStat()+ " ";
						userIds = TextUtil.getOwners(calnoteVo.getReviewer(), "id");
						
					} else if (calnoteVo.getState() != null && (calnoteVo.getState().equals("A004") )) { // 승인요청
						mail_title = calnoteVo.getStat()+ " ";
						userIds = TextUtil.getOwners(calnoteVo.getApprover(), "id");
						
					} else if (calnoteVo.getState() != null && (calnoteVo.getState().equals("S002") )) { // 등록완료
						mail_title = calnoteVo.getStat()+ " ";
						userIds = TextUtil.getOwners(calnoteVo.getName(), "id");
						userIds = userIds +","+TextUtil.getOwners(calnoteVo.getIndependent(), "id");
						userIds = userIds +","+TextUtil.getOwners(calnoteVo.getReviewer(), "id");
						userIds = userIds +","+TextUtil.getOwners(calnoteVo.getApprover(), "id");
						 
						// pdf 임시파일 삭제
						this.pdfFileDelete(calnoteVo);
					}
				 
					if (userIds != null && userIds.length() > 0) {
						userInfoList = memberService.readUserInfoList(userIds.split(",")); // 배열로 넘김
					} 
					int mail_send = 0;
					int mail_false = 0;
						if (userInfoList != null  ) {   
							
								DefaultMailMessage mailMsg = new DefaultMailMessage();
								mailMsg.setCharset("euc-kr");
								mailMsg.setSubject(mail_title);  // 메일 타이틀
								
								StringBuffer mailContent = new StringBuffer(); // 메일 내용
								mailContent.append("mail_title"); 
								mailContent.append("<br>"); 
								mailContent.append( mail_content_link );
								mailContent.append("<br>");		
								
							 for (MemberVo value: userInfoList){
								 try{
								 	if (value.getEmail() != null && value.getEmail().length() > 0) { 
								 	  
				 		    				mailMsg.setFrom(mailProp.getProperty("mail.username"));  // 보내는 메일 주소 
				 		    				mailMsg.setFromName("i-Can");
				 		    		 		
				 		    				mailMsg.setHtmlContent(mailContent.toString());
				 	    					mailMsg.setTo(value.getEmail());
				 	    					mailMsg.setToName(value.getName());
				 	    	//				mailNotifier.sendEmailTo(mailMsg);
				 	    					
				 	    					mail_send ++;
									}
								 	System.out.println("mailMessage::"+mailMsg.toString());
						    		 
								 // test 메일 발송 (SimpleMailMessage)
				//				email.setTo("dolhyun@withustech.com");  //이메일 복호화
				//	       	        email.setSubject(boardListVO.getListTitle());
				//	       	        email.setText(mail_contents);
				//	       	        email.setFrom(mailProp.getProperty("mail.username"));
				
				//	       	        mailSender.send(email);
				
								 
								 //html 메일 전송
				//				mailMsg.setFrom(mailProp.getProperty("mail.username"));  // 보내는 메일 주소
				//	    				mailMsg.setFromName("i-can"); 
				//	    			 
				// 					mailMsg.setHtmlContent(mailContent.toString());
				// 					mailMsg.setTo("dolhyun@withustech.com");
				// 					mailMsg.setToName("주현");
				// 					mailNotifier.sendEmailTo(mailMsg); 
								 	
								 	
							 } catch (Exception e) {
							    	System.out.println(e);
							    	mail_false++; 
							}  
						} 
				    }
			    	
		        
			        
		    } else {
		    	 xml.setMessage(calnoteVo.getState());
		 	     xml.setError(false);
		    }

		     
		   
		     
	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
    
    
    
    ///
   /* @RequestMapping(value="/calNote/feedbackPageNum.do", method=RequestMethod.POST)
	public View feedbackPageNum(@ModelAttribute("calnoteVo") CalnoteVO calnoteVo, Model model ) throws Exception {
    		Map<String, Object> map = new HashMap<String, Object>();
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 

		     String calnoteFeedbackPath = JProperties.getString("system.calnoteFeedback");
		        File file = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
	        	boolean isExists = file.exists();
	        	if(isExists){
	        		com.itextpdf.text.pdf.PdfReader reader2 = new com.itextpdf.text.pdf.PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
	        		int pagenumber = reader2.getNumberOfPages();
	        		int feedbackPage = 0;
	        		for(int i = 1; i<= pagenumber; i++) {
	    	            String text = PdfTextExtractor.getTextFromPage(reader2,i);
	    	            feedbackPage = i;
	    	        }
	        		calnoteVo.setFeedbackPageNum(String.valueOf(feedbackPage));
	        	} 
     	
	        	calnoteService.updateCalnote(calnoteVo);
	        	 xml.setMessage(calnoteVo.getFeedbackPageNum());
		     
	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}*/
    
    
    
    
    @RequestMapping(value="/calNote/calNoteDelete.do", method=RequestMethod.POST)
	public View deptDelete(@RequestParam(value="calnoteId" ,required=true)String calnoteId, Model model ) {
			   
			XStream xst = xstreamMarshaller.getXStream();
	    	xst.alias("result", XmlResult.class);  
	        XmlResult xml = new XmlResult(); 
	        
		     try {
				if ( calnoteService.deleteCalnote(calnoteId) > 0) {
				        xml.setMessage("삭제되었습니다.");
				        xml.setError(true);
				   
				} else {
					xml.setMessage("삭제에 실패하였습니다.");
				     xml.setError(false);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
	    model.addAttribute("xmlData", xml);
	    
	    return xmlView;
	    
	}
    
    @RequestMapping(value = "/calNote/pop_doc.do" )
    public String calnotePopDoc(  String calnoteId, Model model,  Integer pagelimit ) throws Exception  {
     
    	if (calnoteId != null && calnoteId.length() >0 ) {
		model.addAttribute("thisVo", calnoteService.getCalnote(calnoteId));
    	}
 
    	return "/calNote/popDoc";
   } 
    
    @RequestMapping(value="/calNote/popApprovalUpdateList.do")
    public String approvalList(Model model,String kinds)throws Exception{  
    	model.addAttribute("kinds", kinds);
    	return "/calNote/popApprovalUpdateList";
    }
    
    @RequestMapping(value="/calNote/calNoteGetDocId.do", method={RequestMethod.GET, RequestMethod.POST})
    public View checkDocId(Model model, String docId ) throws Exception {
     
    	String checkDocNum = calnoteService.checkDocId(docId);
    	String docNum = "";
    	if(checkDocNum != null){
    		docNum = docId+checkDocNum;
    	}else{
    		docNum = docId + "001";
    	}
		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
    	xml.setMessage(docNum);
 	    xml.setError(true);
	    model.addAttribute("xmlData", xml);
	    return xmlView;
    	}
    
    @RequestMapping(value="/calNote/calNoteNomalDocId.do", method={RequestMethod.GET, RequestMethod.POST})
    public View calNoteNomalDocId(Model model, String docId ) throws Exception {
    	String checkDocNum = calnoteService.checkDocId(docId);
    	String docNum = "";
    	if(checkDocNum != null){
    		docNum = docId+checkDocNum;
    	}else{
    		docNum = docId + "001";
    	}

		XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 

    	xml.setMessage(docNum);
 	    xml.setError(true);

	    model.addAttribute("xmlData", xml);

	    return xmlView;



    	}
    
    @RequestMapping("/calNote/calNoteUpdate_ind.do")
	 public String calNoteUpdate_indDetail(  String type , ModelMap model,String calnoteId,String state) throws Exception {
    	 
    	if (calnoteId == null) calnoteId="";
    	/*if (flag == null) return null;*/
     
		
		//ArrayList<?> checkList = checkListService.selectCheckList(type);  //체크리스트 문항
		
		//CalnoteUpdateVO calnoteUpdateVo = calnoteService.getCalnoteUpdateVo(calnoteId);  // 체크리스트 체크항목
    	CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
		model.addAttribute("state",state);
		//model.addAttribute("checkList", checkList); 
		//model.addAttribute("thisUpVo", calnoteUpdateVo);
		model.addAttribute("type", type);
		model.addAttribute("thisVo", calnoteVo); 
		model.addAttribute("stateName", this.thisStateName(calnoteVo.getState()));
		model.addAttribute("nextState", this.nextStateName(calnoteVo.getState()));
		model.addAttribute("nextStateCode", this.nextStateCode(calnoteVo.getState()));
		model.addAttribute("preStateCode", this.preStateCode(calnoteVo.getState()));
		return "/calNote/calNoteUpdate_ind";
	}
    
    @RequestMapping(value="/calNote/calNoteUpdate_Add.do", method=RequestMethod.POST)
    @Transactional
    public View calNoteUpdate_Add(CalnoteUpdateVO checklistVo, String state, Model model )throws Exception {
        
        XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult();  
        CalnoteVO calnoteVo = new CalnoteVO();
        calnoteVo.setCalnoteId(checklistVo.getCalnoteId());
        calnoteVo.setState(state);
        
	     if (calnoteService.updateCalnote(calnoteVo)  > 0) {
	    	calnoteService.mergeCheck1_1(checklistVo);
	        xml.setMessage(checklistVo.getCalnoteId());
	        xml.setError(true);
	       
	    } else {
	    	 xml.setMessage(checklistVo.getCalnoteId());
	 	     xml.setError(false);
	    }

    model.addAttribute("xmlData", xml);
    
    return xmlView;
        
        
    }
    
    @RequestMapping(value="/calNote/calNoteUpdate_State.do", method=RequestMethod.POST)
    public View calNoteUpdate_State(CalnoteVO calnoteVo, Model model )throws Exception {
        
        XStream xst = xstreamMarshaller.getXStream();
    	xst.alias("result", XmlResult.class);  
        XmlResult xml = new XmlResult(); 
	     if ( calnoteService.updateCalnote(calnoteVo) > 0) {
	        xml.setMessage(calnoteVo.getCalnoteId());
	        xml.setError(true);
	       
	    } else {
	    	 xml.setMessage(calnoteVo.getCalnoteId());
	 	     xml.setError(false);
	    }

    model.addAttribute("xmlData", xml);
    
    return xmlView;
        
        
    }
    
    
    @RequestMapping("/calNote/calNoteUpdate_rev.do")
	 public String calNoteUpdate_revDetail(  String type , ModelMap model,String calnoteId,String state) throws Exception {
	    	
	    	if (calnoteId == null) calnoteId="";
	    	/*if (flag == null) return null;*/ 
			
			CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
			model.addAttribute("type", type);
			model.addAttribute("thisVo", calnoteVo);
			model.addAttribute("stateName", this.thisStateName(calnoteVo.getState()));
			model.addAttribute("nextState", this.nextStateName(calnoteVo.getState()));
			model.addAttribute("nextStateCode", this.nextStateCode(calnoteVo.getState()));
			model.addAttribute("preStateCode", this.preStateCode(calnoteVo.getState()));
		return "/calNote/calNoteUpdate_rev";
	}
    
    @RequestMapping("/calNote/calNoteUpdate_app.do")
	 public String calNoteUpdate_appDetail(  String type , ModelMap model,String calnoteId,String state) throws Exception {
	    	
	    	if (calnoteId == null) calnoteId="";
	    	/*if (flag == null) return null;*/ 
			
			CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
			model.addAttribute("type", type);
			model.addAttribute("thisVo", calnoteVo);
			model.addAttribute("stateName", this.thisStateName(calnoteVo.getState()));
			model.addAttribute("nextState", this.nextStateName(calnoteVo.getState()));
			model.addAttribute("nextStateCode", this.nextStateCode(calnoteVo.getState()));
			model.addAttribute("preStateCode", this.preStateCode(calnoteVo.getState()));
		return "/calNote/calNoteUpdate_app";
	}
     
  
     
        @RequestMapping("/calNote/popFeedBack.do")
    	 public String calNote_Feedback(  String type , ModelMap model,String calnoteId) throws Exception {
 
        	CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
        		model.addAttribute("thisVo", calnoteVo);
    			model.addAttribute("type", type);
    			model.addAttribute("calnoteId", calnoteId);  
 
    		return "/calNote/popFeedBack";
    	}
        

        
     @RequestMapping("/calNote/popCheckList.do")
   	 public String calNote_CheckList(  String type , ModelMap model,String calnoteId) throws Exception {
        	CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
       	    ArrayList<?> checkList = checkListService.selectCheckList(type,"user");  //체크리스트 문항
       	    CalnoteUpdateVO thisUpVo = calnoteService.getCalnoteUpdateVo(calnoteId);  // 체크리스트 체크항목
   			model.addAttribute("type", type);
   			model.addAttribute("calnoteId", calnoteId);
   			model.addAttribute("checkList", checkList);
   			model.addAttribute("thisUpVo", thisUpVo);
   			model.addAttribute("thisVo", calnoteVo);

   		return "/calNote/popCheckList";
   	}
       
     @RequestMapping(value="/calNote/checkList_Whether.do", method=RequestMethod.POST)
     public View checkList_Whether(String calnoteId,Model model)throws Exception {
    	 XStream xst = xstreamMarshaller.getXStream();
         xst.alias("result", XmlResult.class);  
         XmlResult xml = new XmlResult();  
    	 CalnoteUpdateVO thisUpVo = calnoteService.getCalnoteUpdateVo(calnoteId);
    	 
    	 if (thisUpVo != null) { 
    	        xml.setError(true);
    	       
    	    } else {
    	 	     xml.setError(false);
    	    }
    	 
    	 model.addAttribute("xmlData", xml);
         
         return xmlView;
     
     
     } 
     
     
       @RequestMapping(value="/calNote/checkList_proc.do", method=RequestMethod.POST)
         public View CheckList_proc(CalnoteUpdateVO checklistVo,  Model model )throws Exception {
           
           XStream xst = xstreamMarshaller.getXStream();
           xst.alias("result", XmlResult.class);  
           XmlResult xml = new XmlResult();  
           CalnoteVO calnoteVo = new CalnoteVO();
           calnoteVo.setCalnoteId(checklistVo.getCalnoteId());
             
   	     if (calnoteService.mergeCheck1_1(checklistVo)  > 0) { 
   	    	 
   	    	Map<String, Object> map = new HashMap<String, Object>();
   	    	CalnoteVO vo = calnoteService.getCalnote(checklistVo.getCalnoteId());
   	    	map.put("calnoteVo", vo);
   	    	map.put("checklistVo", checklistVo);
   	    	map.put("calnoteId", checklistVo.getCalnoteId());
 
   	        ArrayList<?> checkList = checkListService.selectCheckList("1-1","user");
 
   	        map.put("checkList", checkList);
   	    	com.withus.pdf.calNote.CalnotePdfCheckListController.buildPdfDocument2(map);  
   	    	 
   	    	 
   	        xml.setMessage(checklistVo.getCalnoteId());
   	        xml.setError(true);
   	       
   	    } else {
   	    	 xml.setMessage(checklistVo.getCalnoteId());
   	 	     xml.setError(false);
   	    }

       model.addAttribute("xmlData", xml);
       
       return xmlView; 
           
       } 
        
          public String thisStateName (String state){
        	 
        	String thisStateName = prop_state.getProperty("CAL_THISSTATE0");  //작성중
        	
        	if (state != null && state.equals("R") ) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_R"); // 작성중
        	} else if (state != null && state.equals("A002") ) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_A002"); // 독립검토 중
        	} else if (state != null && state.equals("A003")) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_A003");  //검토 중   
        	} else if (state != null && state.equals("A004")) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_A004");  //승인처리중    	 
        	} else if (state != null && state.equals("S002")) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_S002");  // 결제완료        		
        	} else if (state != null && state.equals("R000") ) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_R000"); // 반려(검토자 검토 의견 송부)        		
        	} else if (state != null && state.equals("R001")) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_R001");  // 독립검토 리턴
        	} else if (state != null && state.equals("R002")) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_R002");  // 검토요청 리턴
        	} else if (state != null && state.equals("R003")) {
        		thisStateName = prop_state.getProperty("CAL_THISSTATE_R003");  // 승인요청 리턴
        	}
//        	System.out.println(state+"::thisStateName::"+thisStateName);
        	return thisStateName;
        }
        
        public String nextStateName (String state){
        	 
        	String nextStateName =prop_state.getProperty("CAL_NEXTSTATE_R") ;  // 저장됨 (독립검토요청)
        	if (state != null &&  ( state.equals("R") )) { // 저장됨 (독립검토요청)
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_R"); 
        	} else if (state != null && state.equals("A002") ) {  // 독립검토중(검토요청)
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_A002");          	 
        	} else if (state != null && (state.equals("A003")   ) ) {  // 검토중(승인요청)
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_A003"); 
        	} else if (state != null && state.equals("A004")) { // 승인중 ( 완료요청)
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_A004");   
        	} else if (state != null && state.equals("R000")) { // return
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_R000");   
        	} else if (state != null && state.equals("R001")) {// return
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_R001");   
        	} else if (state != null && state.equals("R002")) { // return
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_R002");   
        	} else if (state != null && state.equals("R003")) { // return
        		nextStateName = prop_state.getProperty("CAL_NEXTSTATE_R003");   
        	}else if (state != null && state.equals("S002")) { // 저장됨(completed)
        		nextStateName ="";
        		//nextStateName = prop_state.getProperty("CAL_NEXTSTATE_S002");  //Completed 
        	}
        	return nextStateName;
        }
        
        public String nextStateCode (String state){
       	 
        	String nextStateCode = "";
        	if (state != null && ( state.equals("R") || state.equals("R000")  || state.equals("R001")  ) ) {
        		nextStateCode = "A002";  //기본정보 저장
        	} else if (state != null && state.equals("A002") || state.equals("R002") || state.equals("R003") ) {
        		nextStateCode = "A003"; // 기본정보 저장
        	} else if (state != null && state.equals("A003") ) {
        		nextStateCode = "A004";  //독립검토
        	} else if (state != null && state.equals("A004") ) { 
        		nextStateCode = "S002"; // 작성자 검토
        	}  
//        	System.out.println(state+"::nextStateName::"+nextStateName);
        	return nextStateCode;
        }
        
        public String preStateCode (String state){
          	 
        	String preStateCode = "";
        	if (state != null && ( state.equals("A002") ) ){
        		preStateCode = "R001";  
        	} else if (state != null && state.equals("A003") ) {
        		preStateCode = "R002";   
        	} else if (state != null && state.equals("A004") ) {
        		preStateCode = "R003";   
        	} else if (  state.equals("R002")|| state.equals("R003")   ) {
        		preStateCode = "R001"; 
        	} else if (  state.equals("S002") ) {
        		preStateCode = "R000"; 
        	}  
//        	System.out.println(state+"::nextStateName::"+nextStateName);
        	return preStateCode;
        }
        
        
        
        @RequestMapping(value="/calHistory/list.do")
	    public String selectHisotryList(String calnoteId, String ctype , Integer curPage,String searchFild,  String searchWord, Model model)
	            throws Exception {
	    	if (calnoteId == "" || calnoteId==null){
	    		return "redirect:/calNote/calNoteList.do";
	    	}
	    	if (curPage == null) curPage = 1;
			if (searchWord == null) searchWord = "";
			if (searchFild == null) searchFild = "";
			if (ctype == null) ctype = "A";  //A = calnote , T = trReport
	 
//			int numPerPage = com.withus.commons.WebContants.NUMPERPAGE;
//			int pagePerBlock = com.withus.commons.WebContants.PAGEPERBLOCK;
			
			int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
			int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
			
			int totalRecord = calHistoryService.selectCalHistoryListTotCnt(calnoteId, ctype, searchFild, searchWord);
			PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
	 	
			page.setPagingHelper(pagingHelper);
			int start = pagingHelper.getStartRecord();
			int end = pagingHelper.getEndRecord();
			
			Integer prevLink = page.getPrevLink();
			Integer nextLink = page.getNextLink();
			Integer firstPage = page.getFirstPage();
			Integer lastPage = page.getLastPage();
			int[] pageLinks = page.getPageLinks();  
			
	        ArrayList<?> calHistoryList = calHistoryService.selectCalHistoryList(calnoteId, ctype, searchFild, searchWord, start, end);
	        model.addAttribute("resultList", calHistoryList);
	        
	        model.addAttribute("totalRecord", totalRecord);
	        model.addAttribute("prevLink", prevLink);
			model.addAttribute("nextLink", nextLink);
			model.addAttribute("firstPage", firstPage);
			model.addAttribute("lastPage", lastPage);
			model.addAttribute("pageLinks", pageLinks);
			model.addAttribute("curPage", curPage); 
			
			
			if (calnoteId == null) calnoteId="";
	    	/*if (flag == null) return null;*/ 
			
			CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
			 
			model.addAttribute("thisVo", calnoteVo);
			model.addAttribute("stateName", this.thisStateName(calnoteVo.getState()));
			model.addAttribute("nextState", this.nextStateName(calnoteVo.getState()));
			model.addAttribute("nextStateCode", this.nextStateCode(calnoteVo.getState()));
			model.addAttribute("preStateCode", this.preStateCode(calnoteVo.getState()));
	        
	        return "/calHistory/list";
	    }
	  
        
        @RequestMapping(value="/calHistory/listAll.do")
	    public String selectHistoryListAll(String calnoteId, String ctype, Model model)
	            throws Exception {
  
	    	if (calnoteId == "" || calnoteId==null){
	    		return "redirect:/calNote/calNoteList.do";
	    	}
	    	if (ctype == null) ctype = "A";  //A = calnote , T = trReport

	        ArrayList<?> calHistoryList = calHistoryService.selectCalHistoryListAll(calnoteId, ctype);
	        model.addAttribute("resultList", calHistoryList);
 
	       
	        return "/calHistory/listAll";
	    }
	   
	  
        
        @RequestMapping(value = "/calNote/panding_cal.do", method={RequestMethod.GET, RequestMethod.POST})
        public String panding_calList( Integer curPage, String searchFild,  String searchWord,
        		String sortField, String sortOrder,
        		Model model, Integer pagelimit ) throws Exception  {    	
             
        	if (curPage == null) curPage = 1;
    		if (searchFild == null) searchFild = ""; 
    		if (searchWord == null) searchWord = ""; 
    		if (sortField == null) sortField = ""; 
    		if (sortOrder == null) sortOrder = ""; 
    		
    		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
    		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
    		int totalRecord = calnoteService.pandingListTotCnt(searchFild, searchWord );
    		
    		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
    		
    		
    		page.setPagingHelper(pagingHelper);
    		int start = pagingHelper.getStartRecord();
    		int end = pagingHelper.getEndRecord();
    		
    		ArrayList<?> calnoteList = calnoteService.pandingList(  start,  end,  searchFild, searchWord,  sortField,  sortOrder );
 
    		Integer prevLink = page.getPrevLink();
    		Integer nextLink = page.getNextLink();
    		Integer firstPage = page.getFirstPage();
    		Integer lastPage = page.getLastPage();
    		int[] pageLinks = page.getPageLinks();
    		 
    		model.addAttribute("prevLink", prevLink);
    		model.addAttribute("nextLink", nextLink);
    		model.addAttribute("firstPage", firstPage);
    		model.addAttribute("lastPage", lastPage);
    		model.addAttribute("pageLinks", pageLinks);
    		model.addAttribute("curPage", curPage); 
    		model.addAttribute("totalRecord", totalRecord); 
    		model.addAttribute("sortField", sortField); 
    		model.addAttribute("sortOrder", sortOrder); 
    		model.addAttribute("searchFild", searchFild); 
    		model.addAttribute("searchWord", searchWord); 
    		
            model.addAttribute("resultList", calnoteList);
        
        	return "/myWork/panding_cal";
       } 
        
        
        @RequestMapping(value = "/calNote/processed_cal.do", method={RequestMethod.GET, RequestMethod.POST})
        public String prossed_calList( Integer curPage, String searchFild,  String searchWord,
        		String sortField, String sortOrder,
        		Model model, Integer pagelimit ) throws Exception  {    	
             
        	if (curPage == null) curPage = 1;
        	if (searchFild == null) searchFild = ""; 
    		if (searchWord == null) searchWord = ""; 
    		if (sortField == null) sortField = ""; 
    		if (sortOrder == null) sortOrder = ""; 
    		
    		int numPerPage = Integer.parseInt(prop.getProperty("NUMPERPAGE").trim());
    		int pagePerBlock =Integer.parseInt(prop.getProperty("PAGEPERBLOCK").trim());
    		int totalRecord = calnoteService.processedListTotCnt(searchFild, searchWord );
    		
    		PagingHelper pagingHelper = new PagingHelper(totalRecord, curPage, numPerPage, pagePerBlock); 
    		
    		
    		page.setPagingHelper(pagingHelper);
    		int start = pagingHelper.getStartRecord();
    		int end = pagingHelper.getEndRecord();
    		
    		ArrayList<?> calnoteList = calnoteService.processedList(  start,  end,  searchFild, searchWord,  sortField,  sortOrder );
 
    		Integer prevLink = page.getPrevLink();
    		Integer nextLink = page.getNextLink();
    		Integer firstPage = page.getFirstPage();
    		Integer lastPage = page.getLastPage();
    		int[] pageLinks = page.getPageLinks();
    		 
    		model.addAttribute("prevLink", prevLink);
    		model.addAttribute("nextLink", nextLink);
    		model.addAttribute("firstPage", firstPage);
    		model.addAttribute("lastPage", lastPage);
    		model.addAttribute("pageLinks", pageLinks);
    		model.addAttribute("curPage", curPage); 
    		model.addAttribute("totalRecord", totalRecord); 
    		model.addAttribute("sortField", sortField); 
    		model.addAttribute("sortOrder", sortOrder); 
    		model.addAttribute("searchFild", searchFild); 
    		model.addAttribute("searchWord", searchWord); 
            model.addAttribute("resultList", calnoteList);
        
        	return "/myWork/processed_cal";
       } 
        
        @RequestMapping(value="/calNote/calnoteCheck.do", method={RequestMethod.GET, RequestMethod.POST})
        public @ResponseBody Map<?,?> auto(String calnoteId) throws Exception {
           
    		Map< String, Object> map = new HashMap< String, Object>();
    		CalnoteUpdateVO thisUpVo = calnoteService.getCalnoteUpdateVo(calnoteId);
    		if(thisUpVo == null){
    			return null;
    		}else{
    		map.put("data",thisUpVo);
    		   return map;
    		}
        }
        
        
        @RequestMapping(value = "/calNote/pdfCreate.do")
        public String pdfCreate(HttpServletRequest req, ModelMap modelMap,String calnoteId,Model model) throws Exception {
          CalnoteVO calnoteVo = calnoteService.getCalnote(calnoteId);
          List<JFileDetails> jfileVo = jfileService.getAttachFiles(calnoteVo.getJfile());
          MemberVo independentVo = memberService.memberInfo(calnoteVo.getIndependent());
          MemberVo reviewerVo = memberService.memberInfo(calnoteVo.getReviewer());
          MemberVo approverVo = memberService.memberInfo(calnoteVo.getApprover());
        
          List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
          JFileVO jdVo = (JFileVO) jfileDivision.get(0);
          JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
          
          
          model.addAttribute("downloadFile", downloadFile);
          model.addAttribute("calnoteVo", calnoteVo);
          model.addAttribute("jfileVo", jfileVo);
          model.addAttribute("independentVo", independentVo);
          model.addAttribute("reviewerVo", reviewerVo);
          model.addAttribute("approverVo", approverVo);
          return "calNotePdfController";
        }
        
        @RequestMapping(value = "/calNote/completedPDF.do")
        public void completedPDF(CalnoteVO calnoteVo) throws Exception {
        	String savePath = JProperties.getString("system.pdfCombine");
        	 File pdfFile = new File(savePath+"/"+calnoteVo.getCalnoteId()+".pdf");
             Desktop.getDesktop ().open(pdfFile);
        }
        
        
        @RequestMapping(value = "/calNote/pdfAbsorption.do")
        public View pdfAbsorption(CalnoteVO calnoteVo, Model model) throws Exception {
        	   
            XStream xst = xstreamMarshaller.getXStream();
            xst.alias("result", XmlResult.class);  
            XmlResult xml = new XmlResult();  
            
        	List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
          	 JFileVO jdVo = (JFileVO) jfileDivision.get(0);
          	 JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
          	 String calnotePath = JProperties.getString("system.calnote");
          	 String downPath = downloadFile.toString();
//          	 String calnoteRevPath = JProperties.getString("system.calnoteRev");
          	 String calnoteFeedbackPath = JProperties.getString("system.calnoteFeedback");                       
          	 String calnoteEndPath = JProperties.getString("system.calnoteEnd");
          	 String calnoteCheckListPath = JProperties.getString("system.pdfCheckList");
          	 
          	String savePath = JProperties.getString("system.pdfCombine");
          	File savePathFile = new File(savePath);
           if (!savePathFile.exists()){
        	   savePathFile.mkdirs();
           }
           
          	File feedbackFile = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
          	File checkListFile = new File(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
          	
             PdfReader reader1 = new PdfReader(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
          	 PdfReader reader2 = new PdfReader(downPath);
          	 PdfReader reader5 = new PdfReader(calnoteEndPath+"/"+calnoteVo.getCalnoteId()+".pdf");
          	 
          	 PdfCopyFields copy = new PdfCopyFields(new FileOutputStream(savePath+"/"+calnoteVo.getCalnoteId()+".pdf"));
          	 
          	 boolean isExistFeedbackFile = feedbackFile.exists();
             boolean isExistCheckListFile = checkListFile.exists();
          	 if(isExistFeedbackFile && isExistCheckListFile ){
          		 PdfReader reader3 = new PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
              	 PdfReader reader4 = new PdfReader(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
          		 copy.addDocument(reader1);
             	 copy.addDocument(reader2);
          		 copy.addDocument(reader3);  
          		 copy.addDocument(reader4);  
          		 copy.addDocument(reader5);
          	 }else if(isExistFeedbackFile){
          		 PdfReader reader3 = new PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
          		 copy.addDocument(reader1);
            	copy.addDocument(reader2);
            	copy.addDocument(reader3);  
            	copy.addDocument(reader5);
          	 }else if(isExistCheckListFile){
          		 PdfReader reader4 = new PdfReader(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
          		 copy.addDocument(reader1);
            	 copy.addDocument(reader2);
            	 copy.addDocument(reader4);
            	 copy.addDocument(reader5);
          	 }
          	 else{
          		 copy.addDocument(reader1);
            	 copy.addDocument(reader2);
            	 copy.addDocument(reader5);
          	 }
          	 /*File pdfFile = new File(savePath+"/"+calnoteVo.getCalnoteId()+".pdf");
            Desktop .getDesktop ().open(pdfFile);*/
//          	 PdfReader reader3 = new PdfReader(calnoteRevPath+"/"+calnoteVo.getCalnoteId()+".pdf");
          	 
          	 /*PdfCopyFields copy = new PdfCopyFields(new FileOutputStream("C://sts_work//2017_sts//iCan_2017//src//main//webapp//pdf//calnote//"+calnoteVo.getCalnoteId()+".pdf"));*/
          	 copy.close();
        	 File pdfFile = new File(savePath+"/"+calnoteVo.getCalnoteId()+".pdf");
             Desktop .getDesktop ().open(pdfFile);
             
             model.addAttribute("xmlData", xml);
             
             return xmlView; 
        }
        
        
        @RequestMapping(value = "/calNote/pdfCombine.do")
        public View pdfCombine(CalnoteVO calnoteVo, Model model) throws Exception {
        	 XStream xst = xstreamMarshaller.getXStream();
             xst.alias("result", XmlResult.class);  
             XmlResult xml = new XmlResult();  
             
         List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
       	 JFileVO jdVo = (JFileVO) jfileDivision.get(0);
       	 JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
       	 String calnotePath = JProperties.getString("system.calnote");
       	 String downPath = downloadFile.toString();
//       	 String calnoteRevPath = JProperties.getString("system.calnoteRev");
       	 String calnoteFeedbackPath = JProperties.getString("system.calnoteFeedback");                       
       	 String calnoteEndPath = JProperties.getString("system.calnoteEnd");
       	String savePath = JProperties.getString("system.pdfCombine");
       	File savePathFile = new File(savePath);
        if (!savePathFile.exists())
        	savePathFile.mkdirs();
       	File file = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
       	  
       	 PdfReader reader1 = new PdfReader(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
       	 PdfReader reader2 = new PdfReader(downPath);
       	 PdfReader reader4 = new PdfReader(calnoteEndPath+"/"+calnoteVo.getCalnoteId()+".pdf");
       	 
       	 PdfCopyFields copy = new PdfCopyFields(new FileOutputStream(savePath+"/"+calnoteVo.getCalnoteId()+".pdf"));
       	 try{
       	 boolean isExists = file.exists();
       	 if(isExists){
       		 PdfReader reader3 = new PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
       		 copy.addDocument(reader1);
          	 copy.addDocument(reader2);
       		 copy.addDocument(reader3);  
       		 copy.addDocument(reader4);
       	 }else{
       		 copy.addDocument(reader1);
         	 copy.addDocument(reader2);
         	 copy.addDocument(reader4);
       	 }
       	 /*File pdfFile = new File(savePath+"/"+calnoteVo.getCalnoteId()+".pdf");
         Desktop .getDesktop ().open(pdfFile);*/
//       	 PdfReader reader3 = new PdfReader(calnoteRevPath+"/"+calnoteVo.getCalnoteId()+".pdf");
       	 
       	 /*PdfCopyFields copy = new PdfCopyFields(new FileOutputStream("C://sts_work//2017_sts//iCan_2017//src//main//webapp//pdf//calnote//"+calnoteVo.getCalnoteId()+".pdf"));*/
       	 copy.close();
       	 }catch (Exception e){
       		 System.out.println(e);
       	 }finally{
       		 copy.close();
       	 }
       	 
         model.addAttribute("xmlData", xml);
         
         return xmlView; 
         
        }
        
        
        @RequestMapping(value = "/calNote/feedbackPageCheck.do")  // feedback  페이징 읽어와서 몇페이지 인지 업데이트
        public View feedbackPageCheck(CalnoteVO calnoteVo, Model model) throws Exception {
          
        	 XStream xst = xstreamMarshaller.getXStream();
             xst.alias("result", XmlResult.class);  
             XmlResult xml = new XmlResult();  
             
        	String calnoteFeedbackPath = JProperties.getString("system.calnoteFeedback");
            File feedbackFile = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
            boolean isExistFeedbackFile = feedbackFile.exists();
            int realTotalPageNum = 0;
             if(isExistFeedbackFile){
            	
            com.itextpdf.text.pdf.PdfReader realPageReader = new com.itextpdf.text.pdf.PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
           
            try{
	            int realTotalPage = realPageReader.getNumberOfPages();	           
	            for(int i = 1; i<= realTotalPage; i++) {
	                realTotalPageNum = i;
	            }
	            realPageReader.close();
        	}catch (Exception e) {    	       	 
    			 System.out.println(e);
    			     
    		}finally{
    			realPageReader.close();
    		}
           
            calnoteVo.setRealTotalPage(realTotalPageNum);
 
            calnoteService.updateCalnote(calnoteVo);
            }
           
             xml.setMessage(realTotalPageNum+"");
    	     xml.setError(true);
    	        
             model.addAttribute("xmlData", xml);
             
             return xmlView; 
        }
        
        
        @RequestMapping(value = "/calNote/pdfFileDelete.do")
        public View pdfFileDelete( Model model,CalnoteVO calnoteVo ) throws Exception {
        	/*File file = new File("c://Example//File//existFile.txt");
        	boolean isExists = file.exists();
        	if(isExists){
        		
        	} */
        	/*List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
        	 JFileVO jdVo = (JFileVO) jfileDivision.get(0);
        	 JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
        	 String downPath = downloadFile.toString();
        	 */
        	
        	 XStream xst = xstreamMarshaller.getXStream();
             xst.alias("result", XmlResult.class);  
             XmlResult xml = new XmlResult();  
        	
        	List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
         	 JFileVO jdVo = (JFileVO) jfileDivision.get(0);
         	 JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
         	 String calnotePath = JProperties.getString("system.calnote");
         	 String downPath = downloadFile.toString();
//         	 String calnoteRevPath = JProperties.getString("system.calnoteRev");
         	 String calnoteFeedbackPath = JProperties.getString("system.calnoteFeedback");                       
         	 String calnoteEndPath = JProperties.getString("system.calnoteEnd");
         	String savePath = JProperties.getString("system.pdfCombine");
         	String calnoteCheckListPath = JProperties.getString("system.pdfCheckList");
         	
         	File savePathFile = new File(savePath);
	          if (!savePathFile.exists()){
	       	   savePathFile.mkdirs();
	          }
         	File feedbackFile = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	File checkListFile = new File(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	
            PdfReader reader1 = new PdfReader(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	 PdfReader reader2 = new PdfReader(downPath);
         	 PdfReader reader5 = new PdfReader(calnoteEndPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	 
         	 PdfCopyFields copy = new PdfCopyFields(new FileOutputStream(savePath+"/"+calnoteVo.getCalnoteId()+".pdf"));
         	 
         	 boolean isExistFeedbackFile = feedbackFile.exists();
            boolean isExistCheckListFile = checkListFile.exists();
         	 if(isExistFeedbackFile && isExistCheckListFile ){
         		 PdfReader reader3 = new PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
             	 PdfReader reader4 = new PdfReader(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         		 copy.addDocument(reader1);
            	 copy.addDocument(reader2);
         		 copy.addDocument(reader3);  
         		 copy.addDocument(reader4);  
         		 copy.addDocument(reader5);
         	 }else if(isExistFeedbackFile){
         		 PdfReader reader3 = new PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         		 copy.addDocument(reader1);
           	copy.addDocument(reader2);
           	copy.addDocument(reader3);  
           	copy.addDocument(reader5);
         	 }else if(isExistCheckListFile){
         		 PdfReader reader4 = new PdfReader(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         		 copy.addDocument(reader1);
           	 copy.addDocument(reader2);
           	 copy.addDocument(reader4);
           	 copy.addDocument(reader5);
         	 }
         	 else{
         		 copy.addDocument(reader1);
           	 copy.addDocument(reader2);
           	 copy.addDocument(reader5);
         	 }
         	 copy.close();
        	
        	 File calnoteFile = new File(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 File calnoteFeedbackFile = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 File calnoteCheckListFile = new File(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 File calnoteEndFile = new File(calnoteEndPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 calnoteFile.delete();
        	 calnoteFeedbackFile.delete();
        	 calnoteCheckListFile.delete();
        	 calnoteEndFile.delete();          
                        
             File pdfFile = new File(savePath+"/"+calnoteVo.getCalnoteId()+".pdf");
             Desktop .getDesktop ().open(pdfFile);
             
             model.addAttribute("xmlData", xml);
             
             return xmlView; 
        }
        
        
        
        @RequestMapping(value = "/calNote/pdfCompleted.do")
        public String pdfCompleted(HttpServletRequest req, ModelMap modelMap,CalnoteVO calnoteVo,Model model) throws Exception {
        	
        	File file = new File("c://Example//File//existFile.txt");
        	boolean isExists = file.exists();
        	if(isExists){
        		
        	} 
        	
        	List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
        	 JFileVO jdVo = (JFileVO) jfileDivision.get(0);
        	 JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
        	 String calnotePath = JProperties.getString("system.calnote");
        	 String downPath = downloadFile.toString();
        	 String calnoteRevPath = JProperties.getString("system.calnoteRev");
        	 String calnoteEndPath = JProperties.getString("system.calnoteEnd");
        	 
        	 
        	 PdfReader reader1 = new PdfReader(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 PdfReader reader2 = new PdfReader(downPath);
        	 PdfReader reader3 = new PdfReader(calnoteRevPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 PdfReader reader4 = new PdfReader(calnoteEndPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 PdfCopyFields copy = new PdfCopyFields(new FileOutputStream("D://report//"+calnoteVo.getCalnoteId()+".pdf"));
        	 copy.addDocument(reader1);
        	 copy.addDocument(reader2);
        	 copy.addDocument(reader3);  
        	 copy.addDocument(reader4);
        	 copy.close();
        	 model.addAttribute("calnoteVo", calnoteVo); 
        	 
          return "CalnotePdfCreateController";
        }  
        
	    
        public void pdfFileDelete( CalnoteVO calnoteVo) throws Exception {
        	/*File file = new File("c://Example//File//existFile.txt");
        	boolean isExists = file.exists();
        	if(isExists){
        		
        	} */
        	/*List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
        	 JFileVO jdVo = (JFileVO) jfileDivision.get(0);
        	 JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
        	 String downPath = downloadFile.toString();
        	 */
        	
        	List<JFileDetails> jfileDivision = jfileService.getAttachFiles(calnoteVo.getJfile(), "C");
         	 JFileVO jdVo = (JFileVO) jfileDivision.get(0);
         	 JFile downloadFile = jfileService.getFile(jdVo.getFileId(), jdVo.getFileSeq(), jdVo.getUseSecurity());
         	 String calnotePath = JProperties.getString("system.calnote");
         	 String downPath = downloadFile.toString();
//         	 String calnoteRevPath = JProperties.getString("system.calnoteRev");
         	 String calnoteFeedbackPath = JProperties.getString("system.calnoteFeedback");                       
         	 String calnoteEndPath = JProperties.getString("system.calnoteEnd");
         	String savePath = JProperties.getString("system.pdfCombine");
         	String calnoteCheckListPath = JProperties.getString("system.pdfCheckList");
         	
         	File savePathFile = new File(savePath);
	          if (!savePathFile.exists()){
	       	   savePathFile.mkdirs();
	          }
         	File feedbackFile = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	File checkListFile = new File(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	
            PdfReader reader1 = new PdfReader(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	 PdfReader reader2 = new PdfReader(downPath);
         	 PdfReader reader5 = new PdfReader(calnoteEndPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         	 
         	 PdfCopyFields copy = new PdfCopyFields(new FileOutputStream(savePath+"/"+calnoteVo.getCalnoteId()+".pdf"));
         	 
         	 boolean isExistFeedbackFile = feedbackFile.exists();
            boolean isExistCheckListFile = checkListFile.exists();
         	 if(isExistFeedbackFile && isExistCheckListFile ){
         		 PdfReader reader3 = new PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
             	 PdfReader reader4 = new PdfReader(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         		 copy.addDocument(reader1);
            	 copy.addDocument(reader2);
         		 copy.addDocument(reader3);  
         		 copy.addDocument(reader4);  
         		 copy.addDocument(reader5);
         	 }else if(isExistFeedbackFile){
         		 PdfReader reader3 = new PdfReader(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         		 copy.addDocument(reader1);
           	copy.addDocument(reader2);
           	copy.addDocument(reader3);  
           	copy.addDocument(reader5);
         	 }else if(isExistCheckListFile){
         		 PdfReader reader4 = new PdfReader(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
         		 copy.addDocument(reader1);
           	 copy.addDocument(reader2);
           	 copy.addDocument(reader4);
           	 copy.addDocument(reader5);
         	 }
         	 else{
         		 copy.addDocument(reader1);
           	 copy.addDocument(reader2);
           	 copy.addDocument(reader5);
         	 }
         	 copy.close();
        	
        	 File calnoteFile = new File(calnotePath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 File calnoteFeedbackFile = new File(calnoteFeedbackPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 File calnoteCheckListFile = new File(calnoteCheckListPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 File calnoteEndFile = new File(calnoteEndPath+"/"+calnoteVo.getCalnoteId()+".pdf");
        	 calnoteFile.delete();
        	 calnoteFeedbackFile.delete();
        	 calnoteCheckListFile.delete();
        	 calnoteEndFile.delete();          
                        
             File pdfFile = new File(savePath+"/"+calnoteVo.getCalnoteId()+".pdf");
             Desktop .getDesktop ().open(pdfFile);
        }
        
        
}

 