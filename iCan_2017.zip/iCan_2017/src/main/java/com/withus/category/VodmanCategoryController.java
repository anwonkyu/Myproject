package com.withus.category;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.oxm.xstream.XStreamMarshaller;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
 







import org.springframework.web.servlet.View;

import com.thoughtworks.xstream.XStream;
import com.withus.category.service.CategoryService;
 
import com.withus.category.dao.CategoryVO;
import com.withus.commons.XmlResult;

/**
 * @Class Name : CategoryController.java
 * @Description : Category Controller class
 * @Modification Information
 *
 * @author joohyun
 * @since 2011-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */

@Controller
@RequestMapping("/vodman")
public class VodmanCategoryController {

	
	@Resource(name = "xstreamMarshaller")
	private XStreamMarshaller xstreamMarshaller;
    @Resource(name = "xmlView")
    private View xmlView;
    
    @Resource(name = "categoryService")
    private CategoryService categoryService;
 
    /**
	 * category 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 CategoryDefaultVO
	 * @return "/category/CategoryList"
	 * @exception Exception
	 */
    
 
	    @RequestMapping(value="/category/list.do")
	    public String selectCategoryList(String ccode,String ctype, ModelMap model)
	            throws Exception { 
	    	   ArrayList<CategoryVO> cateList = categoryService.selectCategoryList(ccode, ctype);
	           model.addAttribute("resultList", cateList); 
	           
	           return "/category/list";
	    }
	 
    @RequestMapping(value="/category/listAll.do")
    public String selectCategoryListAll(String ccode,String ctype, ModelMap model)
            throws Exception { 
 
		if (ccode == null) ccode = ""; 
		if (ctype == null) ctype = "V"; 
		
    	   List<CategoryVO> cateList1 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "A") != null) {
    		   cateList1 = categoryService.selectCategoryList_cinfo(ccode, ctype, "A");
    	   } 
    	   List<CategoryVO> cateList2 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "B") != null) {
    		   cateList2 = categoryService.selectCategoryList_cinfo(ccode, ctype, "B");
    	   }
    	   List<CategoryVO> cateList3 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "C") != null) {
    		   cateList3 = categoryService.selectCategoryList_cinfo(ccode, ctype, "C");
    	   }
    	   List<CategoryVO> cateList4 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "D") != null) {
    		   cateList4 = categoryService.selectCategoryList_cinfo(ccode, ctype, "D");
    	   } 
    	   
    	   HashMap<String, Object> hashMap = new HashMap<String, Object>();
    	   
    	   hashMap.put("cateList1", cateList1);
    	   hashMap.put("cateList2", cateList2);
    	   hashMap.put("cateList3", cateList3);
    	   hashMap.put("cateList4", cateList4);
    	   
           model.addAttribute("cateListAll", hashMap); 
           
           return "/vodman/category/listAll";
    }
    
    @RequestMapping(value="/category/write.do" , method=RequestMethod.GET)
    public String addCategoryView(String ccode, String ctype, Model model)
            throws Exception {
    	 
        model.addAttribute("ccode", ccode);
        model.addAttribute("ctype", ctype);
        return "/vodman/category/addForm";
    }
    
    @RequestMapping(value="/category/write.do" , method=RequestMethod.POST)
    public String addCategory( @ModelAttribute("categoryVO") CategoryVO categoryVO )
            throws Exception {
    	
        categoryService.insertCategory(categoryVO);
        
        return "redirect:/vodman/category/listAll.do?ctype="+categoryVO.getCtype();
    }
    
 
    @RequestMapping(value="/category/update.do" , method=RequestMethod.GET)
    public String updateCategoryView(
            @RequestParam(value="cuid",required=true)  int cuid , Model model)
            throws Exception {
        CategoryVO categoryVO = categoryService.selectCategory(cuid);
        model.addAttribute("categoryVO", categoryVO);
       
        return "/vodman/category/addForm";
    }
 

    @RequestMapping(value="/category/update.do" , method=RequestMethod.POST)
    public String updateCategory(
    		 @ModelAttribute("categoryVO") CategoryVO categoryVO )
            throws Exception {
        categoryService.updateCategory(categoryVO); 
        //return "forward:/category/list.do";
        return "redirect:/vodman/category/listAll.do?ctype="+categoryVO.getCtype();
    } 
    
	 @RequestMapping(value="/category/delete.do", method=RequestMethod.POST)
		public View update(@RequestParam(value="cuid",required=true)Integer cuid, Model model )  throws Exception {
			   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     if (cuid != null && categoryService.deleteCategory(cuid) > 0) {
				        xml.setMessage("삭제되었습니다.");
				        xml.setError(true);
			       
			    } else {
			    	xml.setMessage("삭제에 실패하였습니다.");
			 	    xml.setError(false);
			    }

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
    
    @RequestMapping(value="/category/selectbox.do", method={RequestMethod.GET, RequestMethod.POST})
    public @ResponseBody Map<?,?> auto(String ccode, String ctype, String cinfo ) throws Exception {
       
      	if (ccode == null) ccode = ""; 
		if (ctype == null) ctype = "V"; 
		if (cinfo == null) cinfo = "A"; 
		  
		Map< String, Object> map = new HashMap< String, Object>();
	 
		map.put("data",categoryService.selectCategoryList_cinfo(ccode, ctype, cinfo));
		
		return map;
 
		
    }
 
    
    ////////////////////////
    
    @RequestMapping(value="/menu/list.do")
    public String selectCategoryMenuAll(String ccode,String ctype, ModelMap model)
            throws Exception { 
 
		if (ccode == null) ccode = ""; 
		if (ctype == null) ctype = "M"; 
		
    	   List<CategoryVO> cateList1 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "A") != null) {
    		   cateList1 = categoryService.selectCategoryList_cinfo(ccode, ctype, "A");
    	   } 
    	   List<CategoryVO> cateList2 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "B") != null) {
    		   cateList2 = categoryService.selectCategoryList_cinfo(ccode, ctype, "B");
    	   }
    	   List<CategoryVO> cateList3 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "C") != null) {
    		   cateList3 = categoryService.selectCategoryList_cinfo(ccode, ctype, "C");
    	   }
    	   List<CategoryVO> cateList4 = null;
    	   if ( categoryService.selectCategoryList_cinfo(ccode, ctype, "D") != null) {
    		   cateList4 = categoryService.selectCategoryList_cinfo(ccode, ctype, "D");
    	   } 
    	   
    	   HashMap<String, Object> hashMap = new HashMap<String, Object>();
    	   
    	   hashMap.put("cateList1", cateList1);
    	   hashMap.put("cateList2", cateList2);
    	   hashMap.put("cateList3", cateList3);
    	   hashMap.put("cateList4", cateList4);
    	   
           model.addAttribute("cateListAll", hashMap); 
           
           return "/vodman/menu/list";
    }
    
    @RequestMapping(value="/menu/write.do" , method=RequestMethod.GET)
    public String addCategoryMenuView(String ccode, String ctype, Model model)
            throws Exception {
    	 
        model.addAttribute("ccode", ccode);
        model.addAttribute("ctype", ctype);
        return "/vodman/menu/addForm";
    }
    
    @RequestMapping(value="/menu/write.do" , method=RequestMethod.POST)
    public String addMenuCategory( @ModelAttribute("categoryVO") CategoryVO categoryVO )
            throws Exception {
    	
        categoryService.insertCategory(categoryVO);
        
        return "redirect:/vodman/menu/list.do?ctype="+categoryVO.getCtype();
    }
    
 
    @RequestMapping(value="/menu/update.do" , method=RequestMethod.GET)
    public String updateCategoryMenuView(
            @RequestParam(value="cuid",required=true)  int cuid , Model model)
            throws Exception {
        CategoryVO categoryVO = categoryService.selectCategory(cuid);
        model.addAttribute("categoryVO", categoryVO);
       
        return "/vodman/menu/addForm";
    }
 

    @RequestMapping(value="/menu/update.do" , method=RequestMethod.POST)
    public String updateMenuCategory(
    		 @ModelAttribute("categoryVO") CategoryVO categoryVO )
            throws Exception {
        categoryService.updateCategory(categoryVO); 
        //return "forward:/category/list.do";
        return "redirect:/vodman/menu/list.do?ctype="+categoryVO.getCtype();
    } 
    
	 @RequestMapping(value="/menu/delete.do", method=RequestMethod.POST)
		public View updateMenu(@RequestParam(value="cuid",required=true)Integer cuid, Model model )  throws Exception {
			   
				XStream xst = xstreamMarshaller.getXStream();
		    	xst.alias("result", XmlResult.class);  
		        XmlResult xml = new XmlResult(); 
		        
			     if (cuid != null && categoryService.deleteCategory(cuid) > 0) {
				        xml.setMessage("삭제되었습니다.");
				        xml.setError(true);
			       
			    } else {
			    	xml.setMessage("삭제에 실패하였습니다.");
			 	    xml.setError(false);
			    }

		    model.addAttribute("xmlData", xml);
		    
		    return xmlView;
		    
		}
	 
	 //////////////////////////////
    

}
