package com.withus.commons;

 
import java.io.File; 
import java.io.IOException;
 
import java.util.HashMap;
import java.util.Iterator;
 
import java.util.regex.Pattern; 

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper; 

import org.owasp.esapi.ESAPI;
 
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.withus.commons.uploadFile.UploadUtil;

public class XSSMultipartRequestWrapper extends HttpServletRequestWrapper {

 
private static Pattern[] patterns = new Pattern[] {
	Pattern.compile("<script>(.*?)</script>",                       
	Pattern.CASE_INSENSITIVE),
	Pattern.compile("src[\r\n]*=[\r\n]*\\\'(.*?)\\\'",
	Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
	Pattern.compile("src[\r\n]*=[\r\n]*\\\"(.*?)\\\"",
	Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
	Pattern.compile("</script>", Pattern.CASE_INSENSITIVE),
	Pattern.compile("<script(.*?)>", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
	Pattern.compile("eval\\((.*?)\\)", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
	Pattern.compile("expression\\((.*?)\\)", 
	Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL),
	Pattern.compile("javascript:", Pattern.CASE_INSENSITIVE),
	Pattern.compile("vbscript:", Pattern.CASE_INSENSITIVE),
	Pattern.compile("onload(.*?)=", Pattern.CASE_INSENSITIVE | Pattern.MULTILINE | Pattern.DOTALL)
};



@SuppressWarnings("unchecked")
public XSSMultipartRequestWrapper(HttpServletRequest servletRequest) throws IOException{
	super(servletRequest);
            try {
            	if (servletRequest.getMethod().equalsIgnoreCase("POST") && servletRequest.getContentType().startsWith("multipart/form-data")){
            		HashMap<String, Object> params  = new HashMap<String, Object>(servletRequest.getParameterMap());
	            	MultipartHttpServletRequest mpRequest =  (MultipartHttpServletRequest)servletRequest;  //다중파일 업로드
	            	//System.out.println("path::::"+mpRequest.getContextPath());
	            	String BASE_PATH="d:/test/upload/";
	            	File dir = new File(BASE_PATH);
	        		
			    	if (!dir.isDirectory()) { 
			    		dir.mkdirs(); 
			    	}
			    	
	    			Iterator<String> it = mpRequest.getFileNames(); 
	 	
	    			while (it.hasNext()) {
	 				
						MultipartFile multiFile = mpRequest.getFile((String) it.next());
	 	
						if (multiFile.getSize() > 0 && com.withus.commons.TextUtil.isFileNameCheck(multiFile.getOriginalFilename()) && com.withus.commons.TextUtil.isFileCheck(multiFile.getContentType())) {
							String filename = UploadUtil.getUniqueFileName(multiFile.getOriginalFilename());
//							System.out.println("upload_file:"+filename);
							multiFile.transferTo(new File(BASE_PATH + filename));
							
							
							if (multiFile.getName() != null) {
//								System.out.println(multiFile.getName()+multiFile.getOriginalFilename());
								String[] oneParam = {filename};
		 		    			//params.put(multiFile.getName(), oneParam);
								params.put("_playLogo", oneParam );
							} 
						} 
	    			} 
            	}
            	super.setRequest(servletRequest);
 
      		} catch (Exception e) {
      			throw new IOException("file upload error: " + e.toString());
      		}
}

@Override
public String[] getParameterValues(String parameter) {
 
    String[] values = super.getParameterValues(parameter);
    if (values == null) {
        return null;
    }
    int count = values.length;
    String[] encodedValues = new String[count];
    for (int i = 0; i < count; i++) {
        encodedValues[i] = stripXSS(values[i]);
 
    }
    return encodedValues;
}

@Override
public String getParameter(String parameter) {
    String value = super.getParameter(parameter);
 
    return stripXSS(value);
}

@Override
public String getHeader(String name) {
    String value = super.getHeader(name);
    return stripXSS(value);
}

private String stripXSS(String value) {
   if (value != null) {

   // ESAPI library 이용하여 XSS 필터를 적용하려면 아래 코드의 커맨트
   // 를 제거하고 사용한다. 강력추천!!
    value = ESAPI.encoder().canonicalize(value);
    
    // null 문자를 제거한다.
    value = value.replaceAll("\0", "");

	// 패턴을 포함하는 입력에 대해 <, > 을 인코딩한다.
		for (Pattern scriptPattern : patterns) {
		   if ( scriptPattern.matcher(value).find() ) {
		
		      value=value.replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll("'","&#39;");   
		    }
		}  
    }
    return value;
  }
}