package com.withus.memo.service;

import java.util.ArrayList;
 


import org.springframework.transaction.annotation.Transactional;

import com.withus.memo.dao.ContentMemoVO;

/**
 * @Class Name : ContentMemoService.java
 * @Description : ContentMemo Business class
 * @Modification Information
 *
 * @author joohyun
 * @since 2014-11-10
 * @version 1.0
 * @see
 *  
 *  Copyright (C)  All right reserved.
 */
public interface ContentMemoService {
	
	/**
	 * content_memo을 등록한다.
	 * @param vo - 등록할 정보가 담긴 ContentMemoVO
	 * @return 등록 결과
	 * @exception Exception
	 */

    int insertContentMemo(ContentMemoVO vo) throws Exception;
    
    int replyContentMemo(ContentMemoVO vo) throws Exception;
    
    /**
	 * content_memo을 수정한다.
	 * @param vo - 수정할 정보가 담긴 ContentMemoVO
	 * @return void형
	 * @exception Exception
	 */
	
    int updateContentMemo(ContentMemoVO vo) throws Exception;
    
    /**
	 * content_memo을 삭제한다.
	 * @param vo - 삭제할 정보가 담긴 ContentMemoVO
	 * @return void형 
	 * @exception Exception
	 */

    int deleteContentMemo(ContentMemoVO vo) throws Exception;

    int deleteContentMemo_vodman(ContentMemoVO vo) throws Exception;
   
    int comment_check(ContentMemoVO vo) throws Exception;
    
    /**
	 * content_memo을 조회한다.
	 * @param vo - 조회할 정보가 담긴 ContentMemoVO
	 * @return 조회한 content_memo
	 * @exception Exception
	 */
    ContentMemoVO selectContentMemo(int muid) throws Exception;
    
    /**
	 * content_memo 목록을 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return content_memo 목록
	 * @exception Exception
	 */
    ArrayList<ContentMemoVO> selectContentMemoList(String calnoteId, String searchFild, String searchWord ,String state, int start, int end) throws Exception;
    
    /**
	 * content_memo 총 갯수를 조회한다.
	 * @param searchVO - 조회할 정보가 담긴 VO
	 * @return content_memo 총 갯수
	 * @exception
	 */
     
    int selectContentMemoListTotCnt(String calnoteId,  String searchFild, String searchWord,String state);
    
    ContentMemoVO selectContentMemoFlag(String calnoteId, String state) throws Exception;
    
    int updateContentMemoFlag(ContentMemoVO vo) throws Exception;

	ContentMemoVO codceComment_select(String calonteId, String state) throws Exception;
    
}
